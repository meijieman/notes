package com.zhiyi.xppay.hook.mayou;

/**
 * Created by pc_mg on 2019/4/10.
 */

import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class PrePayInfoProxy implements InvocationHandler {
    public static String QRCODERECEIVED_ACTION = "com.tools.payhelper.qrcodereceived";
    Context mContext;
    String money;
    String orderInfo;
    String receiveId;

    public PrePayInfoProxy(Context context, String orderInfo, String money, String receiveId) {
        this.mContext = context;
        this.orderInfo = orderInfo;
        this.money = money;
        this.receiveId = receiveId;
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String methodName = method.getName();
        XposedBridge.log("PrePayInfoProxy 调用的方法名称为:" + methodName);
        XposedBridge.log("PrePayInfoProxy 返回的类型为" + method.getReturnType().getName());
        if (methodName.equals("callback")) {
            try {
                ClassLoader loader = proxy.getClass().getClassLoader();
                byte[] bytes = (byte[]) args[0];
                if (bytes == null || bytes.length <= 0) {
                    return null;
                }
                XposedBridge.log("发起预付订单返回成功...");
                Object pp = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.aoetech.aoelailiao.core.proto.ProtoBufPacket", loader), "getProtoBufInputByte", new Object[]{bytes});
                Object userGrantAliEnvelopeInfoAns = XposedHelpers.callMethod(XposedHelpers.getStaticObjectField(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.UserGetPayOrderInfoAns", loader), "ADAPTER"), "decode", new Object[]{pp});
                String pay_order_info = (String) XposedHelpers.getObjectField(userGrantAliEnvelopeInfoAns, "pay_order_info");
                String pay_order_no = (String) XposedHelpers.getObjectField(userGrantAliEnvelopeInfoAns, "pay_order_no");
                XposedBridge.log("发起预付订单:pay_order_info=" + pay_order_info);
                XposedBridge.log("发起预付订单:pay_order_no=" + pay_order_no);
                Intent broadCastIntent = new Intent();
                broadCastIntent.putExtra("type", AppConst.TYPE_MY);
                broadCastIntent.putExtra("mark", this.orderInfo);//+ "_" + this.receiveId
                broadCastIntent.putExtra("money", this.money);
                broadCastIntent.putExtra("mayouOrderNo", pay_order_no);
                broadCastIntent.putExtra("img_url",pay_order_no);
                broadCastIntent.putExtra("mayouMark", this.orderInfo);
                broadCastIntent.putExtra("money", this.money);
                broadCastIntent.putExtra("payurl", pay_order_info);
                broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                this.mContext.sendBroadcast(broadCastIntent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
