package com.zhiyi.xppay.consts;

/**
 * Created by Administrator on 2018/11/7.
 */

public class AppConst {

    public static final String APP_DINGDING = "com.alibaba.android.rimet";
    public static final String APP_XGJ = "com.newland.satrpos.starposmanager";
    public static final String APP_TBH = "com.alibaba.mobileim";
    public static final String APP_SKB = "com.shoukb51.zhongm.app";
    public static final String APP_XXQG = "cn.xuexi.android";
    public static final String APP_MY = "com.aoetech.aoelailiao";
    public static final String APP_NXYS_HB = "com.buybal.buybalpay.nxy.fkepay";
    public static final String APP_NXYS_GT = "com.buybal.buybalpay.nxy.xtmsf";
    public static final String APP_NXFJSH = "cn.swiftpass.enterprise.v3.fjnx";
    public static final String APP_JYES = "com.hnnx.sh.mbank";
    public static final String APP_HYBSYT = "com.hybunion.shouyintai";
    public static final String APP_YZF = "com.softbank.flybank.rest.wshyvb";
    public static final String APP_FL = "com.feiliao.flipchat.android";
    public static final String APP_QNSHB = "com.gyBank";
    public static final String APP_WZP = "com.hkrt.com.kuairutong";
    public static final String APP_SB = "cn.lcsw.lcpay";
    public final static String WECHATSTART_ACTION = "com.zhiyi.xppay.wechat.start";
    public final static String ALIPAYSTART_ACTION = "com.zhiyi.xppay.alipay.start";
    public final static String QQSTART_ACTION = "com.zhiyi.xppay.qq.start";
    public final static String MSGRECEIVED_ACTION = "com.zhiyi.xppay.msgreceived";
    public final static String TRADENORECEIVED_ACTION = "com.zhiyi.xppay.tradenoreceived";
    public final static String LOGINIDRECEIVED_ACTION = "com.zhiyi.xppay.loginidreceived";
    public final static String DINGDING_ACTION = "com.zhiyi.xppay.dindingstart";
    public final static String TBH_ACTION = "com.zhiyi.xppay.tbstart";
    public final static String ALIPAYMBANK_ACTION = "com.zhiyi.xppay.alipay.mbank";
    public final static String ALIPAYPERSONALQRCODE_ACTION = "com.zhiyi.xppay.alipaypersonalqrcode";
    public final static String ALIPAY_GET_TRADE_ACTION = "com.zhiyi.xppay.alipay.gettradelist";
    public final static String TRADEDETAIL_ACTION = "com.zhiyi.xppay.alipay.gettradedetail";
    public final static String BILLRECEIVED_ACTION = "com.zhiyi.xppay.billreceived";
    public final static String ALIPAY_FRIEND_ORDER_ACTION = "com.zhiyi.xppay.alipay.creattrade";
    public final static String ALIPAY_FRIEND_CHECK_ACTION = "com.zhiyi.xppay.alipay.isfriend";
    public final static String HOOK_FRIEND_CHECK_ACTION = "com.zhiyi.xppay.hook.isfriend";
    public final static String HOOK_FRIEND_ORDER_ACTION = "com.zhiyi.xppay.hook.creattrade";
    public final static String HOOK_COMPAREORDER_ACTION = "com.zhiyi.xppay.hook.alipaycompareorder";
    public final static String ALIPAY_FIXED_POSITION = "com.zhiyi.xppay.alipay.fixedposition";
    /**
     *  收到订单消息
     */
    public final static String HOOK_BILL_RECEIVED = "com.zhiyi.xppay.hook.billreceived";
    public final static String HOOK_DianDianChong_TOKEN_ACTION = "com.zhiyi.xppay.hook.diandianchong.token";

    public final static String QRCODERECEIVED_ACTION = "com.zhiyi.xppay.qrcodereceived";
    public final static String NOTIFY_ACTION = "com.zhiyi.xppay.notify";
    public final static String NOT_LOGIN_ACTION = "com.zhiyi.xppay.notloginreceived";
    public final static String PERSONALQRCODE = "com.zhiyi.xppay.alipaypersonqrcode";

    public final static String CP_QRCODE = "com.zhiyi.xppay.cloundpayqrcode";
    public final static String CP_LOGIN = "com.zhiyi.xppay.cloundpaylogin";
    public final static String CP_GETPAYERLIST = "com.zhiyi.xppay.cloundpaygetpayerlist";
    public final static String CP_GETPAYER = "com.zhiyi.xppay.cloundpaygetpayer";
    public final static String CP_START = "com.zhiyi.xppay.cloundpaystart";
    //final
    public final static String LKL_QRCODE = "com.zhiyi.xppay.lakalaqrcode";
    public final static String LKL_START = "com.zhiyi.xppay.lakalastart";
    public final static String LKL_TRADELIST = "com.zhiyi.xppay.tradelist";
    //final
    public final static String MBANK_SERVICE = "com.zhiyi.xppay.mabnkservice";
    public final static String TYPE_ALIPAY = "ALIPAY";
    public final static String TYPE_ALIPAY_B = "ALIPAYB";
    public final static String TYPE_WXPAY = "WXPAY";
    public final static String TYPE_QQPAY = "QQPAY";
    public final static String TYPE_CPPAY = "CPPAY";
    public final static String TYPE_LKLPAY = "LKLPAY";
    public final static String TYPE_BANK = "BANK";
    public final static String TYPE_DingDing = "DING";
    public final static String TYPE_XiangLiao = "IXL";
    public final static String TYPE_APP = "APP";
    public final static String TYPE_DIANDIANCHONG = "DDCHONG";
    public final static String TYPE_TBH = "TBH";
    public final static String TYPE_SKB = "SKB";
    public final static String TYPE_XXQG = "XXQG";
    public final static String TYPE_LONGPAY = "WXPAY_LEF";
    public final static String TYPE_ZHIPAY = "WXPAY_ZEF";
    public final static String TYPE_LONGPAYSMS = "LEFSMS";
    public final static String TYPE_MY = "MY";
    public final static String TYPE_XX = "XX";// 小信
    public final static String TYPE_NXFJSH = "NXFJSH";
    public final static String TYPE_JYES = "JYES";// 金燕E商
    public static final String TYPE_HYBSYT = "HYBSYT";
    public static final String TYPE_YZF = "YZF";
    public static final String TYPE_FL = "FL";
    public static final String TYPE_WL = "WL";
    public static final String TYPE_QNSHB = "qnshb";
    public static final String TYPE_WZP = "WZP";
    public static final String TYPE_QN = "QN";
    public static final String TYPE_SB = "SB";
    public final static String ACTION_BUILD_QRCODE = "A_BUILD_QRCODE";

    // 银行卡通知  0 支付宝 1短信 2网商银行
    public static boolean LOCKSCREEN = false;
    //
    public final static String ACTION_STARTTRADEQUERY_SKB = "com.zhiyi.skb.starttradequery";
    public final static String ACTION_CREATEQRCODE_SKB = "com.zhiyi.skb.createqr";
    public final static String ACTION_ACTIVITYSTART_SKB = "com.zhiyi.skb.activitystart";
    public final static String ACTION_TRADEQUERY_SKB = "com.zhiyi.skb.tradequery";
    // 学习强国
    public final static String ACTION_CREATEQRCODE_XXQG = "com.zhiyi.xxqg.createqr";
    //麻油
    public final static String ACTION_CREATEQRCODE_MAYOU = "com.zhiyi.mayou.createqr";
    public final static String ACTION_ORDERCOMPLETE_MAYOU = "com.zhiyi.mayou.complete";
    public final static String ACTION_ORDERCOMPLETE_GROUP_MAYOU = "com.zhiyi.mayou.complete_gropup";
    // 小信
    public final static String ACTION_CREATEQRCODE_XIAOXIN = "com.zhiyi.xiaoxin.createqr";
    //会员宝收银台
    public final static String ACTION_CREATEQRCODE_HYBSYT = "com.zhiyi.hybsyt.createqrcode";
    public final static String ACTION_QUERYTRADE_HYBSYT = "com.zhiyi.hybsyt.querytrade";
    //益支付
    public final static String ACTION_CREATEQRCODE_YZF = "com.zhiyi.yzf.createqrcode";
    // 飞聊
    public final static String ACTION_CREATEQRCODE_FL = "com.zhiyi.fl.createqrcode";
    // 微聊
    public final static String ACTION_CREATEQRCODE_WL = "com.zhiyi.wl.createqrcode";
    public static int version = 0;
}
