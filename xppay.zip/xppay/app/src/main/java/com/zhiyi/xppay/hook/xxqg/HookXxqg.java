package com.zhiyi.xppay.hook.xxqg;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/4/2.
 */

public class HookXxqg {
    static ClassLoader mclassloader;
    public static Context mcontext;
    public static Handler handler;
    public static Map<String,JSONObject> taskList =new HashMap<>();
    static ArrayList listgroup = new ArrayList();
    private void initHandler(){
        if (handler==null){
            handler =new Handler(){

                @Override
                public void handleMessage(Message msg) {
                    if (msg.what==1){
                        List<String> re =new ArrayList<>();
                        for (String key:taskList.keySet()){
                            JSONObject object =taskList.get(key);
                            if (System.currentTimeMillis()-object.optLong("time")>1000*60*10){
                                re.add(key);
                            }
                        }
                        for (String i:re){
                            //除去超过10分钟未支付了
                            taskList.remove(i);
                        }
                        if (taskList.size()>0) {
                            query(mclassloader);
                        }
                        handler.sendEmptyMessageDelayed(1, 10000);
                        XposedBridge.log("查询 结果"+taskList.size());

                    }

                }
            };
            handler.sendEmptyMessageDelayed(1,10000);
        }
    }
    public void hook(final ClassLoader classLoader, final Context context) {
        mclassloader = classLoader;
        mcontext = context;
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("当前 activity >>>>>>>> " + param.thisObject.getClass().getName());
                if ("com.alibaba.android.rimet.biz.home.activity.HomeActivity".equals(param.thisObject.getClass().getName())) {
                    Context context1 = (Context) param.thisObject;
                    ClassLoader classLoader1 = context1.getClassLoader();
                    getConversationscids(classLoader1, context1);
//                    getMessage(classLoader1);
                    PayHelperUtils.sendLoginId(""+getCid(),AppConst.TYPE_XXQG,context);
                    initHandler();
                }
            }
        });
        XposedHelpers.findAndHookMethod("cgy", classLoader, "a", Long.class, String.class, String.class, Integer.class, List.class, Integer.class, String.class, String.class, long.class,
                XposedHelpers.findClass("cgk", classLoader), long.class, String.class, int.class, XposedHelpers.findClass("cpl", classLoader), new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        super.beforeHookedMethod(param);
                        XposedBridge.log("sender >>> " + param.args[0] + "\n clusterId >>> " + param.args[1] +"\n receiver"+ param.args[4] +"\n cid >>>>>> " + param.args[6] + "\n oid >>>>> " + param.args[8]);
                    }
                });
//        XposedHelpers.findAndHookMethod("cgy", classLoader, "a", Long.class, String.class, boolean.class, XposedHelpers.findClass("cpl", classLoader), new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                XposedBridge.log("领取红包 sender >>> " + param.args[0] + "\n clusterId >>> " + param.args[1] +"\n safe"+ param.args[2]);
//            }
//        });a(String amount, Integer size, List<Long> receivers, Integer type, String congratulations, int senderPayType)
//        XposedHelpers.findAndHookMethod("com.alibaba.android.dingtalk.redpackets.fragments.SendFragment", classLoader, "a",
//                XposedHelpers.findClass("com.alibaba.android.dingtalk.redpackets.fragments.SendFragment",classLoader),
//                XposedHelpers.findClass("com.alibaba.android.dingtalk.redpackets.models.RedPacketsClusterObject",classLoader)
//                , new XC_MethodHook() {
//                    @Override
//                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                        super.afterHookedMethod(param);
//                        throw new Exception("发送红包异常");
//                    }
//                });
    }

    public static void CreateTrade(String amount,String remark){
        Class<?> clazz = XposedHelpers.findClass("cgy",mclassloader);
        Object o_ins = XposedHelpers.callStaticMethod(clazz,"a");

        Object newProxyInstance = Proxy.newProxyInstance(mclassloader, new Class[]{XposedHelpers.findClass("cpl", mclassloader)}, new CreateCnyProxy(mcontext,amount,remark));
        Long cid = Long.valueOf(Long.parseLong(String.valueOf(getCid())));
        ArrayList<Long> receiver = new ArrayList();
        receiver.add(cid);
        XposedHelpers.callMethod(o_ins, "a", new Object[]{cid, ""+getClusterId(), amount, Integer.valueOf(1), receiver,
                Integer.valueOf(2), ""+listgroup.get(0), remark, Long.valueOf(0), null, Long.valueOf(0),
                null, Integer.valueOf(0), newProxyInstance});
        // 添加监控的订单
        JSONObject object =new JSONObject();
        try {
            object.put("money",amount);
            object.put("remark",remark);
            object.put("time",System.currentTimeMillis());
            taskList.put(remark,object);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //
    }

    public static void OpenRedPacket(Long sender,String clusterid){
        Object newProxyInstance = Proxy.newProxyInstance(mclassloader, new Class[]{XposedHelpers.findClass("cpl", mclassloader)}, new OpenRedPack());
        Class<?> clazz = XposedHelpers.findClass("cgy",mclassloader);
        Object o_ins = XposedHelpers.callStaticMethod(clazz,"a");
        XposedHelpers.callMethod(o_ins, "a", new Object[]{sender,clusterid,false,newProxyInstance});
    }

    public static Object getCid(){
        Object obj = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("clq", mclassloader), "a", new Object[0]), "b", new Object[0]),"getCurrentUid", new Object[0]);
        return obj;
    }

    public static void getConversationscids(ClassLoader classLoader, Context context) {
        try {
            Object callStaticMethod = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alibaba.wukong.im.IMEngine", classLoader), "getIMService", new Object[]{XposedHelpers.findClass("com.alibaba.wukong.im.ConversationService", classLoader)});
            Object newProxyInstance = Proxy.newProxyInstance(classLoader, new Class[]{XposedHelpers.findClass("com.alibaba.wukong.Callback", classLoader)}, new ListConversationsCnyProxy());
            XposedHelpers.callMethod(callStaticMethod,"listLocalGroupConversations",new Object[]{newProxyInstance, Integer.valueOf(1000)} );
//            XposedHelpers.callMethod(callStaticMethod,"listConversations",new Object[]{newProxyInstance, Integer.valueOf(1000),Integer.valueOf(1000)} );
        } catch (Throwable th) {
            XposedBridge.log(th);
        }
    }

    public static void getMessage(ClassLoader classLoader){
        Object callStaticMethod = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alibaba.wukong.im.IMEngine", classLoader), "getIMService",
                new Object[]{XposedHelpers.findClass("com.alibaba.wukong.im.MessageService", classLoader)});
        Object newProxyInstance = Proxy.newProxyInstance(classLoader, new Class[]{XposedHelpers.findClass("com.alibaba.wukong.im.MessageListener", classLoader)}, new MessageProxy());
        XposedHelpers.callMethod(callStaticMethod,"addMessageListener",new Object[]{newProxyInstance} );
    }

    public static Object getClusterId() {
        Object obj = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("cgx", mclassloader), "a", new Object[0]), "b", new Object[0]);
        return obj;
    }
    //轮询
    public static void query(ClassLoader classLoader) {
        try {
            Object newProxyInstance = Proxy.newProxyInstance(classLoader, new Class[]{XposedHelpers.findClass("cpl", classLoader)}, new QueryCnyProxy(new com.zhiyi.xppay.hook.xxqg.QueryCnyImpl(classLoader,handler,mcontext)));
            Object callStaticMethod = XposedHelpers.callStaticMethod(XposedHelpers.findClass("cgy", classLoader), "a", new Object[0]);
            XposedBridge.log("rpc class:" + callStaticMethod.getClass());
            XposedHelpers.callMethod(callStaticMethod, "a", new Object[]{Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(50), newProxyInstance});
        } catch (Throwable th) {
            XposedBridge.log(th);
        }
    }
    //
    static class OpenRedPack implements InvocationHandler{
        public  OpenRedPack(){
        }
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            if (method.getName().contains("toString")) {
                return "this is string";
            }
            if (method.getName().equals("onDataReceived")){
                Object result = objects[0];
                try{
                    XposedBridge.log("result >>> "+result.getClass().getName());
                    Object redEnvelopCluster = XposedHelpers.getObjectField(result,"redEnvelopCluster");
                    JSONObject jsonObject = new JSONObject(JsonHelper.toJson(redEnvelopCluster));
                    String amount = jsonObject.optString("amount");
                    String businessId = jsonObject.optString("businessId");
                    String remark = jsonObject.optString("congratulations");
                    String dt = jsonObject.optString("createTime");
                    Intent v2 = new Intent();
                    v2.putExtra("bill_type", AppConst.TYPE_TBH);
                    v2.putExtra("bill_mark", remark);
                    v2.putExtra("bill_money", ""+amount);
                    v2.putExtra("bill_no", businessId);
                    v2.putExtra("bill_dt",""+dt);
                    v2.setAction(AppConst.BILLRECEIVED_ACTION);
                    mcontext.sendBroadcast(v2);
                    XposedBridge.log("amount >>> "+amount +"\n businessId >> "+businessId+"\n remark >> "+remark+"\n dt>>"+dt);
                }catch(Exception e){
                    XposedBridge.log("e>>>>>>>> "+e.fillInStackTrace());
                }
            }else{
                XposedBridge.log("OpenRedPack 异常 >>>>>>> "+objects[0].toString());
            }
            return null;
        }
    }
    // 收到消息
    static class MessageProxy implements InvocationHandler{
        public  MessageProxy(){}
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("invoke ListConversationsCnyImpl method: " + method.getName());
            if (method.getName().contains("toString")) {
                return "this is string";
            }
            if (method.getName().equals("onAdded")) {
                List list = (List) objects[0];
                if (list != null && list.size() > 0){
                    for(int i = 0;i<list.size();i++){
                        Object obj = list.get(i);
                        Object content = XposedHelpers.callMethod(obj,"messageContent");
                        if(content.toString().contains("amount")){
                            List msgobj = (List)XposedHelpers.callMethod(content,"contents");
                            Object msgdetail = msgobj.get(0);
                            Object objextension = XposedHelpers.callMethod(msgdetail,"extension");
                            HashMap map = (HashMap)objextension;
                            Long sender = Long.valueOf(Long.parseLong(String.valueOf(map.get("sid"))));
                            String clusterid = ""+map.get("clusterid");
                            OpenRedPacket(sender,clusterid);
                        }
                    }
                }
            }
            return null;
        }
    }
    //
    static class ListConversationsCnyProxy implements InvocationHandler {
        public ListConversationsCnyProxy() {
        }

        public Object invoke(Object obj, Method method, Object[] objArr) throws Throwable {
            XposedBridge.log("invoke ListConversationsCnyImpl method: " + method.getName());
            if (method.getName().contains("toString")) {
                return "this is string";
            }
            if (method.getName().equals("onSuccess")) {
                try {
                    List list = (List) objArr[0];
                    if(list.size()<=0){
                        PayHelperUtils.sendmsg(mcontext,"请建群后，重启");
                        return null;
                    }
                    for(int i = 0;i<list.size();i++){
                        String conversationId = "" + XposedHelpers.callMethod(list.get(i), "conversationId");
                        listgroup.add(conversationId);
                    }
                } catch (Exception e) {
                    XposedBridge.log(e);

                }
            }
            return null;
        }
    }
    static class CreateCnyProxy implements InvocationHandler {
        private Context mContext;
        private String amount;
        private String remark;
        public CreateCnyProxy(Context context,String amount,String remark) {
            this.amount = amount;
            this.remark = remark;
            mContext=context;
        }
        public Object invoke(Object obj, Method method, Object[] objArr) throws Throwable {
            XposedBridge.log("invoke CreateCnyImpl method: " + method.getName());
            if (method.getName().contains("toString")) {
                return "this is string";
            }
            if (method.getName().equals("onDataReceived")){
                try {
                    obj =objArr[0];
                    String orderStr = ""+XposedHelpers.getObjectField(obj, "alipayOrderString");
//                    orderStr = orderStr.replace("\"", "\\\"");
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("money", amount);
                    broadCastIntent.putExtra("mark", remark);
                    broadCastIntent.putExtra("type", AppConst.TYPE_XXQG);
                    broadCastIntent.putExtra("payurl",  orderStr);
                    broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                    mContext.sendBroadcast(broadCastIntent);
                }catch (Exception e){
                    XposedBridge.log(e);
                }
            }else{
                XposedBridge.log("CreateCnyProxy 异常 >>>>>> "+objArr[0].toString()+objArr[1].toString());
            }
            return null;
        }
    }
}
