package com.zhiyi.xppay.hook.taobao;

import android.text.TextUtils;

import com.zhiyi.xppay.item.ReqData;

import java.util.Iterator;
import java.util.LinkedList;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/3/30.
 */

public class ToolsTaobao {
    public static void SendHongbao(String amount, String remark) {
        float famount = Float.parseFloat(amount);
        long lamount = (long) (famount*100);
        HookTB.SendHongbao(lamount,remark);
    }

    ;
}
