package com.zhiyi.xppay.hook.sb;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Base64;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by pc_mg on 2019/6/28.
 */

public class HookSB {
    private static ClassLoader mClassLoader;
    private static Context mContext;
    private static JSONObject jsonLogin;
    private Handler mHandler;

    public void hook(final ClassLoader classLoader, final Context context) {
        final Class<?> clazz = XposedHelpers.findClass("com.stub.StubApp", classLoader); // onCreate
        XposedHelpers.findAndHookMethod(clazz, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log(" onCreate " + param.thisObject);
                Field field = XposedHelpers.findField(clazz, "ᵢˎ");
                XposedBridge.log(" onCreate field " + field.getClass().getName());
                field.setAccessible(true);
                Object obj = field.get(param.thisObject);
                Field fieldc = XposedHelpers.findField(clazz, "ᵢˑ");
                fieldc.setAccessible(true);
                Object objc = fieldc.get(param.thisObject);
                hook_real(obj.getClass().getClassLoader(), (Context) objc);
            }
        });
    }

    public void hook_real(ClassLoader classLoader, final Context context) {
        mClassLoader = classLoader;
        mContext = context;
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("当前 activity 》》》》》》》》" + param.thisObject.getClass().getName());
                if (param.thisObject.getClass().getName().equals("cn.lcsw.lcpay.presentation.feature.home.HomeActivity")) {
                    if (mHandler == null) {
                        mHandler = new Handler() {
                            @Override
                            public void handleMessage(Message msg) {
                                super.handleMessage(msg);
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        queryTradeAll();
                                    }
                                }).start();
                                mHandler.sendEmptyMessageDelayed(1001, 10000);
                            }
                        };
                        mHandler.sendEmptyMessageDelayed(1001, 10000);
                    } else {
                        mHandler.removeMessages(1001);
                    }
                }
            }
        });
        XposedHelpers.findAndHookMethod("cn.lcsw.lcpay.presentation.feature.base.BaseActivity", classLoader, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if (param.thisObject.getClass().getName().equals("cn.lcsw.lcpay.presentation.feature.home.HomeActivity")) {
                    String loginid = jsonLogin.getString("merchant_no") + "|" + jsonLogin.getString("terminal_id");
                    PayHelperUtils.sendLoginId(loginid, AppConst.TYPE_SB, context);
                    XposedBridge.log("开始登录》》》》》》》");
                }

            }
        });
        XposedHelpers.findAndHookMethod("cn.lcsw.lcpay.data.net.ApiConnection", classLoader, "createService", Class.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log(">>>>>>>>>> ApiConnection >>>>>>>>>>>" + param.getResult().getClass().getName());
            }
        });
        XposedHelpers.findAndHookMethod("okhttp3.OkHttpClient", classLoader, "newCall", XposedHelpers.findClass("okhttp3.Request", classLoader), new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                Object obj = param.args[0];
                Object url = XposedHelpers.getObjectField(XposedHelpers.getObjectField(obj, "url"), "url");
                Object body = XposedHelpers.getObjectField(obj, "body");
                Object headers = XposedHelpers.getObjectField(obj, "headers");
                XposedBridge.log("url >>>" + url + ">>body>>" + body.getClass().getName() + "headers namesAndValues >>> " + JsonHelper.toJson(XposedHelpers.getObjectField(headers, "namesAndValues")));
            }
        });
        XposedHelpers.findAndHookMethod("okhttp3.RequestBody", classLoader, "create", XposedHelpers.findClass("okhttp3.MediaType", classLoader), String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("str >>>>>>>>>>>> " + param.args[1]);
            }
        });
        XposedBridge.hookAllMethods(XposedHelpers.findClass("okhttp3.RequestBody", classLoader), "create", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log(">>>>>>>>>>>>" + new String(Base64.decode(Base64.encodeToString((byte[]) XposedHelpers.getObjectField(param.args[1], "data"), 0), 0)));
            }
        });
        XposedHelpers.findAndHookMethod("cn.lcsw.lcpay.data.util.RequestParamUtil", classLoader, "FilterNullSign", Object.class, String.class, String.class, String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("FilterNullSign obj >>> " + param.args[0].getClass() + " >> json >> " + JsonHelper.toJson(param.args[0]));
            }
        });
        XposedHelpers.findAndHookMethod("cn.lcsw.lcpay.data.util.RequestParamUtil", classLoader, "alphabetOrderSign", Object.class, String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("alphabetOrderSign obj >>> " + param.args[0].getClass() + " >> json >> " + JsonHelper.toJson(param.args[0]) + ">> str >>" + param.args[1]);
            }
        });
        XposedHelpers.findAndHookMethod("cn.lcsw.lcpay.data.cache.UserCache", classLoader, "buglyMapping", String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
//                {"access_token":"fb1c03a8ef684291b8ac7be334efecb4","changelog":"2.0版本升级",
//                  "downloadurl":"http://oss.lcsw.cn/lcpay_android.apk","email":"",
//                  "is_qm_authority":false,"merchant_name":"安徽至臻装饰",
//                  "merchant_no":"836100293000034","terminal_id":"11239245"
//                  "must_update":false,
//                  "nickname":"伍总",
//                  "phone":"18201788379",
//                  "result_code":"01","return_code":"01","return_msg":"登录成功!",
// "role_type":"2","settle_type":"1","store_id":"123209","store_name":"至臻北京店","terminal_id":"11239245","user_id":"1963765","username":"20116743","verno":"2.0.180912.22133"}

                jsonLogin = new JSONObject("" + param.args[0]);
            }
        });
    }

    private static String getTerminalTrace() {
        Class clazz = XposedHelpers.findClass("cn.lcsw.lcpay.data.util.RequestParamUtil", mClassLoader);
        Object result = XposedHelpers.callStaticMethod(clazz, "getTerminalTrace");
        return "" + result;
    }

    private static String getCurrTerminaltime() {
        Class clazz = XposedHelpers.findClass("cn.lcsw.lcpay.data.util.RequestParamUtil", mClassLoader);
        Object result = XposedHelpers.callStaticMethod(clazz, "getCurrTerminaltime");
        return "" + result;
    }

    private static Object createQrPayRequest(String money) {
        float amount = Float.parseFloat(money);
        long _amount = (long) (amount * 100);
        Class clazz = XposedHelpers.findClass("cn.lcsw.lcpay.data.bean.request.QrPayRequest", mClassLoader);
        Object objNew = XposedHelpers.newInstance(clazz);
        XposedHelpers.callMethod(objNew, "setPay_ver", "110");
        XposedHelpers.callMethod(objNew, "setService_id", "016");
        XposedHelpers.callMethod(objNew, "setPay_type", "000");
        XposedHelpers.callMethod(objNew, "setTotal_fee", "" + _amount);
        XposedHelpers.callMethod(objNew, "setMerchant_no", jsonLogin.optString("merchant_no"));
        XposedHelpers.callMethod(objNew, "setTerminal_id", jsonLogin.optString("terminal_id"));
        XposedHelpers.callMethod(objNew, "setTerminal_trace", getTerminalTrace());
        XposedHelpers.callMethod(objNew, "setTerminal_time", getCurrTerminaltime());
        String token = jsonLogin.optString("access_token");
        String key_sign = alphabetOrderSign(objNew, token);
        XposedHelpers.callMethod(objNew, "setKey_sign", key_sign);
        return objNew;
    }

    private static Object createTradeRecordListRequest() {
        Class clazz = XposedHelpers.findClass("cn.lcsw.lcpay.data.bean.request.TradeRecordListRequest", mClassLoader);
        Object objNew = XposedHelpers.newInstance(clazz);
        XposedHelpers.callMethod(objNew, "setStart_id", "0");
        XposedHelpers.callMethod(objNew, "setUser_id", jsonLogin.optString("user_id"));
        XposedHelpers.callMethod(objNew, "setTerminal_no", jsonLogin.optString("terminal_id"));
        XposedHelpers.callMethod(objNew, "setTrace_no", getTerminalTrace());
        XposedHelpers.callMethod(objNew, "setMerchant_no", jsonLogin.optString("merchant_no"));
        String token = jsonLogin.optString("access_token");
        String key_sign = alphabetOrderSign(objNew, token);
        XposedHelpers.callMethod(objNew, "setKey_sign", key_sign);
        return objNew;
    }

    private static Object createSingleTradeRecordRequest(String no) {
        Class clazz = XposedHelpers.findClass("cn.lcsw.lcpay.data.bean.request.SingleTradeRecordRequest", mClassLoader);
        Object objNew = XposedHelpers.newInstance(clazz);
        XposedHelpers.callMethod(objNew, "setMerchant_no", jsonLogin.optString("merchant_no"));
        XposedHelpers.callMethod(objNew, "setTerminal_no", jsonLogin.optString("terminal_id"));
        XposedHelpers.callMethod(objNew, "setTrace_no", getTerminalTrace());
        XposedHelpers.callMethod(objNew, "setUser_id", jsonLogin.optString("user_id"));
        XposedHelpers.callMethod(objNew, "setOut_trade_no", no);
        String token = jsonLogin.optString("access_token");
        String key_sign = alphabetOrderSign(objNew, token);
        XposedHelpers.callMethod(objNew, "setKey_sign", key_sign);
        return objNew;
    }

    private static String alphabetOrderSign(Object object, String token) {
        Class clazz = XposedHelpers.findClass("cn.lcsw.lcpay.data.util.RequestParamUtil", mClassLoader);
        Object result = XposedHelpers.callStaticMethod(clazz, "alphabetOrderSign", object, token);
        return "" + result;
    }

    public static void CreateQRCode(Intent intent) {
        String money = intent.getStringExtra("money");
        String mark = intent.getStringExtra("mark");
        final String type = intent.getStringExtra("type");
        XposedBridge.log("开始创建qrcode");
        String url = "https://pay.lcsw.cn/lcsw/pay/110/qrpay";
        //
        OkHttpClient.Builder builder = new OkHttpClient().newBuilder();
        builder.connectTimeout(50, TimeUnit.SECONDS);
        builder.writeTimeout(50, TimeUnit.SECONDS);
        builder.readTimeout(50, TimeUnit.SECONDS);
        OkHttpClient client = builder.build();
        //
        Request request = new Request.Builder()
                .post(RequestBody.create(MediaType.parse("application/json"), JsonHelper.toJson(createQrPayRequest(money))))
                .url(url).build();
        try {
            Response response = client.newCall(request).execute();
            String result = response.body().string();
            XposedBridge.log("请求QR结果》》》》》" + result);
            JSONObject json = new JSONObject(result);
            String code = json.optString("return_code");
            if (code.equals("01")) {
                String qr = json.optString("qr_url");
                //
                Intent broadCastIntent = new Intent();
                broadCastIntent.putExtra("money", money);
                broadCastIntent.putExtra("mark", mark);
                broadCastIntent.putExtra("type", type);
                broadCastIntent.putExtra("payurl", qr);
                broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                mContext.sendBroadcast(broadCastIntent);
                //
            }
        } catch (IOException e) {
            XposedBridge.log(e);
            e.printStackTrace();
        } catch (JSONException e) {
            XposedBridge.log(e);
            e.printStackTrace();
        }
    }

    private void queryTradeAll() {
        XposedBridge.log("开始轮询订单》》》》》》》");
        String url = "https://apis.lcsw.cn/app/app/200/trade/gettradedetail_all";
        //
        OkHttpClient.Builder builder = new OkHttpClient().newBuilder();
        builder.connectTimeout(50, TimeUnit.SECONDS);
        builder.writeTimeout(50, TimeUnit.SECONDS);
        builder.readTimeout(50, TimeUnit.SECONDS);
        OkHttpClient client = builder.build();
        //
        Request request = new Request.Builder()
                .post(RequestBody.create(MediaType.parse("application/json"), JsonHelper.toJson(createTradeRecordListRequest())))
                .url(url).build();
        try {
            Response response = client.newCall(request).execute();
            String result = response.body().string();
            XposedBridge.log("轮询订单结果》》》》》" + result);
            JSONObject json = new JSONObject(result);
            String code = json.optString("return_code");
            if (code.equals("01")) {
                String strarray = json.optString("list_json");
                XposedBridge.log("strarray》》》》》" + strarray);
                JSONArray array = new JSONArray(strarray);
                XposedBridge.log("array》》》》》" + array);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject object = array.getJSONObject(i);
                    String no = object.optString("out_trade_no");
                    String money = object.optString("balance");
                    float amount = Float.parseFloat(money);
                    amount /= 100.0f;
                    //
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("bill_no", no);
                    broadCastIntent.putExtra("bill_money", "" + amount);
                    broadCastIntent.putExtra("bill_mark", no);
                    broadCastIntent.putExtra("bill_type", AppConst.TYPE_SB);
                    broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                    mContext.sendBroadcast(broadCastIntent);
                    //
                }
            }
        } catch (IOException e) {
            XposedBridge.log(e);
            e.printStackTrace();
        } catch (JSONException e) {
            XposedBridge.log(e);
            e.printStackTrace();
        }
    }
}
//{"key_sign":"6c1d8e8a02f32061396acd2ed9dd3ff4","merchant_no":"836100293000034","pay_type":"000","pay_ver":"110","service_id":"016","terminal_id":"11239245","terminal_time":"20190629093444","terminal_trace":"67251b95240244e8baf7b28e299a0643","total_fee":"700"}