package com.zhiyi.xppay.hook.mowang;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.mayou.ToolsMY;
import com.zhiyi.xppay.hook.mayou.TradeBean;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by pc_mg on 2019/4/13.
 */

public class HookMoTong {
    public static Context mcontext;
    public static ClassLoader mclassloader;
    public void hook(final ClassLoader classLoader, final Context context) {
        if (groupids == null) {
            groupids = new ArrayList<String>();
        }
        final Class<?> clazz = XposedHelpers.findClass("com.stub.StubApp", classLoader); // onCreate

        XposedHelpers.findAndHookMethod(clazz, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                Field field = XposedHelpers.findField(clazz, "ᵢˎ");
                field.setAccessible(true);
                Object obj = field.get(param.thisObject);
                Field fieldc = XposedHelpers.findField(clazz, "ᵢˑ");
                fieldc.setAccessible(true);
                Object objc = fieldc.get(param.thisObject);
                hook_real(obj.getClass().getClassLoader(), (Context) objc);
            }
        });
    }

    private void hook_real(final ClassLoader classLoader, final Context context) {
        mcontext = context;
        mclassloader = classLoader;
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("onCreate >>>>>>>> " + param.thisObject.getClass().getName());
                if (param.thisObject.getClass().getName().equals("com.mostone.life.ui.MainActivity")) {
                    String id = getUserId(classLoader);
                    XposedBridge.log("登录id>>>>>>>>>>>>>" + id);
                    PayHelperUtils.sendLoginId(id, AppConst.TYPE_MY, context);
                }
            }
        });
        XposedHelpers.findAndHookMethod("com.mostone.life.ui.MainActivity", classLoader, "initUI", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                getConversationList(classLoader);
            }
        });
        XposedHelpers.findAndHookMethod("com.mostone.module.im.model.MessageFactory", classLoader, "getMessage",
                XposedHelpers.findClass("com.mostone.module.im.model.IMMessage", classLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        String type = ""+XposedHelpers.callMethod(param.args[0],"getContentType");
                        if(type.equals("Red")){
                            Class clazzAliRed = XposedHelpers.findClass("com.mostone.module.im.model.RedAliPayMessage",classLoader);
                            Object newAlired = XposedHelpers.newInstance(clazzAliRed,param.args[0]);
                            Object obean = XposedHelpers.callMethod(newAlired, "getAliPayRed");
                            Object msg = XposedHelpers.callMethod(param.args[0], "getMessage");
                            XposedBridge.log("获得的完整的消息》》》》》》》》》"+msg);
                            String chatId = ""+XposedHelpers.callMethod(msg,"getChatId");
                            String senderId = ""+XposedHelpers.callMethod(msg,"getContactId");
                            long createtime = Long.parseLong(""+XposedHelpers.callMethod(msg,"getCreateTime"));
                            JSONObject omsg = new JSONObject(JsonHelper.toJson(obean));
                            int states = omsg.optInt("status");
                            if (states == 0 && (System.currentTimeMillis() - createtime < 300000)) {
                                openRPGroup(classLoader,context, chatId, senderId,""+createtime, omsg,obean,param.args[0]);
                            }
                        }
                    }
                });
    }

    public static String getUserInfo(ClassLoader classLoader, String key) {
        Class<?> clazz = XposedHelpers.findClass("com.mostone.lib.utlis.UserInfoUtils", classLoader);
        Object objcom = XposedHelpers.getStaticObjectField(clazz, "Companion");
        Object objins = XposedHelpers.callMethod(objcom, "getInstance");
        Object objuser = XposedHelpers.callMethod(objins, "getUserInfo");
        try {
            JSONObject jsonObject = new JSONObject(JsonHelper.toJson(objuser));
            return jsonObject.getString(key);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String getUserId(ClassLoader classLoader) {
        return getUserInfo(classLoader, "id");
    }
    public static String getUserTokenId(ClassLoader classLoader) {
        Class<?> classUserInfoUtils = XposedHelpers.findClass("com.mostone.lib.utlis.UserInfoUtils", classLoader);
        Object uInfoCompanion = XposedHelpers.getStaticObjectField(classUserInfoUtils, "Companion");
        Object UserInfoUtils = XposedHelpers.callMethod(uInfoCompanion, "getInstance");
        String tokenId = (String) XposedHelpers.callMethod(UserInfoUtils, "getTokenId");
        XposedBridge.log("=====tokenId:" + tokenId);
        return tokenId;
    }
    static ArrayList<String> groupids = new ArrayList<String>();

    public static void getConversationList(ClassLoader classLoader) {
        //
//        XposedBridge.log("=====开始hook群ID");
//        Class<?> classIMGroupManager = XposedHelpers.findClass("com.mostone.lib.im.IMGroupManager", mclassloader);
//        XposedBridge.log("=====classIMGroupManager:" + classIMGroupManager);
//        Object Companion = XposedHelpers.getStaticObjectField(classIMGroupManager, "Companion");
//        XposedBridge.log("=====Companion:" + Companion);
//        Object IMGroupManager = XposedHelpers.callMethod(Companion, "getInstance");
//        XposedBridge.log("=====IMGroupManager:" + IMGroupManager);
//        List groups = (List) XposedHelpers.callMethod(IMGroupManager, "getGroupList", new Object[]{null});
//        XposedBridge.log("=====groups:" + groups);
//        String list = JsonHelper.toJson(groups);
//        XposedBridge.log("list>>>>>>>>>>>>"+list);
//        try {
//            JSONArray grouparray = new JSONArray(list);
//            for (int i = 0; i < grouparray.length(); i++) {
//                JSONObject obj = grouparray.getJSONObject(i);
//                String id = obj.optString("id");
//                groupids.add(id);
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        //
        Class<?> clazz = XposedHelpers.findClass("com.mostone.lib.im.dbsel.IMManagerExt", classLoader);
        Object objcom = XposedHelpers.getStaticObjectField(clazz, "Companion");
        Object objins = XposedHelpers.callMethod(objcom, "getInstance");
        Object objConversationManager = XposedHelpers.callMethod(objins, "getConversationManager");
        Object objConversationListByAll = XposedHelpers.callMethod(objConversationManager, "getConversationListByAll");
        String list = JsonHelper.toJson(objConversationListByAll);
        try {
            JSONArray grouparray = new JSONArray(list);
            for (int i = 0; i < grouparray.length(); i++) {
                JSONObject obj = grouparray.getJSONObject(i);
                String type = obj.optString("type");
                if (type.equals("Group")) {
                    String groupid = obj.optString("contactId");
                    XposedBridge.log("群groupid>>>>>>>" + groupid);
                    groupids.add(groupid);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static String getGroupid() {
        int index = (int) (Math.random() * (groupids.size()));
        String id = "" + groupids.get(index);
        return id;
    }


    public static void createGroupBill(ClassLoader classLoader, Intent intent) {
        XposedBridge.log("开始生成红包数据》》》》》》》》》》");
        if(true){
            httpCreatGroupBill(classLoader,intent);
            return;
        }
    }

    public static void httpCreatGroupBill(ClassLoader classLoader, Intent intent){
        final String money = intent.getStringExtra("money");
        final String mark = intent.getStringExtra("mark");
        OkHttpClient client = new OkHttpClient().newBuilder().hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String s, SSLSession sslSession) {
                return true;
            }
        }).build();
        String dian_order = "https://alipay.mostonetech.com/alipay/nParam";

        RequestBody body = new FormBody.Builder()
                .add("tokenId", getUserTokenId(classLoader))
                .add("amount", money)
                .add("rt", "13")
                .add("os", "1")
                .add("innerVersionCode", "28")
                .add("groupId", getGroupid())
                .add("fixation", "0")
                .add("count", "1")
                .add("title", mark)
                .build();
        final Request.Builder builder = new Request.Builder().url(dian_order);
        builder.addHeader("Host", "alipay.mostonetech.com" );
        builder.addHeader("mostone", "android" );
        builder.addHeader("innerVersionCode", "android" );
        builder.addHeader("type", "1" );
        Request request = builder.post(body).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                XposedBridge.log("======onFailure=========:" + e.toString());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String getString = response.body().string();
                XposedBridge.log("创建 群红包结果》》》》》》》》》"+getString);
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(getString);
                    String data = jsonObject.getString("data");
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("type", AppConst.TYPE_MY);
                    broadCastIntent.putExtra("mark", mark);//+ "_" + this.receiveId
                    broadCastIntent.putExtra("money", money);
                    broadCastIntent.putExtra("payurl", ""+data);
                    broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                    mcontext.sendBroadcast(broadCastIntent);
                    Uri uri = Uri.parse(data);
                    XposedBridge.log("");
                    TradeBean bean = new TradeBean();
                    String dt = ""+System.currentTimeMillis();
                    bean.money = money;
                    bean.mark = mark;
                    bean.createtime = Long.parseLong(dt);
                    bean.state = 0;
                    ToolsMY.addBean(bean);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        //
//        final String money = intent.getStringExtra("money");
//        final String mark = intent.getStringExtra("mark");
//        HttpUtils httpUtils = new HttpUtils(300000);
//        RequestParams params = new RequestParams();
//        //
//        params.addHeader("Host", "alipay.mostonetech.com" );
//        params.addHeader("mostone", "android" );
//        params.addHeader("innerVersionCode", "android" );
//        params.addHeader("type", "1" );
//        //
//        params.addBodyParameter("tokenId", getUserTokenId(classLoader));
//        params.addBodyParameter("amount", money);
//        params.addBodyParameter("rt", "13");
//        params.addBodyParameter("os", "1");
//        params.addBodyParameter("innerVersionCode", "28");
//        params.addBodyParameter("groupId", getGroupid());
//        params.addBodyParameter("count", "1");
//        params.addBodyParameter("title", mark);
//
//        httpUtils.send(HttpRequest.HttpMethod.POST, "https://alipay.mostonetech.com/alipay/nParam", params, new RequestCallBack<String>() {// 获取IP地址
//            @Override
//            public void onSuccess(ResponseInfo<String> responseInfo) {
//                XposedBridge.log("创建 群红包结果》》》》》》》》》"+responseInfo.result);
//                JSONObject jsonObject = null;
//                try {
//                    jsonObject = new JSONObject(responseInfo.result);
//                    String data = jsonObject.getString("data");
//                    Uri uri = Uri.parse(data);
//                    String biz_content = uri.getQueryParameter("biz_content");
//                    XposedBridge.log("biz_content >>>>>>>>> "+biz_content);
//                    Intent broadCastIntent = new Intent();
//                    broadCastIntent.putExtra("type", AppConst.TYPE_MY);
//                    broadCastIntent.putExtra("mark", mark);//+ "_" + this.receiveId
//                    broadCastIntent.putExtra("money", money);
//                    broadCastIntent.putExtra("payurl", ""+data);
//                    broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
//                    mcontext.sendBroadcast(broadCastIntent);
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//            }
//
//            @Override
//            public void onFailure(HttpException e, String s) {
//                XposedBridge.log("获取地址失败e "+e);
//            }
//        });
    }

    public static QueryTradeMW queryTradeMW;

    public static void openRPGroup(ClassLoader classLoader,Context context, String chatid, String senderid,String createtime,JSONObject jsondata,Object redinfo,Object objmessage) {
        String no = jsondata.optString("no");
        String remark = jsondata.optString("title");
        XposedBridge.log("准备打开红包");
        if(!ToolsMY.compareRemark(remark)){
            XposedBridge.log("不是该手机的订单备注》》"+remark);
            return;
        }

        XposedBridge.log("开始打开红包");
        Class<?> clazz = XposedHelpers.findClass("com.mostone.lib.extend.SubscriberExtendKt", classLoader);
        Class<?> clazzapi = XposedHelpers.findClass("com.mostone.lib.im.http.IMApi", classLoader);
        Object objCompanion = XposedHelpers.getStaticObjectField(clazzapi, "Companion");
        Object o_ins = XposedHelpers.callMethod(objCompanion, "getInstance");
        Object o_observable = XposedHelpers.callMethod(o_ins, "getGroupAliPayGetPK",  Long.parseLong(chatid), Long.parseLong(senderid), no);
        Class<?> classfunc1 = XposedHelpers.findClass("kotlin.jvm.functions.Function1", classLoader);
        Function4MoTong func4 = new Function4MoTong(context,no,remark,o_observable,redinfo,objmessage);// no,remark,createtime,money
        Object objfunc4 = Proxy.newProxyInstance(classLoader, new Class[]{classfunc1}, func4);
        Class<?> classfunc3 = XposedHelpers.findClass("kotlin.jvm.functions.Function3", classLoader);
        Function5MoTong func5 = new Function5MoTong();// no,remark,createtime,money
        Object objfunc5 = Proxy.newProxyInstance(classLoader, new Class[]{classfunc3}, func5);
        if(queryTradeMW == null){ queryTradeMW = new QueryTradeMW(context);}
        OrderObjectMW obj = new OrderObjectMW(o_observable,objfunc5,objfunc4,remark);
        queryTradeMW.CreateTrade(obj);
//        XposedHelpers.callStaticMethod(clazz, "subscribeRes", o_observable, objfunc5, objfunc4);
    }
    public static void checkCallBack(OrderObjectMW objectMW){
        XposedBridge.log("checkCallBack收到订单反馈》》》》"+objectMW.mark);
        Object observable = objectMW.o_observable;
        Object func5 = objectMW.objfunc5;
        Object func4 = objectMW.objfunc4;
        Class<?> clazz = XposedHelpers.findClass("com.mostone.lib.extend.SubscriberExtendKt", mclassloader);
        XposedHelpers.callStaticMethod(clazz, "subscribeRes", observable, func5, func4);
    }
    public static void updateRedMessage(Object redinfo,Object message,int result){
        XposedHelpers.callMethod(redinfo,"setStatus",result);
        String jsonStr = JsonHelper.toJson(redinfo);
        XposedHelpers.callMethod(message,"setMessage",jsonStr);
        Class classIMMessageExt = XposedHelpers.findClass("com.mostone.lib.im.dbsel.IMMessageExt",mclassloader);
        Class classIMManagerExt = XposedHelpers.findClass("com.mostone.lib.im.dbsel.IMManagerExt",mclassloader);
        Object objectmanager = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.getStaticObjectField(classIMManagerExt,"Companion"),"getInstance"),"getMessageManager");
        Object msgdbid = XposedHelpers.callMethod(message,"getDbId");
        Object msgMsg = XposedHelpers.callMethod(message,"getMessage");
        XposedHelpers.callStaticMethod(classIMMessageExt,"updateMessageInfo$default",objectmanager,msgdbid, null, null, msgMsg.toString(), null, null, null, null, 246, null);
        Class objEventBUSUtils = XposedHelpers.findClass("com.mostone.lib.utlis.EventBusUtils",mclassloader);
        Class objChatRefresh = XposedHelpers.findClass("com.mostone.module.im.ui.chat.ChatRefresh",mclassloader);
        XposedHelpers.callStaticMethod(objEventBUSUtils,"post",XposedHelpers.newInstance(objChatRefresh,message));
    }
}
