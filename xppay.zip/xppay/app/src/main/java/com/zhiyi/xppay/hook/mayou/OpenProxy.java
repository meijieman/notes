package com.zhiyi.xppay.hook.mayou;

import android.content.Context;
import android.content.Intent;
import com.zhiyi.xppay.consts.AppConst;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class OpenProxy implements InvocationHandler {
    public static String QRCODERECEIVED_ACTION = "com.tools.payhelper.qrcodereceived";
    String cenvelope_desc;
    Context mContext;

    public OpenProxy(Context context, String cenvelope_desc) {
        this.mContext = context;
        this.cenvelope_desc = cenvelope_desc;
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String methodName = method.getName();
        XposedBridge.log("OpenProxy 调用的方法名称为:" + methodName);
        XposedBridge.log("OpenProxy 返回的类型为" + method.getReturnType().getName());
        if (methodName.equals("callback")) {
            try {
                ClassLoader loader = proxy.getClass().getClassLoader();
                byte[] bytes = (byte[]) args[0];
                if (bytes == null || bytes.length <= 0) {
                    return null;
                }
                Object pp = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.aoetech.aoelailiao.core.proto.ProtoBufPacket", loader), "getProtoBufInputByte", new Object[]{bytes});
                Object UserOpenEnvelopeReq = XposedHelpers.callMethod(XposedHelpers.getStaticObjectField(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.UserOpenEnvelopeAns", loader), "ADAPTER"), "decode", new Object[]{pp});
                Object ali_envelope_detail_info = XposedHelpers.getObjectField(UserOpenEnvelopeReq, "ali_envelope_detail_info");
                String result_string = (String) XposedHelpers.getObjectField(UserOpenEnvelopeReq, "result_string");
                Integer result_code = (Integer) XposedHelpers.getObjectField(UserOpenEnvelopeReq, "result_code");
                Integer envelope_total_amount = (Integer) XposedHelpers.getObjectField(ali_envelope_detail_info, "envelope_total_amount");
                float fmoney = ((float)(Integer.valueOf(envelope_total_amount))/100.0f);
                Integer envelope_receiver = (Integer) XposedHelpers.getObjectField(ali_envelope_detail_info, "envelope_receiver");
                XposedBridge.log("toString:" + ((String) XposedHelpers.callMethod(UserOpenEnvelopeReq, "toString", new Object[0])));
                XposedBridge.log("result_string:" + result_string);
                XposedBridge.log("result_code:" + result_code);
                XposedBridge.log("envelope_total_amount:" + envelope_total_amount);
                Intent broadCastIntent = new Intent();
                broadCastIntent.putExtra("bill_no", this.cenvelope_desc);
                broadCastIntent.putExtra("bill_money", fmoney + "");
                broadCastIntent.putExtra("bill_mark", this.cenvelope_desc);
                broadCastIntent.putExtra("bill_type", AppConst.TYPE_MY);
                broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                this.mContext.sendBroadcast(broadCastIntent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}