package com.zhiyi.xppay.net.Socket.SendMsg;

/**
 * Created by pc_unity on 2018/11/10.
 */

public class PayAppDisable {
    public int type;
    public String paytype;

    @Override
    public String toString() {
        return "PayAppDisable:{" +
                "type=" + type +
                ",paytype='" + paytype + '\'' +
                "}";
    }
}
