package com.zhiyi.xppay.net.Socket.SendMsg;

import android.content.Intent;

import com.zhiyi.xppay.net.Socket.TransConst;



public class FriendShip extends TransMessage{
    public FriendShip(Intent intent) {
        super(TransConst.IS_FRIEND);
        orderid = intent.getStringExtra("orderid");
        boolean f = intent.getBooleanExtra("isfriend",false);
        friendType = f?"2":"-1";
    }

    public String orderid;
    public String friendType;
}
