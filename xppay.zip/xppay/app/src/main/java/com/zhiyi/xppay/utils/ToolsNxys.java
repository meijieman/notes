package com.zhiyi.xppay.utils;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConstsNxys;
import com.zhiyi.xppay.hook.HookNxys;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/3/6.
 */

public class ToolsNxys {

    public static boolean ishookeed;// hook到
    public static boolean isactivitystart;// activity开启

    public static void CreateQRCode(String money,String mark,String type) {
        HookNxys.CreateQR(money,mark,type);
    }

    public static void sendmsg(Context context, String msg) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("msg", msg);
        broadCastIntent.setAction(AppConstsNxys.ACTION_MSGRECEIVED);
        context.sendBroadcast(broadCastIntent);
    }

    public static void sendtrade(Context context, String payTime, String orderId, String realAmount) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(AppConstsNxys.ACTION_SENDTRADE);
        broadCastIntent.putExtra("payTime", payTime);
        broadCastIntent.putExtra("orderId", orderId);
        broadCastIntent.putExtra("realAmount", realAmount);
        context.sendBroadcast(broadCastIntent);
    }

    public static void sendActivitystart(Context context) {
        Intent intent = new Intent();
        intent.setAction(AppConstsNxys.ACTION_ACTIVITYSTART);
        context.sendBroadcast(intent);
    }

    public static void tradequery(final Context context) {
        if (isactivitystart && ishookeed) {
            if(!TextUtils.isEmpty(HookNxys.loginid)){
                PayHelperUtils.sendLoginId(HookNxys.loginid, AppConstsNxys.TYPE_NXYS, context);
                ToolsNxys.sendmsg(context,"农信易扫开启账单轮询");
                Intent broadCastIntent = new Intent();
                broadCastIntent.putExtra("appname",AppConstsNxys.PACKAGENAME);
                broadCastIntent.setAction(AppConstsNxys.ACTION_STARTTRADEQUERY);
                context.sendBroadcast(broadCastIntent);
            }else{
                PayHelperUtils.sendmsg(context,"未获取到农信易扫账号");
            }
        }
    }
}
