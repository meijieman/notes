package com.zhiyi.xppay.hook.xiangliao;

import android.content.Context;
import android.content.Intent;


import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Chenkai on 2019/3/26.
 */

public class CreatPacketProxy implements InvocationHandler {
    String amount;
    Context mContext;
    String mark;
    String receiveId;
    String orderId;

    public CreatPacketProxy(Context arg1, String arg2, String arg3, String arg4,String orderId) {
        super();
        this.mContext = arg1;
        this.mark = arg2;
        this.amount = arg3;
        this.receiveId = arg4;
        this.orderId = orderId;
    }

    public Object invoke(Object arg11, Method arg12, Object[] arg13) throws Throwable {
        String v4 = arg12.getName();
        XposedBridge.log("调用的方法名称为:" + v4);
        XposedBridge.log("返回的类型为" + arg12.getReturnType().getName());
        if(v4.equals("onResponse")) {
            int v7 = 2;
            try {

                /*Object data=XposedHelpers.getObjectField(arg13[v7], "data");
                XposedBridge.log("乡聊支付数据：data\n" + (((String)data)));*/

                Object v5 = XposedHelpers.getObjectField(XposedHelpers.getObjectField(arg13[v7], "data"), "orderInfo");
                if(v5 == null){
                    PayHelperUtils.sendmsg(mContext,"乡聊订单生成失败!");
                    return null;
                }
                XposedBridge.log("乡聊支付数据：\n" + (((String)v5)));
                Intent v2 = new Intent();
                v2.putExtra("type", AppConst.TYPE_XiangLiao);
                v2.putExtra("mark", this.mark);
                v2.putExtra("money", this.amount);
                v2.putExtra("payurl", ((String)v5));
                v2.putExtra("orderid", orderId);
                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                this.mContext.sendBroadcast(v2);
            }
            catch(Exception v3) {
                XposedBridge.log("GetRedPacketProxy  解析异常:" + v3);
                v3.printStackTrace();
            }
        }

        return null;
    }
}
