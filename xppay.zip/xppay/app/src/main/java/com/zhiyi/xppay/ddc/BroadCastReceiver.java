package com.zhiyi.xppay.ddc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;


public class BroadCastReceiver extends BroadcastReceiver{

    public BroadCastReceiver(DianDianChong main){
        this.main = main;
    }
    private DianDianChong main;

    @Override
    public void onReceive(Context context, Intent intent) {
        String act = intent.getAction();
        if(AppConst.BILLRECEIVED_ACTION.equals(act)){
            if(AppConst.TYPE_DIANDIANCHONG.equals(intent.getStringExtra("paytype"))){
                String money = intent.getStringExtra("money");
                String remark = intent.getStringExtra("remark");
//                main.buildQrcode(money,remark);
            }
        }
    }
}
