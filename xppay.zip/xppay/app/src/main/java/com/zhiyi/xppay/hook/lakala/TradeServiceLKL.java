package com.zhiyi.xppay.hook.lakala;

import com.zhiyi.xppay.hook.LakalaHook;

import java.util.Iterator;
import java.util.LinkedList;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/5/11.
 */

public class TradeServiceLKL implements Runnable {
    private static LinkedList<TradeDataLKL> reqlist;
    private static TradeServiceLKL instance;
    // 线程控制
    boolean isrunnig = false;

    public static TradeServiceLKL getInstance(){
        if(instance == null){
            instance = new TradeServiceLKL();
            instance.init();
        }
        return instance;
    }

    public void add(TradeDataLKL data){
        XposedBridge.log("添加 data 数据》》》》》"+data.tradeNo);
        if(!reqlist.contains(data)){
            reqlist.add(data);
        }
        if(!isrunnig){
            isrunnig = true;
            new Thread(this).start();
        }
    }
    private void init(){
        reqlist = new LinkedList<TradeDataLKL>();
    }


    @Override
    public void run() {
        while(isrunnig){
            try{
                do {
                    long now = System.currentTimeMillis();
                    if (reqlist.isEmpty()) {
                        isrunnig = false;
                        break;
                    }
                    for (Iterator<TradeDataLKL> item = reqlist.iterator(); item.hasNext();){
                        TradeDataLKL data = item.next();
                        if(data.states == 1||now - data.reqTime>600000){
                            item.remove();
                            continue;
                        }
                        XposedBridge.log("开始循环数据》》》》》"+data.tradeNo);
                        LakalaHook.GetOneTrade(data);
                    }
                }
                while(false);
                Thread.sleep(5000);
            }
            catch (Throwable t){
                XposedBridge.log(t);
            }
        }
    }
}
