package com.zhiyi.xppay.hook.mowang;

import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.mayou.ToolsMY;
import com.zhiyi.xppay.hook.mayou.TradeBean;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/4/13.
 */

public class Function1MoTong implements InvocationHandler {
    private Context context;
    private String strmoney;
    private String strmark;
    public Function1MoTong(Context _context,String money,String mark){
        context = _context;
        strmoney = money;
        strmark = mark;
    }
    @Override
    public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
        String methodName = method.getName();
        XposedBridge.log("Function1MoTong 调用的方法名称为:" + methodName);
        XposedBridge.log("Function1MoTong 返回的类型为" + method.getReturnType().getName());
        XposedBridge.log("Function1MoTong >>>>>>> 结果"+objects[0]);
        // renderAliPayInfo
        // check
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("type", AppConst.TYPE_MY);
        broadCastIntent.putExtra("mark", strmark);//+ "_" + this.receiveId
        broadCastIntent.putExtra("money", strmoney);
        broadCastIntent.putExtra("payurl", ""+objects[0]);
        broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
        context.sendBroadcast(broadCastIntent);
//        TradeBean bean = new TradeBean();
//        String dt = ""+System.currentTimeMillis();
//        bean.money = strmoney;
//        bean.mark = strmark;
//        bean.createtime = Long.parseLong(dt);
//        bean.state = 0;
//        ToolsMY.addBean(bean);
//        HookMoTong.checkOrder(null);
        return null;
    }
}
