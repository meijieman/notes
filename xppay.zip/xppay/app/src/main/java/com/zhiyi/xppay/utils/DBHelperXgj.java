package com.zhiyi.xppay.utils;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by pc_mg on 2019/3/21.
 */

public class DBHelperXgj extends SQLiteOpenHelper {
    public DBHelperXgj(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "trade.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS trade" +
                "(_id INTEGER PRIMARY KEY AUTOINCREMENT, tradeno varchar)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
