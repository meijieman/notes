package com.zhiyi.xppay.hook.v138;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.List;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class Tools {


    public static String getUserId(ClassLoader classLoader) {

        try {

            Class AlipayApplication=classLoader.loadClass("com.alipay.mobile.framework.AlipayApplication");
            Object AlipayApplicationInstance= XposedHelpers.callStaticMethod(AlipayApplication,"getInstance");
            Object ApplicationContext=XposedHelpers.callMethod(AlipayApplicationInstance,"getMicroApplicationContext");

            Object AuthService=XposedHelpers.callMethod(ApplicationContext,"getExtServiceByInterface","com.alipay.mobile.framework.service.ext.security.AuthService");
            Object UserInfo=XposedHelpers.callMethod(AuthService,"getUserInfo");
            String LogonId=(String) XposedHelpers.callMethod(UserInfo,"getUserId");

            return  LogonId;
        }catch (Exception e)
        {
            XposedBridge.log(e);
        }
        return  null;

    }

    public static Object getContactAccount(ClassLoader classLoader,String userid) {
        try {
            List group = getAllAlipayFriends(classLoader);
            Object conresult = null;
            for(Object con : group){
                String userid_con = ""+XposedHelpers.getObjectField(con,"userId");
                if(!TextUtils.isEmpty(userid_con)&&userid.equals(userid_con)){
                    conresult = con;
                    break;
                }
            }
            return conresult;
//            Class AlipayApplication=classLoader.loadClass("com.alipay.mobile.framework.AlipayApplication");
//            Object AlipayApplicationInstance= XposedHelpers.callStaticMethod(AlipayApplication,"getInstance");
//            Object ApplicationContext=XposedHelpers.callMethod(AlipayApplicationInstance,"getMicroApplicationContext");
//
//
//            Object socialSdkContactService=XposedHelpers.callMethod(ApplicationContext,"getExtServiceByInterface","com.alipay.mobile.personalbase.service.SocialSdkContactService");
//            Object ContactAccount =XposedHelpers.callMethod(socialSdkContactService,"queryAccountById",userid);
//
//            XposedBridge.log("ContactAccount ="+JSON.toJSONString(ContactAccount));
//            return  ContactAccount;
        }catch (Exception e)
        {
            XposedBridge.log(e);
        }
        return  null;
    }

    public static Object compareFriend(String userid,ClassLoader mClassLoader) {
        Class appclazz = XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", mClassLoader);
        Object mapp2 = XposedHelpers.callStaticMethod(appclazz, "getInstance");
        Object bundleContext = XposedHelpers.callMethod(mapp2, "getBundleContext");
        ClassLoader classload = (ClassLoader) XposedHelpers.callMethod(bundleContext, "findClassLoaderByBundleName", "android-phone-wallet-socialpayee");
        Object contactAccount = Tools.getContactAccount(classload, userid);
        return contactAccount;
    }
    public static void sendBillMsg(final String userid, final String money, final String remark, final String orderid, final Context context) {
        try {
            Object o = sendBillMsg(userid, money, remark,context.getClassLoader());
            JSONObject json = new JSONObject(JSON.toJSONString(o));
//            HttpManager.getInstance().sendTrade(json.getString("transferNo"),odrderid,context);
            if (json.has("transferNo")) {
                Intent intent = new Intent();
                intent.setAction(AppConst.HOOK_FRIEND_ORDER_ACTION);
                intent.putExtra("no", json.getString("transferNo"));
                intent.putExtra("orderid", orderid);
                context.sendBroadcast(intent);
            } else {
                PayHelperUtils.sendmsg(context, "支付宝提示你：" + json.getString("message"));
            }
        } catch (Exception e) {
            XposedBridge.log("发送订单异常");
            XposedBridge.log(e);
        }
    }
    public static Object sendBillMsg(final String userid, final String money, final String remark, ClassLoader mClassLoader) {
        Class appclazz = XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", mClassLoader);
        Object mapp2 = XposedHelpers.callStaticMethod(appclazz, "getInstance");
        Object bundleContext = XposedHelpers.callMethod(mapp2, "getBundleContext");
        ClassLoader classload = (ClassLoader) XposedHelpers.callMethod(bundleContext, "findClassLoaderByBundleName", "android-phone-wallet-socialpayee");
        Object service = Tools.getRpcService(Tools.getAlipayApplication(mClassLoader));
        XposedBridge.log("service " + service);
        Object SingleCollectRpc = XposedHelpers.callMethod(service, "getRpcProxy", XposedHelpers.findClass("com.alipay.android.phone.personalapp.socialpayee.rpc.SingleCollectRpc", classload));
        Object singleCreateReq = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.android.phone.personalapp.socialpayee.rpc.req.SingleCreateReq", classload));
        XposedBridge.log(" singleCreateReq " + JSON.toJSONString(singleCreateReq));
        Field[] fields = singleCreateReq.getClass().getDeclaredFields();
        XposedHelpers.setObjectField(singleCreateReq, "userId", userid);
//        XposedHelpers.setObjectField(singleCreateReq, "logonId", logonId);
        XposedHelpers.setObjectField(singleCreateReq, "desc", remark);
        XposedHelpers.setObjectField(singleCreateReq, "payAmount", money);
        XposedHelpers.setObjectField(singleCreateReq, "billName", "个人收款");
        XposedHelpers.setObjectField(singleCreateReq, "source", "chat");
        Object o = XposedHelpers.callMethod(SingleCollectRpc, "createBill", singleCreateReq);
        XposedBridge.log(" 结果 " + JSON.toJSONString(o));//  结果 {"success":true,"transferNo":"20190225200040011100700099484159"}
//        Tools.delectContact(mClassLoader,userid);
        return o;
    }

    public static  List getAllAlipayFriends(ClassLoader classLoader){
        try {
            Class AlipayApplication=classLoader.loadClass("com.alipay.mobile.framework.AlipayApplication");
            Object AlipayApplicationInstance= XposedHelpers.callStaticMethod(AlipayApplication,"getInstance");
            Object ApplicationContext=XposedHelpers.callMethod(AlipayApplicationInstance,"getMicroApplicationContext");
            Object socialSdkContactService=XposedHelpers.callMethod(ApplicationContext,"getExtServiceByInterface","com.alipay.mobile.personalbase.service.SocialSdkContactService");
            Object ContactAccount =XposedHelpers.callMethod(socialSdkContactService,"getAllFriends");
            return  (List)ContactAccount;
        }catch (Exception e)
        {
            XposedBridge.log(e);
        }
        return  null;
    }

    public static Object receiveCrowd(ClassLoader classLoader,Object GiftCrowdReceiveReq)
    {
        try {
            Class GiftCrowdReceiveService = classLoader.loadClass(
                    "com.alipay.giftprod.biz.crowd.gw.GiftCrowdReceiveService");
            Object app=getAlipayApplication(classLoader);
            Object GiftCrowdReceiveServiceObj=getRpcProxy(app,GiftCrowdReceiveService);
            Object re=   XposedHelpers.callMethod(GiftCrowdReceiveServiceObj,"receiveCrowd",GiftCrowdReceiveReq);
            return  re;
        }catch (Exception e)
        {
            XposedBridge.log(e);
        }
        return null;
    }

    public static Object getAlipayApplication(ClassLoader classLoader)
    {
        try {
            Class AlipayApplication=classLoader.loadClass("com.alipay.mobile.framework.LauncherApplicationAgent");

            Object AlipayApplicationInstance= XposedHelpers.callStaticMethod(AlipayApplication,"getInstance");

            Object ApplicationContext=XposedHelpers.callMethod(AlipayApplicationInstance,"getMicroApplicationContext");
            XposedBridge.log("ApplicationContext cn:"+ApplicationContext.getClass().getName());
            return ApplicationContext;

        }catch (Exception e)
        {
            XposedBridge.log(e);
        }
        return null;
    }

    public static Object findServiceByInterface(Object AlipayApplication,String name)
    {
        try {


            return  XposedHelpers.callMethod(AlipayApplication,"findServiceByInterface", name);
        }catch (Exception e)
        {
            XposedBridge.log(e);
        }
        return null;
    }

    public static Object findAppById(Object AlipayApplication,String name)
    {
        try {


            return  XposedHelpers.callMethod(AlipayApplication,"findAppById", name);
        }catch (Exception e)
        {
            XposedBridge.log(e);
        }
        return null;
    }

    public static Object getRpcService(Object AlipayApplication)
    {
        try {

            //  Application application=(Application) XposedHelpers.callMethod(AlipayApplication,"getApplicationContext");
            ClassLoader classLoader=AlipayApplication.getClass().getClassLoader();
            Class RpcService=XposedHelpers.findClass("com.alipay.mobile.framework.service.common.RpcService",classLoader);
            return  XposedHelpers.callMethod(AlipayApplication,"findServiceByInterface", RpcService.getName());
        }catch (Exception e)
        {           XposedBridge.log(e);
        }
        return null;
    }
    public static Object getServiceByInterface(Object AlipayApplication)
    {
        try {

            //  Application application=(Application) XposedHelpers.callMethod(AlipayApplication,"getApplicationContext");
            ClassLoader classLoader=AlipayApplication.getClass().getClassLoader();
            Class RpcService= classLoader.loadClass("com.alipay.mobile.framework.service.common.RpcService");
            return  XposedHelpers.callMethod(AlipayApplication,"getServiceByInterface", RpcService.getName());
        }catch (Exception e)
        {          XposedBridge.log(e);
        }
        return null;
    }

    public static  Object getRpcProxy(Object AlipayApplication, Class face) {
        try {

            Object RpcService= getRpcService(AlipayApplication);
            return   XposedHelpers.callMethod(RpcService,"getRpcProxy",face);
        }catch (Exception e)
        {
            XposedBridge.log(e);
        }
        return null;
    }

    public static void delectContact(ClassLoader classLoader,String userid){
    /*    HandleRelationReq handleRelationReq = new HandleRelationReq();
        handleRelationReq.targetUserId = profileSettingActivity.k.userId;
        handleRelationReq.bizType = "2";
        handleRelationReq.alipayAccount = profileSettingActivity.k.account;
        BaseResult handleRelation = profileSettingActivity.u.handleRelation(handleRelationReq);*/
        Object contactAccount= getContactAccount(classLoader,userid);

        Object handleRelationReq =XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.req.HandleRelationReq",classLoader));
        String userId =XposedHelpers.getObjectField(contactAccount,"userId")+"";
        String account =XposedHelpers.getObjectField(contactAccount,"account")+"";
        XposedHelpers.setObjectField(handleRelationReq,"targetUserId",userId);
        XposedHelpers.setObjectField(handleRelationReq,"alipayAccount",account);
        XposedHelpers.setObjectField(handleRelationReq,"bizType","2");
        Object service =  Tools.getRpcService( Tools.getAlipayApplication(classLoader));
        XposedBridge.log("service "+service);
        Object alipayRelationManageService= XposedHelpers.callMethod(service,"getRpcProxy",XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.rpc.AlipayRelationManageService",classLoader));
        XposedBridge.log("alipayRelationManageService>>>>>>>>>"+alipayRelationManageService.getClass());
        Object re=XposedHelpers.callMethod(alipayRelationManageService,"handleRelation",handleRelationReq);
        XposedBridge.log("删除好友结果"+JSON.toJSONString(re));
    }


}
