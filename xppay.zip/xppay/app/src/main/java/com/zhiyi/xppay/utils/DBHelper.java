package com.zhiyi.xppay.utils;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.zhiyi.xppay.hook.CustomApplcation;

import java.io.File;

import de.robv.android.xposed.XposedBridge;

/**
 * 

* @ClassName: DBHelper

* @Description: TODO(这里用一句话描述这个类的作用)

* @author SuXiaoliang

* @date 2018年6月23日 下午1:27:16

*
 */
public class DBHelper extends SQLiteOpenHelper{
	public DBHelper(Context context) {  
        super(context, "trade.db", null, 2);
    }

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE IF NOT EXISTS qrcode" + 
				"(_id INTEGER PRIMARY KEY AUTOINCREMENT, money varchar, mark varchar, type varchar, payurl varchar, dt varchar)");
		db.execSQL("CREATE TABLE IF NOT EXISTS payorder" + 
				"(_id INTEGER PRIMARY KEY AUTOINCREMENT, money varchar, mark varchar, type varchar, tradeno varchar, dt varchar, result varchar, time integer)");
		db.execSQL("CREATE TABLE IF NOT EXISTS tradeno" +
				"(_id INTEGER PRIMARY KEY AUTOINCREMENT, tradeno varchar,cookie varchar)");
		db.execSQL("CREATE TABLE IF NOT EXISTS account" +
				"(_id INTEGER PRIMARY KEY AUTOINCREMENT,appid varchar,token varchar, dt varchar)");
		db.execSQL("CREATE TABLE IF NOT EXISTS alipayinfo" +
				"(_id INTEGER PRIMARY KEY AUTOINCREMENT,pwd varchar,withdrawcount varchar,bankcardno varchar,bankaccount varchar,alipayaccount varchar,withdrawtype int)");
		db.execSQL("CREATE TABLE IF NOT EXISTS cpcheckorder" +
				"(_id INTEGER PRIMARY KEY AUTOINCREMENT,remark varchar,checkorder varchar,createdt varchar)");
		db.execSQL("CREATE TABLE IF NOT EXISTS alibankorder" +
				"(_id INTEGER PRIMARY KEY AUTOINCREMENT,billno varchar,money varchar)");
		db.execSQL("CREATE TABLE IF NOT EXISTS device(deviceid char(32) PRIMARY KEY)");
	}
 
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		if(newVersion == 2){
			db.execSQL("CREATE TABLE IF NOT EXISTS device(deviceid char(32) PRIMARY KEY)");
		}
	}
	private static boolean mainTmpDirSet = false;
	@Override
	public SQLiteDatabase getReadableDatabase() {
		if (!mainTmpDirSet) {
			String tempdir = "/data/data/com.zhiyi.xppay/databases/main";
			boolean rs = new File(tempdir).mkdir();
			XposedBridge.log("数据库创建临时文件"+rs);
			super.getReadableDatabase().execSQL("PRAGMA temp_store_directory = '/data/data/com.zhiyi.xppay/databases/main'");
			mainTmpDirSet = true;
			return super.getReadableDatabase();
		}
		return super.getReadableDatabase();
	}
}
