package com.zhiyi.xppay.hook.fl;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.consts.AppConstsNxys;
import com.zhiyi.xppay.utils.AbSharedUtil;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONObject;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/5/22.
 */

public class HookFL {

    private static Class ConsumerClass;
    private static Constructor OpenNormalRpRequest;
    private static Constructor SendNormalRpRequest;
    private static Class<Enum> TypeClass;
//    private ClassLoader classLoader;
    private static Object luckyMoneyApi;
    private static Object transformer;
    private static String con_id;
    private static Context mcontext;
    private static String userid;
    private Handler mHandler;
    public void hook(final ClassLoader classLoader, final Context context) {
        //
        if (mHandler == null) {
            mHandler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    super.handleMessage(msg);
                    boolean isAppRunning = PayHelperUtils.isAppRunning(context, AppConst.APP_FL);
                    XposedBridge.log("飞聊" + (isAppRunning ? "" : "未") + "启动》》》》》》");
                    if (!isAppRunning) {
                        XposedBridge.log("重新启动飞聊");
                        PayHelperUtils.startAPP(context,AppConst.APP_FL);
                    }
                    mHandler.sendEmptyMessageDelayed(1001, 300000);
                }
            };
            mHandler.sendEmptyMessageDelayed(1001, 300000);
        } else {
            mHandler.removeMessages(1001);
        }
        //
        String _conid = AbSharedUtil.getString(context,"fy_conid");
        if(!TextUtils.isEmpty(_conid)){
            con_id = _conid;
        }
        try {
            mcontext = context;
            XposedBridge.hookAllConstructors(context.getClassLoader().loadClass("rocket.user_info.GetSelfInfoResponse"),
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            super.afterHookedMethod(param);
                            try {
                                String json = JsonHelper.toJson(param.thisObject);
                                JSONObject jsonObject = new JSONObject(json);
                                if (jsonObject.has("user_info")) {
                                    long userId = jsonObject.getJSONObject("user_info").optLong("user_id");
                                    if (userId != 0) {
                                        userid = ""+userId;
                                        PayHelperUtils.sendLoginId("" + userId, AppConst.TYPE_FL, context);
                                        XposedBridge.log("获取到的loginid 》》》" + userId);
                                    }
                                } else {
                                    PayHelperUtils.sendmsg(context, "获取uid失败");
                                }
                            } catch (Throwable e) {
                            }
                        }
                    });
        } catch (Throwable e) {
            XposedBridge.log(e);
        }
        try {
            XposedHelpers.findAndHookMethod("com.rocket.android.conversation.chatroom.ChatActivity",
                    context.getClassLoader(), "onCreate", Bundle.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            super.afterHookedMethod(param);
                            Activity activity = (Activity) param.thisObject;
                            con_id = activity.getIntent().getStringExtra("con_id");
                            AbSharedUtil.putString(context,"fy_conid",con_id);
                            XposedBridge.log("当前群id 》》》 " + con_id);
                        }
                    });
            XposedHelpers.findAndHookMethod("com.rocket.im.core.internal.d.k",
                    context.getClassLoader(), "e_", List.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            super.beforeHookedMethod(param);
                            String json = JsonHelper.toJson(((List) param.args[0]).get(0));
                            JSONObject jsonObject = new JSONObject(json);
                            String conversationId = jsonObject.getString("conversationId");
                            long msgId = jsonObject.getLong("msgId");
                            if (jsonObject.getInt("msgType") == 10011) {
                                JSONObject protoObject = jsonObject.getJSONObject("contentObj").getJSONObject("protoObject");
                                long rp_order_no = protoObject.getLong("rp_order_no");
                                long send_user_id = protoObject.getLong("send_user_id");
                                String subject = protoObject.getString("subject");
                                //  if (send_user_id != id) {
                                openEnvelope(rp_order_no, conversationId, send_user_id, msgId, subject);
                                // }
                            }
                            String stringBuilder = "收到消息：" + json;
                            XposedBridge.log(stringBuilder);
                        }
                    });
        } catch (Throwable e) {
            XposedBridge.log(e);
        }
        try {
            //修复飞聊红包领取异常问题
            XposedBridge.hookAllMethods(context.getClassLoader().loadClass("com.rocket.android.commonsdk.a.a"),
                    "a", new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            super.beforeHookedMethod(param);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            if (param.args != null && param.args.length > 2) {
                                String url = (String) param.getResult();
                                if (!TextUtils.isEmpty(url) && url.startsWith("http")) {
                                    String url2 = parse(url);
                                    param.setResult(url2);
                                }
                            }
                            super.afterHookedMethod(param);
                        }
                    });
        } catch (Throwable e) {
            XposedBridge.log(e.getMessage());
        }

        XposedHelpers.findAndHookMethod("com.ss.sys.ces.c.a", classLoader, "a", Context.class, new XC_MethodReplacement() {

            @Override
            protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                return false;
            }
        });


        XposedHelpers.findAndHookMethod("com.ss.sys.ces.c.a", classLoader, "a", String.class, new XC_MethodReplacement() {

            @Override
            protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                return false;
            }
        });

        XposedHelpers.findAndHookMethod("com.ss.sys.ces.c.a", classLoader, "b", new XC_MethodReplacement() {

            @Override
            protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                return false;
            }
        });


        XposedHelpers.findAndHookConstructor("com.ss.sys.ces.b", classLoader,
                Context.class, long.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Object result = XposedHelpers.callMethod(param.thisObject, "d");
                        XposedBridge.log("是否是xposed:" + result);
                    }
                });
    }

    private static String shuffleValue(String vaule) {
        List<String> list = Arrays.asList(vaule.split(""));
        Collections.shuffle(list);
        StringBuilder out = new StringBuilder();
        for (String s : list) {
            out.append(s);
        }
        return out.toString();
    }

    public static String parse(String url) {
        String[] urlParts = url.split("\\?");
        String baseUrl = urlParts[0];
        if (urlParts.length == 1) {
            return url;
        }
        String[] params = urlParts[1].split("&");
        StringBuffer buffer = new StringBuffer();
        buffer.append(baseUrl).append("?");
        try {
            for (String param : params) {
                String[] keyValue = param.split("=");
                if (keyValue.length == 2) {
                    switch (keyValue[0]) {
                        case "iid":
                        case "uuid":
                        case "openudid":
                        case "mas":
                        case "device_id":
                        case "as":
                            buffer.append("&").append(keyValue[0]).append("=").append(shuffleValue(keyValue[1]));
                            break;
                        default:
                            if (buffer.toString().contains("&")) {
                                buffer.append("&").append(keyValue[0]).append("=").append(keyValue[1]);
                            } else {
                                buffer.append(keyValue[0]).append("=").append(keyValue[1]);
                            }
                    }
                } else {
                    buffer.append("&").append(param);
                }
            }
        } catch (Exception e) {
            return url;
        }
        return buffer.toString();
    }

    private static synchronized void initEnvelope() throws ClassNotFoundException, NoSuchMethodException {
        if (luckyMoneyApi == null) {
            Class<?> ILuckyMoneyApi = XposedHelpers.findClass("com.rocket.android.luckymoney.ILuckyMoneyApi$a", mcontext.getClassLoader());
            luckyMoneyApi = XposedHelpers.callMethod(XposedHelpers.getStaticObjectField(ILuckyMoneyApi, "a"), "a");
            transformer = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.rocket.android.commonsdk.utils.al", mcontext.getClassLoader()), "a");
            ConsumerClass = mcontext.getClassLoader().loadClass("io.reactivex.functions.Consumer");
            TypeClass = (Class<Enum>) XposedHelpers.findClass("rocket.luckymoney.RpCommon$Type", mcontext.getClassLoader());
            SendNormalRpRequest = mcontext.getClassLoader().loadClass("rocket.luckymoney.SendNormalRpRequest").getConstructor(Long.class, Long.class, String.class, String.class, TypeClass, String.class, Long.class);
            OpenNormalRpRequest = mcontext.getClassLoader().loadClass("rocket.luckymoney.OpenNormalRpRequest").getConstructor(Long.class, String.class, String.class, Long.class, Long.class);
        }
    }

    public void openEnvelope(Long orderNo, String groupId, Long sendUserId, Long messageId, String subject) throws Exception {
        XposedBridge.log("orderNo: " + orderNo + " groupId: " + groupId + " sendUserId: " + sendUserId + " subject:" + subject);
        if(!userid.equals(""+sendUserId)){
            return;
        }
        initEnvelope();
        String groupName = groupId;
        Object openNormalRpRequest = OpenNormalRpRequest.newInstance(orderNo, groupId, groupName, sendUserId, messageId);
        JSONObject object = new JSONObject();
        object.put("tradeNo", orderNo);
        object.put("groupId", groupId);
        object.put("sendUserId", sendUserId);
        object.put("messageId", messageId);
        object.put("remark", subject);
        XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callMethod(luckyMoneyApi,
                "openNormalRp", openNormalRpRequest),
                "compose", transformer),
                "subscribe", new OpenCallback(object).target);
    }

    public static void CreateQR(Intent intent){
        String money = intent.getStringExtra("money");
        String mark = intent.getStringExtra("mark");
        long amount = (long)(Float.parseFloat(money)*100);
        try {
            createEnvelope(Long.valueOf(amount),1L,con_id,mark);
        } catch (Exception e) {
            e.printStackTrace();
            XposedBridge.log(e);
        }
    }

    /**
     * @param amount
     * @param number
     * @param conversation_id
     * @param subject
     * @throws Exception
     */
     static void createEnvelope(Long amount, Long number, String conversation_id, String subject) throws Exception {
        if (TextUtils.isEmpty(conversation_id)) {
            XposedBridge.log("群ID为空");
            PayHelperUtils.sendmsg(mcontext,"群ID为空,请到飞聊点击一个群之后重试");
            return;
        }
        initEnvelope();
        XposedBridge.log("金額 》》"+amount+"》》 备注 》》"+subject);
        String groupName = conversation_id;
        Enum[] enumConstants = TypeClass.getEnumConstants();//3="MULTI_RANDOM",4="MULTI_NORMAL"
        Object sendNormalRpRequest = SendNormalRpRequest.newInstance(amount, number, conversation_id, subject, enumConstants[3], groupName, null);
         XposedBridge.log("sendNormalRpRequest 》》"+sendNormalRpRequest);
        XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callMethod(luckyMoneyApi,
                "sendNormalRp", sendNormalRpRequest),
                "compose", transformer),
                "subscribe", new SendCallback(amount, subject).target);
    }

    private static class SendCallback implements InvocationHandler {
        private String remark;
        private Object target;
        private Long money;

        public SendCallback(Long amount, String orderId) {
            money = amount;
            this.remark = orderId;
            this.target = Proxy.newProxyInstance(mcontext.getClassLoader(), new Class[]{ConsumerClass}, this);
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            String json = JsonHelper.toJson(args[0]);
            XposedBridge.log(json);
            JSONObject jsonObject = new JSONObject(json);
            String pay_url = jsonObject.getString("pay_url");
            long rp_order_no = jsonObject.getLong("rp_order_no");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("rp_order_no=");
            stringBuilder.append(rp_order_no);
            stringBuilder.append("\npay_url=");
            stringBuilder.append(pay_url);
            XposedBridge.log(stringBuilder.toString());
            JSONObject object = new JSONObject();
            //
            Intent v2 = new Intent();
            v2.putExtra("type", AppConst.TYPE_FL);
            v2.putExtra("mark", remark);
            v2.putExtra("money", ""+(((float)(money))/100f));
            v2.putExtra("payurl", pay_url);
            v2.putExtra("img_url",""+rp_order_no);
            v2.setAction(AppConst.QRCODERECEIVED_ACTION);
            mcontext.sendBroadcast(v2);
            return null;
        }
    }

    private class OpenCallback implements InvocationHandler {
        private JSONObject object;
        private Object target;

        public OpenCallback(JSONObject object) {
            this.object = object;
            this.target = Proxy.newProxyInstance(mcontext.getClassLoader(), new Class[]{ConsumerClass}, this);
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            String json = JsonHelper.toJson(args[0]);
            XposedBridge.log(json);
            XposedBridge.log("has : 拆红包" + json);
            JSONObject jsonObject = new JSONObject(json);
            JSONObject errorjsonObject = jsonObject.optJSONObject("base_resp");
            long amount = 0;
            long recv_time = 0;
            String remark = "";
            if(errorjsonObject == null){
                amount = jsonObject.optLong("amount");
                recv_time = jsonObject.optLong("recv_time");
                remark = object.optString("remark");
            }else{
                String msg = errorjsonObject.optString("status_message");
                PayHelperUtils.sendmsg(mcontext,msg);
            }
            if ("OPENED".equals(jsonObject.getString("status"))) {
                //
                Intent broadCastIntent = new Intent();
                broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                broadCastIntent.putExtra("bill_type", AppConst.TYPE_FL);
                broadCastIntent.putExtra("bill_money", "" + (amount / 100f));
                broadCastIntent.putExtra("bill_mark", remark);
                broadCastIntent.putExtra("bill_no", remark);
                broadCastIntent.putExtra("bill_dt", "" + recv_time);
                mcontext.sendBroadcast(broadCastIntent);
                /*      WsClientTool.getSingleton().sendMessage(object.toString());*/
            }
            return null;
        }

    }
}
