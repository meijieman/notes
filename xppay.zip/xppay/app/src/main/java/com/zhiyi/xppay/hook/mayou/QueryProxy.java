package com.zhiyi.xppay.hook.mayou;

/**
 * Created by pc_mg on 2019/4/10.
 */

import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class QueryProxy implements InvocationHandler {
    private String orderno;
    private Context context;
    public QueryProxy(String _orderno,Context _context){
        orderno = _orderno;
        context = _context;
    }
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String methodName = method.getName();
        XposedBridge.log("QueryProxy调用的方法名称为:" + methodName);
        XposedBridge.log("QueryProxy返回的类型为" + method.getReturnType().getName());
        if (methodName.equals("callback")) {
            try {
                ClassLoader loader = proxy.getClass().getClassLoader();
                byte[] bytes = (byte[]) args[0];
                if (bytes == null || bytes.length <= 0) {
                    return null;
                }
                Object pp = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.aoetech.aoelailiao.core.proto.ProtoBufPacket", loader), "getProtoBufInputByte", new Object[]{bytes});
                String result = ""+XposedHelpers.getObjectField(XposedHelpers.callMethod(XposedHelpers.getStaticObjectField(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.UserQueryPayResultAns", loader), "ADAPTER"), "decode", new Object[]{pp}), "pay_result_desc");
                XposedBridge.log("订单查询结果：" + result);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
