package com.zhiyi.xppay.net.Socket.RecevieMsg;

/**
 * Created by zhiyi on 2018/10/19.
 */

public class BuildQrcode {
    public String orderId="0";
    public int type;
    public String money;
    public String remark;
    public String paytype;
    public String qrcode;
    public String img_url;

    @Override
    public String toString() {
        return "BuildQrcode{" +
                "type=" + type +
                ",orderId='" + orderId +"'" +
                ",money='" + money +"'" +
                ",remark='" + remark +"'" +
                ",paytype='" + paytype +"'" +
                "}";
    }
}
