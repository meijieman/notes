package com.zhiyi.xppay.hook.xgj;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.zhiyi.xppay.hook.TradeQueryService;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/3/21.
 */

public class ServiceXGJTrade extends Service implements Runnable {
    private boolean isrunning = false;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(!isrunning){
            isrunning = true;
            XposedBridge.log("星管家轮询服务启动·················");
            new Thread(this).start();
        }
        return START_STICKY;
    }

    @Override
    public void run() {
        while(true){
            try {
                Thread.sleep(20000);
                XposedBridge.log("20秒 轮询一次");
                Intent intent = new Intent();
                intent.setAction(AppConst.ACTION_TRADEQUERY);
                sendBroadcast(intent);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void onDestroy() {
        super.onDestroy();
        // 如果Service被杀死 重启自己
        Intent intent = new Intent(getApplicationContext(),ServiceXGJTrade.class);
        startService(intent);
        isrunning = false;
    }
}
