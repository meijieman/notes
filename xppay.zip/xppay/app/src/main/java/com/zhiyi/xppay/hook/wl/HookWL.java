package com.zhiyi.xppay.hook.wl;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.AbSharedUtil;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.yst.consts.Appconsts;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;

/**
 * Created by pc_mg on 2019/5/25.
 */

public class HookWL {
    private static Context mcontext;
    private static ClassLoader mClassLoader;
    private static Class ConsumerClass;
    public void hook(final ClassLoader classLoader, final Context context) {
        final Class<?> clazz = XposedHelpers.findClass("com.stub.StubApp", classLoader); // onCreate
        XposedHelpers.findAndHookMethod(clazz, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log(" onCreate " + param.thisObject);
                Field field = XposedHelpers.findField(clazz, "ᵢˎ");
                XposedBridge.log(" onCreate field " + field.getClass().getName());
                field.setAccessible(true);
                Object obj = field.get(param.thisObject);
                Field fieldc = XposedHelpers.findField(clazz, "ᵢˑ");
                fieldc.setAccessible(true);
                Object objc = fieldc.get(param.thisObject);
                hook_real(obj.getClass().getClassLoader(), (Context) objc);
            }
        });
    }
    public void hook_real(ClassLoader classLoader, final Context context) {
        try {
            mcontext = context;
            mClassLoader = classLoader;
            XposedBridge.log("mClassLoader >>>"+mClassLoader);
            XposedHelpers.findAndHookMethod("com.jmxchat.im.main.activity.NewMainActivity", classLoader, "onResume", new Object[]{new XC_MethodHook() {
                protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                    try {
                        XposedBridge.log("NewMainActivityNewMainActivityNewMainActivityNewMainActivity");
                        PayHelperUtils.sendLoginId(getUid(), AppConst.TYPE_WL,context);
//                        PayHelperUtils.sendLoginId(context.getSharedPreferences("Demo", 0).getString("account", ""), AppConst.TYPE_WL, context);
                    } catch (Exception e) {
                        PayHelperUtils.sendmsg(context, e.getMessage());
                    }
                }
            }});
            XposedHelpers.findAndHookMethod("com.jmxchat.im.redpacket.zfb.activity.SendRedPacketsActivity", classLoader, "init", new Object[]{new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        PayHelperUtils.sendLoginId((String) XposedHelpers.getObjectField(XposedHelpers.getObjectField(param.thisObject, "redPacketInfo"), "groupId"), "wl_groupId", context);
                    } catch (Exception e) {
                        PayHelperUtils.sendmsg(context, e.getMessage());
                    }
                }
            }});
            XposedHelpers.findAndHookMethod("com.ems358.version.utils.Utils", classLoader, "isNeedUpdate", new Object[]{Context.class, Integer.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        param.setResult(Boolean.valueOf(false));
                    } catch (Exception e) {
                        PayHelperUtils.sendmsg(context, e.getMessage());
                    }
                }
            }});
            try {
                Class<?> groupParams = XposedHelpers.findClass("com.jmxchat.im.redpacket.zfb.model.params.GroupParams", classLoader);
                XposedHelpers.findAndHookMethod("com.jmxchat.im.redpacket.zfb.activity.SendRedPacketsActivity", classLoader, "sendGroupRedPacket", groupParams, new XC_MethodHook() {
                    /* Access modifiers changed, original: protected */
                    public void afterHookedMethod(MethodHookParam param) throws Throwable {
                        try {
                            Activity activity = (Activity) param.thisObject;
//                            mcontext = activity;
                            Object GroupParams = param.args[0];

                            String money = (String) XposedHelpers.getObjectField(GroupParams, "money");
                            String greeting = (String) XposedHelpers.getObjectField(GroupParams, "greeting");
                            String group_id = (String) XposedHelpers.getObjectField(GroupParams, "group_id");
                            String group_name = (String) XposedHelpers.getObjectField(GroupParams, "group_name");
                            String moneyType = (String) XposedHelpers.getObjectField(GroupParams, "moneyType");
                            String receiverUserIds = (String) XposedHelpers.getObjectField(GroupParams, "receiverUserIds");
                            String redPacketCount = (String) XposedHelpers.getObjectField(GroupParams, "redPacketCount");
                            //redPacketType
                            int redPacketType = (int) XposedHelpers.getObjectField(GroupParams, "redPacketType");
                            String senderUserId = (String) XposedHelpers.getObjectField(GroupParams, "senderUserId");
                            AbSharedUtil.putString(mcontext, "wl_group_id", group_id);
                            AbSharedUtil.putString(mcontext, "wl_group_name", group_name);
                            AbSharedUtil.putString(mcontext, "wl_moneyType", moneyType);
                            AbSharedUtil.putString(mcontext, "wl_senderUserId", senderUserId);
                            AbSharedUtil.putInt(mcontext, "wl_redPacketType", redPacketType);
                            XposedBridge.log("======money:" + money + " greeting:" + greeting + "  group_id:" + group_id + "  group_name:" + group_name + " moneyType:" + moneyType + " receiverUserIds:"
                                    + receiverUserIds + " redPacketCount:" + redPacketCount + " redPacketType:" + redPacketType + " senderUserId:" + senderUserId);
                        } catch (Exception e) {
                            XposedBridge.log("======ERROR:" + e.getMessage());
                            PayHelperUtils.sendmsg(mcontext, e.getMessage());
                        }
                    }
                });
                Class a = XposedHelpers.findClass("com.netease.nimlib.q.a", mClassLoader);
                XposedHelpers.findAndHookMethod("com.netease.nimlib.q.h", mClassLoader, "d", a, new XC_MethodHook() {
                    /* Access modifiers changed, original: protected */
                    public void afterHookedMethod(MethodHookParam param) throws Throwable {
                        try {
                            XposedBridge.log("==========com.netease.nimlib.q.h json:");

                            String Str = (String) XposedHelpers.callMethod(param.args[0], "a", new Object[]{Boolean.valueOf(false)});
                            XposedBridge.log("==========Str:");
                            JSONObject msgObject = new JSONObject((String) XposedHelpers.callMethod(param.args[0], "a", new Object[]{Boolean.valueOf(false)})).getJSONObject("msgObject");
                            XposedBridge.log("==========msgObject:" + msgObject.toString());
                            if (msgObject.has("money") && msgObject.has("redPacketGreeting") && msgObject.has("redPacketId")) {

                                final String money = msgObject.getString("money");
                                final String mark = msgObject.getString("redPacketGreeting");
                                final String redPacketId = msgObject.getString("redPacketId");
                                final String senderid = msgObject.getString("sendUserId");
                                final long time = ((long) (Math.random() * 1500.0d)) + 1500;

                                new Thread() {
                                    public void run() {
                                        super.run();
                                        try {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("========time sleep:");
                                            stringBuilder.append(time);
                                            XposedBridge.log(stringBuilder.toString());
                                            sleep(time);
                                        } catch (InterruptedException e) {
                                            StringBuilder stringBuilder2 = new StringBuilder();
                                            stringBuilder2.append("========time sleep error:");
                                            stringBuilder2.append(e.getMessage());
                                            XposedBridge.log(stringBuilder2.toString());
                                            e.printStackTrace();
                                        }

                                        if(senderid.equals(getUid())){
                                            checkRed(redPacketId, money, mark);
                                        }else{
                                            XposedBridge.log("这不是我发的包我不抢");
                                        }
                                    }
                                }.start();

//                                openRed(redPacketId, money, mark);
                            }
                        } catch (Exception e) {
                            XposedBridge.log("======ERROR:" + e.getMessage());
                            PayHelperUtils.sendmsg(mcontext, e.getMessage());
                        }
                    }
                });
            } catch (Throwable e) {
                XposedBridge.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                XposedBridge.log(e);
            }
        } catch (Throwable e) {
            XposedBridge.log("外面");
            XposedBridge.log(e);
        }
    }

    public void checkRed(String redpacketId, String money, String mark) {
        StringBuilder stringBuilder;
        try {
            Class<?> claRedHttp = XposedHelpers.findClass("com.jmxchat.im.repository.http.RedHttp", this.mClassLoader);
            stringBuilder = new StringBuilder();
            stringBuilder.append("======claRedHttp:");
            stringBuilder.append(claRedHttp);
            XposedBridge.log(stringBuilder.toString());
            if (this.ConsumerClass == null) {
                this.ConsumerClass = this.mClassLoader.loadClass("io.reactivex.functions.Consumer");
            }
            XposedHelpers.callMethod(XposedHelpers.callStaticMethod(claRedHttp, "queryRedPacket", getUid(), redpacketId), "subscribe", new checkRedCallback(redpacketId, mark, money).target);
        } catch (Exception e) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("=====pay error:");
            stringBuilder.append(e.getMessage());
            XposedBridge.log(stringBuilder.toString());
        }
    }

    public void openRed(String redpacketId, String money, String mark) {
        try {
            Class<?> claRedHttp = XposedHelpers.findClass("com.jmxchat.im.repository.http.RedHttp", mClassLoader);
            XposedBridge.log("======claRedHttp:" + claRedHttp);
            if (ConsumerClass == null) {
                ConsumerClass = mClassLoader.loadClass("io.reactivex.functions.Consumer");
            }
            String uid = getUid();
            XposedHelpers.callMethod(XposedHelpers.callStaticMethod(claRedHttp, "disburseRedPacket", uid, redpacketId), "subscribe", new PlayCallback(mark, money,redpacketId).target);
        } catch (Exception e) {
            XposedBridge.log("=====pay error:" + e.getMessage());
        }
    }

    private String getUid() {
        Class clazz = XposedHelpers.findClass("com.jmxchat.im.DemoCache", mClassLoader);
        Object account = XposedHelpers.callStaticMethod(clazz, "getAccount");
        Object tid = XposedHelpers.callStaticMethod(clazz, "getTid");
        return "" + account;
    }
    public static void CreateQR(Intent intent){
        String money = intent.getStringExtra("money");
        String mark = intent.getStringExtra("mark");
        try {
            sendGroupRedPacket(money,mark);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void sendGroupRedPacket(String money, String mark) throws Exception {

        String group_id = AbSharedUtil.getString(mcontext, "wl_group_id");

        if (group_id == null) {
//            Toast.makeText(mContext, "第一次请在页面手动发红包一次", Toast.LENGTH_SHORT).show();
            PayHelperUtils.sendmsg(mcontext,"第一次请在页面手动发红包一次");
            return;
        }
        String group_name = AbSharedUtil.getString(mcontext, "wl_group_name");
        String moneyType = AbSharedUtil.getString(mcontext, "wl_moneyType");
        int redPacketType = AbSharedUtil.getInt(mcontext, "wl_redPacketType");
        String senderUserId = AbSharedUtil.getString(mcontext, "wl_senderUserId");

        Class<?> claRedHttp = XposedHelpers.findClass("com.jmxchat.im.repository.http.RedHttp", mClassLoader);
        XposedBridge.log("======claRedHttp:" + claRedHttp);
        if (ConsumerClass == null) {
            ConsumerClass = mClassLoader.loadClass("io.reactivex.functions.Consumer");
        }
        XposedHelpers.callMethod(XposedHelpers.callStaticMethod(claRedHttp, "sendGroupRedPacket", money, "1", mark, senderUserId, "", redPacketType, moneyType
                , group_id, group_name), "subscribe", new SendCallback(mark, money).target);


    }

    private class PlayCallback implements InvocationHandler {

        private Object target;
        private String mMoney;
        private String mMark;
        private String redid;
        public PlayCallback(String mark, String money,String _redid) {
            this.target = Proxy.newProxyInstance(mClassLoader, new Class[]{ConsumerClass}, this);
            mMoney = money;
            mMark = mark;
            redid =_redid;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            XposedBridge.log("PlayCallback method funtcion >>>"+method.getName());
            Object json = args[0];
            XposedBridge.log("========pay json" + json.toString());
            int code = (int) XposedHelpers.callMethod(json, "getCode");
            String messagee = (String) XposedHelpers.callMethod(json, "getMessage");

            XposedBridge.log("========code:" + code + "    messagee:" + messagee);

            if(code != 1000) {
                PayHelperUtils.sendmsg(mcontext,"有红包未开，请手动领取");
                return null;
            }

            try {
                Object data = XposedHelpers.callMethod(json, "getData");

                String mark = (String) XposedHelpers.callMethod(data, "getOrder_title");
                String money = (String) XposedHelpers.callMethod(data, "getTotal_amount");

                XposedBridge.log("========mark:" + mark + "    money:" + money);

                Intent broadCastIntent = new Intent();
                broadCastIntent.putExtra("bill_no", mark);
                broadCastIntent.putExtra("bill_money", money);
                broadCastIntent.putExtra("bill_mark", mark);
                broadCastIntent.putExtra("bill_type", AppConst.TYPE_WL);
                broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                mcontext.sendBroadcast(broadCastIntent);
            } catch (Exception e) {

                XposedBridge.log("========open error" + e.getMessage());
            }
          /*  XposedBridge.log("========payUrl" + json);
            Intent broadCastIntent = new Intent();
            broadCastIntent.putExtra("type", "wxpay");
            broadCastIntent.putExtra("mark", mMark);
            broadCastIntent.putExtra("money", mMoney);
            broadCastIntent.putExtra("payurl", "" + json);
            broadCastIntent.setAction(Constant.QRCODERECEIVED_ACTION);
            mContext.sendBroadcast(broadCastIntent);
            XposedBridge.log("========回传payUrl" );*/
            return null;
        }
    }

    private static class SendCallback implements InvocationHandler {

        private Object target;
        private String mMoney;
        private String mMark;

        public SendCallback(String mark, String money) {
            this.target = Proxy.newProxyInstance(mClassLoader, new Class[]{ConsumerClass}, this);
            mMoney = money;
            mMark = mark;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            String json = args[0].toString();
            XposedBridge.log("========json" + json);

            XposedBridge.log("========payUrl" + json);

            //   playString(json,mMark,mMoney);
            Intent broadCastIntent = new Intent();
            broadCastIntent.putExtra("type", AppConst.TYPE_WL);
            broadCastIntent.putExtra("mark", mMark);
            broadCastIntent.putExtra("money", mMoney);
            broadCastIntent.putExtra("payurl", "" + json);
            broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
            mcontext.sendBroadcast(broadCastIntent);
            XposedBridge.log("========回传payUrl");
            return null;
        }
    }
    private class checkRedCallback implements InvocationHandler {
        private String mMark;
        private String mMoney;
        private String mRedPacketId;
        private Object target;

        public checkRedCallback(String redpacketId, String mark, String money) {
            this.target = Proxy.newProxyInstance(mClassLoader, new Class[]{ConsumerClass}, this);
            this.mRedPacketId = redpacketId;
            this.mMoney = money;
            this.mMark = mark;
        }

        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            XposedBridge.log("checkRedCallback method funtcion >>>"+method.getName());
            Object json = args[0];
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("========pay json");
            stringBuilder.append(json);
            XposedBridge.log(stringBuilder.toString());
            int code = ((Integer) XposedHelpers.callMethod(json, "getCode", new Object[0])).intValue();
            String messagee = (String) XposedHelpers.callMethod(json, "getMessage", new Object[0]);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("========code:");
            stringBuilder2.append(code);
            stringBuilder2.append("    messagee:");
            stringBuilder2.append(messagee);
            XposedBridge.log(stringBuilder2.toString());
            if (code == 1000) {
                try {
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("查詢紅包狀態：");
                    stringBuilder3.append(messagee);
                    XposedBridge.log(stringBuilder3.toString());
                    final long time = ((long) (Math.random() * 1500)) + 1500;
                    XposedBridge.log("========time:"+time);
                    new Thread() {
                        public void run() {
                            super.run();
                            try {
                                sleep(time);
                            } catch (InterruptedException e) {
                            }
                            openRed(checkRedCallback.this.mRedPacketId, checkRedCallback.this.mMoney, checkRedCallback.this.mMark);
                        }
                    }.start();
                } catch (Exception e) {
                    stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("========open error");
                    stringBuilder2.append(e.getMessage());
                    XposedBridge.log(stringBuilder2.toString());
                }
            } else {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append("错误：");
                stringBuilder2.append(messagee);
                XposedBridge.log(stringBuilder2.toString());
            }
            return null;
        }
    }
}
