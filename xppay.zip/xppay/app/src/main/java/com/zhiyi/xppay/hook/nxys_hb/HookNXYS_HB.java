package com.zhiyi.xppay.hook.nxys_hb;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.consts.AppConstsNxys;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/5/5.
 */

public class HookNXYS_HB {
    private static ClassLoader classLoader_real;
    private static Context context_real;
    private static Object objappnxys;
    private static String urlold = "http://nxt.nongxinyin.com/fvp-qp/qp.do?reqJson=";
    private static String urlnew = "https://nxt.nongxinyin.com/fvp-qp/security/qp.do";
    private static String urlCurrent;
    private static boolean isnewversion;
    public static boolean isactivitystart;
    public static boolean ishookeed;
    public static String loginid = "";
    private static HashMap<String,String> mapqrcode = new HashMap<String,String>();
    public void hook(ClassLoader classLoader,Context context){
        classLoader_real = context.getClassLoader();
        context_real = context;
        XposedHelpers.findAndHookMethod("com.buybal.buybalpay.base.BaseApplaction", classLoader, "onCreate", new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                if(objappnxys == null){
                    objappnxys = methodHookParam.thisObject;
                }
            }
        });
        hookreal(classLoader_real,context);
    }

    private void hookreal(ClassLoader classLoader,final Context context){
        String version = PayHelperUtils.getVerName(context_real);
        isnewversion = version.equals("2.1.5");
        urlCurrent = isnewversion?urlnew:urlold;
        Class clazzhome = XposedHelpers.findClass("com.buybal.buybalpay.activity.HomeActivity",classLoader);
        XposedHelpers.findAndHookMethod(clazzhome, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                //
                PayHelperUtils.LogMsg("*****************************");
                String str = getPhonenum((Context) param.thisObject);
                PayHelperUtils.LogMsg("登录账号>>"+str);
                if(TextUtils.isEmpty(str)) {
                    PayHelperUtils.sendmsg(context,"登录账号异常，请打开农信易扫登录");
                    return;
                }
                loginid = str;
                PayHelperUtils.sendLoginId(str, AppConstsNxys.TYPE_NXYS, context);
                PayHelperUtils.LogMsg("*****************************");
            }
        });
        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.buybal.buybalpay.net.okhttputil.OkhttpHelper", classLoader), "formPostAsynHttp", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("args[0] >>> "+param.args[0]+"args[1] >>>"+param.args[1]);
            }
        });
//        XposedHelpers.findAndHookMethod("com.buybal.buybalpay.net.okhttputil.OkhttpHelper", classLoader, "postAsynHttp", String.class, String.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                PayHelperUtils.LogMsg("OkhttpHelper postAsynHttp  args[0] >>> "+param.args[0]+"args[1] >>>"+param.args[1]);
//            }
//        });
//        XposedHelpers.findAndHookMethod("com.buybal.buybalpay.net.okhttputil.OkhttpHelper", classLoader, "getAsyHttp", String.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                PayHelperUtils.LogMsg("OkhttpHelper getAsyHttp  args[0] >>> "+param.args[0]);
//            }
//        });
//        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                PayHelperUtils.LogMsg("当前activity 》》》》"+param.thisObject.getClass().getName());
//            }
//        });
//        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.buybal.buybalpay.util.RequestUtils", classLoader), "getSearchMacode", new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                PayHelperUtils.LogMsg("RequestUtils getSearchMacode 》》》》"+param.args[2]+" --- "+param.args[3]+">>>"+param.getResult());
//            }
//        });
    }

    public static void CreateQR(final String money, final String mark,String type){
        String index = type.split(AppConstsNxys.TYPE_NXYS,2)[1];
        PayHelperUtils.LogMsg("请求二维码的索引》》》》"+index);
        if(TextUtils.isEmpty(index)){
            createqr(money,mark,type);
        }else{
            getStaticQRCode(money,mark,type,index);
        }
    }

    public static void getStaticQRCode(final String money, final String mark,String type,String index){
        try {
            if(mapqrcode.containsKey(index)){
                Intent v2 = new Intent();
                v2.putExtra("type", type);
                v2.putExtra("mark", mark);
                v2.putExtra("money", money);
                v2.putExtra("payurl", mapqrcode.get(index));
                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                context_real.sendBroadcast(v2);
                return;
            }
            PayHelperUtils.LogMsg("获取静态二维码》》》》》》》》》》》");
            //
            Class<?> clazzre = getRequestUtils();
            Object app = getApplication();
            Object o_encry = getEncry(app);
            Object o_req = XposedHelpers.callStaticMethod(clazzre, "getSearchMacode", app, o_encry, getCurrentshopId(), getCurrentLoginId());
            //
            final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
            Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
            Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new GetStaticQR(money,mark,type,index));
            XposedHelpers.callMethod(o_asy, "enqueue",call);
            //
        } catch (Exception e) {
            XposedBridge.log("eeee >>>>>>>>> " + e.fillInStackTrace());
        }
    }

    public static void createqr(final String money, final String mark,String type) {
        try {
            //
            Class<?> clazzre = getRequestUtils();
            Object app = getApplication();
            Object o_encry = getEncry(app);
            //
            Object o_money = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.buybal.framework.utils.AmountUtils", classLoader_real), "yesAmt", money);
            Object o_req = XposedHelpers.callStaticMethod(clazzre, "getReciveAmt", app, o_encry, o_money, mark);
            //
            final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
            Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
            Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new CreateQRCallBack(money, mark,type));
            XposedHelpers.callMethod(o_asy, "enqueue",call);
            //
        } catch (Exception e) {
            XposedBridge.log("eeee >>>>>>>>> " + e.fillInStackTrace());
        }
    }

    public static String getCurrentshopId(){
        Object object = getShopData();
        Object shopId = XposedHelpers.callMethod(object,"getShopId");
        return ""+shopId;
    }

    public static String getCurrentLoginId(){
        Object object = getShopData();
        Object loginid = XposedHelpers.callMethod(object,"getLoginId");
        return loginid+"";
    }

    private static Object getShopData(){
        Object object = getApplication();
        Object bean = XposedHelpers.getObjectField(object, "e");
        Object num = XposedHelpers.callMethod(bean, "getShopList");
        List shoplist = (List)num;
        if(shoplist.size()>0){
            Object shopdata = shoplist.get(0);
            return shopdata;
        }
        return null;
    }

    public static String getPhonenum(Context context) {
        Object object = getApplication();
        Object bean = XposedHelpers.getObjectField(object, "e");
        Object num = XposedHelpers.callMethod(bean, "getPhoneNum");
        if(num == null) return"";
        return String.valueOf(num);
    }
    private static Object getApplication() {
        return objappnxys;
    }
    private static Object getEncry(Object app) {
        Class<?> clazz = XposedHelpers.findClass("com.buybal.buybalpay.util.RequestNetutils", classLoader_real);
        Object o_rn = XposedHelpers.newInstance(clazz, app);
        Object o_encry = XposedHelpers.getObjectField(o_rn, "a");
        return o_encry;
    }

    private static Object GetAsy(Object o_req) {
        try {
            PayHelperUtils.LogMsg("o_req>>>>"+o_req);
            String encodestr = URLEncoder.encode(URLEncoder.encode("" + o_req, "utf-8"), "utf-8");
            String fullpath = urlold + encodestr;
            PayHelperUtils.LogMsg("fullpath>>>>"+fullpath);
            //
            Class<?> clazzhttph = XposedHelpers.findClass("com.buybal.buybalpay.net.okhttputil.OkhttpHelper", classLoader_real);
            Object o_httphelper = XposedHelpers.newInstance(clazzhttph);
            Object o_asy = XposedHelpers.callMethod(o_httphelper, "getAsyHttp", fullpath);
            return o_asy;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static Object PostFormAsy(Object o_req) {
        try {
            String encodestr = URLEncoder.encode("" + o_req, "utf-8");
            //
            Class<?> clazzhttph = XposedHelpers.findClass("com.buybal.buybalpay.net.okhttputil.OkhttpHelper", classLoader_real);
            Object o_httphelper = XposedHelpers.newInstance(clazzhttph);
            Object o_asy = XposedHelpers.callMethod(o_httphelper, "formPostAsynHttp", urlnew,encodestr);
            return o_asy;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void getalltrade() {
        if (TextUtils.isEmpty(getPhonenum(context_real))) {
            XposedBridge.log("农信易扫登录信息为空");
            return;
        }
        //
        Class<?> clazzre = getRequestUtils();
        Object app = getApplication();
        Object o_encry = getEncry(app);
        Object o_req = XposedHelpers.callStaticMethod(clazzre, "getAllstoreLsit", app, o_encry, "10006");
        //
        final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
        Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
        Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new GetAllStores());
        XposedHelpers.callMethod(o_asy, "enqueue", call);
        //
    }

    private static void getMonTrade(String shopid,String loginid){
        //
        Class<?> clazzre = getRequestUtils();
        Object app = getApplication();
        Object o_encry = getEncry(app);
        String date =  new SimpleDateFormat("yyyy-MM").format(Calendar.getInstance().getTime());
        Object o_req = XposedHelpers.callStaticMethod(clazzre, "getstoreOrdeLsit", app,o_encry,"10007",shopid,loginid,date,null,null,null);
        //
        final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
        Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
        Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new GetMonTrade());
        XposedHelpers.callMethod(o_asy, "enqueue",call);
    }

    private static void getDayTrade(String shopid,String loginid){
        //
        Class<?> clazzre = getRequestUtils();
        Object app = getApplication();
        Object o_encry = getEncry(app);
        String date =  new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());
        Object o_req = XposedHelpers.callStaticMethod(clazzre, "getstoreOrdeLsit", app, o_encry,"10008",shopid,loginid,date,"1","15",null);
        //
        final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
        Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
        Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new GetDayTrade(date));
        XposedHelpers.callMethod(o_asy, "enqueue", call);
    }

    private static Class<?> getRequestUtils() {
        return XposedHelpers.findClass("com.buybal.buybalpay.util.RequestUtils", classLoader_real);
    }
    static class GetMonTrade implements InvocationHandler {
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            return null;
        }
    }
    static class GetDetailTrade implements InvocationHandler{
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                PayHelperUtils.LogMsg("GetDetailTrade strbody >>>>>>>> "+strbody);
//              {"amount":"w6b64Bjxvmc=","orderId":"00005415570452510374762020","realPayAmt":"w6b64Bjxvmc=","fee":"0.00","merCoupon":"VLTDeMvpMVc=","memberName":"","remark":"","channeiOrderId":"2019050510052000100278426394","source":"支付宝","payState":"支付成功","parentOrderNo":"","retCode":"0000","retMsg":"成功","orderTime":"2019-05-05 16:34:11","displayOutlay":"0","merReciveAmt":"w6b64Bjxvmc=","seq":"20190505163505000022","funCode":"10009","sign":"LdvnczlzLS9aXeBMLqErc55BlDrLO2YLx/JX0fbdEYzvers4XLtYAg=="}

            }
            return null;
        }
    }

    static class GetDayTrade implements InvocationHandler{
        String date;
        public GetDayTrade(String _date){
            date = _date;
        }
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("GetDayTrade method.getName() >>>>>>>> " + method.getName());
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                XposedBridge.log("strbody >>>>>>>> "+strbody);
                PayHelperUtils.LogMsg("strbody >>>>>>>> "+strbody);
                JSONObject json = new JSONObject(strbody);
                JSONArray orderlist = json.optJSONArray("orderList");
                if(orderlist!=null){
                    int length = orderlist.length();
                    length = length>=10?10:length;
                    for (int i = 0; i <length; i++) {
                        JSONObject object = orderlist.getJSONObject(i);
                        String payTime = object.getString("orderTime");
                        payTime = date+" "+payTime;
                        payTime = PayHelperUtils.dateToStamp(payTime,"yyyy-MM-dd HH:mm:ss");
                        String orderId = object.getString("orderId");
                        String realAmount = object.getString("amount");
//                        getDetailTrade(orderId);
                        //
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                        broadCastIntent.putExtra("bill_type", AppConstsNxys.TYPE_NXYS);
                        broadCastIntent.putExtra("bill_money", realAmount);
                        broadCastIntent.putExtra("bill_mark", orderId);
                        broadCastIntent.putExtra("bill_no", orderId);
                        broadCastIntent.putExtra("bill_dt", payTime);
                        context_real.sendBroadcast(broadCastIntent);
                        //
                        Thread.sleep(200);
                    }
                }
            }
            return null;
        }
    }

    static class GetAllStores implements InvocationHandler {
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("GetAllStores method.getName() >>>>>>>> " + method.getName());
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                XposedBridge.log("strbody >>>>>>>> "+strbody);
                PayHelperUtils.LogMsg("GetAllStores strbody >>>>>>>> "+strbody);
                JSONObject json = new JSONObject(strbody);
                JSONArray storearr = json.getJSONArray("storeList");
                for(int i = 0;i<storearr.length();i++){
                    JSONObject storedata = storearr.optJSONObject(i);
                    String shopid =storedata.optString("shopId");
                    String loginid = storedata.optString("loginId");
                    XposedBridge.log("shopid >>>>>>>>> "+shopid+">>>loginid+>>>"+loginid);
                    PayHelperUtils.LogMsg("shopid >>>>>>>>> "+shopid+">>>loginid+>>>"+loginid);
                    getMonTrade(shopid,loginid);
                    getDayTrade(shopid,loginid);
                }
            }
            return null;
        }
    }

    static class CreateQRCallBack implements InvocationHandler {
        private String money;
        private String mark;
        private String type;
        public CreateQRCallBack(String _money, String _mark,String _type) {
            money = _money;
            mark = _mark;
            type = _type;
        }

        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("CreateQRCallBack method.getName() >>>>>>>> " + method.getName());
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                JSONObject json = new JSONObject(strbody);
                XposedBridge.log("CreateQRCallBack json >>>>>>>>>>>>>>>> "+json);
                PayHelperUtils.LogMsg("CreateQRCallBack json >>>>>>>>>>>>>>>> "+json);
                String payurl = json.getString("codeUrl");
                Intent v2 = new Intent();
                v2.putExtra("type", type);
                v2.putExtra("mark", mark);
                v2.putExtra("money", money);
                v2.putExtra("payurl", payurl);
                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                context_real.sendBroadcast(v2);
                //
            } else if (method.getName().contains("onError")) {
                XposedBridge.log("openhongbao  onError==>" + objects[0] + "---" + objects[1]);
            }
            return null;
        }
    }

    static class GetStaticQR implements InvocationHandler{

        private String money;
        private String mark;
        private String type;
        private String index;
        public GetStaticQR(String _money, String _mark,String _type,String _index) {
            money = _money;
            mark = _mark;
            type = _type;
            index = _index;
        }

        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("GetStaticQR method.getName() >>>>>>>> " + method.getName());
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                JSONObject json = new JSONObject(strbody);
                XposedBridge.log("GetStaticQRCallBack json >>>>>>>>>>>>>>>> "+json);
                PayHelperUtils.LogMsg("GetStaticQRCallBack json >>>>>>>>>>>>>>>> "+json);
                JSONArray array = json.optJSONArray("codeList");
                if(array!=null){
                    for(int i = 0;i<array.length();i++){
                        JSONObject code = array.optJSONObject(i);
                        String codetype = code.optString("codeType");
                        String codeurl = code.optString("codeUrl");
                        mapqrcode.put(codetype,codeurl);
                    }
                }

                Intent v2 = new Intent();
                v2.putExtra("type", type);
                v2.putExtra("mark", mark);
                v2.putExtra("money", money);
                v2.putExtra("payurl", mapqrcode.get(index));
                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                context_real.sendBroadcast(v2);
                //
            } else if (method.getName().contains("onError")) {
                XposedBridge.log("GetStaticQRCallBack  onError==>" + objects[0] + "---" + objects[1]);
            }
            return null;
        }
    }
}
