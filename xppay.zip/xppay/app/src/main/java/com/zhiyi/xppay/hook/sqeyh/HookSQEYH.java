package com.zhiyi.xppay.hook.sqeyh;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.zhiyi.xppay.utils.PayHelperUtils;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/6/12.
 */

public class HookSQEYH {
    public void hook(final ClassLoader appClassLoader, final Context context) {
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("~~~~~~~~~~~平安商户管家当前activity>>>>>>"+param.thisObject.getClass().getName());
            }
        });
        XposedBridge.hookAllConstructors(XposedHelpers.findClass("com.froad.froadsqbk.base.libs.views.SocialBankWebView", appClassLoader), new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("SocialBankWebView >>>>>>>>>>>>>>>>>>> "+param.thisObject);
            }
        });
        XposedHelpers.findAndHookMethod(XposedHelpers.findClass("com.froad.froadsqbk.base.libs.views.SocialBankWebView", appClassLoader), "a",String.class,new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("SocialBankWebView a >>>>>>>>>>>>>>>>>>> "+param.thisObject);
            }
        });
        XposedHelpers.findAndHookMethod(WebView.class, "setWebViewClient",WebViewClient.class,new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("WebView setWebViewClient >>>>>>>>>>>>>>>>>>> "+param.args[0].getClass().getName());
                XposedBridge.log(new Exception("--- 异常 ---"));
            }
        });
        XposedHelpers.findAndHookMethod("com.froad.froadsqbk.base.libs.views.fragments.d$9", appClassLoader, "shouldOverrideUrlLoading", WebView.class, String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("WebView setWebViewClient >>>>>>>>>>>>>>>>>>> "+param.args[0].getClass().getName()+">> str >> "+param.args[1]);
            }
        });
    }
}
