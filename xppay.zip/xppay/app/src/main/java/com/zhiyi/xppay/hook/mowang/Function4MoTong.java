package com.zhiyi.xppay.hook.mowang;

import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.mayou.HookMayou;
import com.zhiyi.xppay.hook.mayou.ToolsMY;
import com.zhiyi.xppay.utils.JsonHelper;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/4/13.
 */

public class Function4MoTong implements InvocationHandler {
    private String no;
    private String mark;
    private Context context;
    private Object object;
    private Object redinfo;
    private Object message;
    public Function4MoTong(Context _context, String _no, String _mark,Object _object,Object _redinfo,Object _message){
        no = _no;
        mark = _mark;
        context = _context;
        object = _object;
        redinfo = _redinfo;
        message = _message;
    }
    @Override
    public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
        String methodName = method.getName();
        XposedBridge.log("Function4MoTong 调用的方法名称为:" + methodName);
        XposedBridge.log("Function4MoTong 返回的类型为" + method.getReturnType().getName());
        XposedBridge.log("Function4MoTong >>>>>>> 结果"+objects[0]);
        try{
            if (methodName.equals("invoke")) {
                int result = (int)objects[0];
                if (result == 10 || result == 0||result == 1) {
                    String money = ToolsMY.removeBean(mark);
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("bill_no", this.no);
                    broadCastIntent.putExtra("bill_money", money);
                    broadCastIntent.putExtra("bill_mark", this.mark);
                    broadCastIntent.putExtra("bill_type", AppConst.TYPE_MY);
                    broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                    this.context.sendBroadcast(broadCastIntent);
                    HookMoTong.queryTradeMW.receiveOrderBean(object);
//                    HookMoTong.updateRedMessage(redinfo,message,1);
                    XposedBridge.log("领取成功");
                    XposedBridge.log("红包备注>>>>"+mark);
                }else if (result != 3){
//                    HookMoTong.updateRedMessage(redinfo,message,result);
                }
            }
        }catch(Exception e){

        }
        return null;
    }
}
