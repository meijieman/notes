package com.zhiyi.xppay.hook.mayou;

/**
 * Created by pc_mg on 2019/4/10.
 */

public class MayouOrder {
    private long creattime;
    private String mark;
    private String pay_order_no;

    public String getMark() {
        return this.mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getPay_order_no() {
        return this.pay_order_no;
    }

    public void setPay_order_no(String pay_order_no) {
        this.pay_order_no = pay_order_no;
    }

    public long getCreattime() {
        return this.creattime;
    }

    public void setCreattime(long creattime) {
        this.creattime = creattime;
    }
}