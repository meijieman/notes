package com.zhiyi.xppay.hook.dingding;

import android.content.Intent;


import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.RimetHook;
import com.zhiyi.xppay.utils.PayHelperUtils;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class OpenCnyImpl {
    private ClassLoader classLoader;
    private String clusterid;
    private int errNum;
    private String sender;

    public OpenCnyImpl(ClassLoader classLoader, String str, String str2, int i) {
        this.classLoader = classLoader;
        this.sender = str;
        this.clusterid = str2;
        this.errNum = i;
    }

    void onDataReceived(Object obj) {
        try {
            if (XposedHelpers.getObjectField(obj, "pickStatus").toString().equals("1")) {
                XposedBridge.log("catch re package ok");
                Object objectField = XposedHelpers.getObjectField(obj, "redEnvelopCluster");
                PayHelperUtils.traceObject(objectField);
                String tradeNo = ""+XposedHelpers.getObjectField(objectField, "businessId");
                String amount =""+ XposedHelpers.getObjectField(objectField, "amount");
//                String clusterId = ""+XposedHelpers.getObjectField(objectField, "clusterId");
                Intent intent = new Intent();
                intent.setAction(AppConst.BILLRECEIVED_ACTION);

//                String no = intent.getStringExtra("bill_no");
//                String money = intent.getStringExtra("bill_money");
//                String mark = intent.getStringExtra("bill_mark");
//                String type = intent.getStringExtra("bill_type");

                intent.putExtra("bill_type", AppConst.TYPE_DingDing);
                intent.putExtra("bill_money", amount);
                intent.putExtra("bill_mark", tradeNo);
                intent.putExtra("bill_no", tradeNo);
                RimetHook.context.sendBroadcast(intent);
                XposedBridge.log("open red package ok");
                return;
            }
            OpenRedpacketThread2 openRedpacketThread2 = new OpenRedpacketThread2(this.classLoader, this.sender, this.clusterid, this.errNum + 1);
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    void onException(String str, String str2) {
        XposedBridge.log("OpenCnyImpl onException");
        OpenRedpacketThread2 openRedpacketThread2 = new OpenRedpacketThread2(this.classLoader, this.sender, this.clusterid, this.errNum + 1);
    }

    void onProgress(Object obj, int i) {
        XposedBridge.log("OpenCnyImpl onProgress");
    }
}