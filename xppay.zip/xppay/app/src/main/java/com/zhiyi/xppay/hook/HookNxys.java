package com.zhiyi.xppay.hook;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.consts.AppConstsNxys;
import com.zhiyi.xppay.hook.taobao.HookTB;
import com.zhiyi.xppay.utils.DBManagerNxys;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.ToolsNxys;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/3/6.
 */

public class HookNxys {
    private static ClassLoader classLoader_real;
    private static Context context_real;
    private static String url = "https://nxt.nongxinyin.com/fvp-qp/security/qp.do";
    public static String loginid = "";
    private static Object objappnxys;
    private static boolean isnewversion;
//    private static String urlnew = "https://nxt.nongxinyin.com/fvp-qp/security/qp.do";
//    private static DBManagerNxys dbManager;
    private static boolean ishook;

    private static HashMap<String,String> mapqrcode = new HashMap<String,String>();
    public void hook(final ClassLoader _classLoader, final Context _context) {
        classLoader_real = _context.getClassLoader();
        context_real = _context;
        XposedHelpers.findAndHookMethod("com.buybal.buybalpay.base.BaseApplaction", _classLoader, "onCreate", new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                if(objappnxys == null){
                    objappnxys = methodHookParam.thisObject;
                }
            }
        });
        hookreal(classLoader_real,_context);
    }

    private void hookreal(ClassLoader classLoader,final Context context){
        String version = PayHelperUtils.getVerName(context_real);
        isnewversion = version.equals("2.1.8");
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("当前Acivity >>>>"+param.thisObject.getClass().getName());
            }
        });
        Class clazzhome = XposedHelpers.findClass("com.buybal.buybalpay.activity.HomeActivity",classLoader);
        XposedHelpers.findAndHookMethod(clazzhome, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                //
                PayHelperUtils.LogMsg("*****************************");
                String str = getPhonenum((Context) param.thisObject);
                PayHelperUtils.LogMsg("登录账号>>"+str);
                if(TextUtils.isEmpty(str)) {
                    PayHelperUtils.sendmsg(context,"登录账号异常，请打开农信易扫登录");
                    return;
                }
                loginid = str;
                PayHelperUtils.sendLoginId(str, AppConstsNxys.TYPE_NXYS, context);
//                new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//                        try {
//                            Thread.sleep(2000);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
//                        PayHelperUtils.sendmsg(context,"切回到监控页面");
//                        PayHelperUtils.forceOpenSelf(context);
//                    }
//                }).start();
                PayHelperUtils.LogMsg("*****************************");
            }
        });
        final Class clazzlogin = XposedHelpers.findClass("com.buybal.buybalpay.activity.LoginActivity",classLoader);
        PayHelperUtils.LogMsg("clazzlogin >>>>>>>> "+clazzlogin);
        XposedHelpers.findAndHookMethod("com.buybal.buybalpay.activity.LoginActivity", classLoader, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                final Object objactivity = param.thisObject;
                Object objc = XposedHelpers.getObjectField(objactivity,"d");
                Object objd = XposedHelpers.getObjectField(objactivity,"e");
                String trim = ((EditText)objc).getText().toString().trim();
                String trim2 = ((EditText)objd).getText().toString().trim();
                PayHelperUtils.LogMsg("trim >>>>>>>>>"+trim+">>trim2"+trim2);
                if(!TextUtils.isEmpty(trim)&&!TextUtils.isEmpty(trim2)){
                    PayHelperUtils.sendmsg(context,"农信易扫正在重新登录");
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(3000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            if(TextUtils.isEmpty(loginid)){
                                XposedHelpers.callMethod(objactivity,"loginNet",new Object[]{null});
                            }
                        }
                    }).start();
                }
                Object objm = XposedHelpers.getObjectField(objactivity,"y");// x

                Object objx = XposedHelpers.getObjectField(objactivity,"x");
                PayHelperUtils.LogMsg("objmy class>>>>>>>>>"+objm.getClass());
                PayHelperUtils.LogMsg("objx class>>>>>>>>>"+objx.getClass());
            }
        });
        XposedHelpers.findAndHookMethod("com.buybal.buybalpay.activity.LoginActivity$2", classLoader, "onHttpSuccess", Message.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                Message msg = (Message)param.args[0];
                PayHelperUtils.LogMsg("LoginActivity$2》》》》"+msg.obj.toString());
            }
        });
        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.buybal.buybalpay.net.okhttputil.OkhttpHelper", classLoader), "formPostAsynHttp", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("args[0] >>> "+param.args[0]+"args[1] >>>"+param.args[1]);
            }
        });
    }

    public static void CreateQR(final String money, final String mark,String type){
        String index = type.split(AppConstsNxys.TYPE_NXYS,2)[1];
        PayHelperUtils.LogMsg("请求二维码的索引》》》》"+index);
        if(TextUtils.isEmpty(index)){
            createqr(money,mark,type);
        }else{
            getStaticQRCode(money,mark,type,index);
        }
    }

    public static void getStaticQRCode(final String money, final String mark,String type,String index){
        try {
            if(mapqrcode.containsKey(index)){
                Intent v2 = new Intent();
                v2.putExtra("type", type);
                v2.putExtra("mark", mark);
                v2.putExtra("money", money);
                v2.putExtra("payurl", mapqrcode.get(index));
                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                context_real.sendBroadcast(v2);
                return;
            }
            PayHelperUtils.LogMsg("获取静态二维码》》》》》》》》》》》");
            //
            Class<?> clazzre = getRequestUtils();
            Object app = getApplication();
            Object o_encry = getEncry(app);
            Object o_req = XposedHelpers.callStaticMethod(clazzre, "getSearchMacode", app, o_encry, getCurrentshopId(), getCurrentLoginId());
            //
            final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
            Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
            Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new GetStaticQR(money,mark,type,index));
            XposedHelpers.callMethod(o_asy, "enqueue",call);
            //
        } catch (Exception e) {
            XposedBridge.log("eeee >>>>>>>>> " + e.fillInStackTrace());
        }
    }

    public static void createqr(final String money, final String mark,String type) {
        try {
            //
            Class<?> clazzre = getRequestUtils();
            Object app = getApplication();
            Object o_encry = getEncry(app);
            //
            Object o_money = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.buybal.framework.utils.AmountUtils", classLoader_real), "yesAmt", money);
            Object o_req = XposedHelpers.callStaticMethod(clazzre, "getReciveAmt", app, o_encry, o_money, mark);
            //
            final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
            Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
            Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new CreateQRCallBack(money, mark,type));
            XposedHelpers.callMethod(o_asy, "enqueue",call);
            //
        } catch (Exception e) {
            XposedBridge.log("eeee >>>>>>>>> " + e.fillInStackTrace());
        }
    }

    public static String getCurrentshopId(){
        Object object = getShopData();
        Object shopId = XposedHelpers.callMethod(object,"getShopId");
        return ""+shopId;
    }

    public static String getCurrentLoginId(){
        Object object = getShopData();
        Object loginid = XposedHelpers.callMethod(object,"getLoginId");
        return loginid+"";
    }

    private static Object getShopData(){
        Object object = getApplication();
        Object bean = XposedHelpers.getObjectField(object, "e");
        Object num = XposedHelpers.callMethod(bean, "getShopList");
        List shoplist = (List)num;
        if(shoplist.size()>0){
            Object shopdata = shoplist.get(0);
            return shopdata;
        }
        return null;
    }

    public static String getPhonenum(Context context) {
        Object object = getApplication();
        Object bean = XposedHelpers.getObjectField(object, "e");
        Object num = XposedHelpers.callMethod(bean, "getPhoneNum");
        if(num == null) return"";
        return String.valueOf(num);
    }
    private static Object getApplication() {
        return objappnxys;
    }
    private static Object getEncry(Object app) {
        Class<?> clazz = XposedHelpers.findClass("com.buybal.buybalpay.util.RequestNetutils", classLoader_real);
        Object o_rn = XposedHelpers.newInstance(clazz, app);
        Object o_encry = XposedHelpers.getObjectField(o_rn, "a");
        return o_encry;
    }

    private static Object GetAsy(Object o_req) {
        return null;
    }

    private static Object PostFormAsy(Object o_req) {
        try {
            String encodestr = URLEncoder.encode("" + o_req, "utf-8");
            //
            Class<?> clazzhttph = XposedHelpers.findClass("com.buybal.buybalpay.net.okhttputil.OkhttpHelper", classLoader_real);
            Object o_httphelper = XposedHelpers.newInstance(clazzhttph);
            Object o_asy = XposedHelpers.callMethod(o_httphelper, "formPostAsynHttp", url,encodestr);
            return o_asy;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void getalltrade() {
        if (TextUtils.isEmpty(getPhonenum(context_real))) {
            XposedBridge.log("农信易扫登录信息为空");
            return;
        }
        //
        Class<?> clazzre = getRequestUtils();
        Object app = getApplication();
        Object o_encry = getEncry(app);
        Object o_req = XposedHelpers.callStaticMethod(clazzre, "getAllstoreLsit", app, o_encry, "10006");
        //
        final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
        Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
        Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new GetAllStores());
        XposedHelpers.callMethod(o_asy, "enqueue", call);
        //
    }

    private static void getMonTrade(String shopid,String loginid){
        //
        Class<?> clazzre = getRequestUtils();
        Object app = getApplication();
        Object o_encry = getEncry(app);
        String date =  new SimpleDateFormat("yyyy-MM").format(Calendar.getInstance().getTime());
        Object o_req = XposedHelpers.callStaticMethod(clazzre, "getstoreOrdeLsit", app,o_encry,"10007",shopid,loginid,date,null,null,null);
        //
        final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
        Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
        Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new GetMonTrade());
        XposedHelpers.callMethod(o_asy, "enqueue",call);
    }

    private static void getDayTrade(String shopid,String loginid){
        //
        Class<?> clazzre = getRequestUtils();
        Object app = getApplication();
        Object o_encry = getEncry(app);
        String date =  new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());
        Object o_req = XposedHelpers.callStaticMethod(clazzre, "getstoreOrdeLsit", app, o_encry,"10008",shopid,loginid,date,"1","15",null);
        //
        final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
        Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
        Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new GetDayTrade(date));
        XposedHelpers.callMethod(o_asy, "enqueue", call);
    }

    private static void getBillDetail(String orderid){
        Class<?> clazzre = getRequestUtils();
        Object app = getApplication();
        Object o_encry = getEncry(app);
        Object o_req = XposedHelpers.callStaticMethod(clazzre, "getBillDetail", app, o_encry,"10009",orderid); final Object o_asy = isnewversion?PostFormAsy(o_req):GetAsy(o_req);
        Class<?> clazzcallback = XposedHelpers.findClass("okhttp3.Callback", classLoader_real);
        Object call = Proxy.newProxyInstance(classLoader_real, new Class[]{clazzcallback}, new BillDetail(o_encry));
        XposedHelpers.callMethod(o_asy, "enqueue", call);
    }

    private static Class<?> getRequestUtils() {
        return XposedHelpers.findClass("com.buybal.buybalpay.util.RequestUtils", classLoader_real);
    }

    static class BillDetail implements InvocationHandler{
        Object objencry;
        public BillDetail(Object o_encry){
            objencry = o_encry;
        }
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("getBillDetail method.getName() >>>>>>>> " + method.getName());
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                XposedBridge.log("strbody >>>>>>>> "+strbody);
//                PayHelperUtils.LogMsg("getBillDetail strbody >>>>>>>> "+strbody);
                JSONObject json = new JSONObject(strbody);
                String amount = json.optString("amount");
                Object desamount = XposedHelpers.callMethod(objencry,"getDecryptDES",amount);
                PayHelperUtils.LogMsg("desamount >>>>>>>> "+desamount);
            }
            return null;
        }
    }

    static class GetMonTrade implements InvocationHandler {
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            return null;
        }
    }

    static class GetDayTrade implements InvocationHandler{
        String date;
        public GetDayTrade(String _date){
            date = _date;
        }
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("GetDayTrade method.getName() >>>>>>>> " + method.getName());
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                XposedBridge.log("strbody >>>>>>>> "+strbody);
                PayHelperUtils.LogMsg("strbody >>>>>>>> "+strbody);
                JSONObject json = new JSONObject(strbody);
                JSONArray orderlist = json.optJSONArray("orderList");
                if(orderlist!=null){
                    int length = orderlist.length();
                    length = length>=10?10:length;
                    for (int i = 0; i <length; i++) {
                        JSONObject object = orderlist.getJSONObject(i);
                        String payTime = object.getString("orderTime");
                        payTime = date+" "+payTime;
                        payTime = PayHelperUtils.dateToStamp(payTime,"yyyy-MM-dd HH:mm:ss");
                        String orderId = object.getString("orderId");
                        String realAmount = object.getString("amount");
//                        getDetailTrade(orderId);
                        //
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                        broadCastIntent.putExtra("bill_type", AppConstsNxys.TYPE_NXYS);
                        broadCastIntent.putExtra("bill_money", realAmount);
                        broadCastIntent.putExtra("bill_mark", orderId);
                        broadCastIntent.putExtra("bill_no", orderId);
                        broadCastIntent.putExtra("bill_dt", payTime);
                        context_real.sendBroadcast(broadCastIntent);
                        //
                        getBillDetail(orderId);
                        //
                        Thread.sleep(200);
                    }
                }
            }
            return null;
        }
    }

    static class GetAllStores implements InvocationHandler {
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("GetAllStores method.getName() >>>>>>>> " + method.getName());
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                XposedBridge.log("strbody >>>>>>>> "+strbody);
                PayHelperUtils.LogMsg("GetAllStores strbody >>>>>>>> "+strbody);
                JSONObject json = new JSONObject(strbody);
                JSONArray storearr = json.getJSONArray("storeList");
                for(int i = 0;i<storearr.length();i++){
                    JSONObject storedata = storearr.optJSONObject(i);
                    String shopid =storedata.optString("shopId");
                    String loginid = storedata.optString("loginId");
                    XposedBridge.log("shopid >>>>>>>>> "+shopid+">>>loginid+>>>"+loginid);
                    PayHelperUtils.LogMsg("shopid >>>>>>>>> "+shopid+">>>loginid+>>>"+loginid);
                    getMonTrade(shopid,loginid);
                    getDayTrade(shopid,loginid);
                }
            }
            return null;
        }
    }

    static class CreateQRCallBack implements InvocationHandler {
        private String money;
        private String mark;
        private String type;
        public CreateQRCallBack(String _money, String _mark,String _type) {
            money = _money;
            mark = _mark;
            type = _type;
        }

        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("CreateQRCallBack method.getName() >>>>>>>> " + method.getName());
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                JSONObject json = new JSONObject(strbody);
                XposedBridge.log("CreateQRCallBack json >>>>>>>>>>>>>>>> "+json);
                PayHelperUtils.LogMsg("CreateQRCallBack json >>>>>>>>>>>>>>>> "+json);
                String payurl = json.getString("codeUrl");
                Intent v2 = new Intent();
                v2.putExtra("type", type);
                v2.putExtra("mark", mark);
                v2.putExtra("money", money);
                v2.putExtra("payurl", payurl);
                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                context_real.sendBroadcast(v2);
                //
            } else if (method.getName().contains("onError")) {
                XposedBridge.log("openhongbao  onError==>" + objects[0] + "---" + objects[1]);
            }
            return null;
        }
    }

    static class GetStaticQR implements InvocationHandler{

        private String money;
        private String mark;
        private String type;
        private String index;
        public GetStaticQR(String _money, String _mark,String _type,String _index) {
            money = _money;
            mark = _mark;
            type = _type;
            index = _index;
        }

        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            XposedBridge.log("GetStaticQR method.getName() >>>>>>>> " + method.getName());
            if (method.getName().contains("onResponse")) {
                Object obs = objects[1];
                Object o_body = XposedHelpers.callMethod(obs, "body");
                String strbody = "" + XposedHelpers.callMethod(o_body, "string");
                JSONObject json = new JSONObject(strbody);
                XposedBridge.log("GetStaticQRCallBack json >>>>>>>>>>>>>>>> "+json);
                PayHelperUtils.LogMsg("GetStaticQRCallBack json >>>>>>>>>>>>>>>> "+json);
                JSONArray array = json.optJSONArray("codeList");
                if(array!=null){
                    for(int i = 0;i<array.length();i++){
                        JSONObject code = array.optJSONObject(i);
                        String codetype = code.optString("codeType");
                        String codeurl = code.optString("codeUrl");
                        mapqrcode.put(codetype,codeurl);
                    }
                }

                Intent v2 = new Intent();
                v2.putExtra("type", type);
                v2.putExtra("mark", mark);
                v2.putExtra("money", money);
                v2.putExtra("payurl", mapqrcode.get(index));
                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                context_real.sendBroadcast(v2);
                //
            } else if (method.getName().contains("onError")) {
                XposedBridge.log("GetStaticQRCallBack  onError==>" + objects[0] + "---" + objects[1]);
            }
            return null;
        }
    }
}
