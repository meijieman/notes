package com.zhiyi.xppay.hook.sb;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * @author 大连致一科技
 * @ClassName: Main
 * @Description: 开始监控所有
 * @date 2018年11月7日 下午1:26:26
 */
public class Main implements IXposedHookLoadPackage {
    private static boolean SB_HOOK = false;
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam)
            throws Throwable {
        if (lpparam.appInfo == null || (lpparam.appInfo.flags & (ApplicationInfo.FLAG_SYSTEM |
                ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) {
            if (lpparam.appInfo != null) {
                XposedBridge.log("不能监控的包" + lpparam.appInfo.name + "," + lpparam.packageName);
            }
            return;
        }
        final String packageName = lpparam.packageName;
        final String processName = lpparam.processName;
        if(AppConst.APP_SB.equals(packageName)){
            XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Context context = (Context) param.args[0];
                    ClassLoader appClassLoader = context.getClassLoader();
                    if (AppConst.APP_SB.equals(processName) && !Main.SB_HOOK) {
                        SB_HOOK = true;
                        XposedBridge.log("handleLoadPackage: " + packageName);
                        PayHelperUtils.sendmsg(context, "扫呗Hook成功，当前扫呗版本:" + PayHelperUtils.getVerName(context) + ";");
                        ReceiverSB receiver = new ReceiverSB();
                        context.registerReceiver(receiver,receiver.filter);
                        new HookSB().hook(appClassLoader, context);
                    }
                }
            }});
        }
        else {
            XposedBridge.log("-----调试--------:" + lpparam.packageName);
        }
    }
}
