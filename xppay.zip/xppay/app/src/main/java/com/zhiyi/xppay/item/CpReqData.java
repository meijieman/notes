package com.zhiyi.xppay.item;

/**
 * Created by pc_mg on 2019/1/3.
 */

public class CpReqData {
    public final static int Status_New = 0;
    public final static int Status_Query = 1;
    public final static int Status_Error = 5;
    public final static int Status_Comp = 200;
    public CpReqData(String mark){
        this.mark = mark;
        this.orderid = "";
    }
    public String orderid;
    public String time;
    private String mark;
//    public void setOrderid(String oid){
//        orderid = oid;
//    }


    public String remark(){return mark;}
    public int status;
    public int times;
    public long reqTime;
//    @Override
//    public String toString() {
//        return orderid;
//    }
    @Override
    public boolean equals(Object obj) {
        if(obj instanceof CpReqData){
            CpReqData req = (CpReqData)obj;
            return mark.equals(req.mark);
//            if(orderid == null){
//            }
//            if(orderid.equals(req.orderid)){
//                return true;
//            }
        }
        return false;
    }
}
