package com.zhiyi.xppay.hook;

import android.app.Application;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class GpsHook {

    private double getLatitude(String packageName){
        return 100.0000;
    }
    private double getLongitude(String packageName){
        return 100.0000;
    }
    public void handPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (lpparam.packageName.equals("com.fakemygps.android")) {
            XposedHelpers.findAndHookMethod("com.fakemygps.android.Utils", lpparam.classLoader, "activeVersion", new Object[]{XC_MethodReplacement.returnConstant(Integer.valueOf(13))});
        }
        XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{
                Context.class, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                final Context context = (Context) param.args[0];
                final String packageName = context.getPackageName();
                    XposedHelpers.findAndHookMethod("android.location.Location", lpparam.classLoader, "getLatitude", new Object[]{new XC_MethodHook() {
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            if (!GpsHook.this.isSpoofing(packageName)) {
                                return;
                            }
                            Bundle extras = (Bundle) XposedHelpers.getObjectField(param.thisObject, "mExtras");
                            if (extras == null || !extras.getBoolean("copiedLocation")) {
                                param.setResult(GpsHook.this.getLatitude(packageName));
                            }
                        }
                    }});
                    XposedHelpers.findAndHookMethod("android.location.Location", lpparam.classLoader, "getLongitude", new Object[]{new XC_MethodHook() {
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {

                            if (!GpsHook.this.isSpoofing(packageName)) {
                                return;
                            }
                            Bundle extras = (Bundle) XposedHelpers.getObjectField(param.thisObject, "mExtras");
                            if (extras == null || !extras.getBoolean("copiedLocation")) {
                                param.setResult(Double.valueOf(GpsHook.this.getLatitude(packageName)));
                            }
                        }
                    }});
                    //海拔
//                    XposedHelpers.findAndHookMethod("android.location.Location", lpparam.classLoader, "getAltitude", new Object[]{new XC_MethodHook() {
//                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
//                            if (!GpsHook.this.isSpoofing(packageName)) {
//                                return;
//                            }
//                            Bundle extras = (Bundle) XposedHelpers.getObjectField(param.thisObject, "mExtras");
//                            if (extras == null || !extras.getBoolean("copiedLocation")) {
//                                try {
//                                    double alt = Double.valueOf(XposedHooks.mAltitude).doubleValue();
//                                    if (alt > Double.valueOf(PreferencesHelper.DEFAULT_ALTITUDE).doubleValue()) {
//                                        param.setResult(Double.valueOf(alt));
//                                    }
//                                } catch (NumberFormatException e) {
//                                    e.printStackTrace();
//                                }
//                            }
//                        }
//                    }});
                    XposedHelpers.findAndHookMethod("android.location.Location", lpparam.classLoader, "set", new Object[]{Location.class, new XC_MethodHook() {
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            if (!GpsHook.this.isSpoofing(packageName)) {
                                return;
                            }
                                Location location = (Location) param.args[0];
                                Bundle extras = location.getExtras();
                                if (extras == null) {
                                    extras = new Bundle();
                                }
                                extras.putBoolean("copiedLocation", true);
                                location.setExtras(extras);

                                location.setLatitude(GpsHook.this.getLatitude(packageName));
                                location.setLongitude(GpsHook.this.getLongitude(packageName));

                                param.args[0] = location;
                            }
                    }});
                    XposedHelpers.findAndHookMethod("android.location.Location", lpparam.classLoader, "setExtras", new Object[]{Bundle.class, new XC_MethodHook() {
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            if (!GpsHook.this.isSpoofing(packageName)) {
                                return;
                            }
                            if (GpsHook.isValidProvider(context, (Location) param.thisObject)) {
                                Bundle extras = (Bundle) param.args[0];
                                Bundle extrasThisLocation = (Bundle) XposedHelpers.getObjectField(param.thisObject, "mExtras");
                                if (extrasThisLocation != null && extrasThisLocation.getBoolean("copiedLocation")) {
                                    extras.putBoolean("copiedLocation", true);
                                    param.args[0] = extras;
                                }
                            }
                        }
                    }});
                }
        }});
    }

    private boolean isSpoofing(String packageName){
        return true;
    }

    private static boolean isValidProvider(Context context, Location location) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        List<String> providers = new ArrayList();
        if (locationManager != null) {
            providers = locationManager.getAllProviders();
        }
        if (providers == null) {
            providers = new ArrayList();
        }
        String provider = location.getProvider();
        if (providers.contains(provider) || (provider != null && provider.equals("fused"))) {
            return true;
        }
        return false;
    }
}
