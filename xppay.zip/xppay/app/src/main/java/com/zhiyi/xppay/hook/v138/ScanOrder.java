package com.zhiyi.xppay.hook.v138;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

import org.json.JSONObject;

import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/4/14.
 */

public class ScanOrder {
    static Object pageImpl;
    public static void HookH5Activity(final ClassLoader classLoader, final Context context){
        XposedBridge.log("testdebug  H5WebViewClient afterHookedMethod xxx");

        XposedHelpers.findAndHookMethod("com.alipay.mobile.nebulacore.ui.H5Activity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                super.afterHookedMethod(methodHookParam);
            }
        });
        XposedHelpers.findAndHookConstructor("com.alipay.mobile.nebulacore.Nebula", classLoader, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                super.afterHookedMethod(methodHookParam);
                XposedHelpers.setBooleanField(methodHookParam.thisObject, "DEBUG", true);
            }
        });
        XposedHelpers.findAndHookConstructor("com.alipay.mobile.nebulacore.web.H5WebViewClient", classLoader, XposedHelpers.findClass("com.alipay.mobile.nebulacore.core.H5PageImpl", classLoader), new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                super.afterHookedMethod(methodHookParam);
                Object obj = methodHookParam.args[0];
                if (obj != null) {
                    XposedBridge.log("testdebug H5WebViewClient afterHookedMethod 333");
                    pageImpl = obj;
                }else{
                    XposedBridge.log("testdebug H5WebViewClient afterHookedMethod 444 为null");
                }
            }
        });
        XposedHelpers.findAndHookMethod("com.alipay.android.phone.messageboxstatic.biz.dao.ServiceDao", classLoader, "queryMsginfoByOffset", String.class, Long.TYPE, Long.TYPE, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(methodHookParam.args[1]);
                stringBuilder.append("");
                String stringBuilder2 = stringBuilder.toString();
                XposedBridge.log("--------------  收款 ------------  ServiceDao  queryMsginfoByOffset");
                if (stringBuilder2.equals("0")) {
                    List<Object> objList = (List)XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alipay.mbxsgsg.d.c", classLoader), "a", methodHookParam.getResult());

                    if(objList.size()>0){
                        Object next = objList.get(0);

                        String str = (String) XposedHelpers.getObjectField(next, "content");
                        String str2 = (String) XposedHelpers.getObjectField(next, "msgState");
                        str2 = (String) XposedHelpers.getObjectField(next, "msgId");
                        str2 = JSON.toJSONString(next);
                        XposedBridge.log(str);
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(str2.contains("收款到账"));
                        stringBuilder3.append(" 消息==> ");
                        stringBuilder3.append(str2);
                        XposedBridge.log(stringBuilder3.toString());
                        if (str2.contains("点单号")) {
                            XposedBridge.log("--------------  扫码点单收款 ------------");
                            XposedBridge.log("扫码点单");
                            XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 222");
                            checkTableNo(classLoader,context);
                            XposedBridge.log("--------------  扫码点单收款end ------------");
                        }
                    }

                }
            }
        });
    }

    public static void checkTableNo(final ClassLoader classLoader,final Context context) {
        if (pageImpl != null) {
            XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() this.pageImpl != null");
            new Thread(new Runnable() {
                /* JADX WARNING: Removed duplicated region for block: B:10:0x009e  */
                /* Code decompiled incorrectly, please refer to instructions dump. */
                public void run() {
                    XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() run ");
                    Object callStaticMethod = null;
                    StringBuilder stringBuilder;
                    int i = 0;
                    try {
                        callStaticMethod = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alipay.mobile.nebulabiz.rpc.H5RpcUtil", classLoader),
                                "rpcCall", "alipay.merchant.reachShop.orderlist.query", "[{\"offset\":0,\"pageNum\":1,\"pageSize\":10,\"startRow\":0}]", "",
                                Boolean.valueOf(true), XposedHelpers.findClass("com.alibaba.fastjson.JSONObject", classLoader).newInstance(), "", Boolean.valueOf(false), pageImpl, Integer.valueOf(0),
                                "", Boolean.valueOf(false), Integer.valueOf(-1));
                        XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 10 ");

                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (InstantiationException e2) {
                        e2.printStackTrace();
                    }

                    XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 11 ");
                    String obj = XposedHelpers.callMethod(callStaticMethod, "getResponse", new Object[0]).toString();
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("stringRes is111 ");
                    stringBuilder2.append(obj);
//                    longLogPrint("完整=======:"+obj);
                    XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 12 ");
                    XposedBridge.log(stringBuilder2.toString());
                    if (!TextUtils.isEmpty(obj)) {
                        com.alibaba.fastjson.JSONObject parseObject = JSON.parseObject(obj);
                        if (parseObject.getBoolean("success").booleanValue()) {
                            JSONArray jSONArray = parseObject.getJSONArray("data");
                            JSONArray jSONArray2 = new JSONArray();
                            XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 13 ");
                            while (i < jSONArray.size()) {
                                com.alibaba.fastjson.JSONObject jSONObject = jSONArray.getJSONObject(i);
                                com.alibaba.fastjson.JSONObject jSONObject2 = new com.alibaba.fastjson.JSONObject();
                                Object string = jSONObject.getString("orderTime");
                                Object string2 = jSONObject.getString("realAmount");
                                Object string3 = jSONObject.getString("tableNo");
                                Object string4 = jSONObject.getString("orderId");
                                Object string5 = jSONObject.getString("buyerId");
                                jSONObject2.put("realAmount", string2);
                                jSONObject2.put("orderTime", string);
                                jSONObject2.put("tableNo", string3);
                                jSONObject2.put("orderId", string4);
                                jSONObject2.put("buyerId", string5);
                                jSONArray2.add(jSONObject2);
                                i++;
                            }
                            stringBuilder = new StringBuilder();
                            stringBuilder.append("JSONARRAY INFO is ");
                            stringBuilder.append(jSONArray2.toJSONString());
                            XposedBridge.log(stringBuilder.toString());

                            if(jSONArray2.size()>0){
                                com.alibaba.fastjson.JSONObject jsonObject = (com.alibaba.fastjson.JSONObject) jSONArray2.get(0);
                                Intent intent = new Intent();
                                // todo uid需要改
                                intent.putExtra("bill_user_id",  jsonObject.getString("buyerId"));
                                intent.putExtra("bill_no", jsonObject.getString("orderId"));
                                intent.putExtra("bill_money", jsonObject.getString("realAmount"));
                                intent.putExtra("bill_mark", "mark_alipay_meal");
                                intent.putExtra("bill_table_no", jsonObject.getString("tableNo"));

                                StringBuilder stringBuilder3 = new StringBuilder();
                                stringBuilder3.append(System.currentTimeMillis());
                                stringBuilder3.append("");
                                intent.putExtra("time", stringBuilder3.toString());
//                                intent.putExtra("bill_type", StringConstant.TYPE.ALIPAY_MEAL);
                                intent.putExtra("arrayInfo", jSONArray2.toJSONString());

                                XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 14 ");

//                                intent.setAction(StringConstant.BILLRECEIVED_ACTION);

                                XposedBridge.log("testdebug  发出广播");
                                context.sendBroadcast(intent);
                            }
                        }
                        XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 15 ");
                    }
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("H5Activity:: == >>>>  call action result is ");
                    stringBuilder.append(obj);
                    XposedBridge.log(stringBuilder.toString());
                    callStaticMethod = null;
                    String obj2 = XposedHelpers.callMethod(callStaticMethod, "getResponse", new Object[0]).toString();
                    StringBuilder stringBuilder22 = new StringBuilder();
                    stringBuilder22.append("stringRes is222 ");
                    stringBuilder22.append(obj2);

                    XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 14 ");
                    XposedBridge.log(stringBuilder22.toString());
                    if (TextUtils.isEmpty(obj2)) {
                    }
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("H5Activity:: == >>>>  call action result is ");
                    stringBuilder.append(obj2);

                    XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 15 ");
                    XposedBridge.log(stringBuilder.toString());

                    XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() 16 ");
                }
            }).start();
        } else {
            XposedBridge.log("Page对象为空");

            XposedBridge.log("testdebug alipayHook_scanOrders.checkTableNo() Page对象为空");
        }
    }
}
