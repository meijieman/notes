package com.zhiyi.xppay.hook.xiangliao;

import android.content.Context;
import android.content.IntentFilter;
import android.os.Bundle;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.StringUtils;

import java.lang.reflect.Proxy;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Chenkai on 2019/3/26.
 */

public class XLHook {

    private static ClassLoader mClassLoader;
    public static Context mContext;
    private static boolean hooked;
    private static String uid;
    public XLHook() {
        super();
    }

    static void access$000(ClassLoader arg0, Context arg1, String arg2, String arg3, String arg4, String arg5) {
        XLHook.getRedPacketDetail(arg0, arg1, arg2, arg3, arg4, arg5);
    }

    private static void getRedPacketDetail(ClassLoader arg11, Context arg12, String arg13, String arg14, String arg15, String arg16) {
        Object v8 = XposedHelpers.newInstance(XposedHelpers.findClass("com.ixl.talk.xlmm.base.api.b.d.a", arg11), new Object[]{Proxy.newProxyInstance(arg11, new Class[]{XposedHelpers.findClass("com.ixl.talk.xlmm.base.api.resp.IRequestCallBack", arg11)}, new GetRedPacketProxy(arg12, arg11, arg13, arg14, arg15, arg16))});
        XposedHelpers.setObjectField(v8, "b", arg13);
        XposedHelpers.setObjectField(v8, "c", arg14);
        XposedHelpers.callMethod(v8, "e", new Object[0]);
    }

    public static void hook(final ClassLoader classLoader, final Context arg9) {
        if(mContext == null) {
            mContext = arg9;
            mClassLoader = classLoader;
            PayHelperUtils.sendmsg(mContext, "乡聊Hook成功，当前乡聊版本:" + PayHelperUtils.getVerName(mContext));

            XLReceived receiver = new XLReceived(mContext);
            IntentFilter filter = new IntentFilter();
            filter.addAction(AppConst.TYPE_XiangLiao + AppConst.ACTION_BUILD_QRCODE);
            mContext.registerReceiver(receiver, filter);
        }
        mContext = arg9;
        if(hooked){
            if(uid!=null){
                PayHelperUtils.sendLoginId(uid, AppConst.TYPE_XiangLiao, mContext);
            }
            return;
        }
        XposedHelpers.findAndHookMethod(XposedHelpers.findClass("com.ixl.talk.xlmm.ui.activity.home.HomeActivity", mClassLoader), "onCreate",Bundle.class, new XC_MethodHook() {
            protected void afterHookedMethod(XC_MethodHook.MethodHookParam arg5) throws Throwable {
                super.afterHookedMethod(arg5);
                Object v1 = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.ixl.talk.xlmm.base.a.c", mClassLoader), "m", new Object[0]);
                uid = (String)v1;
                XposedBridge.log("----->userid=" + uid);
                PayHelperUtils.sendLoginId(uid, AppConst.TYPE_XiangLiao, mContext);
            }
        });
        Class v0 = XposedHelpers.findClass("com.ixl.talk.xlmm.base.imservice.entity.MessageEntity", mClassLoader);
        XposedHelpers.findAndHookMethod("com.ixl.talk.xlmm.base.imservice.base.db.IMDBManager", mClassLoader, "addMessageContent", v0, new XC_MethodHook() {
            protected void afterHookedMethod(XC_MethodHook.MethodHookParam arg7) throws Throwable {
                super.afterHookedMethod(arg7);
                XposedBridge.log("================插入数据 start==============");
                Object v0 = arg7.args[0];
                if (v0 != null && 7 ==(int) XposedHelpers.callMethod(XposedHelpers.getObjectField(v0, "msgType"), "get_value", new Object[0])) {
                    XposedBridge.log("=======收到红包消息:" + XposedHelpers.getObjectField(v0, "content"));

                }

                XposedBridge.log("================插入数据 end ==============");
            }
        });
        XposedHelpers.findAndHookMethod("com.ixl.talk.xlmm.base.imservice.base.db.IMDBManager", mClassLoader, "addTcpMessageContent", v0, Boolean.TYPE, new XC_MethodHook() {
            protected void afterHookedMethod(XC_MethodHook.MethodHookParam arg11) throws Throwable {
                super.afterHookedMethod(arg11);
                XposedBridge.log("================插入数据 start==============");
                Object v6 = arg11.args[0];
                if (v6 != null && 7 == (int)XposedHelpers.callMethod(XposedHelpers.getObjectField(v6, "msgType"), "get_value", new Object[0])) {
                    Object v7 = XposedHelpers.getObjectField(v6, "content");
                    XposedBridge.log("========收到红包消息:" + (((String) v7)));

                    XLHook.getRedPacketDetail(mClassLoader, mContext, StringUtils.getTextCenter(((String) v7), "RedPackAgeID\":", ","), StringUtils.getTextCenter(((String) v7), "PayType\":", ","), StringUtils.getTextCenter(((String) v7), "RedPackAmount\":", ",").replaceAll("\"", ""), StringUtils.getTextCenter(((String) v7), "RedPackDesc\":", ",").replaceAll("\"", ""));
                }

                XposedBridge.log("================插入数据 end ==============");
            }
        });
        hooked = true;
    }
}
