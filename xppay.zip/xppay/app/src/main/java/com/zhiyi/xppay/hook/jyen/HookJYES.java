package com.zhiyi.xppay.hook.jyen;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.StringUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/5/13.
 */

public class HookJYES {
    private static ClassLoader mclassLoader;
    private static Context mcontext;
    public static boolean isactivitystart;
    public static boolean ishookeed;
    public static String loginid;
    private static String staticqrurl;
    Handler mHandler;
    public void hook(ClassLoader classLoader, final Context context) {
        mcontext = context;
        mclassLoader = context.getClassLoader();
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if(param.thisObject.getClass().getName().equals("com.hnnx.sh.mbank.android.activity.MainActivity")){
                    PayHelperUtils.LogMsg("---------------------------");
                    PayHelperUtils.LogMsg("河南农信 金燕E商 MainActivity >>>>>> ");
                    if (mHandler == null) {
                        mHandler = new Handler() {
                            @Override
                            public void handleMessage(Message msg) {
                                super.handleMessage(msg);
                                if(msg.what == 1001){
                                    PayHelperUtils.startAPP(mcontext,AppConst.APP_JYES);
                                    PayHelperUtils.sendmsg(context,"定时拉起金燕e商");
                                    mHandler.sendEmptyMessageDelayed(1002,15000);
                                }else if(msg.what == 1002){
                                    PayHelperUtils.forceOpenSelf(context);
                                    PayHelperUtils.sendmsg(context,"定时拉起金燕e商成功");
                                    mHandler.sendEmptyMessageDelayed(1001, 300000);
                                }
                            }
                        };
                        mHandler.sendEmptyMessageDelayed(1001, 300000);
                    } else {
                        mHandler.removeMessages(1001);
                        mHandler.removeMessages(1002);
                    }
                }
            }
        });
    }

    static class Trade implements InvocationHandler{
        private int type;// 0是单1是全
        private String key;
        public Trade(int _type,String _key){
            type = _type;
            key = _key;
        }
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            String methodName = method.getName();
            Object obj = null;
            if(methodName.equals("a")){
                obj = objects[0];
                if(obj.getClass().getName().equals("okhttp3.Response")){
                    if (!Thread.currentThread().isInterrupted()) {
                        Object objbody = XposedHelpers.callMethod(obj,"body");
                        byte[] a = a(objbody);
                        if (!Thread.currentThread().isInterrupted()) {
                            if(a != null){
                                String result = new String(a,"UTF-8");
                                String deresult = ""+decode(result,key);
                                PayHelperUtils.LogMsg("解密之后的数据 》》》"+deresult);
                                //
                                if(type == 0){
                                    queryAllTrade(deresult);
                                }else{ // 全部订单
                                    JSONObject jsonObject = new JSONObject(deresult);
                                    JSONArray array = jsonObject.optJSONArray("LIST");
                                    if(array!=null&&array.length()>0){
                                        for(int i = 0;i<array.length();i++){
                                            JSONObject object = array.getJSONObject(i);
                                            String time = object.optString("MESS_TIME");
                                            time = PayHelperUtils.dateToStamp(time,"yyyy-MM-dd hh:mm:ss");
                                            String msg = object.optString("MESS_CONTENT");
                                            String money = StringUtils.getTextCenter(msg,"￥","元");
                                            String tradeNo = StringUtils.getTextCenter(msg,"订单号为","的订单");
                                            Intent broadCastIntent = new Intent();
                                            broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                                            broadCastIntent.putExtra("bill_type", AppConst.TYPE_JYES);
                                            broadCastIntent.putExtra("bill_money", money);
                                            broadCastIntent.putExtra("bill_mark", tradeNo);
                                            broadCastIntent.putExtra("bill_no", tradeNo);
                                            broadCastIntent.putExtra("bill_dt", time);
                                            mcontext.sendBroadcast(broadCastIntent);
                                        }
                                    }
                                }
                                //
                            }
                        }

                    }
                }
            }
            return null;
        }
    }

    static class QRCode implements InvocationHandler {
        private String key;
        private String money;
        private String mark;
        private String type;
        private boolean isstatic;
        public QRCode (String _key,String _money,String _mark,String _type,boolean _isstatic){
            PayHelperUtils.LogMsg("构造 QRCode》》》"+_key);
            key = _key;
            money = _money;
            mark = _mark;
            type = _type;
            isstatic = _isstatic;
        }
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            String methodName = method.getName();
            Object obj = null;
            PayHelperUtils.LogMsg("调用方法》》》"+methodName);
            if(methodName.equals("a")){
                obj = objects[0];
                if(obj.getClass().getName().equals("okhttp3.Response")){
                    if (!Thread.currentThread().isInterrupted()) {
                        PayHelperUtils.LogMsg(">>>>>>>>>>>"+obj);
                        Object objbody = XposedHelpers.callMethod(obj,"body");
                        byte[] a = a(objbody);
                        if (!Thread.currentThread().isInterrupted()) {
                            if(a != null){
                                String result = new String(a,"UTF-8");
                                PayHelperUtils.LogMsg("result 》》》"+result);
                                String deresult = ""+decode(result,key);
                                //
                                JSONObject json = new JSONObject(deresult);
                                String qrurl = json.optString("QRCODE_INFO");
                                if(isstatic){
                                    staticqrurl = qrurl;
                                    if(TextUtils.isEmpty(this.money)){
                                        PayHelperUtils.LogMsg("请求的是静态二维码》》"+staticqrurl);
                                        return null;
                                    }
                                }
                                String money = !isstatic?json.optString("TRANS_AMT"):this.money;
                                String tradeNo = !isstatic?json.optString("MER_SEQ_NBR"):"";
                                Intent v2 = new Intent();
                                v2.putExtra("type", type);
                                v2.putExtra("mark", mark);
                                v2.putExtra("money", money);
                                v2.putExtra("payurl", qrurl);
                                if(!isstatic){
                                    v2.putExtra("img_url", tradeNo);
                                }
                                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                                mcontext.sendBroadcast(v2);
                                //
                                PayHelperUtils.LogMsg("解密之后的数据 》》》"+deresult);
                            }
                        }

                    }
                }
            }
            if(methodName.equals("b")){
                Throwable objbyte = (Throwable) objects[3];
                PayHelperUtils.LogMsg("objbody>>>>>>>>>>>"+objbyte);
                XposedBridge.log(objbyte);
            }
            return null;
        }
    }

    public static void createQRCode(Intent intent){
        String money = intent.getStringExtra("money");
        String mark = intent.getStringExtra("mark");
        String type = intent.getStringExtra("type");
        try{
            if(!type.contains("STATIC")){
                createActiveQRCode(money,mark,type);
            }else{
                createStaticQRCode(money,mark,type);
            }
        }
        catch(Exception excption){
            XposedBridge.log(excption);
        }
    }

    private static void createActiveQRCode(String money,String mark,String type){
        PayHelperUtils.LogMsg("开始生成动态二维码》》》");
        String str = "https://mbank.hnnx.com/mer/Merchant/MerdyActiveQRcode.do";
        final String strencode = ""+encode();
        Class clazz_e = XposedHelpers.findClass("com.yitong.c.e",mclassLoader);
        QRCode code = new QRCode(strencode,money,mark,type,false);
        Object o_proxy = Proxy.newProxyInstance(mclassLoader,new Class[]{clazz_e},code);
        Class clazz = XposedHelpers.findClass("com.yitong.e.a.d",mclassLoader);
        String[] strs = type.split("_",2);
        type = strs[1];
        XposedHelpers.callStaticMethod(clazz,"a",str,createqrdata(money,type),o_proxy,strencode);
    }

    private static void createStaticQRCode(String money,String mark,String type){
        PayHelperUtils.LogMsg("开始生成静态二维码》》》");
        if(!TextUtils.isEmpty(staticqrurl)&&!TextUtils.isEmpty(money)){
            PayHelperUtils.LogMsg("静态码已存在,开始生成订单");
            Intent v2 = new Intent();
            v2.putExtra("type", type);
            v2.putExtra("mark", mark);
            v2.putExtra("money", money);
            v2.putExtra("payurl", staticqrurl);
            v2.setAction(AppConst.QRCODERECEIVED_ACTION);
            mcontext.sendBroadcast(v2);
            return;
        }
        String str = "https://mbank.hnnx.com/mer/Merchant/MerdyStateQRcode.do";
        final String strencode = ""+encode();
        Class clazz_e = XposedHelpers.findClass("com.yitong.c.e",mclassLoader);
        QRCode code = new QRCode(strencode,money,mark,type,true);
        Object o_proxy = Proxy.newProxyInstance(mclassLoader,new Class[]{clazz_e},code);
        Class clazz = XposedHelpers.findClass("com.yitong.e.a.d",mclassLoader);
        XposedHelpers.callStaticMethod(clazz,"a",str,createstaticqrdata(),o_proxy,strencode);
    }

    private static Object createstaticqrdata(){
        Class clazz = XposedHelpers.findClass("com.yitong.e.b.a",mclassLoader);
        Object o_new = XposedHelpers.newInstance(clazz,0);
        XposedHelpers.callMethod(o_new,"a","MERNBR",getMERC_NO());// 金额
        return o_new;
    }

    public static void sendLoginID() {
        loginid = "" + getMERC_NO();// 商户号
        PayHelperUtils.sendLoginId(loginid, AppConst.TYPE_JYES, mcontext);
        if(TextUtils.isEmpty(staticqrurl)){
            createStaticQRCode("","","");
        }
    }

    private static Object createqrdata(String money,String type){
        Class clazz = XposedHelpers.findClass("com.yitong.e.b.a",mclassLoader);
        Object o_new = XposedHelpers.newInstance(clazz,0);
        XposedHelpers.callMethod(o_new,"a","TRANS_AMT",money);// 金额
        XposedHelpers.callMethod(o_new,"a","PAY_TYPCD",type); // B支付宝C微信D银联
        XposedHelpers.callMethod(o_new,"a","ORDER_TITLE",getCUST_NAME());// CUST_NAME
        XposedHelpers.callMethod(o_new,"a","SUB_MERCHANT_ID",getMERC_NO());// 金额
        return o_new;
    }

    private static void queryAllTrade(String params){
        String str = "https://mbank.hnnx.com/mer/Merchant/payMessageListQuery.do";
        final String strencode = ""+encode();
        Class clazz_e = XposedHelpers.findClass("com.yitong.c.e",mclassLoader);
        Trade trade = new Trade(1,strencode);
        Object o_proxy = Proxy.newProxyInstance(mclassLoader,new Class[]{clazz_e}, trade);
        Class clazz = XposedHelpers.findClass("com.yitong.e.a.d",mclassLoader);
        XposedHelpers.callStaticMethod(clazz,"a",str,createaqtdata(params),o_proxy,strencode);
    }

    private static Object createaqtdata(String params){
        //{"UNREAD_NUM":"0","MESS_TIME":"2019-05-14 19:21:25","MESS_URL":"css/img/core/bank-icon.png","MESS_CONTENT":"您在05月14日19点20分有一笔金额为￥0.01元,订单号为TBQR190514196004433603的订单通过支付宝支付成功",
        // "MESS_CODE":"A","MESS_DESC":"交易信息","NEXT_KEY":"1","PAGE_SIZE":"13","REQ_TIME":"20190514204924"}
//        {"UNREAD_NUM":"0","MESS_TIME":"2019-05-14 19:21:25","MESS_URL":"css/img/core/bank-icon.png","MESS_CONTENT":"您在05月14日19点20分有一笔金额为￥0.01元,订单号为TBQR190514196004433603的订单通过支付宝支付成功",
//          "MESS_CODE":"A","MESS_DESC":"交易信息"} "NEXT_KEY":"1","PAGE_SIZE":"13","REQ_TIME":"20190514204924"
        try {
            JSONObject jsonObject = new JSONObject(params);
            jsonObject.put("NEXT_KEY","1");
            jsonObject.put("PAGE_SIZE","13");
            String time = System.currentTimeMillis()+"";
            time = PayHelperUtils.stampToDate(time,"yyyyMMddhhmmss");
            jsonObject.put("REQ_TIME",time);
            Class clazz = XposedHelpers.findClass("com.yitong.e.b.a",mclassLoader);
            Object o_a = XposedHelpers.newInstance(clazz,jsonObject.toString());
            return o_a;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void queryTrade(){
        PayHelperUtils.LogMsg("开始轮询账单》》");
        String str = "https://mbank.hnnx.com/mer/Merchant/payMessageTypeQuery.do";
        final String strencode = ""+encode();
        Class clazz_e = XposedHelpers.findClass("com.yitong.c.e",mclassLoader);
        Trade trade = new Trade(0,strencode);
        Object o_proxy = Proxy.newProxyInstance(mclassLoader,new Class[]{clazz_e}, trade);
        Class clazz = XposedHelpers.findClass("com.yitong.e.a.d",mclassLoader);
        XposedHelpers.callStaticMethod(clazz,"a",str,createqtdata(),o_proxy,strencode);
    }

    private static Object createqtdata(){
        String time = System.currentTimeMillis()+"";
        time = PayHelperUtils.stampToDate(time,"yyyyMMddhhmmss");
        String params = "{\"NEXT_KEY\":\"1\",\"PAGE_SIZE\":\"0\",\"REQ_TIME\":\""+time+"\"}";
        Class clazz = XposedHelpers.findClass("com.yitong.e.b.a",mclassLoader);
        Object o_a = XposedHelpers.newInstance(clazz,params);
        return o_a;
    }

    private static Object getUserInfo(){
        Class clazzf = XposedHelpers.findClass("com.hnnx.sh.mbank.utils.g",mclassLoader);
        Object o_a = XposedHelpers.callStaticMethod(clazzf,"a");
        Object o_userinfo = XposedHelpers.callMethod(o_a,"c");
        return o_userinfo;
    }

    private static Object getMERC_NO(){
        Object o_userinfo = getUserInfo();
        Object o_mercno = XposedHelpers.callMethod(o_userinfo,"getMERC_NO");
        return o_mercno;
    }

    private static Object getCUST_NAME(){
        Object o_userinfo = getUserInfo();
        Object o_custname = XposedHelpers.callMethod(o_userinfo,"getCUST_NAME");
        return o_custname;
    }

    private static Object getCLIENT_NO(){
        Class clazz = XposedHelpers.findClass("com.yitong.utils.a",mclassLoader);
        Object o_clientno = XposedHelpers.callStaticMethod(clazz,"a",getApp());
        return o_clientno;
    }

    private static Object encode(){
        Class clazz = XposedHelpers.findClass("com.yitong.mbank.util.security.CryptoUtil",mclassLoader);
        Object result = XposedHelpers.callStaticMethod(clazz,"b");
        return result;
    }

    private static Object encode(Object app,String str,String str2){
        Class clazz = XposedHelpers.findClass("com.yitong.mbank.util.security.CryptoUtil",mclassLoader);
        Object result = XposedHelpers.callStaticMethod(clazz,"b",app,str,str2);
        return result;
    }

    private static Object decode(String str,String str2){
        Object app = getApp();
        Class clazz = XposedHelpers.findClass("com.yitong.mbank.util.security.CryptoUtil",mclassLoader);
        Object result = XposedHelpers.callStaticMethod(clazz,"c",app,str,str2);
        return result;
    }

    private static Object getApp(){
        Class clazz = XposedHelpers.findClass("com.yitong.android.application.YTBaseApplication",mclassLoader);
        Object o_a = XposedHelpers.getStaticObjectField(clazz,"a");
        return o_a;
    }
//
    static byte[] a(Object responseBody) {
        int i = 4096;
        if (responseBody != null) {
            InputStream byteStream = (InputStream)XposedHelpers.callMethod(responseBody,"byteStream");
            if (byteStream != null) {
                long contentLength = (long)XposedHelpers.callMethod(responseBody,"contentLength");
                if (contentLength > 2147483647L) {
                    throw new IllegalArgumentException("HTTP entity too large to be buffered in memory");
                }
                if (contentLength > 0) {
                    i = (int) contentLength;
                }
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(i);
                try {
                    byte[] bArr = new byte[4096];
                    long j = 0;
                    boolean isrunning = true;
                    while(isrunning) {
                        int read = byteStream.read(bArr);
                        if (read != -1 && !Thread.currentThread().isInterrupted()) {
                            long j2 = ((long) read) + j;
                            byteArrayOutputStream.write(bArr, 0, read);
                            j = j2;
                        } else if (byteStream != null) {
                            try {
                                byteStream.close();
                                isrunning = false;
                            } catch (Throwable e) {
                                PayHelperUtils.LogMsg("a error 0 》》"+e);
                            }
                        }
                    }
                    return byteArrayOutputStream.toByteArray();
                } catch (OutOfMemoryError e2) {
                    System.gc();
                    try {
                        PayHelperUtils.LogMsg("File too large to fit into available memory");
                        throw new IOException("File too large to fit into available memory");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } catch (Throwable th) {
                    if (byteStream != null) {
                        try {
                            byteStream.close();
                        } catch (Throwable e3) {
                            PayHelperUtils.LogMsg("Cannot close input stream");
                        }
                    }
                }
            }
        }
        return null;
    }

}
