package com.zhiyi.xppay.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.CustomApplcation;
import com.zhiyi.xppay.item.ReqData;
import com.zhiyi.xppay.net.Socket.ClientManager;
import com.zhiyi.xppay.net.Socket.LoginInfoManager;
import com.zhiyi.xppay.net.Socket.SendMsg.LoginInfo;
import com.zhiyi.xppay.receiver.AliReceiver;
import com.zhiyi.xppay.utils.DBManager;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.ZyUtil;

import java.util.LinkedList;
public class MainService extends Service implements Runnable {
    private BroadcastReceiver aliReceiver;
    public MainService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    public void onCreate(){
        super.onCreate();
        Log.w("ZYKJ","服务启动");
        new Thread(this).start();
        aliReceiver = new AliReceiver(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction(AppConst.HOOK_FRIEND_ORDER_ACTION);
        filter.addAction(AppConst.HOOK_FRIEND_CHECK_ACTION);
        filter.addAction(AppConst.HOOK_DianDianChong_TOKEN_ACTION);
        filter.addAction(AppConst.HOOK_BILL_RECEIVED);
        filter.addAction(AppConst.HOOK_COMPAREORDER_ACTION);
        registerReceiver(aliReceiver,filter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(aliReceiver);
    }

    @Override
    public void run() {
        try {
            Thread.sleep(60000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ClientManager client = ClientManager.getInstance();
        while(true){
            try {
                Thread.sleep(60*1000);
            } catch (InterruptedException e) {
                Log.e("XPPAY",e.getMessage(),e);
            }
            if(client.isLogin(AppConst.TYPE_ALIPAY)){
                if (!ZyUtil.isAppRunning(this.getApplicationContext(), "com.eg.android.AlipayGphone")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("alipays://platformapi/startapp?appId=20000067&showTitleBar=YES&showToolBar=NO&url=alipays://platformapi/startapp?appId=60000081"));
                        startActivity(intent);
                        Thread.sleep(5000);
                        ZyUtil.startAPP();
                    } catch (InterruptedException e) {
                        Log.e("XPPAY","线程异常",e);
                    }
                }
            }
        }
    }

    public void receiveBroadcast(Context context, Intent intent) {
        ClientManager client = ClientManager.getInstance();
        String action = intent.getAction();
        Log.w("ZYKJ","服务消息"+action);
        switch (action){
            case AppConst.HOOK_FRIEND_CHECK_ACTION:
                client.sentFriendType(intent);
                break;
            case AppConst.HOOK_FRIEND_ORDER_ACTION:
                client.sentFriendOrder(intent);
            case AppConst.HOOK_DianDianChong_TOKEN_ACTION:
                client.sendToken(intent);
                break;
            case AppConst.HOOK_BILL_RECEIVED:
                client.sendBill(intent);
                break;
            case AppConst.HOOK_COMPAREORDER_ACTION:
                Log.i("ZYKJ","开始对比支付宝订单");
                client.setPayComplete(intent);
                break;
        }
    }
}
