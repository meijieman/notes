package com.zhiyi.xppay.hook.qnshb;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Field;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/6/15.
 */

public class HookQNSHB {
    private static ClassLoader mClassLoader;
    private static Context mContext;
    private static Object obj_refresh;
    private Handler mHandler;

    public void hook(final ClassLoader classLoader, final Context context) {
        mClassLoader = classLoader;
        mContext = context;
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @SuppressLint("ResourceType")
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("当前 activity 》》》》》》》》》》" + param.thisObject.getClass().getName());
            }
        });
        XposedHelpers.findAndHookMethod("com.gyBank.activity.HomeActivity", classLoader, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.sendLoginId(getUserName(),AppConst.TYPE_QN,context);
            }
        });
        XposedHelpers.findAndHookMethod("com.gyBank.activity.HomeActivity", classLoader, "addFragment", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                obj_refresh = getOnRefreshObj(getFramet(param.thisObject));
                if (mHandler == null) {
                    mHandler = new Handler() {
                        @Override
                        public void handleMessage(Message msg) {
                            super.handleMessage(msg);
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    XposedHelpers.callMethod(obj_refresh, "onRefresh");
                                }
                            }).start();
                            mHandler.sendEmptyMessageDelayed(1001, 20000);
                        }
                    };
                    mHandler.sendEmptyMessageDelayed(1001, 20000);
                } else {
                    mHandler.removeMessages(1001);
                }
            }
        });
        XposedHelpers.findAndHookMethod("com.gyBank.fragment.i", classLoader, "OnResult", String.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                super.beforeHookedMethod(param);
                XposedBridge.log("收到订单查询结果》》》》》》》》》》》" + param.args[0]);
                String str = "" + param.args[0];
                JSONObject jSONObject = new JSONObject(str);
                if (!jSONObject.isNull("totalCnt") && jSONObject.getInt("totalCnt") > 0) {
                    JSONArray jSONArray = jSONObject.getJSONArray("transList");
                    for (int i = 0; i < jSONArray.length(); i++) {
                        JSONObject json = jSONArray.getJSONObject(i);
                        String orderId =json.optString("orderId");
                        String transAmt = json.optString("transAmt");
                        float temp = Float.parseFloat(transAmt);
                        temp = temp/100;
                        transAmt = ""+temp;
                        //
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("bill_no", orderId);
                        broadCastIntent.putExtra("bill_money", transAmt);
                        broadCastIntent.putExtra("bill_mark", orderId);
                        broadCastIntent.putExtra("bill_type", AppConst.TYPE_QN);
                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                        context.sendBroadcast(broadCastIntent);
                        //
                    }
                }

//                {"totalCnt":1,"transList":
//                  [{"transTime":"151257","orderId":"21020190619151257543888727971181","transStat":"S","srAmtSum":"0","payTypeDesc":"支付宝支付","termId":"静态码",
//                  "payType":"A005","payerInfo":"188****0103","transType":"S","transDesc":"支付宝交易预创建（扫码支付）","transAmt":"1","transDate":"20190619",
// "transBusStat":"00","transCode":"100702","transSsn":"20020190619151257789578113621197"}],"respMsg":"交易成功","reqSsn":"20190619155656obwwlz","respCode":"0000"}

            }
        });
        XposedHelpers.findAndHookMethod("com.gyBank.util.i", classLoader, "a", Context.class, new XC_MethodReplacement() {
            @Override
            protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                XposedBridge.log("NotificationsUtils isNotificationEnabled " + methodHookParam.getResult());
                return true;
            }
        });
//        XposedHelpers.findAndHookMethod("com.gyBank.manager.SecurityManager", classLoader, "doPost", String.class, Object.class, String.class, Class.class,
//                XposedHelpers.findClass("com.ruimin.ifm.core.task.FmAsyncTask",classLoader), new XC_MethodHook() {
//                    @Override
//                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                        super.afterHookedMethod(param);
//                        if(param.args[1].getClass().getName().equals("com.gyBank.request.home.TransactionResquest")){
//                            XposedBridge.log("str >> "+param.args[0]+">> obj >> \n"+ JsonHelper.toJson(param.args[1]) +">> str2 >>"+param.args[2]+">> cls >>"+param.args[3]);
//                        }
//                    }
//                });
    }
    public String getUserName(){
        Class clazz = XposedHelpers.findClass("com.gyBank.util.k",mClassLoader);
        String result = ""+XposedHelpers.callStaticMethod(clazz,"a",mContext,"UserPhone");
        return result;
    }
    public Object getFramet(Object object) {
        Object obj = XposedHelpers.callMethod(object, "getFragmet", XposedHelpers.findClass("com.gyBank.fragment.HomeFragment", mClassLoader));
        return obj;
    }

    private Object getOnRefreshObj(Object object) {
        Class clazz = XposedHelpers.findClass("com.gyBank.fragment.f", mClassLoader);
        Object object1 = XposedHelpers.newInstance(clazz, object);
        return object1;
    }
}
