package com.zhiyi.xppay.utils;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by pc_mg on 2019/3/21.
 */

public class DBManagerXgj {
    private SQLiteDatabase db;
    private DBHelperNxys helper;
    public DBManagerXgj(Context context){
        helper = new DBHelperNxys(context);
        db = helper.getWritableDatabase();

    }

    public void addTradeNo(String tradeNo) {
        db.beginTransaction();// 开始事务
        try {
            db.execSQL("INSERT INTO trade VALUES(null,?)", new Object[] { tradeNo });
            db.setTransactionSuccessful();// 事务成功
        } finally {
            db.endTransaction();// 结束事务
        }
    }

    public boolean isExistTradeNo(String tradeNo) {
        boolean isExist=false;
        String sql = "SELECT * FROM trade WHERE tradeno='"+tradeNo+"'";
        Cursor c = ExecSQLForCursor(sql);
        if(c.getCount()>0){
            isExist=true;
        }
        c.close();
        return isExist;
    }


    /**
     * 执行SQL，返回一个游标
     *
     * @param sql
     * @return
     */
    private Cursor ExecSQLForCursor(String sql) {
        Cursor c = db.rawQuery(sql, null);
        return c;
    }
}
