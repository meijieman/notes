package com.zhiyi.xppay.hook;

import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2018/11/21.
 */

public class RestartAlipayService extends Service implements Runnable {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate(){
        new Thread(this).start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void reStartAlipay(){
        // 商户界面之后返回到监控
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("alipays://platformapi/startapp?appId=20000067&showTitleBar=YES&showToolBar=NO&url=alipays://platformapi/startapp?appId=60000081"));
                    startActivity(intent);
                    Thread.sleep(5000);
                    PayHelperUtils.startAPP();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
        //
    }

    @Override
    public void run() {
        while(true){
            try {
                Thread.sleep(3600000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            XposedBridge.log("重启支付宝服务"+(AppConst.LOCKSCREEN?"不":"")+"执行");
            if(!AppConst.LOCKSCREEN){
                reStartAlipay();
            }
        }
    }
}
