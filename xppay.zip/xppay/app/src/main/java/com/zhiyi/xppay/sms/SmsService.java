package com.zhiyi.xppay.sms;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.ui.MainActivity;
import com.zhiyi.xppay.utils.MD5;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/1/15.
 */

public class SmsService extends Service implements Handler.Callback{
    private static final Uri CONTENT_URI = Uri.parse("content://sms");
    private ContentObserver mObserver;
    @Override
    public void onCreate() {
        super.onCreate();
        registerSMSObserver();
    }

    private void registerSMSObserver(){
        XposedBridge.log("注册短信监听器监听器");
        smsHandler = new Handler(this);
        //注册监听器
        ContentResolver resolver = getContentResolver();
        //获取观察者对象
        mObserver = new SMSObserver(resolver, this.smsHandler);
        test();
        //注册
        resolver.registerContentObserver(CONTENT_URI, true, mObserver);
    }

    public void test(){
        ((SMSObserver)mObserver).test();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.getContentResolver().unregisterContentObserver(mObserver);
    }

    private Handler smsHandler;

    private void holdphonemsg(SMSItem item) {
        try {
            String content = item.body;
            String date = item.date;
            if(System.currentTimeMillis()-Long.parseLong(date)>30000){
                XposedBridge.log("这是条旧短信");
                return;
            }
            PayHelperUtils.sendmsg(this,"收款短信>>"+content);
            String tailnum = "";
            String money = "";
            String money2 = "";
            String tailnum2 = "";
            String paytype = AppConst.TYPE_BANK;
            Pattern p=Pattern.compile("(\\d+\\.\\d+\\d)");
            Matcher m=p.matcher(content);
            if(m.find()){
                money2 = m.group(1);
            }
            p=Pattern.compile("(\\d+\\d+\\d+\\d)");
            m=p.matcher(content);
            if(m.find()){
                tailnum2 = m.group(1);
            }
            String mark = "false";
            XposedBridge.log("tail num2>>>>>>>>"+tailnum2);
            if (content.contains("[兴业银行]")) {
                mark = "兴业银行";
                tailnum = StringUtils.getTextCenter(content, "账户*", "*网联");
                money = StringUtils.getTextCenter(content, "收入", "元");
            }else
            if (content.contains("【华夏银行】")) {
                mark = "华夏银行";
                tailnum = StringUtils.getTextCenter(content, "（**", "），");
                money = StringUtils.getTextCenter(content, "到账人民币", "元");
            }else
            if (content.contains("【中国农业银行】")) {
                mark = "中国农业银行";
                tailnum = StringUtils.getTextCenter(content, "尾号", "账户");
                money = StringUtils.getTextCenter(content, "人民币", "，");
            }else
            if (content.contains("【工商银行】")) {
                mark = "中国工商银行";
                tailnum = StringUtils.getTextCenter(content, "尾号", "卡");
                Pattern p2 = Pattern.compile("([\\d\\.]+)元");
                Matcher m2 = p2.matcher(content);
                if (m2.find()) {
                    money = m2.group(1);
                }
            }else
            if (content.contains("【民生银行】")) {
                mark = "中国民生银行";
                tailnum = StringUtils.getTextCenter(content, "账户*", "于");
                money = StringUtils.getTextCenter(content, "存入￥", "元，");
            }else
            if (content.contains("【平安银行】")) {
                mark = "平安银行";
                tailnum = StringUtils.getTextCenter(content, "尾号", "的");
                money = StringUtils.getTextCenter(content, "转入人民币", "元,");
            }else
            if (content.contains("【厦门银行】")) {
                mark = "厦门银行";
                tailnum = StringUtils.getTextCenter(content, "尾数为", "的");
                money = StringUtils.getTextCenter(content, "转入", "元,");
            }else
            if (content.contains("【泉州银行】")) {
                mark = "泉州银行";
                tailnum = StringUtils.getTextCenter(content, "尾号", "的");
                money = StringUtils.getTextCenter(content, "入账人民币", "元，");
            }else if (content.contains("[建设银行]")) {
                if(content.contains("您注册的商户")){
                    tailnum="0000";
                    paytype = AppConst.TYPE_LONGPAYSMS;
                    Pattern py=Pattern.compile("(\\d+\\.\\d+)元");
                    Matcher my=py.matcher(content);
                    if(my.find()){
                        money = my.group(1);
                    }
                    mark = StringUtils.getTextCenter(content, "商户名称：", "，");
                }else{
                    mark = "中国建设银行";
                    tailnum = StringUtils.getTextCenter(content, "尾号", "的");
                    money = StringUtils.getTextCenter(content, "收入人民币", "元");
                }
            }else if (content.contains("[招商银行]")) {
                mark = "招商银行";
                tailnum = StringUtils.getTextCenter(content, "账户", "于");
                money = StringUtils.getTextCenter(content, "收款人民币", "，");
            }else if (content.contains("【中信银行】")) {
                mark = "中信银行";
                tailnum = StringUtils.getTextCenter(content, "尾号", "的");
                money = StringUtils.getTextCenter(content, "存入人民币", "元，");
            }else{
                tailnum = tailnum2;
                money = money2;
            }
            if(tailnum.equals("error")){
                tailnum = tailnum2;
            }
            try {
                float f = Float.parseFloat(money);
                money = ""+f;
            }catch (Exception e){
                XposedBridge.log(e);
                money = money2;
            }
            String no = MD5.md5("message" + date + tailnum + money);
            if(money != null) {
                Intent broadCastIntent = new Intent();
                broadCastIntent.putExtra("no", no);
                broadCastIntent.putExtra("money", money);
                broadCastIntent.putExtra("mark", mark);
                broadCastIntent.putExtra("wh", tailnum);
                broadCastIntent.putExtra("paytype", paytype);
                broadCastIntent.putExtra("dt", date);
                broadCastIntent.setAction(AppConst.HOOK_BILL_RECEIVED);
                sendBroadcast(broadCastIntent);
            }
            Log.i("yyk ","no"+no+"date"+date +"tailnum "+tailnum + "money "+money);
        }
        catch (Exception e)
        {
            Log.e("ZYKJ","error:",e);
        }
    }
    public static boolean isNumeric(String str){
        for(int i=str.length();--i>=0;){
            int chr=str.charAt(i);
            if(chr<48 || chr>57)
                return false;
        }
        return true;
    }
    @Override
    public boolean handleMessage(Message msg) {
        holdphonemsg((SMSItem)msg.obj);
        return true;
    }
}
