package com.zhiyi.xppay.hook.mayou;

/**
 * Created by pc_mg on 2019/4/10.
 */
import android.content.Context;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class CreatBilProxy implements InvocationHandler {
    public static String QRCODERECEIVED_ACTION = "com.tools.payhelper.qrcodereceived";
    Context mContext;
    String money;
    String orderInfo;
    String receiveId;

    public CreatBilProxy(Context context, String orderInfo, String money, String receiveId) {
        this.mContext = context;
        this.orderInfo = orderInfo;
        this.money = money;
        this.receiveId = receiveId;
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String methodName = method.getName();
        XposedBridge.log("CreatBilProxy调用的方法名称为:" + methodName);
        XposedBridge.log("CreatBilProxy返回的类型为" + method.getReturnType().getName());
        if (methodName.equals("callback")) {
            try {
                ClassLoader loader = proxy.getClass().getClassLoader();
                byte[] bytes = (byte[]) args[0];
                if (bytes == null || bytes.length <= 0) {
                    return null;
                }
                Object pp = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.aoetech.aoelailiao.core.proto.ProtoBufPacket", loader), "getProtoBufInputByte", new Object[]{bytes});
                getPayInfo(1, XposedHelpers.getObjectField(XposedHelpers.callMethod(XposedHelpers.getStaticObjectField(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.UserGrantAliEnvelopeInfoAns", loader), "ADAPTER"), "decode", new Object[]{pp}), "pre_pay_info"), loader, this.mContext);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private void getPayInfo(int i, Object pre_pay_info, ClassLoader classLoader, Context context) {
        Object[] objArr = new Object[]{pre_pay_info};
        Object Message = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.UserGetPayOrderInfoReq.Builder", classLoader), new Object[0]), "pay_type", new Object[]{Integer.valueOf(i)}), "pre_pay_info", objArr), "build", new Object[0]);
        Object ProtoBufPacket = XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.core.proto.ProtoBufPacket", classLoader), new Object[]{Integer.valueOf(1031), Message});
        Class PacketSendCallback = XposedHelpers.findClass("com.aoetech.aoelailiao.entity.PacketSendCallback", classLoader);
        Class MessageInfoManagerCls = XposedHelpers.findClass("com.aoetech.aoelailiao.core.local.manager.MessageInfoManager", classLoader);
        Class[] clsArr = new Class[]{PacketSendCallback};
        Object obj = Proxy.newProxyInstance(classLoader, clsArr, new PrePayInfoProxy(context, this.orderInfo, this.money, this.receiveId));
        XposedHelpers.callMethod(XposedHelpers.callStaticMethod(MessageInfoManagerCls, "getInstant", new Object[0]), "a", new Object[]{ProtoBufPacket, obj});
    }
}