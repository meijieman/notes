package com.zhiyi.xppay.hook.hybsyt;

import com.zhiyi.xppay.utils.JsonHelper;

/**
 * Created by pc_mg on 2019/5/8.
 */

public class TradeCode {
    String mid;
    String amount;
    String unno;
    String sign;
    String strUuid;
    public TradeCode(String mid, String amount, String unno, String sign, String strUuid) {
        this.mid = mid;
        this.amount = amount;
        this.unno = unno;
        this.sign = sign;
        this.strUuid = strUuid;

    }

    public String toJson() {
        String sendStr = JsonHelper.toJson(this);
        return sendStr;
    }
}
