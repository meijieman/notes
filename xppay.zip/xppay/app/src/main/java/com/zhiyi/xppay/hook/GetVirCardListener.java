package com.zhiyi.xppay.hook;

/**
 * Created by pc_mg on 2018/12/28.
 */

public interface GetVirCardListener {
    public void success(String re);
    public void error(String error);
}
