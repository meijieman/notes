package com.zhiyi.xppay.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.app.Activity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.zhiyi.xppay.R;
import com.zhiyi.xppay.net.Socket.ClientManager;
import com.zhiyi.xppay.net.Socket.ConnectInfo;
import com.zhiyi.xppay.utils.AbSharedUtil;

/**
 * Created by pc_unity on 2019/3/20.
 */

public class SettingConnectActivity{

    public static AlertDialog.Builder showNetSettingDialog(final Context context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("请输入服务器的IP或域名");
        //    通过LayoutInflater来加载一个xml的布局文件作为一个View对象
        View view = LayoutInflater.from(context).inflate(R.layout.activity_netsetting, null);
        //    设置我们自己定义的布局文件作为弹出框的Content
        builder.setView(view);

        final EditText ip = (EditText)view.findViewById(R.id.connect_ip);

        builder.setPositiveButton("确定", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                if(ip.length()==0){
                    Toast toast=Toast.makeText(context,"输入ip长度不对",Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }
                String strIp = ip.getText().toString().trim();
                AbSharedUtil.putString(context,"connect_ip",strIp);
                ClientManager.getInstance().reconnection();
            }
        });
        builder.setCancelable(false);
        builder.setOnKeyListener(new DialogInterface.OnKeyListener(){
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_SEARCH) {
                    return true;
                }
                else {
                    return false;//默认返回false
                }
            }
        });
        return builder;
    }
}
