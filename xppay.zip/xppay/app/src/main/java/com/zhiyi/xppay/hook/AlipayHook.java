package com.zhiyi.xppay.hook;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.AlipayInfo;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.MD5;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.StringUtils;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * 支付宝监控
 * create by zhiyi
 *
 * @date 2018年10月20日 下午1:25:54
 */
public class AlipayHook {
    public static final String TYPE_ALIPAY = AppConst.TYPE_ALIPAY;
    public static String BILLRECEIVED_ACTION = "com.tools.payhelper.billreceived";
    public static String QRCODERECEIVED_ACTION = "com.tools.payhelper.qrcodereceived";
    public static String NOT_LOGIN_ACTION = "com.tools.payhelper.notloginreceived";

    boolean istranfer;
    String node = "";
    View view;
    AlipayInfo alipayInfo;

    public void hook(final ClassLoader classLoader, final Context context) {
        securityCheckHook(classLoader);
        //
        //
        try {
            XposedHelpers.findAndHookMethod("com.alipay.android.app.birdnest.ui.BNTplActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    //
                    Activity mactivity = (Activity) (param.thisObject);
                    Bundle bundle = mactivity.getIntent().getExtras();
                    if (bundle != null && alipayInfo == null) {
                        String data = bundle.getString("alipayinfo");
                        alipayInfo = JsonHelper.fromJson(data, AlipayInfo.class);
                    }
                    //
                    super.afterHookedMethod(param);
                }
            });
            XposedHelpers.findAndHookMethod("com.flybird.FBDocument", classLoader, "setProp", String.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    if (param.args[0].toString().equals("userPreferences") && Integer.parseInt(param.getResult().toString()) == 1) {
                        if (alipayInfo != null) {
                            String strdata = param.args[1].toString();
                            XposedBridge.log("余额 strdata " + strdata);
                            JSONObject jsondata = new JSONObject(strdata);
                            Object objres = jsondata.get("data");
                            if (objres != null) {
                                String str = objres.toString();
                                JSONObject json = new JSONObject(str);
                                float banlance = Float.parseFloat(json.getString("availableAmount"));
                                float withdrawcount = Float.parseFloat(alipayInfo.withdrawcount);
                                PayHelperUtils.sendmsg(context, "当前余额 " + banlance);
                                if (banlance >= withdrawcount) {
                                    PayHelperUtils.withDraw(context, alipayInfo, banlance);
                                } else {
                                    PayHelperUtils.forceOpenSelf(context);
                                    alipayInfo = null;
                                }
                            }
                        }
                    }
                    super.afterHookedMethod(param);
                }
            });
            Class<?> insertTradeMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.TradeDao", classLoader);
            XposedBridge.hookAllMethods(insertTradeMessageInfo, "insertMessageInfo", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        XposedBridge.log("======支付宝个人账号订单start=========");
                        //获取content字段
//            			String content=(String) XposedHelpers.getObjectField(param.args[0], "content");
//            			XposedBridge.log(content);
                        //获取全部字段
                        Object object = param.args[0];
                        String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                        Log.e("e", "消息 " + MessageInfo);
                        XposedBridge.log(MessageInfo);
                        String content = StringUtils.getTextCenter(MessageInfo, "content='", "'");
                        if (content.contains("二维码收款") || content.contains("收到一笔转账")) {
                            JSONObject jsonObject = new JSONObject(content);
                            String money = jsonObject.getString("content").replace("￥", "");
                            String mark = jsonObject.getString("assistMsg2");
                            String tradeNo = StringUtils.getTextCenter(MessageInfo, "tradeNO=", "&");
                            XposedBridge.log("收到支付宝支付订单：" + tradeNo + "==" + money + "==" + mark);

                            //
                            //
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("bill_no", tradeNo);
                            broadCastIntent.putExtra("bill_money", money);
                            broadCastIntent.putExtra("bill_mark", mark);
                            broadCastIntent.putExtra("bill_type", TYPE_ALIPAY);
                            broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                        }
                        XposedBridge.log("======支付宝个人账号订单end=========");
                    } catch (Exception e) {
                        XposedBridge.log(e.getMessage());
                    }
                    super.beforeHookedMethod(param);
                }
            });
            Class<?> insertServiceMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.ServiceDao", classLoader);
            Set<?> hooks = XposedBridge.hookAllMethods(insertServiceMessageInfo, "insertMessageInfo", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        Object object = param.args[0];
                        //XposedHelpers.
                        String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                        String content = StringUtils.getTextCenter(MessageInfo, "extraInfo='", "'").replace("\\", "");
                        XposedBridge.log(content);
                        if (content.contains("收钱到账") || content.contains("收款到账")) {
                            XposedBridge.log("======支付宝商家服务订单start=========");
                            String cookie = PayHelperUtils.getCookieStr(classLoader);
                            PayHelperUtils.getTradeInfo(context, cookie);
                            // 收钱到账发送广播
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("ispersonal", false);
                            broadCastIntent.putExtra("bill_type", TYPE_ALIPAY);
                            broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                            //
                            XposedBridge.log("======支付宝商家服务订单end=========");
                        }
                        if (content.contains("银行卡收款通知")) {
                            XposedBridge.log("======>银行卡到账通知");
                            String TFDetail = StringUtils.getTextCenter(MessageInfo, "assistMsg1\":", "已到账");
                            String name = StringUtils.getTextCenter(TFDetail, "\"", "通过");
                            String money = StringUtils.getTextCenter(TFDetail, "转账", "元");
                            String cardNo = StringUtils.getTextCenter(TFDetail, "尾号", "）");
                            //
                            XposedBridge.log("===>" + "付款人:" + name);
                            XposedBridge.log("===>" + "金额:" + money);
                            XposedBridge.log("===>" + "卡号:" + cardNo);
                            //
                            XposedBridge.log("支付宝监听银行卡");
                            long dt = System.currentTimeMillis();
                            String no = MD5.md5("alipay"+dt+cardNo+money);
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("bill_no", no);
                            broadCastIntent.putExtra("bill_money", money);
                            broadCastIntent.putExtra("bill_mark", "false");
                            broadCastIntent.putExtra("bill_wh",cardNo);
                            broadCastIntent.putExtra("bill_dt", dt);
                            broadCastIntent.putExtra("bill_type", AppConst.TYPE_BANK);
                            broadCastIntent.setAction(BILLRECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                            //
                        }
                    } catch (Exception e) {
                        PayHelperUtils.sendmsg(context, e.getMessage());
                    }
                    super.beforeHookedMethod(param);
                }
            });
            XposedBridge.log("----------商家订单:" + hooks.size() + "-----------");

            // hook设置金额和备注的onCreate方法，自动填写数据并点击
            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("========支付宝设置金额start=========");
                    Field jinErField = XposedHelpers.findField(param.thisObject.getClass(), "b");
                    final Object jinErView = jinErField.get(param.thisObject);
                    Field beiZhuField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                    final Object beiZhuView = beiZhuField.get(param.thisObject);
                    Intent intent = ((Activity) param.thisObject).getIntent();
                    String mark = intent.getStringExtra("mark");
                    String money = intent.getStringExtra("money");
                    //设置支付宝金额和备注
                    XposedHelpers.callMethod(jinErView, "setText", money);
                    XposedHelpers.callMethod(beiZhuView, "setText", mark);
                    //点击确认
                    Field quRenField = XposedHelpers.findField(param.thisObject.getClass(), "e");
                    final Button quRenButton = (Button) quRenField.get(param.thisObject);
                    quRenButton.performClick();
                    XposedBridge.log("=========支付宝设置金额end========");
                }
            });

            // hook获得二维码url的回调方法
            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "a",
                    XposedHelpers.findClass("com.alipay.transferprod.rpc.result.ConsultSetAmountRes", classLoader), new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            XposedBridge.log("=========支付宝生成完成start========");
                            Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "g");
                            String money = (String) moneyField.get(param.thisObject);

                            Field markField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                            Object markObject = markField.get(param.thisObject);
                            String mark = (String) XposedHelpers.callMethod(markObject, "getUbbStr");

                            Object consultSetAmountRes = param.args[0];
                            Field consultField = XposedHelpers.findField(consultSetAmountRes.getClass(), "qrCodeUrl");
                            String payurl = (String) consultField.get(consultSetAmountRes);
                            XposedBridge.log(money + "  " + mark + "  " + payurl);

                            if (money != null) {
                                XposedBridge.log("调用增加数据方法==>支付宝");
                                Intent broadCastIntent = new Intent();
                                broadCastIntent.putExtra("money", money);
                                broadCastIntent.putExtra("mark", mark);
                                broadCastIntent.putExtra("type", TYPE_ALIPAY);
                                broadCastIntent.putExtra("payurl", payurl);
                                broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                                context.sendBroadcast(broadCastIntent);
                            }
                            XposedBridge.log("=========支付宝生成完成end========");
                        }
                    });

            // hook获取loginid
            XposedHelpers.findAndHookMethod("com.alipay.mobile.quinox.LauncherActivity", classLoader, "onResume",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            String loginid = PayHelperUtils.getAlipayLoginId(classLoader);
                            PayHelperUtils.sendLoginId(loginid, TYPE_ALIPAY, context);
                        }
                    });

            //弹出顶号界面
            XC_MethodHook.Unhook bb = XposedHelpers.findAndHookMethod("com.alipay.android.widget.security.msgreceiver.DeviceLockMsgReceiverNew", classLoader, "showDeviceLockTip", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("type", TYPE_ALIPAY);
                    broadCastIntent.setAction(NOT_LOGIN_ACTION);
                    context.sendBroadcast(broadCastIntent);
                }
            });
            //监控通知栏
            XposedHelpers.findAndHookMethod("android.app.Notification.Builder", classLoader, "setContentTitle", CharSequence.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Object prm = param.args[0];
                    if (prm.equals("支付宝账号在其他设备登录")) {
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("type", TYPE_ALIPAY);
                        broadCastIntent.setAction(NOT_LOGIN_ACTION);
                        context.sendBroadcast(broadCastIntent);
                    }
                }
            });
            //
            XposedHelpers.findAndHookConstructor("com.alipay.mobile.quinox.activity.QuinoxContext", classLoader, Activity.class, Context.class, "com.alipay.mobile.quinox.LauncherApplication", ClassLoader.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("QuinoxContext 參數0" + param.args[0] + "|參數1" + param.args[1] + "|參數2" + param.args[2] + "|參數3" + param.args[3] + "|参数4" + param.args[4]);
                    final Object objectActivity = param.args[0];
                    if (objectActivity.getClass().getName().equals("com.alipay.mobile.withdraw.ui.WithdrawActivity_")) {
                        XposedHelpers.findAndHookMethod(objectActivity.getClass(), "onCreate", Bundle.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                Activity activity = (Activity) param.thisObject;
                                String pwd = activity.getIntent().getStringExtra("passward");
                                if (pwd != null) {
                                    withdrawSuccess(param.thisObject.getClass(), context);
                                    withdrawError(param.thisObject.getClass(), context);
                                    withDrawAuto(param.thisObject.getClass().getClassLoader(), param.thisObject, pwd, context);
                                }
                                super.afterHookedMethod(param);
                            }
                        });
                    }
                    if (objectActivity.getClass().getName().equals("com.alipay.mobile.transferapp.ui.TransferToCardFormActivity_")) {
                        Activity activity = (Activity) objectActivity;
                        Intent intent = activity.getIntent();
                        if (intent != null) {
                            String account = intent.getStringExtra("account");
                            String cardno = intent.getStringExtra("cardno");
                            String money = intent.getStringExtra("money");
                            String pwd = intent.getStringExtra("passward");
                            if (!account.equals("") && !cardno.equals("") && !money.equals("") && !pwd.equals("")) {
                                tranferAuto(objectActivity.getClass().getClassLoader(), context, account, cardno, money, pwd);
                                onTranstoBankSuccess(objectActivity.getClass().getClassLoader(), context);
                                onTranstoBankFailed(objectActivity.getClass().getClassLoader(), context);
                                istranfer = true;
                            }
                        }
                    }
                    if (objectActivity.getClass().getName().equals("com.alipay.mobile.transferapp.ui.TFToCardConfirmActivity_") && istranfer) {
                        XposedHelpers.findAndHookMethod("com.alipay.mobile.transferapp.ui.TFToCardConfirmActivity_", classLoader, "onViewChanged", "org.androidannotations.api.view.HasViews", new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                Field fieldbut = XposedHelpers.findField(param.thisObject.getClass(), "j");
                                fieldbut.setAccessible(true);
                                Object but = fieldbut.get(param.thisObject);
                                ((Button) but).performClick();
                                super.afterHookedMethod(param);
                            }
                        });
                    }
                    if (objectActivity.getClass().getName().equals("com.alipay.mobile.verifyidentity.module.password.pay.ui.PayPwdHalfActivity")) {
                        final Class<?> clazz = XposedHelpers.findClass("com.alipay.mobile.verifyidentity.module.password.pay.ui.PayPwdCommonActivity", objectActivity.getClass().getClassLoader());
                        XposedBridge.log("PayPwdCommonActivity === " + clazz);
                        XposedHelpers.findAndHookMethod(clazz, "onPwdError", "com.alipay.mobileic.core.model.rpc.MICRpcResponse", new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                                Field field = clazz.getDeclaredField("isShowGetBackPwd");
                                field.setAccessible(true);
                                Object objectshow = field.get(param.thisObject);
                                XposedBridge.log(" PayPwdCommonActivity onPwdError objectshow " + objectshow);
                                boolean isshow = Boolean.parseBoolean(objectshow.toString());
                                if (isshow) {
                                    field.set(param.thisObject, false);
                                    XposedBridge.log(" PayPwdCommonActivity onPwdError field value " + field.get(param.thisObject));
                                }
                                // mback 返回键
                                //
                                super.beforeHookedMethod(param);
                            }

                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                PayHelperUtils.sendmsg(context, "提现密码错误，请检查");
                                if (alipayInfo != null) alipayInfo = null;
                                PayHelperUtils.forceOpenSelf(context);
                                super.afterHookedMethod(param);
                            }
                        });
                    }
                    if (objectActivity.getClass().getName().equals("com.alipay.mobile.transferapp.ui.TFToAccountInputActivity_")) {
                        //
                        Activity activity = (Activity) objectActivity;
                        Intent intent = activity.getIntent();
                        if (intent != null) {
                            String aliaccount = intent.getStringExtra("aliaccount");
                            String money = intent.getStringExtra("money");
                            String pwd = intent.getStringExtra("passward");
                            if (!aliaccount.equals("") && !money.equals("") && !pwd.equals("")) {
                                tranferAuto(objectActivity.getClass().getClassLoader(), aliaccount);
                                toAccountConfirm(objectActivity.getClass().getClassLoader(), context, money, pwd);
                                toAccountSuccess(objectActivity.getClass().getClassLoader(), context);
                                toAccountFailed(objectActivity.getClass().getClassLoader(), context);
                                istranfer = true;
                            }
                        }
                    }
                    if (objectActivity.getClass().getName().equals("com.alipay.mobile.chatapp.ui.PersonalChatMsgActivity_")) {

                        XposedHelpers.findAndHookMethod("com.alipay.mobile.personalbase.log.SocialLogger", classLoader, "info", String.class, String.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                XposedBridge.log("yyk com.alipay.mobile.personalbase.log.SocialLogger info 参数0 " + param.args[0] + " 参数1 " + param.args[1]);
                                super.afterHookedMethod(param);
                            }
                        });
                    }
                    super.afterHookedMethod(param);
                }
            });

            // 支付宝密码键盘
            XposedHelpers.findAndHookMethod("com.alipay.android.app.safepaybase.alikeyboard.AlipayKeyboard", classLoader, "onInput", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("AlipayKeyboard input " + param.args[0]);
                    super.afterHookedMethod(param);
                }
            });
            // 转账到支付宝账户
        } catch (Error | Exception e) {
            Log.e("e", Log.getStackTraceString(e));
            PayHelperUtils.sendmsg(context, e.getMessage());
        }
    }

    /**
     * 自动转账到支付宝
     */
    private void tranferAuto(final ClassLoader classLoader, final String aliaccountname) {
        final Class<?> clazz = XposedHelpers.findClass("com.alipay.mobile.transferapp.ui.TFToAccountInputActivity", classLoader);
        XposedHelpers.findAndHookMethod(clazz, "a", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Field field_b = clazz.getDeclaredField("b");
                field_b.setAccessible(true);
                Object objb = field_b.get(param.thisObject);
                //
                CharSequence charSequence = aliaccountname;
                XposedHelpers.callMethod(objb, "setText", charSequence);
                //
                Field field_d = clazz.getDeclaredField("d");
                field_d.setAccessible(true);
                Object objd = field_d.get(param.thisObject);
                ((Button) objd).performClick();
                super.afterHookedMethod(param);
            }
        });
    }

    private void toAccountConfirm(final ClassLoader classLoader, final Context context, final String moneycount, final String pwd) {
        final Class<?> clazz = XposedHelpers.findClass("com.alipay.mobile.transferapp.ui.TFToAccountConfirmActivity", classLoader);
        XposedHelpers.findAndHookMethod(clazz, "d", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Field fieldf = clazz.getDeclaredField("f");
                fieldf.setAccessible(true);
                Object objf = fieldf.get(param.thisObject);
                Field fieldedit = objf.getClass().getDeclaredField("mEditText");
                fieldedit.setAccessible(true);
                Object objedit = fieldedit.get(objf);
                CharSequence charSequence = moneycount;
                XposedHelpers.callMethod(objedit, "setText", charSequence, TextView.BufferType.EDITABLE);
                //
                Field fieldh = clazz.getDeclaredField("h");
                fieldh.setAccessible(true);
                Object objh = fieldh.get(param.thisObject);
                ((Button) objh).performClick();
                super.afterHookedMethod(param);
            }
        });
        flybirdWindow(classLoader);
        popupFloatView(classLoader, pwd, context);
        uppasswordKeyBoard(classLoader, pwd, context);
    }

    private void toAccountSuccess(final ClassLoader classLoader, final Context context) {
        final Class<?> clazz = XposedHelpers.findClass("com.alipay.mobile.transferapp.ui.TFToAccountConfirmActivity", classLoader);
        XposedHelpers.findAndHookMethod(clazz, "onPaySuccess", "com.alipay.mobile.framework.service.ext.phonecashier.PhoneCashierPaymentResult", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                istranfer = false;
                node = "";
                view = null;
                if (alipayInfo != null) alipayInfo = null;
                PayHelperUtils.forceOpenSelf(context);
                XposedBridge.log("转到支付宝成功" + JsonHelper.toJson(param.args[0]));
                PayHelperUtils.sendmsg(context, "转到支付宝成功");
                super.afterHookedMethod(param);
            }
        });
    }

    private void toAccountFailed(final ClassLoader classLoader, final Context context) {
        final Class<?> clazz = XposedHelpers.findClass("com.alipay.mobile.transferapp.ui.TFToAccountConfirmActivity", classLoader);
        XposedHelpers.findAndHookMethod(clazz, "onPayFailed", "com.alipay.mobile.framework.service.ext.phonecashier.PhoneCashierPaymentResult", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                istranfer = false;
                node = "";
                view = null;
                if (alipayInfo != null) alipayInfo = null;
                PayHelperUtils.forceOpenSelf(context);
                XposedBridge.log("转到支付宝失败" + JsonHelper.toJson(param.args[0]));
                PayHelperUtils.sendmsg(context, "转到支付宝失败");
                super.afterHookedMethod(param);
            }
        });
    }

    /******自动转账****/
    private void tranferAuto(final ClassLoader classLoader, final Context context, final String accountname, final String cardno, final String moneycount, final String pwd) {
        final Class<?> classtranfettobank = XposedHelpers.findClass("com.alipay.mobile.transferapp.ui.TransferToCardFormActivity", classLoader);
        XposedHelpers.findAndHookMethod(classtranfettobank, "a", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Field inputname = XposedHelpers.findField(param.thisObject.getClass(), "d");
                inputname.setAccessible(true);
                CharSequence charSequence = accountname;
                XposedHelpers.callMethod(inputname.get(param.thisObject), "setText", charSequence);
                //
                Field inputcardno = XposedHelpers.findField(param.thisObject.getClass(), "c");
                charSequence = cardno;
                inputcardno.setAccessible(true);
                // 设置光标
                XposedHelpers.callMethod(inputcardno.get(param.thisObject), "setText", charSequence);
                Field inputboxd = XposedHelpers.findField(inputcardno.getType(), "d");
                inputboxd.setAccessible(true);
                Object objinputbox = inputboxd.get(inputcardno.get(param.thisObject));
                ((EditText) objinputbox).requestFocus();
                ((EditText) objinputbox).clearFocus();
                //
                Field inputmoney = XposedHelpers.findField(param.thisObject.getClass(), "e");
                inputmoney.setAccessible(true);
                charSequence = moneycount;
                XposedHelpers.callMethod(inputmoney.get(param.thisObject), "setText", charSequence);
                inputboxd = XposedHelpers.findField(inputmoney.getType(), "d");
                inputboxd.setAccessible(true);
                //
                Field butnext = XposedHelpers.findField(param.thisObject.getClass(), "m");
                butnext.setAccessible(true);
                ((Button) (butnext.get(param.thisObject))).performClick();
                super.afterHookedMethod(param);
            }
        });
        flybirdWindow(classLoader);
        popupFloatView(classLoader, pwd, context);
        uppasswordKeyBoard(classLoader, pwd, context);
    }

    private void flybirdWindow(final ClassLoader classLoader) {
        XposedHelpers.findAndHookMethod("com.flybird.FBView", classLoader, "updateEvent", String.class, String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Field m = param.thisObject.getClass().getDeclaredField("mTag");
                m.setAccessible(true);
                if (param.args[1].toString().equals("onclick") && m.get(param.thisObject).toString().equals("div") && node == "") {
                    //
                    Field mnode = param.thisObject.getClass().getDeclaredField("mNode");
                    mnode.setAccessible(true);
                    Object objmnode = mnode.get(param.thisObject);
                    node = objmnode.toString();
                    //
                    Field mview = param.thisObject.getClass().getDeclaredField("mView");
                    mview.setAccessible(true);
                    Object objview = mview.get(param.thisObject);
                    View _v = (View) objview;
                    view = _v;
                    //
                }
                super.afterHookedMethod(param);
            }
        });
        XposedHelpers.findAndHookMethod("com.flybird.FBFrameLayout", classLoader, "onDraw", Canvas.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                if (view != null && view.equals(param.thisObject)) {
                    view.performClick();
                    view = null;
                }
                super.afterHookedMethod(param);
            }
        });
    }

    public void onTranstoBankFailed(final ClassLoader classLoader, final Context context) {
        XposedHelpers.findAndHookMethod("com.alipay.mobile.transferapp.ui.TFToCardConfirmActivity", classLoader, "onPayFailed", "com.alipay.mobile.framework.service.ext.phonecashier.PhoneCashierPaymentResult", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                istranfer = false;
                node = "";
                view = null;
                if (alipayInfo != null) alipayInfo = null;
                PayHelperUtils.forceOpenSelf(context);
                XposedBridge.log("转到银行卡失败" + JsonHelper.toJson(param.args[0]));
                PayHelperUtils.sendmsg(context, "银行卡转账失败");
                super.afterHookedMethod(param);
            }
        });
    }

    public void onTranstoBankSuccess(final ClassLoader classLoader, final Context context) {
        XposedHelpers.findAndHookMethod("com.alipay.mobile.transferapp.ui.TFToCardConfirmActivity", classLoader, "onPaySuccess", "com.alipay.mobile.framework.service.ext.phonecashier.PhoneCashierPaymentResult", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                istranfer = false;
                node = "";
                view = null;
                PayHelperUtils.forceOpenSelf(context);
                if (alipayInfo != null) alipayInfo = null;
                XposedBridge.log("转到银行卡成功" + JsonHelper.toJson(param.args[0]));
                PayHelperUtils.sendmsg(context, "转到银行卡成功");
                super.afterHookedMethod(param);
            }
        });
    }

    // 确认转账后的弹窗
    private void popupFloatView(final ClassLoader classLoader, final String pwd, final Context context) {
        XposedHelpers.findAndHookMethod("com.alipay.wealth.common.ui.PopupFloatViewBuilder", classLoader, "show", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                try {
                    Object objclass = param.thisObject;//PopupFloatViewBuilder
                    Field cfield = objclass.getClass().getDeclaredField("c");//PopupFloatView
                    Class<?> view = XposedHelpers.findClass("com.alipay.wealth.common.ui.PopupFloatView", objclass.getClass().getClassLoader());
                    cfield.setAccessible(true);
                    Object o = cfield.get(objclass);
                    //
                    Field f = view.getDeclaredField("m");
                    f.setAccessible(true);
                    Button button = (Button) f.get(o);
                    button.performClick();
                    //
                } catch (Error e) {
                    XposedBridge.log("确认转账 error  " + e);
                }
                super.afterHookedMethod(param);
            }
        });
    }
    /*******end********/
    /*****自动提现****/
    private void withDrawAuto(final ClassLoader classLoader, Object object, final String pwd, final Context context) {
        final Class<?> classwithdraw = XposedHelpers.findClass("com.alipay.mobile.withdraw.ui.WithdrawActivity", classLoader);
        XposedHelpers.findAndHookMethod(classwithdraw, "a", "com.alipay.withdraw.rpc.result.PreWithdrawResp", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
            }

            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                try {
                    Field field = classwithdraw.getDeclaredField("B");
                    field.setAccessible(true);
                    Object objfield = field.get(param.thisObject);
                    Field g = field.getType().getDeclaredField("g");
                    g.setAccessible(true);
                    Object money = g.get(objfield);
                    // 模拟点击
                    Field withdrawall = XposedHelpers.findField(param.thisObject.getClass(), "b");
                    withdrawall.setAccessible(true);
                    View _v = (View) withdrawall.get(param.thisObject);
                    _v.performClick();
                    //
                    Field conviewbut = XposedHelpers.findField(param.thisObject.getClass(), "d");
                    conviewbut.setAccessible(true);
                    //
                    XposedHelpers.callMethod(conviewbut.get(param.thisObject), "setEnabled", true);
                    //
                    Button conview = (Button) conviewbut.get(param.thisObject);
                    conview.performClick();
                    //
                } catch (Error | IllegalAccessException | NoSuchFieldException e) {
                    XposedBridge.log("in withdraw error " + e);
                    e.printStackTrace();
                }
                super.afterHookedMethod(param);
            }
        });
        popupFloatView(classLoader, pwd, context);
        uppasswordKeyBoard(classLoader, pwd, context);
    }

    private void withdrawSuccess(Class classwithdraw, final Context context) {
        XposedHelpers.findAndHookMethod(classwithdraw, "a", "com.alipay.withdraw.rpc.result.WithdrawResp", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("提现成功，result= " + JsonHelper.toJson(param.args[0]));
                PayHelperUtils.forceOpenSelf(context);
                PayHelperUtils.sendmsg(context, "提现成功");
                if (alipayInfo != null) alipayInfo = null;
            }
        });
    }

    private void withdrawError(Class classwithdraw, final Context context) {
        XposedHelpers.findAndHookMethod(classwithdraw, "b", "com.alipay.withdraw.rpc.result.WithdrawResp", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("提现异常，result= " + JsonHelper.toJson(param.args[0]));
                PayHelperUtils.forceOpenSelf(context);
                PayHelperUtils.sendmsg(context, "提现异常,result");
                if (alipayInfo != null) alipayInfo = null;
            }
        });
    }

    // 吊起密码键盘
    private void uppasswordKeyBoard(ClassLoader classLoader, final String pass, final Context context) {
        // 支付宝密码键盘
        XposedHelpers.findAndHookMethod("com.alipay.android.app.safepaybase.alikeyboard.AlipayKeyboard", classLoader, "initializeNumKeyboard", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                //
                LinearLayout layout = (LinearLayout) param.thisObject;
                ViewGroup viewGroup = (ViewGroup) layout.getChildAt(0);
                ArrayList<View> viewlist = new ArrayList<View>();
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    ViewGroup viewchild = (ViewGroup) viewGroup.getChildAt(i);
                    for (int j = 0; j < viewchild.getChildCount(); j++) {
                        View _v = viewchild.getChildAt(j);
                        viewlist.add(_v);
                    }
                }
                char[] pwdchar = pass.toCharArray();
                for (int i = 0; i < pwdchar.length; i++) {
                    int index = Integer.parseInt("" + pwdchar[i], 10);
                    View view = viewlist.get(--index);
                    presspwdAuto(view);
                }
                super.afterHookedMethod(param);
            }
        });
    }

    // 自动输入密码
    private void presspwdAuto(View _view) {
        try {
            Method getListenerInfo = View.class.getDeclaredMethod("getListenerInfo");
            getListenerInfo.setAccessible(true);
            Object listenerInfo = getListenerInfo.invoke(_view); // 得到 原始的 OnClickListener 对象
            //
            Class<?> listenerInfoClz = Class.forName("android.view.View$ListenerInfo");
            Field mOnTouchListener = listenerInfoClz.getDeclaredField("mOnTouchListener");
            mOnTouchListener.setAccessible(true);
            final View.OnTouchListener originOnTouchListener = (View.OnTouchListener) mOnTouchListener.get(listenerInfo);
            final MotionEvent event = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), MotionEvent.ACTION_DOWN, _view.getX(), _view.getY(), 0);
            //
            _view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    originOnTouchListener.onTouch(view, event);
                }
            });
            _view.performClick();
        } catch (Error | Exception e) {
            XposedBridge.log("键盘输入error " + e);
        }
    }

    /****** end ******/
    private void securityCheckHook(ClassLoader classLoader) {
        try {
            Class<?> securityCheckClazz = XposedHelpers.findClass("com.alipay.mobile.base.security.CI", classLoader);
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", String.class, String.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Object object = param.getResult();
                    XposedHelpers.setBooleanField(object, "a", false);
                    param.setResult(object);
                    super.afterHookedMethod(param);
                }
            });

            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", Class.class, String.class, String.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return (byte) 1;
                }
            });
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", ClassLoader.class, String.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return (byte) 1;
                }
            });
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return false;
                }
            });

        } catch (Error | Exception e) {
            e.printStackTrace();
        }
    }


}