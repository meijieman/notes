package com.zhiyi.xppay.hook.mowang;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/4/13.
 */

public class Function2MoTong implements InvocationHandler {
    @Override
    public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
        String methodName = method.getName();
        XposedBridge.log("Function2MoTong 调用的方法名称为:" + methodName);
        XposedBridge.log("Function2MoTong 返回的类型为" + method.getReturnType().getName());
        XposedBridge.log("Function2MoTong >>>>>>> 结果"+objects[0]);
        Object objcorou = objects[0];
        Object objCont = objects[1];
//        AliPayUtils aliPayUtils = new AliPayUtils(getMActivity());

        // doresume
        return null;
    }
}
