package com.zhiyi.xppay.hook;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.main.Main;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by pc_mg on 2018/12/28.
 */

public class CloudPayHook {
    private static ClassLoader mClassloader;
    private static Activity mActivity;
    public static String encvirtualCardNo;
    public static Long time;
    private static long lastUptime;
    public void hook(final ClassLoader classLoader,Context _context) {
        mClassloader = classLoader;
        lastUptime = System.currentTimeMillis();
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Bundle bundle = (Bundle) param.args[0];
                XposedBridge.log("当前activity 》》》》》》》》 "+param.thisObject.getClass().getName());
                if (param.thisObject.getClass().toString().contains("com.unionpay.activity.UPActivityMain")) {
                    XposedBridge.log("云闪付 hook UPActivityMain成功");
                    final Context context = (Context) param.thisObject;
                    mActivity = (Activity) context;
                    //
                    IntentFilter filter = new IntentFilter();
                    filter.addAction(AppConst.CP_QRCODE);
                    filter.addAction(AppConst.CP_GETPAYER);
                    filter.addAction(AppConst.CP_LOGIN);
                    context.registerReceiver(new Main().new CloundPayReceiver(), filter);
                }
                super.afterHookedMethod(param);
            }
        });
        XposedHelpers.findAndHookMethod("com.unionpay.activity.mine.UPActivityMine$1", classLoader, "onReceive", Context.class, Intent.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                Intent intent = (Intent)param.args[1];
                XposedBridge.log("UPActivityMine$1 >>>>>onReceive>>>>> "+intent.getAction()+JsonHelper.toJson(intent.getExtras()));
            }
        });
    }

    public static String CheckNewOrder(final Activity activity) {
        try {
            XposedBridge.log("开始轮询账单");
            String str2 = "https://wallet.95516.com/app/inApp/order/list?currentPage=" + Enc("1", mClassloader) + "&month=" + Enc("0", mClassloader) + "&orderStatus=" + Enc("0", mClassloader) + "&orderType=" + Enc("A30000", mClassloader) + "&pageSize=" + Enc("5", mClassloader) + "";
            OkHttpClient client = null;
            OkHttpClient.Builder builder = new OkHttpClient().newBuilder();
            builder.connectTimeout(50, TimeUnit.SECONDS);
            builder.writeTimeout(50, TimeUnit.SECONDS);
            builder.readTimeout(50, TimeUnit.SECONDS);
            client = builder.build();
            String sid = getSid(mClassloader);
            if(TextUtils.isEmpty(sid)){
                restartCPPay();
                XposedBridge.log("获得sid数据异常，重新启动云闪付");
                return "sid 数据为空";
            }
            Request request = new Request.Builder()
                    .url(str2)
                    .header("X-Tingyun-Id", getXTid(mClassloader))
                    .header("X-Tingyun-Lib-Type-N-ST", "0;" + System.currentTimeMillis())
                    .header("sid", sid)
                    .header("urid", geturid(mClassloader, activity))
                    .header("cityCd", getcityCd(mClassloader))
                    .header("locale", "zh-CN")
                    .header("User-Agent", "Android CHSP")
                    .header("dfpSessionId", getDfpSessionId(mClassloader))
                    .header("gray", getgray(mClassloader))
                    .header("Accept", "*/*")
                    .header("key_session_id", "")
                    .header("Host", "wallet.95516.com")
                    .build();
            Response response = client.newCall(request).execute();

            String RSP = response.body().string();
            String DecRsp = Dec(RSP, mClassloader);
            XposedBridge.log("CheckNewOrder str2=>" + str2 + " DecRSP=>" + DecRsp);
            if (DecRsp != null) {
                JSONObject jsond = new JSONObject(DecRsp);
                String msg = jsond.optString("msg");
                if(!TextUtils.isEmpty(msg)&&msg.contains("请重新登录")){
                    isStartQuery = false;
                    PayHelperUtils.sendmsg(getContext(),"云闪付账号已经在其他设备登录");
                    return "云闪付账号已经在其他设备登录";
                }
                //这里有很多笔，可以自己调整同步逻辑s
                JSONArray o = jsond.getJSONObject("params").getJSONArray("uporders");
                boolean find = false;
                String mrt = "";
//                int length = o.length()>3?3:o.length();
                for (int i = 0; i < o.length(); i++) {
                    JSONObject p = o.getJSONObject(i);
                    final String orderid = p.getString("orderId");
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String rt = DoOrderInfoGet(orderid, activity);
                            if (rt != null && rt.length() > 1) {
                                XposedBridge.log(rt);
                            }
                        }
                    }).start();
//                    if (isNewOrder(orderid)) {
//                        new Thread(new Runnable() {
//                            @Override
//                            public void run() {
//                                String rt = DoOrderInfoGet(orderid, activity);
//                                if (rt != null && rt.length() > 1) {
//                                    XposedBridge.log(rt);
//                                    mrt += rt;
//                                }
//                                find = true;
//                            }
//                        }).start();
//                    }
                }
//                if (find) {
//                    return mrt;
//                }
            } else {
                XposedBridge.log("云闪付请求到的数据为空");
                PayHelperUtils.sendmsg(getContext(),"云闪付CheckNewOrder请求订单数据异常");
                restartCPPay();
            }
            return "NO_MATCH_ORDER";
        } catch (Throwable e) {
//            XposedBridge.log(e);
            return "CheckNewOrder ERR:" + e.getLocalizedMessage();
        }
    }

    private static String DoOrderInfoGet(String orderid, Activity activity) {
        if (orderid.length() > 5) {
            try {
                String args = "{\"orderType\":\"21\",\"transTp\":\"simple\",\"orderId\":\"" + orderid + "\"}";
                String str2 = "https://wallet.95516.com/app/inApp/order/detail";
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url(str2)
                        .header("X-Tingyun-Id", getXTid(mClassloader))
                        .header("X-Tingyun-Lib-Type-N-ST", "0;" + System.currentTimeMillis())
                        .header("sid", getSid(mClassloader))
                        .header("urid", geturid(mClassloader, activity))
                        .header("cityCd", getcityCd(mClassloader))
                        .header("locale", "zh-CN")
                        .header("User-Agent", "Android CHSP")
                        .header("dfpSessionId", getDfpSessionId(mClassloader))
                        .header("gray", getgray(mClassloader))
                        .header("Accept", "*/*")
                        .header("key_session_id", "")
                        .header("Content-Type", "application/json; charset=utf-8")
                        .header("Host", "wallet.95516.com")
                        .post(RequestBody.create(null, Enc(args, mClassloader)))
                        .build();
                Response response = client.newCall(request).execute();
                String RSP = response.body().string();
                String DecRsp = Dec(RSP, mClassloader);
//                XposedBridge.log("FORRECODE DoOrderInfoGet str2=>" + str2 + " DecRSP=>" + DecRsp);
                //这里有很多笔，可以自己调整同步逻辑s
                JSONObject params = new JSONObject(DecRsp).getJSONObject("params");
                String orderDetail = params.optString("orderDetail");
                if(!TextUtils.isEmpty(orderDetail)){
                    JSONObject o = new JSONObject(orderDetail);
                    String u = o.getString("payUserName");
                    String mark = o.getString("postScript");
                    String totalAmount = params.getString("totalAmount");
                    String walletOrderid = params.getString("orderId");
                    walletOrderid = walletOrderid.replaceAll(" ", "");
                    String dt = params.getString("orderTime");
                    dt = PayHelperUtils.dateToStamp(dt,"yyyy-MM-dd HH:mm:ss");
                    float f = Float.parseFloat(totalAmount) / 100;
                    totalAmount = "" + f;
                    //
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("bill_no", walletOrderid);//orderid
                    broadCastIntent.putExtra("bill_money", totalAmount);
                    broadCastIntent.putExtra("bill_mark", mark);
                    broadCastIntent.putExtra("bill_type", AppConst.TYPE_CPPAY);
                    //
                    broadCastIntent.putExtra("bill_payer", u);
                    broadCastIntent.putExtra("bill_dt", dt);
                    //
                    broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                    getContext().sendBroadcast(broadCastIntent);
                }
                return "";
            } catch (Throwable e) {
//                XposedBridge.log(e);
                PayHelperUtils.sendmsg(getContext(),"云闪付DoOrderInfoGet请求订单数据异常");
                restartCPPay();
                return "DoOrderInfoGet ERR:" + e.getLocalizedMessage();
            }
        } else {
            return "ERROR_ORDER:" + orderid;
        }
    }

    private static void getVirtualCardNum(Activity activity, final GetVirCardListener listener) { // E99A1E717BAEFDAE F2E42D325BC2AE7E
        try {
            final String str2 = "https://pay.95516.com/pay-web/restlet/qr/p2pPay/getInitInfo?cardNo=&cityCode=" + Enc(getcityCd(mClassloader), mClassloader);
            cpRequest(str2, activity, new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    XposedBridge.log(e);
                    listener.error(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String RSP = response.body().string();
                    String Rsp = Dec(RSP, mClassloader);
                    if (Rsp == null) {
                        if (listener != null) {
                            listener.error("数据为空");
                        }
                    } else {
                        try {
                            String encvirtualCardNo = Enc(new JSONObject(Rsp).getJSONObject("params").getJSONArray("cardList").getJSONObject(0).getString("virtualCardNo"), mClassloader);
                            if (listener != null) {
                                listener.success(encvirtualCardNo);
                            }
                        } catch (Throwable e) {
                            XposedBridge.log(e);
                            if (listener != null) {
                                listener.error(e.getMessage());
                            }
                        }
                    }
                }
            });
        } catch (Throwable e) {
            XposedBridge.log(e);
        }

    }

    public static void GenQrCode(final Activity activity, final String money, final String mark,final String type, String encvirtualCardNo) {
//        if (System.currentTimeMillis() - lastUptime > 1200000) {
//            lastUptime = System.currentTimeMillis();
//            PayHelperUtils.startAppCP(getContext());
//        }
        try {
            //
            String mark1 = mark;
            String money1 = new BigDecimal(money).setScale(2, RoundingMode.HALF_UP).toPlainString().replace(".", "");
            final String str2 = "https://pay.95516.com/pay-web/restlet/qr/p2pPay/applyQrCode?txnAmt="
                    + Enc(money1, mClassloader) + "&cityCode=" + Enc(getcityCd(mClassloader), mClassloader) + "&comments=" + Enc(mark1, mClassloader) + "&virtualCardNo=" + encvirtualCardNo;
            cpRequest(str2, activity, new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    XposedBridge.log("云闪付生成二维码失败");
//                    PayHelperUtils.startAppCP(getContext());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String RSP = response.body().string();
                    String Rsp = Dec(RSP, mClassloader);
                    XposedBridge.log("云闪付生成二维码结果》》"+Rsp);
                    try {
                        JSONObject o = new JSONObject(Rsp);
                        o.put("mark", mark);
                        o.put("money", money);
                        final String orderid = o.getJSONObject("params").getString("orderId");
                        String payurl = o.getJSONObject("params").getString("certificate");
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("money", money);
                        broadCastIntent.putExtra("mark", mark);
                        broadCastIntent.putExtra("type", type);
                        broadCastIntent.putExtra("payurl", payurl);
                        broadCastIntent.putExtra("img_url", orderid);
                        broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                        getContext().sendBroadcast(broadCastIntent);
//                        if (dbManager == null) {
//                            dbManager = new DBManager(activity);
//                        }
                        startGetPayer(mark, orderid);
                    } catch (Throwable e) {
                        XposedBridge.log(e);
                    }
                }
            });
        } catch (Throwable e) {
            XposedBridge.log(e);
        }
    }

    private static Thread thread;

    private static void startGetPayer(String remark, String orderid) {
//        CpReqData data = new CpReqData(remark);
//        data.time = "" + (System.currentTimeMillis() / 1000);
        if (thread == null || !thread.isAlive()) {
            XposedBridge.log("轮询线程启动~！！！！！！！！！！！！！！！！！！！！");
            isStartQuery = true;
            thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    CloudPayHook.run();
                }
            });
            thread.start();
        }
    }

    private static String Dec(String src, ClassLoader mClassLoader) {
        try {
            return (String) XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.unionpay.encrypt.IJniInterface", mClassLoader), "decryptMsg", src);
        } catch (Throwable e) {
            XposedBridge.log(e);
        }
        return "";
    }

    private static String Enc(String src, ClassLoader mClassLoader) {
        try {
            return (String) XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.unionpay.encrypt.IJniInterface", mClassLoader), "encryptMsg", src);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return "";
    }

    private static String getXTid(ClassLoader mClassLoader) {
        try {
            Class m_s = XposedHelpers.findClass("com.networkbench.agent.impl.m.s", mClassLoader);
            Object f = XposedHelpers.callStaticMethod(m_s, "f");
            Object h = XposedHelpers.callMethod(f, "H");
            Object i = XposedHelpers.callStaticMethod(m_s, "I");

            String xtid = m_s.getDeclaredMethod("a", String.class, int.class).invoke(null, h, i).toString();
            return xtid;
        } catch (Throwable e) {
            XposedBridge.log(e);
        }
        return null;
    }

    private static String getSid(ClassLoader mClassLoader) {
        String sid = "";
        try {
            Object b = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.unionpay.network.aa", mClassLoader), "b");
            sid = XposedHelpers.callMethod(b, "e").toString();
        } catch (Throwable e) {
            XposedBridge.log("CPPAY getSid 异常"+JsonHelper.toJson(e));
        }
//        XposedBridge.log("sid:" + sid + "");
        return sid;
    }

    private static String geturid(ClassLoader mClassLoader, Activity activity) {
        String Cacheurid = "";
        try {
            Class data_d = XposedHelpers.findClass("com.unionpay.data.d", mClassLoader);
            Object o = XposedHelpers.callStaticMethod(data_d, "a", new Class[]{Context.class}, new Object[]{activity});
            Object o_A = XposedHelpers.callMethod(o, "A");
            if (o_A == null) {
                PayHelperUtils.sendmsg(getContext(), "请登录云闪付后重试");
            } else {
                String v1_2 = XposedHelpers.callMethod(XposedHelpers.callMethod(o, "A"), "getHashUserId").toString();
                if (!TextUtils.isEmpty(v1_2) && v1_2.length() >= 15) {
                    Cacheurid = v1_2.substring(v1_2.length() - 15);
                }
            }
        } catch (Throwable e) {
            XposedBridge.log("CPPAY geturid 异常"+JsonHelper.toJson(e));
        }
        return Cacheurid;
    }

    private static String getDfpSessionId(ClassLoader mClassLoader) {
        String CacheDfpSessionId = "";
        try {
            Object o = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.unionpay.service.b", mClassLoader), "d");
            CacheDfpSessionId = o.toString();
        } catch (Throwable e) {
            XposedBridge.log("CPPAY getDfpSessionId 异常"+JsonHelper.toJson(e));
        }
        return CacheDfpSessionId;
    }

    private static String getcityCd(ClassLoader mClassLoader) {
        String CachecityCd = "";
        try {
            CachecityCd = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.unionpay.location.a", mClassLoader), "i").toString();
        } catch (Throwable e) {
            XposedBridge.log("CPPAY getcityCd 异常"+JsonHelper.toJson(e));
        }
        return CachecityCd;
    }

    private static String getgray(ClassLoader mClassLoader) {
        String Cachegray = "";
        try {
            Object b = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.unionpay.network.aa", mClassLoader), "b");
            Cachegray = XposedHelpers.callMethod(b, "d").toString();
        } catch (Throwable e) {
            XposedBridge.log("CPPAY getgray 异常"+JsonHelper.toJson(e));
        }
        return Cachegray;
    }

    private static void cpRequest(String url, Activity activity, Callback callback) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .header("X-Tingyun-Id", getXTid(mClassloader))
                .header("X-Tingyun-Lib-Type-N-ST", "0;" + System.currentTimeMillis())
                .header("sid", getSid(mClassloader))
                .header("urid", geturid(mClassloader, activity))
                .header("cityCd", getcityCd(mClassloader))
                .header("locale", "zh-CN")
                .header("User-Agent", "Android CHSP")
                .header("dfpSessionId", getDfpSessionId(mClassloader))
                .header("gray", getgray(mClassloader))
                .header("key_session_id", "")
                .header("Host", "pay.95516.com")
                .build();
        client.newCall(request).enqueue(callback);
    }

    public static Context getContext() {
        try {
            Class<?> ActivityThread =
                    Class.forName("android.app.ActivityThread");

            Method method = ActivityThread.getMethod("currentActivityThread");
            Object currentActivityThread = method.invoke(ActivityThread);//获取currentActivityThread 对象
            Method method2 = currentActivityThread.getClass().getMethod("getApplication");
            return (Context) method2.invoke(currentActivityThread);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    public static void Login() {
        String loginid = geturid(mClassloader, mActivity);
        PayHelperUtils.sendLoginId(loginid, AppConst.TYPE_CPPAY, getContext());
    }

    public static void BuildQRcode(final Activity activity, final String money, final String mark,final String type) {
        getVirtualCardNum(activity, new GetVirCardListener() {
            @Override
            public void success(String re) {
                encvirtualCardNo = re;
                time = System.currentTimeMillis();
                GenQrCode(activity, money, mark,type, re);
            }

            @Override
            public void error(String error) {
                XposedBridge.log("云闪付生成二维码异常" + error);
                PayHelperUtils.sendmsg(getContext(), "云闪付生成二维码异常，正在重新生成");
                restartCPPay();
            }
        });
    }

    private static void restartCPPay(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    PayHelperUtils.startAppCP(getContext());
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                PayHelperUtils.forceOpenSelf(getContext());
//                if(!AppConst.LOCKSCREEN){
//                }
            }
        }).start();
    }

    public static void run() {
        do {
            try {
                Thread.sleep(10000);
                CheckNewOrder(mActivity);
            } catch (Throwable t) {
                XposedBridge.log("CPPAY RUN >>> 异常"+ JsonHelper.toJson(t));
            }
        }
        while (isStartQuery);
    }
    private static boolean isStartQuery;
}

