package com.zhiyi.xppay.hook.lakala;

/**
 * Created by pc_mg on 2019/5/11.
 */

public class TradeDataLKL {
    public long reqTime;
    public String tradeNo;
    public int states = 0;
    @Override
    public boolean equals(Object obj) {
        if(obj instanceof TradeDataLKL){
            if(tradeNo == null){
                return false;
            }
            if(tradeNo.equals(obj.toString())){
                return true;
            }
        }
        return false;
    }
}
