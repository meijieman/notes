package com.zhiyi.xppay.hook.mowang;

import com.google.myjson.internal.ObjectConstructor;

/**
 * Created by pc_mg on 2019/4/15.
 */

public class OrderObjectMW {
    public Object o_observable;
    public Object objfunc5;
    public Object objfunc4;
    public long createtime;
    public String mark;
    public boolean ischecked;
    public OrderObjectMW(Object observable, Object func5,Object func4,String _mark){
        o_observable = observable;
        objfunc5 = func5;
        objfunc4 = func4;
        createtime = System.currentTimeMillis();
        mark = _mark;
        ischecked = false;
    }
}
