package com.zhiyi.xppay.hook;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;

/**
 * Created by pc_mg on 2019/1/15.
 */

public class RestartLXLService extends Service implements Runnable {
    @Override
    public void onCreate() {
        super.onCreate();
        new Thread(this).start();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000);
                if (!PayHelperUtils.isAppRunning(CustomApplcation.getContext(),"com.lakala.cloudpos.qcodeapp")){
                    PayHelperUtils.sendmsg(CustomApplcation.getContext(), "订时启动拉卡拉");
                    PayHelperUtils.startAppLKL(CustomApplcation.getContext());;
                    Thread.sleep(15000);
                    if (!AppConst.LOCKSCREEN) {
                        PayHelperUtils.startAPP();
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
