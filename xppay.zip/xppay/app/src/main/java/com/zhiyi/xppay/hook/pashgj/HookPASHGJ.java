package com.zhiyi.xppay.hook.pashgj;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/6/10.
 */

public class HookPASHGJ {
    private static ClassLoader mclassLoader;
    private static Context mcontext;
    public void hook(ClassLoader classLoader, final Context context) {
        mcontext = context;
        mclassLoader = context.getClassLoader();
        PayHelperUtils.LogMsg("平安商户管家");
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("平安商户管家当前activity>>>>>>"+param.thisObject.getClass().getName());
            }
        });
        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.yqb.mm.webservice.MMWebActivity", classLoader), "a", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if(param.args.length>=3){
                    PayHelperUtils.LogMsg("str>>"+param.args[1]+">><>mMCookie>>"+param.args[2]);
                }
            }
        });
        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.yqb.mm.webservice.b", classLoader), "shouldInterceptRequest", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                super.afterHookedMethod(param);

                PayHelperUtils.LogMsg("b shouldInterceptRequest str<<<<<<xxxxxxxxxxx>>>>>"+param.args[0].getClass().getName()+">> str >>"+param.args[1]+">>class>>"+param.args[1].getClass().getName());

            }
        });
        XposedBridge.hookAllMethods(WebViewClient.class, "shouldInterceptRequest", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                super.afterHookedMethod(param);
                WebResourceRequest request = (WebResourceRequest)param.args[1];
                URLConnection connection;
                HttpURLConnection conn ;
                URL url = new URL(request.getUrl().toString());
                String methodname = request.getMethod();
                if(methodname.equals("POST")){
                    connection = url.openConnection();
                    conn = (HttpURLConnection) connection;
                    conn.setRequestMethod( "POST");
                    OutputStream os = conn.getOutputStream();

                }
                PayHelperUtils.LogMsg("WebViewClient str<<<<<<dasdasdas>>>>>"+param.args[1].getClass().getName()+"\n >> request headers >>"+request.getRequestHeaders());

            }
        });
        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.yqb.mm.webservice.d", classLoader), "a", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("<<< ---- >>>"+param.args.length+">>>>>"+param.args[0].getClass().getName());
                if("org.json.JSONArray".equals(param.args[0].getClass().getName())){
                    PayHelperUtils.LogMsg(">>>"+param.args[0].toString()+">> result >> "+param.getResult()+"\n param.getResult() result >>"+XposedHelpers.callMethod(param.getResult(),"get","arg0"));
                }
                if("com.yqb.mm.webservice.MMWebActivity$4".equals(param.args[0].getClass().getName())&&param.args.length==5){
                    PayHelperUtils.LogMsg("d a str<<<<<<dasdasdas>>>>>"+param.args[1]+">> str2 >>"+param.args[4]+">>result>>"+param.getResult());
                }
            }
        });
//        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.yqb.mm.webservice.MMWebActivity", classLoader), "onActivityResult", new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                PayHelperUtils.LogMsg("onActivityResult i >>"+param.args[0]+">><>i2 >>"+param.args[1]+">> intent >>"+param.args[2]);
//            }
//        });
//        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.yqb.mm.webservice.MMWebActivity", classLoader), "onActivityResult", new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                PayHelperUtils.LogMsg("onActivityResult i >>"+param.args[0]+">><>i2 >>"+param.args[1]+">> intent >>"+param.args[2]);
//            }
//        });
//        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.yqb.mm.webservice.MMWebActivity$1", classLoader), "onJsPrompt", new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                PayHelperUtils.LogMsg("MMWebActivity$1 onJsPrompt str >>"+param.args[1]+">><>str2 >>"+param.args[2]+">> str3 >>"+param.args[3]);
//            }
//        });
    XposedHelpers.findAndHookMethod("com.bonree.agent.android.webview.BonreeJavaScriptBridge", classLoader, "setUserInfo", String.class, new XC_MethodHook() {
        @Override
        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
            super.afterHookedMethod(param);
            PayHelperUtils.LogMsg("BonreeJavaScriptBridge setUserInfo "+param.args[0]);
        }
    });
    }
}
