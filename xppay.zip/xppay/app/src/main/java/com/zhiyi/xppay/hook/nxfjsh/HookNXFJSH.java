package com.zhiyi.xppay.hook.nxfjsh;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.google.myjson.reflect.TypeToken;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/5/6.
 */

public class HookNXFJSH {
    private static ClassLoader mclassLoader;
    private static Context mcontext;
    public static boolean isactivitystart;
    public static boolean ishookeed;
    public static String loginid;
    private static String staticqrurl;
    public static Object objCasherurl;
    public void hook(ClassLoader classLoader, Context context) {
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                PayHelperUtils.LogMsg("福建农信商户版 Activity >>>>>> " + param.thisObject.getClass().getName());
            }
        });
        mcontext = context;
        mclassLoader = context.getClassLoader();
        try {
            XposedHelpers.findAndHookMethod("cn.swiftpass.enterprise.io.net.NetHelper", mclassLoader, "httpsPost", String.class,
                    JSONObject.class, String.class, String.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            super.beforeHookedMethod(param);
                            PayHelperUtils.LogMsg("NetHelper httpsPost url >>" + param.args[0]+">>data >> "+param.args[1]+">> str >> "+param.args[2]+">> str1>>"+param.args[3]);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            super.afterHookedMethod(param);
                            PayHelperUtils.LogMsg("NetHelper httpsPost result >>" + XposedHelpers.getObjectField(param.getResult(),"data"));
                        }
                    });
        } catch (Exception e) {
            PayHelperUtils.LogMsg("福建农信商户版 error >>>>>>>>>>>>>>" + e);
        }
//        XposedHelpers.findAndHookMethod("cn.swiftpass.enterprise.utils.SignUtil", classLoader, "createSign", Map.class, String.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//            }
//        });
//        XposedBridge.hookAllMethods(XposedHelpers.findClass("cn.swiftpass.enterprise.ui.activity.store.StoreManagerServer", classLoader), "unionStdQrCode", new XC_MethodHook() {
//            @Override
//            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
//                super.beforeHookedMethod(param);
//                throw new Exception("————@@#$@!!!!!!!!!!!!--------------—");
//            }
//
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                throw new Exception("————++————=+——");
//            }
//        });
//        XposedHelpers.findAndHookMethod("cn.swiftpass.enterprise.utils.Logger", classLoader, "log", String.class, String.class,
//                XposedHelpers.findClass("cn.swiftpass.enterprise.utils.Logger$LogType", classLoader), new XC_MethodHook() {
//                    @Override
//                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                        super.afterHookedMethod(param);
//                        PayHelperUtils.LogMsg("Logger 0 >>" + param.args[0]+">> 1 >>"+param.args[1]);
//                    }
//                });
    }

    public static void sendLoginID() {
        loginid = "" + getMchId();
        PayHelperUtils.sendLoginId(loginid, AppConst.TYPE_NXFJSH, mcontext);
        if(getCashierQrCode() == null){
//            RequestCaShierQRCode();
            RequestShopQrcode();
        }
    }

    public static void CreateStaticQR(Intent intent){
        final String money = intent.getStringExtra("money");
        final String mark = intent.getStringExtra("mark");
        final String type = intent.getStringExtra("type");
        final int amount = (int) (Float.parseFloat(money) * 100);
        Object qrId = getqrId();
        final JSONObject jSONObject = new JSONObject();
        final long currentTimeMillis = System.currentTimeMillis();
        if(TextUtils.isEmpty(staticqrurl)){
            try {
                jSONObject.put("qrId",qrId);
                jSONObject.put("spayRs", currentTimeMillis);
                Object sign = createSign(jSONObject);
                jSONObject.put("nns",sign);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Object object = getRequestResult("https://spay3.swiftpass.cn/spay/merchant/interface/unionStdQrCode", jSONObject,String.valueOf(currentTimeMillis),null);
                        object = XposedHelpers.getObjectField(object, "data");
                        JSONObject jsonResult = (JSONObject) object;
                        String result = jsonResult.optString("result");
                        PayHelperUtils.LogMsg("请求的二维码结果》》》》》》》"+jsonResult);
                        //
                        if(result.equals("200")){
                            try {
                                String msg = jsonResult.optString("message");
                                JSONObject jsonMsg = new JSONObject(msg);
                                String qrurl = jsonMsg.optString("unionQrContent");
                                if(!TextUtils.isEmpty(qrurl)){
                                    staticqrurl = qrurl;
                                    qrurl += "&fixMoney="+amount;
                                    Intent v2 = new Intent();
                                    v2.putExtra("type", type);
                                    v2.putExtra("mark", mark);
                                    v2.putExtra("money", money);
                                    v2.putExtra("payurl", qrurl);
                                    v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                                    mcontext.sendBroadcast(v2);
                                }
                            }catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }).start();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }else{
            String qrurl = staticqrurl;
            qrurl += "&fixMoney="+amount;
            Intent v2 = new Intent();
            v2.putExtra("type", type);
            v2.putExtra("mark", mark);
            v2.putExtra("money", money);
            v2.putExtra("payurl", qrurl);
            v2.setAction(AppConst.QRCODERECEIVED_ACTION);
            mcontext.sendBroadcast(v2);
        }

    }

    public static void CreateQR(Intent intent){
        final String type = intent.getStringExtra("type");
        if(type.equals(AppConst.TYPE_NXFJSH)){
            CreateStaticQR(intent);
        }else{
            CreateQR_A(intent);
        }
    }

    public static void CreateQR_A(Intent intent) {
        String money = intent.getStringExtra("money");
        final String mark = intent.getStringExtra("mark");
        final String type = intent.getStringExtra("type");
        boolean isali = type.contains("ALI");
        int amount = (int) (Float.parseFloat(money) * 100);
        try {
            HashMap map = new HashMap();
            map.put("mchId", "" + getMchId());
            map.put("apiCode", isali?"2":"5");// 2
            map.put("client", "SPAY_AND");
            map.put("uId", "" + getUserId());
            map.put("body", "移动支付");
            map.put("money", "" + amount);
            map.put("userName", getRealName());
            map.put("service", isali?"pay.alipay.native":"pay.unionpay.proxy.native");// pay.alipay.native
            Object sign = createSign(map);
            final JSONObject json = new JSONObject();
            json.put("money", "" + amount);
            json.put("uId", getUserId());
            json.put("userName", getRealName());
            json.put("body", "移动支付");
            json.put("client", "SPAY_AND");
            json.put("mchId", getMchId());
            json.put("apiCode", isali?"2":"5");// 1 2支付宝
            json.put("service", isali?"pay.alipay.native":"pay.unionpay.proxy.native"); // pay.unionpay.proxy.native 银联 pay.alipay.native 支付宝
            json.put("sign", sign);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Object object = getRequestResult("https://spay3.swiftpass.cn/spay/unifiedNativePay", json,null,null);
                    object = XposedHelpers.getObjectField(object, "data");
                    JSONObject jsonResult = (JSONObject) object;
                    String result = jsonResult.optString("result");
                    PayHelperUtils.LogMsg("请求的二维码结果》》》》》》》"+jsonResult);
                    //
                    if(result.equals("200")){
                        try {
                            String msg = jsonResult.optString("message");
                            JSONObject jsonMsg = new JSONObject(msg);
                            String money = jsonMsg.optString("money");
                            float _amount = Float.parseFloat(money)/100;
                            Intent v2 = new Intent();
                            v2.putExtra("type", type);
                            v2.putExtra("mark", mark);
                            v2.putExtra("money", _amount+"");
                            v2.putExtra("payurl", jsonMsg.optString("uuid"));
                            v2.putExtra("img_url", jsonMsg.optString("outTradeNo"));
                            v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                            mcontext.sendBroadcast(v2);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
            //
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public static void getalltrade() {
        try {
            final JSONObject json = new JSONObject();
            final long time = System.currentTimeMillis();
            json.put("page", 1);
            json.put("pageSize", 20);
            json.put("mchId", getMchId());
            json.put("startDate", getDate());
            json.put("endDate", getDate());
            json.put("tradeStates", "[2]");
            json.put("spayRs", time);
            Object sign = createSign(json);
            json.put("nns", sign);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Object object = getRequestResult("https://spay3.swiftpass.cn/spay/order/orderListV2", json,String.valueOf(time), "6");
                    object = XposedHelpers.getObjectField(object, "data");
                    PayHelperUtils.LogMsg("查询订单结果》》》》》》》"+object);
                    getTradeDetail(object);
                }
            }).start();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static void getTradeDetail(Object object) {
        JSONObject object1 = (JSONObject)object;
        String result = object1.optString("result");
        if(result.equals("200")){
            String msg = object1.optString("message");
            try {
                JSONObject jsonMsg = new JSONObject(msg);
                JSONArray data = jsonMsg.optJSONArray("data");
                PayHelperUtils.LogMsg("获取到的订单>>>>>>>"+data);
                for (int i = 0; i <data.length(); i++) {
                    JSONObject trade = data.getJSONObject(i);
                    String payTime = trade.getString("tradeTimeNew");
                    payTime = PayHelperUtils.dateToStamp(payTime,"yyyy-MM-dd HH:mm:ss");
                    String orderId = trade.getString("outTradeNo");
                    String money = trade.getString("money");
                    float _real = Float.parseFloat(money)/100f;
                    String realAmount = _real+"";
                    //
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                    broadCastIntent.putExtra("bill_type", AppConst.TYPE_NXFJSH);
                    broadCastIntent.putExtra("bill_money", realAmount);
                    broadCastIntent.putExtra("bill_mark", orderId);
                    broadCastIntent.putExtra("bill_no", orderId);
                    broadCastIntent.putExtra("bill_dt", payTime);
                    mcontext.sendBroadcast(broadCastIntent);
                    //
                    Thread.sleep(200);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private static Object getRequestResult(final String url, final JSONObject jsonObject,String str,String str1) {
        Class clazzNet = XposedHelpers.findClass("cn.swiftpass.enterprise.io.net.NetHelper", mclassLoader);
        Object obj = XposedHelpers.callStaticMethod(clazzNet, "httpsPost", url, jsonObject, str, str1);
        return obj;
    }

    private static Object createSign(Object jsonObject) {
        Map map = null;
        Class clazzSingUtil = XposedHelpers.findClass("cn.swiftpass.enterprise.utils.SignUtil", mclassLoader);
        Object ins = XposedHelpers.callStaticMethod(clazzSingUtil, "getInstance");
        if (jsonObject instanceof Map) {
            map = (Map) jsonObject;
        } else {
            PayHelperUtils.LogMsg("createSign >>>>>>>>>>" + jsonObject);
            Type type = new TypeToken<Map<String, String>>() {
            }.getType();
            map = JsonHelper.fromJson(jsonObject.toString(), type);
            PayHelperUtils.LogMsg("createSign -----------" + map);
        }
        Object sign = XposedHelpers.callMethod(ins, "createSign", map, getSignKey());
        return sign;
    }

    private static void RequestCaShierQRCode(){
        final JSONObject json = new JSONObject();
        final long currenttime = System.currentTimeMillis();
        PayHelperUtils.LogMsg("开始请求CaShierQRCode");
        try {
            json.put("userId", getUserId());
            json.put("md5Str", "" + getUserMd5Str());
            json.put("spayRs", currenttime);
            Object sign = createSign(json);
            json.put("nns", sign);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Object object = getRequestResult("https://spay3.swiftpass.cn/spay/merchant/interface/cashierQrCodeImg", json,String.valueOf(currenttime), null);
                    object = XposedHelpers.getObjectField(object, "data");
                    objCasherurl = ((JSONObject)object).opt("message");
                    PayHelperUtils.LogMsg("请求CaShierQRCode结果》》》》》》》"+objCasherurl);
                    getTradeDetail(object);
                }
            }).start();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static void RequestShopQrcode(){
        final JSONObject json = new JSONObject();
        final long currenttime = System.currentTimeMillis();
        PayHelperUtils.LogMsg("开始请求RequestShopQrcode");
        try {
            json.put("mchId", getMchId());
            json.put("spayRs", currenttime);
            Object sign = createSign(json);
            json.put("nns", sign);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Object object = getRequestResult("https://spay3.swiftpass.cn/spay/merchant/interface/qrCodeList", json,String.valueOf(currenttime), null);
                    object = XposedHelpers.getObjectField(object, "data");
                    PayHelperUtils.LogMsg("object >>>>>>>>> "+object.getClass().getName());
                    try {
                        JSONObject json = ((JSONObject)object);
                        PayHelperUtils.LogMsg("json >>>>>>>>> "+json);
                        String strmsg = json.optString("message");
                        PayHelperUtils.LogMsg("strmsg >>>>>>>>> "+strmsg);
                        JSONObject message = new JSONObject(strmsg);
                        PayHelperUtils.LogMsg("message >>>>>>>>> "+message);
                        JSONArray array = message.optJSONArray("list");
                        PayHelperUtils.LogMsg("array >>>>>>>>> "+array);
                        objCasherurl = array.get(0);
                        PayHelperUtils.LogMsg("objCasherurl >>>>>>>>> "+objCasherurl);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        XposedBridge.log(e);
                    }
                    PayHelperUtils.LogMsg("请求CaShierQRCode结果》》》》》》》"+objCasherurl);
                    getTradeDetail(object);
                }
            }).start();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static Object getqrId(){
        Object objectcachiInApp = getCashierQrCode();
        Object qrId = null;
        try {
            JSONObject object = new JSONObject(objectcachiInApp+"");
            qrId = object.opt("qrId");
        } catch (JSONException e) {
            e.printStackTrace();
            XposedBridge.log(e);
        }
        return qrId;
    }

    public static Object getCashierQrCode(){
        return objCasherurl;
    }


    public static Object getUserMd5Str(){return getAppField("getUserMd5Str");}

    public static Object getUserId() {
        return getAppField("getUserId");
    }

    public static Object getMchId() {
        return getAppField("getMchId");
    }

    public static Object getUserName() {
        return getAppField("getUserName");
    }

    public static Object getSignKey() {
        return getAppField("getSignKey");
    }

    public static Object getRealName() {
        return getAppField("getRealName");
    }

    private static Object getAppField(String methodname) { // getMchId getUserId getUserName getSignKey
        Class clazzApp = XposedHelpers.findClass("cn.swiftpass.enterprise.MainApplication", mclassLoader);
        return XposedHelpers.callStaticMethod(clazzApp, methodname);
    }

    private static Object getDate() {
        Class clazz = XposedHelpers.findClass("cn.swiftpass.enterprise.utils.DateUtil", mclassLoader);
        Object date = XposedHelpers.callStaticMethod(clazz, "formatYYMD", System.currentTimeMillis());
        return date;
    }
}
