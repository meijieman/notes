package com.zhiyi.xppay.hook.mayou;

import android.content.Context;
import android.os.Bundle;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Random;

public class HookMayou {
    public static String lastenvelope_id = null;

    public void hook(final ClassLoader appClassLoader, final Context context) {
        XposedHelpers.findAndHookMethod("com.aoetech.aoelailiao.BaseActivity", appClassLoader, "onCreate", new Object[]{Bundle.class, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if (param.thisObject.getClass().getName().equals("com.aoetech.aoelailiao.ui.main.MainActivity")) {
                    PayHelperUtils.sendLoginId(getLoginId(appClassLoader), AppConst.TYPE_MY, context);
                }
            }
        }});
        XposedHelpers.findAndHookMethod("com.aoetech.aoelailiao.ui.main.MainActivity", appClassLoader, "i", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                setGroupId(appClassLoader);
            }
        });
        Class<?> msgclass = XposedHelpers.findClass("com.peng.one.push.entity.OnePushMsg", appClassLoader);
        XposedHelpers.findAndHookMethod("com.aoetech.aoelailiao.core.service.OnePushPushReceiver", appClassLoader, "onReceiveMessage", new Object[]{Context.class, msgclass, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                try {
                    XposedBridge.log("onReceiveMessage --> " + ((String) XposedHelpers.callMethod(param.args[1], "toString", new Object[0])));
                } catch (Exception e) {
                    e.printStackTrace();
                    XposedBridge.log("hookMethod -->Exception " + e);
                }
            }
        }});
        Class<?> info = XposedHelpers.findClass("com.aoetech.aoelailiao.entity.MessagesInfo", appClassLoader);
        XposedHelpers.findAndHookMethod("com.aoetech.aoelailiao.core.local.manager.UserDbManager", appClassLoader, "addLoadMessage", new Object[]{info, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                try {
                    Object info = param.args[0];
                    int showType = ((Integer) XposedHelpers.callMethod(info, "getDisplayType", new Object[0])).intValue();
                    int isSend = XposedHelpers.getIntField(info, "isSend");
                    Object msgInfo = XposedHelpers.callMethod(info, "getMsgInfo", new Object[0]);
                    if (msgInfo != null) {
                        int is_group_msg = XposedHelpers.getIntField(info, "h");
                        int to_id = XposedHelpers.getIntField(info, "b");
                        String string_content = (String) XposedHelpers.getObjectField(info, "j");
                        XposedBridge.log("===========handler start============\n\n");
                        XposedBridge.log("isSend:" + isSend + " is_group_msg:" + is_group_msg + " to_id string_content:" + string_content);
                        if (isSend == 0) {
                            Object msg_content;
                            if (is_group_msg == 1) {
                                if (showType == 4) {
                                    XposedBridge.log("========收群到红包=======");
                                    msg_content = XposedHelpers.getObjectField(msgInfo, "msg_content");
                                    if (msg_content == null) {
                                        XposedBridge.log("msg_content is null");
                                        return;
                                    } else if (XposedHelpers.getObjectField(msg_content, "red_packet_info") == null) {
                                        XposedBridge.log("red_packet_info is null");
                                        return;
                                    }
                                } else if (showType == 106) {
                                    XposedBridge.log("========抢红包消息=======");
                                    msg_content = XposedHelpers.getObjectField(msgInfo, "msg_content");
                                    if (msg_content == null) {
                                        XposedBridge.log("msg_content is null");
                                        return;
                                    }
                                    Object system_notify_info = XposedHelpers.getObjectField(msg_content, "system_notify_info");
                                    if (system_notify_info == null) {
                                        XposedBridge.log(" is null");
                                        return;
                                    }
                                    Object other_user_notify_info = XposedHelpers.getObjectField(system_notify_info, "other_user_notify_info");
                                    if (other_user_notify_info == null) {
                                        XposedBridge.log("other_user_notify_info is null");
                                        return;
                                    }
                                    String spile_text = (String) XposedHelpers.getObjectField(other_user_notify_info, "spile_text");
                                    XposedBridge.log("msg_text:" + ((String) XposedHelpers.getObjectField(other_user_notify_info, "msg_text")) + " spile_text:" + spile_text);
                                }
                            } else if (showType == 1) {
                                XposedBridge.log("收到+" + to_id + "消息=======" + string_content);
                            } else if (showType == 2) {
                                XposedBridge.log("收到+" + to_id + "图片=======" + string_content);
                            } else if (showType == 3) {
                                XposedBridge.log("收到+" + to_id + "语音=======" + string_content);
                            } else if (showType == 4) {
                                XposedBridge.log("收到+" + to_id + "红包=======");
                                msg_content = XposedHelpers.getObjectField(msgInfo, "msg_content");
                                if (msg_content == null) {
                                    XposedBridge.log("msg_content is null");
                                    return;
                                }
                                Object red_packet_info = XposedHelpers.getObjectField(msg_content, "red_packet_info");
                                if (red_packet_info == null) {
                                    XposedBridge.log("red_packet_info is null");
                                    return;
                                }
                                String envelope_desc = (String) XposedHelpers.getObjectField(red_packet_info, "envelope_desc");
                                Integer envelope_id = (Integer) XposedHelpers.getObjectField(red_packet_info, "envelope_id");
                                XposedBridge.log("envelope_desc:" + envelope_desc + " envelope_id:" + envelope_id.intValue() + " envelope_owner_uid:" + ((Integer) XposedHelpers.getObjectField(red_packet_info, "envelope_owner_uid")).intValue());
                                Object Message = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.UserOpenEnvelopeReq.Builder", appClassLoader), new Object[0]), "envelope_id", new Object[]{envelope_id}), "build", new Object[0]);
                                Object ProtoBufPacket = XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.core.proto.ProtoBufPacket", appClassLoader), new Object[]{Integer.valueOf(3005), Message});
                                if (lastenvelope_id == null || !(envelope_id.intValue() + "").equals(lastenvelope_id)) {
                                    Class PacketSendCallback = XposedHelpers.findClass("com.aoetech.aoelailiao.entity.PacketSendCallback", appClassLoader);
                                    Class MessageInfoManagerCls = XposedHelpers.findClass("com.aoetech.aoelailiao.core.local.manager.MessageInfoManager", appClassLoader);
                                    OpenProxy openProxy = new OpenProxy(context, envelope_desc);
                                    Object obj = Proxy.newProxyInstance(appClassLoader, new Class[]{PacketSendCallback}, openProxy);
                                    XposedHelpers.callMethod(XposedHelpers.callStaticMethod(MessageInfoManagerCls, "getInstant", new Object[0]), "a", new Object[]{ProtoBufPacket, obj});
                                    lastenvelope_id = envelope_id.intValue() + "";
                                }
                            } else if (showType == 106) {
                                XposedBridge.log("抢到+" + to_id + "红包=======");
                            }
                        }
                        XposedBridge.log("\n\n===========handler end============");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    XposedBridge.log("hookMethod -->Exception " + e);
                }
            }
        }});
        Class<?> dataBuffer = XposedHelpers.findClass("com.aoetech.aoelailiao.core.packet.DataBuffer", appClassLoader);
        XposedHelpers.findAndHookMethod("com.aoetech.aoelailiao.core.local.manager.PacketManager", appClassLoader, "receivePacket", new Object[]{dataBuffer, new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                byte[] array = (byte[]) XposedHelpers.callMethod(param.args[0], "array", new Object[0]);
                String a = (String) XposedHelpers.callMethod(param.thisObject, "a", new Object[]{param.args[0]});
                XposedBridge.log("a--->" + a);
                XposedBridge.log("PacketManager#receivePacket#key:" + a + ";packet len :" + array.length);
                XposedHelpers.callMethod(XposedHelpers.getObjectField(param.thisObject, "b"), "dealReceivePacket", new Object[]{array});
            }
        }});
        XposedHelpers.findAndHookMethod("com.aoetech.aoelailiao.core.BaseManager", appClassLoader, "a", new Object[]{byte[].class, XposedHelpers.findClass("com.aoetech.aoelailiao.entity.PacketSendCallback", appClassLoader), new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
            }
        }});
//        XposedHelpers.findAndHookMethod("com.alipay.sdk.app.PayTask", appClassLoader, "payV2", new Object[]{String.class, Boolean.TYPE, new XC_MethodReplacement() {
//            protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                XposedBridge.log("发送红包数据数据：" + param.args[0]);
//                return null;
//            }
//        }});
//        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.aoetech.aoelailiao.core.BaseManager", appClassLoader), "a", new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                if ("com.aoetech.aoelailiao.core.proto.ProtoBufPacket".equals(param.args[0].getClass().getName()))
//                    XposedBridge.log("发送红包信息》》》》》》》》》》》》" + JsonHelper.toJson(param.args[0]));
//            }
//        });
    }

    static ArrayList<Integer> groupids = new ArrayList<Integer>();

    private static void setGroupId(ClassLoader classLoader) {
        Class<?> clazz = XposedHelpers.findClass("com.aoetech.aoelailiao.cache.MessageCache", classLoader);
        Object o_ins = XposedHelpers.callStaticMethod(clazz, "getInstant");
        Object o_list = XposedHelpers.callMethod(o_ins, "getContacts");
        try {
            JSONArray grouparray = new JSONArray(JsonHelper.toJson(o_list));
            for (int i = 0; i < grouparray.length(); i++) {
                JSONObject obj = grouparray.getJSONObject(i);
                int type = obj.optInt("a");
                if (type == 1) {
                    int groupid = obj.optInt("d");
                    groupids.add(Integer.valueOf(groupid));
                }
            }
            XposedBridge.log("groupids >>>>>>>> " + JsonHelper.toJson(o_list));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static String getGroupid() {
        return "" + groupids.get((int) (Math.random() * (groupids.size())));
    }

    public static String getLoginId(ClassLoader classloader) {
        Class<?> clazz = XposedHelpers.findClass("com.aoetech.aoelailiao.cache.UserCache", classloader);
        Object ins = XposedHelpers.callStaticMethod(clazz, "getInstance", new Object[0]);
        String id = "" + XposedHelpers.callMethod(ins, "getLoginUserId", new Object[0]);
        return id;
    }
}
