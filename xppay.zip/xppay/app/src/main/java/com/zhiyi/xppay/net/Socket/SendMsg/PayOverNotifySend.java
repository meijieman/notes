package com.zhiyi.xppay.net.Socket.SendMsg;

import android.content.Intent;

import com.zhiyi.xppay.net.Socket.TransConst;

/**
 * Created by pc_unity on 2018/10/19.
 * String sign=MD5.md5(dt+mark+money+no+type+signkey);
 RequestParams params=new RequestParams();
 params.addBodyParameter("type", type);
 params.addBodyParameter("no", no);
 params.addBodyParameter("money", money);
 params.addBodyParameter("mark", mark);
 params.addBodyParameter("dt", dt);
 if(!TextUtils.isEmpty(account)){
 params.addBodyParameter("account", account);
 }
 params.addBodyParameter("sign", sign);
 */

public class PayOverNotifySend extends TransMessage{
    public String paytype;
    public String no;
    public String money;
    public String mark;
    public String dt;
    public String wh;
    public String uid;
    public String dianyuan;

    public PayOverNotifySend(Intent intent) {
        super(TransConst.PAY_OVER_NOTIFY);
        if(null!=intent){
            paytype = intent.getStringExtra("paytype");
            no = intent.hasExtra("no")?intent.getStringExtra("no"):"";
            money = intent.getStringExtra("money");
            if(money.contains(",")){
                money = money.replace(",","");
            }
            mark = intent.getStringExtra("mark");
            dt = intent.getStringExtra("dt");
            wh = intent.hasExtra("wh")?intent.getStringExtra("wh"):"";
            uid =intent.hasExtra("uid")?intent.getStringExtra("uid"):"";
            dianyuan = intent.hasExtra("dianyuan")?intent.getStringExtra("dianyuan"):"0";
//            if(intent.hasExtra("ext")){
//                String ext = intent.getStringExtra("ext");
//                String[] list = ext.split(",");
//                for(int i=0;i<list.length;i++){
//
//                }
//            }
        }
    }

    public PayOverNotifySend() {
        super(TransConst.PAY_OVER_NOTIFY);
    }

    @Override
    public String toString() {
        return "PayOverNotifySend{" +
                "type=" + type +
                ",paytype='" + paytype + '\'' +
                ",no='" + no + '\'' +
                ",money='" + money + '\'' +
                ",mark='" + mark + '\'' +
                ",dt='" + dt + '\'' +
                ",wh='"+ wh +'\''+
                "}";
    }
}
