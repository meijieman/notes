package com.zhiyi.xppay.ddc;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.NetUtil;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import okhttp3.OkHttpClient;

/**
 * Created by Administrator on 2019/3/22.
 */

public class DianDianChong implements Runnable{
    private Context context;
    private String token;
    private String uid;
    private Object account;
    public DianDianChong(final Context context){
        this.context = context;
        PayHelperUtils.sendmsg(context, "点点虫Hook成功;");
//        XposedHelpers.findAndHookConstructor("com.laiwang.openapi.model.AccountVO",context.getClassLoader(),new XC_MethodHook() {
//            protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
//                account = param.thisObject;
//                PayHelperUtils.sendmsg(context,"账号获取");
//            }
//        });
        //com.alibaba.android.babylon.biz.InitActivity
        //com.alibaba.android.babylon/
        //com.alibaba.android.babylon.biz.MainActionBarActivity
        //com.alibaba.android.babylon.biz.MainActionBarActivity#onCreate
//        XposedHelpers.findAndHookMethod("com.alibaba.android.babylon.biz.MainActionBarActivity",context.getClassLoader(),"onCreate",Bundle.class,new XC_MethodHook(){
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                PayHelperUtils.sendmsg(context,"ddc main");
//                Object user = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.laiwang.sdk.android.Laiwang", context.getClassLoader())
//                        , "currentOAuthProvider", new Object[0]), "getOAuthInfo", new Object[0]);
//
//                PayHelperUtils.traceObject(user);
//                PayHelperUtils.traceObject(account);
//                buildQrcode("10.12","xx");
//            }
//        });
//        BroadCastReceiver receiver = new BroadCastReceiver(this);
//        IntentFilter f = new IntentFilter();
//        f.addAction(AppConst.TYPE_DIANDIANCHONG+AppConst.BILLRECEIVED_ACTION);
//        context.registerReceiver(receiver,f);
//        buildQrcode("10.12","xx");
        new Thread(this).start();
    }

    public void run(){
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (true){
            try{

                String token = (String) XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.laiwang.sdk.android.Laiwang", context.getClassLoader())
                        , "currentOAuthProvider", new Object[0]), "getOAuthToken", new Object[0]), "getAccess_token", new Object[0]);
                Object user = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.laiwang.sdk.android.Laiwang", context.getClassLoader())
                        , "currentOAuthProvider", new Object[0]), "getOAuthInfo", new Object[0]);
                uid = "" + XposedHelpers.getObjectField(user, "clientId");
                if(token.equals(this.token)){
                    Thread.sleep(10000);
                   continue;
                }
                PayHelperUtils.sendmsg(context, "点点虫Hook成功，tokenID:" + token + ",uid="+uid);
                this.token = token;
                Intent broadCastIntent = new Intent();
                broadCastIntent.setAction(AppConst.HOOK_DianDianChong_TOKEN_ACTION);
                broadCastIntent.putExtra("token", token);
                context.sendBroadcast(broadCastIntent);
            }catch (Throwable t){
                XposedBridge.log(t);
            }
        }
    }


//    public void buildQrcode(String money, String remark) {
//        JSONObject params = new JSONObject();
//        try {
//            params.put("size","1");
//            params.put("appkey","21603258");
//            params.put("congratulations","恭喜发财");
//            params.put("amount",money);
//            params.put("_v_","3");
//            params.put("t",""+System.currentTimeMillis());
//            params.put("imei","111111111111111");
//            params.put("imsi","111111111111111");
//            params.put("type","0");
//            params.put("sender","57081356");
//            params.put("access_token",token);
//        } catch (JSONException e) {
//            XposedBridge.log(e);
//        }
//        String json = params.toString();
//        String data;
//        try {
//            data = NetUtil.getInstance().post("https://redenvelop.laiwang.com/v2/redenvelop/send/doGenerate",json);
//        } catch (IOException e) {
//            XposedBridge.log(e);
//            data=e.getMessage();
//        }
//
//        PayHelperUtils.sendmsg(context,""+data);
//    }
}
