package com.zhiyi.xppay.hook.v138;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import com.alibaba.fastjson.JSON;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.yst.consts.Appconsts;

import java.lang.reflect.Proxy;
import java.util.HashMap;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class ReceiveCrowdTask extends AsyncTask {
    ClassLoader classLoader;
    String crowdNo;
    String groupId;
    String sign;
    String prevBiz;
    String clientMsgID;
    String receiverUserType;
    String feedId;
    String channelName;
    String communityId;
    String receiverId;
    Context context;
    String date;
    public ReceiveCrowdTask(ClassLoader classLoader,
                            String crowdNo, String groupId,
                            String sign, String prevBiz,
                            String clientMsgID, String receiverUserType,
                            String feedId, String channelName,
                            String communityId, Context context,String dt) {

        this.classLoader = classLoader;
        // this.classLoader= Main.alipayActivity.getClassLoader();
        this.crowdNo = crowdNo;
        this.groupId = groupId;
        this.sign = sign;
        this.prevBiz = prevBiz;
        this.clientMsgID = clientMsgID;
        this.receiverUserType = receiverUserType;
        this.feedId = feedId;
        this.channelName = channelName;
        this.communityId = communityId;
        this.context = context;
        receiverId = Tools.getUserId(classLoader);
        this.date = dt;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
    }

    @Override
    protected Object doInBackground(Object[] objects) {
        try {

            Thread.sleep(200);

            Tools.getUserId(classLoader);
            Class GiftCrowdReceiveReq = classLoader.loadClass(
                    "com.alipay.giftprod.biz.crowd.gw.request.GiftCrowdReceiveReq");
            Object GiftCrowdReceiveReqObj = XposedHelpers.newInstance(GiftCrowdReceiveReq);
            XposedHelpers.setObjectField(GiftCrowdReceiveReqObj, "crowdNo", crowdNo);
            XposedHelpers.setObjectField(GiftCrowdReceiveReqObj, "groupId", groupId);
            XposedHelpers.setObjectField(GiftCrowdReceiveReqObj, "receiverUserType", receiverUserType);
            XposedHelpers.setObjectField(GiftCrowdReceiveReqObj, "prevBiz", prevBiz);
            XposedHelpers.setObjectField(GiftCrowdReceiveReqObj, "sign", sign);
            XposedHelpers.setObjectField(GiftCrowdReceiveReqObj, "clientMsgID", clientMsgID);
            XposedHelpers.setObjectField(GiftCrowdReceiveReqObj, "receiverId", receiverId);

            HashMap extInfo = new HashMap();
            extInfo.put("feedId", "");
            extInfo.put("canLocalMessage", "Y");
            extInfo.put("channelName", channelName);
            extInfo.put("communityId", channelName);
            extInfo.put("receiverUserType", receiverUserType);


            XposedHelpers.setObjectField(GiftCrowdReceiveReqObj, "extInfo", extInfo);
            Object re = Tools.receiveCrowd(classLoader, GiftCrowdReceiveReqObj);
            while (re == null) {
                //领取失败
                PayHelperUtils.sendmsg(context, "领取红包失败，正在重新领取...");
                XposedHelpers.setObjectField(GiftCrowdReceiveReqObj, "extInfo", extInfo);
                re = Tools.receiveCrowd(classLoader, GiftCrowdReceiveReqObj);
                if (re != null) {
                    PayHelperUtils.sendmsg(context, "重新领取红包成功！");
                    break;
                }
                Thread.sleep(100);
//                return null;
            }
//            if (re == null) {
//                XposedBridge.log("领红包失败");
//                PayHelperUtils.sendmsg(context,"领红包失败");
//                PayHelperUtils.sendmsg(context, "领红包失败");
//                return null;
//            }

            Object giftCrowdFlowInfo = XposedHelpers.getObjectField(re, "giftCrowdFlowInfo");
            String receiveAmount = (String) XposedHelpers.getObjectField(giftCrowdFlowInfo, "receiveAmount");
            String crowdNo = (String) XposedHelpers.getObjectField(giftCrowdFlowInfo, "crowdNo");
            Object receiver = XposedHelpers.getObjectField(giftCrowdFlowInfo, "receiver");
            String alipayAccount = (String) XposedHelpers.getObjectField(receiver, "alipayAccount");
            String userId = (String) XposedHelpers.getObjectField(receiver, "userId");
            String userName = (String) XposedHelpers.getObjectField(receiver, "userName");
            String imgUrl = (String) XposedHelpers.getObjectField(receiver, "imgUrl");
            Object giftCrowdInfo = XposedHelpers.getObjectField(re, "giftCrowdInfo");
            String remark = (String) XposedHelpers.getObjectField(giftCrowdInfo, "remark");
            XposedBridge.log("giftCrowdInfo:" + giftCrowdInfo);
            Object creator = XposedHelpers.getObjectField(giftCrowdInfo, "creator");
            String tuserid = (String) XposedHelpers.getObjectField(creator,"userId");// 发红包的用户id
            String talipayAccount = (String)XposedHelpers.getObjectField(creator,"alipayAccount");// 发红包的账户名字
            String username = (String)XposedHelpers.getObjectField(creator,"userName");// 发红包的账户
            //
            String prodCode = (String)XposedHelpers.getObjectField(giftCrowdInfo,"prodCode");
            String prodName = (String)XposedHelpers.getObjectField(giftCrowdInfo,"prodName");
            if(!prodCode.equals("CROWD_COMMON_CASH")||!prodName.equals("普通红包")){
                PayHelperUtils.sendmsg(context, "接收到的红包类型异常，请与客户确认");
                return null;
            }
            XposedBridge.log("re:" + JSON.toJSONString(re));
            //
//            Tools.delectContact(classLoader,tuserid);

            Class fa = classLoader.loadClass("com.alipay.mobile.redenvelope.proguard.f.a");
            Object faObj = XposedHelpers.newInstance(fa);
            XposedHelpers.setObjectField(faObj, "a", crowdNo);
            XposedHelpers.setObjectField(faObj, "b", clientMsgID);
            XposedHelpers.setObjectField(faObj, "c", receiverUserType);
            XposedHelpers.setObjectField(faObj, "d", receiverId);
            XposedHelpers.setObjectField(faObj, "e", groupId);
            XposedHelpers.setObjectField(faObj, "f", prevBiz);
            XposedHelpers.setObjectField(faObj, "g", sign);

            Class b = classLoader.loadClass("com.alipay.android.phone.discovery.envelope.get.b");
            Class c = classLoader.loadClass("com.alipay.android.phone.discovery.envelope.get.c");

            Object ca = Proxy.newProxyInstance(classLoader, new Class[]{c}, new GetC());
            Object bObj = XposedHelpers.newInstance(b, new Class[]{c}, ca);
            XposedHelpers.callMethod(bObj, "a", faObj, false, true, re);
            String dt = this.date;
            //
//            Intent intent = new Intent();
//            intent.setAction(AppConst.HOOK_BILL_RECEIVED);
//            intent.putExtra("bill_dt", dt);
//            intent.putExtra("bill_no", crowdNo);
//            intent.putExtra("bill_uid",tuserid);
//            intent.putExtra("bill_money", receiveAmount);
//            intent.putExtra("bill_type", AppConst.TYPE_ALIPAY);
//            intent.putExtra("bill_mark", remark);
//            context.sendBroadcast(intent);
            Intent intent = new Intent();
            intent.setAction(AppConst.HOOK_BILL_RECEIVED);
            intent.putExtra("dt", dt);
            intent.putExtra("no", crowdNo);
            intent.putExtra("uid",tuserid);
            intent.putExtra("money", receiveAmount);
            intent.putExtra("paytype", AppConst.TYPE_ALIPAY);
            intent.putExtra("mark", remark);
            intent.putExtra("wh", username);
            context.sendBroadcast(intent);
                    //
            PayHelperUtils.sendmsg(context, "时间："+PayHelperUtils.stampToDate(dt)+"\n金额：" + receiveAmount + "\n备注：" + remark + "\n红包订单号:" + crowdNo + "\n发红包的账户:" + talipayAccount+"\n发红包的用户昵称:"+username);
        } catch (Exception e) {
            XposedBridge.log(e);
        }
        return null;
    }
}
