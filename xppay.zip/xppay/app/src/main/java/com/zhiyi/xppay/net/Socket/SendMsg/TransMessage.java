package com.zhiyi.xppay.net.Socket.SendMsg;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;

/**
 * Created by Administrator on 2018/11/10.
 */

public class TransMessage {
    public int type;
    public int vs;
    public TransMessage(int type){
        this.type = type;
        vs = AppConst.version;
    }
    public String getJson(){
        String sendStr = JsonHelper.toJson(this);
        return sendStr;
    }
}
