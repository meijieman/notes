package com.zhiyi.xppay.hook.dingding;


import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONObject;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class CreateCnyProxy implements InvocationHandler {
    private String orderId;
    private Context mContext;


    public CreateCnyProxy(Context context, String str) {
        this.orderId = str;
        mContext=context;
    }

    public Object invoke(Object obj, Method method, Object[] objArr) throws Throwable {
       XposedBridge.log("invoke CreateCnyImpl method: " + method.getName());
        if (method.getName().contains("toString")) {
            return "this is string";
        }
        if (method.getName().equals("onDataReceived")){
                try {
                    obj =objArr[0];
                    PayHelperUtils.traceObject(obj);
                    XposedBridge.log("args len = "+objArr.length);
                    XposedBridge.log("args = "+obj);
                    Intent broadCastIntent = new Intent();
//                    JSONObject object =new JSONObject();
//                    object.put("orderId", this.orderId);
//                    String orderId = ""+XposedHelpers.getObjectField(obj, "businessId");
//                    if(orderId != null){
//                        object.put("dingdingOrderId", orderId.toString());
//                    }
                    String businessId = ""+XposedHelpers.getObjectField(obj, "businessId");
//                    if(redId != null){
//                        object.put("mark", redId.toString());
//                    }

                    String orderStr = ""+XposedHelpers.getObjectField(obj, "alipayOrderString");
                    broadCastIntent.putExtra("money", XposedHelpers.getObjectField(obj, "amount").toString());
                    broadCastIntent.putExtra("mark", businessId);
                    broadCastIntent.putExtra("type", AppConst.TYPE_DingDing);
                    broadCastIntent.putExtra("payurl",  orderStr);
                    broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                    mContext.sendBroadcast(broadCastIntent);
                }catch (Exception e){
                    XposedBridge.log(e);
                }

        }
        return null;
    }
}