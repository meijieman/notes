package com.zhiyi.xppay.hook.dingding.groupgather;

/**
 * Created by pc_mg on 2019/4/15.
 */

public class GroupGather {
}
