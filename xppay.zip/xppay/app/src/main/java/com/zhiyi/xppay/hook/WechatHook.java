package com.zhiyi.xppay.hook;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.AppUtil;
import com.zhiyi.xppay.utils.MD5;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.StringUtils;
import com.zhiyi.xppay.utils.TimeUtils;
import com.zhiyi.xppay.utils.XmlToJson;
import com.zhiyi.xppay.yst.consts.Appconsts;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * @author SuXiaoliang
 * @ClassName: WechatHook
 * @Description: TODO(这里用一句话描述这个类的作用)
 * @date 2018年6月23日 下午1:27:01
 */
public class WechatHook {
    public static final String TYPE_WX = AppConst.TYPE_WXPAY;
    public static String BILLRECEIVED_ACTION = "com.tools.payhelper.billreceived";
    public static String QRCODERECEIVED_ACTION = "com.tools.payhelper.qrcodereceived";

    public void hook(final ClassLoader appClassLoader, final Context context) {
        checkHook(appClassLoader, context);
        createQRCode(appClassLoader, context);
        // TODO Auto-generated method stub
        XposedHelpers.findAndHookMethod("com.tencent.wcdb.database.SQLiteDatabase", appClassLoader, "insert", String.class, String.class, ContentValues.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param)
                            throws Throwable {
                        try {
                            ContentValues contentValues = (ContentValues) param.args[2];
                            String tableName = (String) param.args[0];
                            if (TextUtils.isEmpty(tableName) || !tableName.equals("message")) {
                                return;
                            }

                            Integer type = contentValues.getAsInteger("type");
                            if (null == type) {
                                return;
                            }
                            XposedBridge.log("type = " + type);
                            if (type == 318767153) {
                                JSONObject msg = new XmlToJson.Builder(contentValues.getAsString("content")).build().getJSONObject("msg");
                                JSONObject appmsg = msg.getJSONObject("appmsg");
                                XposedBridge.log(appmsg.toString());
                                String type2 = appmsg.has("type") ? appmsg.getString("type") : "0";
                                XposedBridge.log("=========微信收到订单start========" + type2);
                                if (!"5".equals(type2)) {
                                    String money = appmsg.getJSONObject("mmreader").getJSONObject("template_detail").getJSONObject("line_content").getJSONObject("topline").getJSONObject("value").getString("word");
                                    money = money.replace("￥", "");
                                    String mark = appmsg.getJSONObject("mmreader").getJSONObject("template_detail").getJSONObject("line_content").getJSONObject("lines").getJSONArray("line").getJSONObject(1).getJSONObject("value").getString("word");
                                    String pay_time = appmsg.getJSONObject("mmreader").getJSONObject("template_header").getString("pub_time") + "000";
                                    String pay_outtradeno = "";
                                    try {
                                        pay_outtradeno = appmsg.getJSONObject("ext_pay_info").getString("pay_outtradeno");
                                    } catch (Exception e) {
                                        pay_outtradeno = MD5.md5(appmsg.getString("template_id")+pay_time+money);
                                    }

                                    XposedBridge.log("收到微信支付订单：" + pay_outtradeno + "==" + money + "==" + mark);

                                    Intent broadCastIntent = new Intent();
                                    broadCastIntent.putExtra("bill_dt", pay_time);
                                    broadCastIntent.putExtra("bill_no", pay_outtradeno);
                                    broadCastIntent.putExtra("bill_money", money);
                                    broadCastIntent.putExtra("bill_mark", mark);
                                    broadCastIntent.putExtra("bill_type", TYPE_WX);
                                    broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                                    context.sendBroadcast(broadCastIntent);
                                }

                                if ("5".equals(type2)) {//消息ID和消息类型判断
                                    if (!appmsg.has("mmreader")) {
                                        return;
                                    }
                                    JSONObject category = appmsg.getJSONObject("mmreader").getJSONObject("category");
                                    String source = category.getString("name");
                                    JSONObject item = category.getJSONObject("item");
                                    String title = item.getString("title");
                                    String Description = item.getString("digest");
                                    //key 存在
                                    if (source.equals("平安银行") && title.equals("账户变动提醒")) {
                                        if (Description.contains("平安银行交易提醒") && Description.contains("转入")) {
                                            String[] sArray = Description.split("\r|\n|：");
                                            long Time = 0;//MM月dd日 HH:mm
                                            String Type = "";
                                            String money = "";
                                            String Mantissa = "";//尾号
                                            for (int i = 0; i < sArray.length; i++) {
                                                if (sArray[i].contains("尾号")) {
                                                    Mantissa = StringUtils.getCutOutString(sArray[i], "尾号", "的");
                                                }
                                                if (i + 1 <= sArray.length) {
                                                    if (sArray[i].equals("时间")) {
                                                        String t = TimeUtils.getCurrentYear() + sArray[i + 1];
                                                        Log.e("收款时间：", t);
                                                        Time = TimeUtils.getTime(t, "yyyy年MM月dd日 HH:mm");
                                                    }
                                                    if (sArray[i].equals("类型")) {
                                                        Type = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("金额")) {
                                                        String M = sArray[i + 1];
                                                        money = StringUtils.getCutOutString(M, "币", "元");
                                                    }
                                                }
                                            }
                                            if (Time != 0 && !TextUtils.isEmpty(Type) && !TextUtils.isEmpty(money)) {
                                                sendBroadcast(context, "平安银行", money, Mantissa, Time, Type);
                                            }
                                        }
                                    } else if (source.equals("兴业银行") && title.equals("交易提醒")) {
                                        if (Description.contains("发生如下交易") && Description.contains("收入")) {
                                            String[] sArray = Description.split("\r|\n|：");//根据“换行 回车”和“：”区分
                                            long Time = 0;// yyyy年MM月dd日 HH:mm
                                            String Type = "";//网联付款收入
                                            String money = "";
                                            String Mantissa = "";

                                            for (int i = 0; i < sArray.length; i++) {
                                                if (sArray[i].contains("理财卡")) {
                                                    Mantissa = StringUtils.getCutOutString(sArray[i], "理财卡", "人民币");
                                                    Mantissa = Mantissa.substring(1, Mantissa.length() - 1);
                                                }
                                                if (i + 1 <= sArray.length) {
                                                    if (sArray[i].equals("交易时间")) {
                                                        Time = TimeUtils.getTime(sArray[i + 1], "yyyy年MM月dd日 HH:mm");
                                                    }
                                                    if (sArray[i].equals("交易类型")) {
                                                        Type = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("交易金额")) {
                                                        String M = sArray[i + 1];
                                                        money = M.substring(0, M.indexOf("元"));
                                                    }
                                                }
                                            }
                                            if (Time != 0 && !TextUtils.isEmpty(Type) && !TextUtils.isEmpty(money)) {
                                                sendBroadcast(context, "兴业银行", money, Mantissa, Time, Type);
                                            }
                                        }
                                    } else if (source.equals("中信银行") && title.equals("交易提醒")) {
                                        if (Description.contains("中信储蓄卡") && Description.contains("存入")) {
                                            String[] sArray = Description.split("\r|\n|：");//根据“换行 回车”和“：”区分
                                            long Time = 0;//MM月dd日 HH:mm
                                            String Type = "";
                                            String money = "";
                                            String Mantissa = "";//尾号
                                            for (int i = 0; i < sArray.length; i++) {
                                                if (sArray[i].contains("尾号")) {
                                                    Mantissa = StringUtils.getCutOutString(sArray[i], "尾号", "的");
                                                }
                                                if (i + 1 <= sArray.length) {
                                                    if (sArray[i].equals("交易时间")) {
                                                        Time = TimeUtils.getTime(TimeUtils.getCurrentYear() + sArray[i + 1], "yyyy年MM月dd日 HH:mm");
                                                    }
                                                    if (sArray[i].equals("交易类型")) {
                                                        Type = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("交易金额")) {
                                                        String M = sArray[i + 1];
                                                        money = StringUtils.getCutOutString(M, "币", "元");
                                                    }
                                                }
                                            }
                                            if (Time != 0 && !TextUtils.isEmpty(Type) && !TextUtils.isEmpty(money)) {
                                                sendBroadcast(context, "中信银行", money, Mantissa, Time, Type);
                                            }
                                        }
                                    } else if (source.equals("中国民生银行") && title.equals("账户变动提醒")) {
                                        if (Description.contains("交易信息") && Description.contains("存入")) {
                                            String[] sArray = Description.split("\r|\n|：");//根据“换行 回车”和“：”区分
                                            long Time = 0;//yyyy-MM-dd HH:mm
                                            String Type = "";
                                            String money = "";

                                            String Mantissa = "";//尾号
                                            for (int i = 0; i < sArray.length; i++) {
                                                if (sArray[i].contains("尾号")) {
                                                    Mantissa = StringUtils.getCutOutString(sArray[i], "尾号", "的");
                                                }
                                                if (i + 1 <= sArray.length) {
                                                    if (sArray[i].equals("交易时间")) {
                                                        Time = TimeUtils.getTime(sArray[i + 1], "yyyy-MM-dd HH:mm");
                                                    }
                                                    if (sArray[i].equals("交易类型")) {
                                                        Type = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("交易金额")) {
                                                        String M = sArray[i + 1].replaceAll(" ", "");
                                                        money = M.substring(M.indexOf("币") + 1, M.length());
                                                    }
                                                }
                                            }
                                            if (Time != 0 && !TextUtils.isEmpty(Type) && !TextUtils.isEmpty(money)) {
                                                sendBroadcast(context, "民生银行", money, Mantissa, Time, Type);
                                            }
                                        }
                                    } else if (source.equals("浦发银行") && title.equals("账户变动提醒")) {
                                        if (Description.contains("交易信息") && Description.contains("互联汇入")) {
//                                    if (Description.contains("交易信息") && (Description.contains("支付宝转账")||Description.contains("互联汇入"))) {
                                            String[] sArray = Description.split("\r|\n|：");//根据“换行 回车”和“：”区分
                                            long Time = 0;//MM月dd日 HH:mm:ss
                                            String Type = "";
                                            String money = "";

                                            String Mantissa = "";//尾号
                                            for (int i = 0; i < sArray.length; i++) {
                                                if (sArray[i].contains("尾号")) {
                                                    Mantissa = StringUtils.getCutOutString(sArray[i], "尾号", "的");
                                                }
                                                if (i + 1 <= sArray.length) {
                                                    if (sArray[i].equals("交易时间")) {
                                                        Time = TimeUtils.getTime(TimeUtils.getCurrentYear() + sArray[i + 1], "MM月dd日 HH:mm:ss");
                                                    }
                                                    if (sArray[i].equals("交易类型")) {
                                                        Type = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("交易金额")) {
                                                        String M = sArray[i + 1];
                                                        money = M.substring(M.indexOf("期") + 1, M.length());
                                                    }
                                                }
                                            }
                                            if (Time != 0 && !TextUtils.isEmpty(Type) && !TextUtils.isEmpty(money)) {
                                                sendBroadcast(context, "浦发银行", money, Mantissa, Time, Type);
                                            }
                                        }
                                    } else if (source.equals("交通银行微银行") && title.equals("交易提醒")) {
                                        XposedBridge.log("description：" + Description);
                                        if (Description.contains("交易发生") && Description.contains("转入")) {
                                            String[] sArray = Description.split("\r|\n|：");//根据“换行 回车”和“：”区分
                                            long Time = 0;//2019-02-27 21:36
                                            String Type = "";
                                            String money = "";

                                            String Mantissa = "";//尾号
                                            for (int i = 0; i < sArray.length; i++) {
                                                if (i + 1 <= sArray.length) {
                                                    if (sArray[i].contains("末四位")) {
                                                        Mantissa = sArray[i + 1].substring(1, sArray[i + 1].length());
                                                    }
                                                    if (sArray[i].equals("交易时间")) {
                                                        Time = TimeUtils.getTime(sArray[i + 1], "yyyy-MM-dd HH:mm");
                                                    }
                                                    if (sArray[i].equals("交易类型")) {
                                                        Type = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("交易金额")) {
                                                        String M = sArray[i + 1];
                                                        money = M.substring(0, M.indexOf("元"));
                                                    }
                                                }
                                            }
                                            if (Time != 0 && !TextUtils.isEmpty(Type) && !TextUtils.isEmpty(money)) {
                                                sendBroadcast(context, "交通银行", money, Mantissa, Time, Type);
                                            } else {
                                                XposedBridge.log("错误:" + Time + " t," + Type + " m," + money);
                                            }
                                        }
                                    } else if (source.equals("建行龙支付") && title.equals("收款成功通知")) {
                                        XposedBridge.log("description：" + Description);
                                        if (Description.contains("收款金额") && Description.contains("收款时间")) {
                                            String[] sArray = Description.split("\r|\n|：");//根据“换行 回车”和“：”区分
                                            long Time = 0;//2019-02-27 21:36
                                            String Type = "商户名称";
                                            String money = "";
                                            String no = "";
                                            String Mantissa = "0000";//尾号
                                            for (int i = 0; i < sArray.length; i++) {
                                                if (i + 1 <= sArray.length) {
                                                    if (sArray[i].contains("末四位")) {
                                                        Mantissa = sArray[i + 1].substring(1, sArray[i + 1].length());
                                                    }
                                                    if (sArray[i].equals("商户名称")) {
                                                        Type = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("收款时间")) {
                                                        Time = TimeUtils.getTime(sArray[i + 1], "yyyy-MM-dd HH:mm:ss");
                                                    }
                                                    if (sArray[i].equals("收款金额")) {
                                                        money = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("订单号")) {
                                                        no = sArray[i + 1];
                                                    }
                                                }
                                            }
                                            if (Time != 0 && !TextUtils.isEmpty(Type) && !TextUtils.isEmpty(money)) {
                                                sendLONGPay(context, money, Mantissa, Time, Type, no);
//                                                    sendBroadcast(context, "中国建设银行", money, Mantissa, Time, Type);
                                            } else {
                                                XposedBridge.log("错误:" + Time + " t," + Type + " m," + money);
                                            }
                                        }
                                    } else if (source.equals("微信支付")) {
                                        sendShouKuan(context, appmsg);
                                    }else  if(source.equals("微信收款助手")){
                                        sendShouKuanHelper(context, appmsg);
                                    }else if (source.equals("博山农村商业银行聚合支付") && title.equals("收款通知")) {
                                        XposedBridge.log("description：" + Description);
                                        if (Description.contains("您收到一笔款项")&&Description.contains("实收金额") && Description.contains("收款时间")) {
                                            String[] sArray = Description.split("\r|\n|：");//根据“换行 回车”和“：”区分
                                            long Time = 0;//2019-02-27 21:36
                                            String Type = "收款门店";
                                            String money = "";
                                            String no = "";
                                            String Mantissa = "0000";//尾号
                                            for (int i = 0; i < sArray.length; i++) {
                                                if (i + 1 <= sArray.length) {
                                                    if (sArray[i].equals("收款门店")) {
                                                        Type = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("收款时间")) {
                                                        Time = TimeUtils.getTime(sArray[i + 1], "yyyy年MM月dd日 HH:mm:ss");
                                                    }
                                                    if (sArray[i].equals("实收金额")) {
                                                        money = sArray[i + 1];
                                                    }
                                                    if (sArray[i].equals("交易单号")) {
                                                        no = sArray[i + 1];
                                                    }
                                                }
                                            }
                                            if (Time != 0 && !TextUtils.isEmpty(Type) && !TextUtils.isEmpty(money)) {
                                                sendZHIPay(context, money, Mantissa, Time, Type, no);
                                            } else {
                                                XposedBridge.log("错误:" + Time + " t," + Type + " m," + money);
                                            }
                                        }
                                    }
                                    else {
                                        PayHelperUtils.sendmsg(context, "未知的消息:" + source);
                                    }
                                }
                            }
                        } catch (Exception e) {
                            XposedBridge.log(e.getMessage());
                        }
                    }

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                    }
                });
        try {
            XposedHelpers.findAndHookMethod("com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI", appClassLoader, "initView",
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param)
                                throws Throwable {
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param)
                                throws Throwable {
                            //
                            Intent intent = ((Activity) param.thisObject).getIntent();
                            String mark = intent.getStringExtra("mark");
                            String money = intent.getStringExtra("money");
                            XposedBridge.log("=========微信设置金额start========");
                            if (PayHelperUtils.getVerName(context).equals("7.0.3")) {
                                //获取WalletFormView控件
                                Field WalletFormViewField = XposedHelpers.findField(param.thisObject.getClass(), "kff");
                                Object WalletFormView = WalletFormViewField.get(param.thisObject);
                                Class<?> WalletFormViewClass = XposedHelpers.findClass("com.tencent.mm.wallet_core.ui.formview.WalletFormView", appClassLoader);
                                //获取金额控件
                                Field AefField = XposedHelpers.findField(WalletFormViewClass, "zsl");
                                Object AefView = AefField.get(WalletFormView);
                                //call设置金额方法
                                XposedHelpers.callMethod(AefView, "setText", money);
                                //call设置备注方法
                                Class<?> clazz = XposedHelpers.findClass("com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI", appClassLoader);
                                XposedHelpers.callStaticMethod(clazz, "a", param.thisObject, mark);
                                XposedHelpers.callStaticMethod(clazz, "c", param.thisObject);
                                //点击确定
                                Button click = (Button) XposedHelpers.callMethod(param.thisObject, "findViewById", 2131822831);
                                click.performClick();

                            } else if (PayHelperUtils.getVerName(context).equals("7.0.4")) {
                                //获取WalletFormView控件
                                Field WalletFormViewField = XposedHelpers.findField(param.thisObject.getClass(), "kGa");
                                Object WalletFormView = WalletFormViewField.get(param.thisObject);
                                Class<?> WalletFormViewClass = XposedHelpers.findClass("com.tencent.mm.wallet_core.ui.formview.WalletFormView", appClassLoader);
                                //获取金额控件
                                Field AefField = XposedHelpers.findField(WalletFormViewClass, "Aih");
                                Object AefView = AefField.get(WalletFormView);
                                //call设置金额方法
                                XposedHelpers.callMethod(AefView, "setText", money);
                                //call设置备注方法
                                Class<?> clazz = XposedHelpers.findClass("com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI", appClassLoader);
                                XposedHelpers.callStaticMethod(clazz, "a", param.thisObject, mark);
                                XposedHelpers.callStaticMethod(clazz, "c", param.thisObject);
                                //点击确定
                                Button click = (Button) XposedHelpers.callMethod(param.thisObject, "findViewById", 2131822846);
                                click.performClick();
                            } else {
                                PayHelperUtils.sendmsg(context, "微信生成二维码版本异常" + PayHelperUtils.getVerName(context));
                            }
                            XposedBridge.log("=========微信设置金额end========");
                        }
                    });
        } catch (Exception e) {
            PayHelperUtils.sendmsg(context, "异常" + e.getMessage());
        }
        try {
            // hook获取loginid
            XposedHelpers.findAndHookMethod("com.tencent.mm.ui.LauncherUI", appClassLoader, "onResume",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            String loginid = PayHelperUtils.getWechatLoginId(context);
                            loginid = loginid.replace("+86", "");
                            PayHelperUtils.sendLoginId(loginid, TYPE_WX, context);
                        }
                    });
        } catch (Exception e) {
        }
    }

    public void checkHook(final ClassLoader classLoader, Context context) {
        if (PayHelperUtils.getVerName(context).equals("7.0.4")) {
            try {
                XposedHelpers.findAndHookMethod("com.tencent.mm.app.u", classLoader, "b", StackTraceElement[].class, new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                        XposedBridge.log("进入检测");
                        Class clazz = XposedHelpers.findClass("com.tencent.matrix.trace.core.AppMethodBeat", classLoader);
                        XposedHelpers.callStaticMethod(clazz, "i", 115034);
                        XposedHelpers.callStaticMethod(clazz, "o", 115034);
                        return false;
                    }
                });
            } catch (Exception e) {
                PayHelperUtils.sendmsg(context, "checkHook异常" + e.getMessage());
            }
        }
    }

    public void createQRCode(ClassLoader classLoader, final Context context) {
        if (PayHelperUtils.getVerName(context).equals("7.0.4")) {
            try {
                Class<?> clazz = XposedHelpers.findClass("com.tencent.mm.plugin.collect.model.s", classLoader);
                XposedBridge.hookAllMethods(clazz, "a", new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param)
                            throws Throwable {
                    }

                    @Override
                    protected void afterHookedMethod(MethodHookParam param)
                            throws Throwable {
                        XposedBridge.log("=========7.0.4微信生成完成start========");
                        double money = 0;
                        String mark = "";
                        String payurl = "";
                        Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "kCJ");
                        money = (double) moneyField.get(param.thisObject);

                        Field markField = XposedHelpers.findField(param.thisObject.getClass(), "desc");
                        mark = (String) markField.get(param.thisObject);

                        Field payurlField = XposedHelpers.findField(param.thisObject.getClass(), "kCI");
                        payurl = (String) payurlField.get(param.thisObject);
                        XposedBridge.log("调用增加数据方法==>微信");
                        XposedBridge.log(money + "  " + mark + "  " + payurl);
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("money", money + "");
                        broadCastIntent.putExtra("mark", mark);
                        broadCastIntent.putExtra("type", TYPE_WX);
                        broadCastIntent.putExtra("payurl", payurl);
                        broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                        context.sendBroadcast(broadCastIntent);
                        XposedBridge.log("=========7.0.4微信生成完成end========");
                    }
                });
            } catch (Exception e) {
                PayHelperUtils.sendmsg(context, "异常" + e.getMessage());
            }
        } else {
            try {
                Class<?> clazz = XposedHelpers.findClass("com.tencent.mm.plugin.collect.b.s", classLoader);
                XposedBridge.hookAllMethods(clazz, "a", new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param)
                            throws Throwable {
                    }

                    @Override
                    protected void afterHookedMethod(MethodHookParam param)
                            throws Throwable {
                        XposedBridge.log("=========微信生成完成start========");
                        double money = 0;
                        String mark = "";
                        String payurl = "";
                        if (PayHelperUtils.getVerName(context).equals("7.0.3")) {
                            Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "kcp");
                            money = (double) moneyField.get(param.thisObject);

                            Field markField = XposedHelpers.findField(param.thisObject.getClass(), "desc");
                            mark = (String) markField.get(param.thisObject);

                            Field payurlField = XposedHelpers.findField(param.thisObject.getClass(), "kco");
                            payurl = (String) payurlField.get(param.thisObject);
                        } else {
                            PayHelperUtils.sendmsg(context, "微信版本异常" + PayHelperUtils.getVerName(context));
                        }
                        XposedBridge.log("调用增加数据方法==>微信");
                        XposedBridge.log(money + "  " + mark + "  " + payurl);
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("money", money + "");
                        broadCastIntent.putExtra("mark", mark);
                        broadCastIntent.putExtra("type", TYPE_WX);
                        broadCastIntent.putExtra("payurl", payurl);
                        broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                        context.sendBroadcast(broadCastIntent);
                        XposedBridge.log("=========微信生成完成end========");
                    }
                });

            } catch (Exception e) {
                PayHelperUtils.sendmsg(context, "异常" + e.getMessage());
            }
        }
    }

    private String getWxNo(JSONObject appmsg,String money,String time){
        try {
            if(appmsg.has("appmsg") && appmsg.getJSONObject("ext_pay_info").has("pay_outtradeno")){
                return appmsg.getJSONObject("ext_pay_info").getString("pay_outtradeno");
            }
        } catch (Exception e) {
        }
        return MD5.md5(AppUtil.randString(32));
    }

    private void sendShouKuanHelper(Context context, JSONObject appmsg) {
        try {
            String money = appmsg.getJSONObject("mmreader").getJSONObject("template_detail").getJSONObject("line_content").getJSONObject("topline").getJSONObject("value").getString("word");
            money = money.replace("￥", "");
            String mark = appmsg.getJSONObject("mmreader").getJSONObject("template_detail").getJSONObject("line_content").getJSONObject("lines").getJSONArray("line").getJSONObject(1).getJSONObject("value").getString("word");
            String pay_time = appmsg.getJSONObject("mmreader").getJSONObject("template_header").getString("pub_time") + "000";
            String pay_outtradeno = getWxNo(appmsg,money,pay_time);


            XposedBridge.log("收到微信支付订单：" + pay_outtradeno + "==" + money + "==" + mark);
            mark = StringUtils.getTextCenter(mark,"店长","的零钱");

            Intent broadCastIntent = new Intent();
            broadCastIntent.putExtra("dt", pay_time);
            broadCastIntent.putExtra("no", pay_outtradeno);
            broadCastIntent.putExtra("money", money);
            broadCastIntent.putExtra("mark", mark);
            broadCastIntent.putExtra("dianyuan", "1");
            broadCastIntent.putExtra("paytype", AppConst.TYPE_WXPAY);
            broadCastIntent.setAction(AppConst.HOOK_BILL_RECEIVED);
            XposedBridge.log("action >>>>>> " + broadCastIntent.getAction());
            context.sendBroadcast(broadCastIntent);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void sendShouKuan(Context context, JSONObject appmsg) {
        try {
            String money = appmsg.getJSONObject("mmreader").getJSONObject("template_detail").getJSONObject("line_content").getJSONObject("topline").getJSONObject("value").getString("word");
            money = money.replace("￥", "");
            String mark = appmsg.getJSONObject("mmreader").getJSONObject("template_detail").getJSONObject("line_content").getJSONObject("lines").getJSONArray("line").getJSONObject(0).getJSONObject("value").getString("word");
            String pay_time = appmsg.getJSONObject("mmreader").getJSONObject("template_header").getString("pub_time") + "000";
            String pay_outtradeno = "";
            try {
                pay_outtradeno = appmsg.getJSONObject("ext_pay_info").getString("pay_outtradeno");
            } catch (Exception e) {
                pay_outtradeno = AppUtil.toMD5(appmsg.getString("template_id") + pay_time);
            }

            XposedBridge.log("收到微信支付订单：" + pay_outtradeno + "==" + money + "==" + mark);
            Intent broadCastIntent = new Intent();
            broadCastIntent.putExtra("dt", pay_time);
            broadCastIntent.putExtra("no", pay_outtradeno);
            broadCastIntent.putExtra("money", money);
            broadCastIntent.putExtra("mark", mark);
            broadCastIntent.putExtra("paytype", AppConst.TYPE_WXPAY);
            broadCastIntent.setAction(AppConst.HOOK_BILL_RECEIVED);
            XposedBridge.log("action >>>>>> " + broadCastIntent.getAction());
            context.sendBroadcast(broadCastIntent);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void sendBroadcast(Context context, String bankNam, String money, String Mantissa, Long Time, String Type) {
        String time = TimeUtils.getStrTime(Time);
        XposedBridge.log("微信公号:" + bankNam + money + Mantissa + time + Type);
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("mark", bankNam);
        broadCastIntent.putExtra("money", money);
        broadCastIntent.putExtra("wh", Mantissa);
        broadCastIntent.putExtra("dt", time);
        broadCastIntent.putExtra("paytype", AppConst.TYPE_BANK);
        broadCastIntent.setAction(AppConst.HOOK_BILL_RECEIVED);
        context.sendBroadcast(broadCastIntent);
    }

    public void sendLONGPay(Context context, String money, String Mantissa, Long Time, String Type, String no) {
        Intent broadCastIntent = new Intent();
        String time = TimeUtils.getStrTime(Time);
        XposedBridge.log("建行龙支付" + money + "-" + Mantissa + "-" + time + "-" + Type + "-" + no);
        broadCastIntent.putExtra("mark", Type);
        broadCastIntent.putExtra("money", money);
        broadCastIntent.putExtra("wh", Mantissa);
        broadCastIntent.putExtra("dt", time);
        broadCastIntent.putExtra("no", no);
        broadCastIntent.putExtra("paytype", AppConst.TYPE_LONGPAY);
        broadCastIntent.setAction(AppConst.HOOK_BILL_RECEIVED);
        context.sendBroadcast(broadCastIntent);
    }

    public void sendZHIPay(Context context, String money, String Mantissa, Long Time, String Type, String no) {
        Intent broadCastIntent = new Intent();
        String time = TimeUtils.getStrTime(Time);
        XposedBridge.log("山东农商智e付" + money + "-" + Mantissa + "-" + time + "-" + Type + "-" + no);
        broadCastIntent.putExtra("mark", Type);
        broadCastIntent.putExtra("money", money);
        broadCastIntent.putExtra("wh", Mantissa);
        broadCastIntent.putExtra("dt", time);
        broadCastIntent.putExtra("no", no);
        broadCastIntent.putExtra("paytype", AppConst.TYPE_ZHIPAY);
        broadCastIntent.setAction(AppConst.HOOK_BILL_RECEIVED);
        context.sendBroadcast(broadCastIntent);
    }
}
