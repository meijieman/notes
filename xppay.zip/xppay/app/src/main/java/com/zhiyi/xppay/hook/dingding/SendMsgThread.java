package com.zhiyi.xppay.hook.dingding;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;

import com.google.myjson.Gson;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.RimetHook;

import org.json.JSONObject;

import java.lang.reflect.Proxy;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;


public class SendMsgThread extends Thread {
    private ClassLoader classLoader;
    private Object redPacketsClusterObject;
    private Handler handler;
    private Context context;

    public SendMsgThread(ClassLoader classLoader, Object obj,Handler handler,Context context) {
        this.classLoader = classLoader;
        this.redPacketsClusterObject = obj;
        this.  handler =handler;
        this.context=context;
    }

    public void run() {
        try {
           XposedBridge.log("重新发送消息开始");
            Object callStaticMethod = XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alibaba.wukong.im.IMEngine", this.classLoader), "getIMService", new Object[]{XposedHelpers.findClass("com.alibaba.wukong.im.ConversationService", this.classLoader)});
            Class findClass = XposedHelpers.findClass("com.alibaba.wukong.Callback", this.classLoader);
            Object newProxyInstance = Proxy.newProxyInstance(this.classLoader, new Class[]{findClass}, new ConversationCnyProxy(new ConversationCnyImpl(this.classLoader, this.redPacketsClusterObject)));
            XposedHelpers.callMethod(callStaticMethod, "getConversation", new Object[]{newProxyInstance, XposedHelpers.getObjectField(this.redPacketsClusterObject, "cid").toString()});
            XposedBridge.log("重新发送消息结束");
            JSONObject jsonObject =new JSONObject(new Gson().toJson(redPacketsClusterObject));
            final String bill_no = ""+XposedHelpers.getObjectField(redPacketsClusterObject, "businessId");
            final String amount = ""+XposedHelpers.getObjectField(redPacketsClusterObject, "amount");

            handler.post(new Runnable() {
                @Override
                public void run() {
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("bill_no", bill_no);
                        broadCastIntent.putExtra("bill_money", amount);
                        broadCastIntent.putExtra("bill_mark", bill_no);
                        broadCastIntent.putExtra("bill_type", AppConst.TYPE_DingDing);
                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                        context.sendBroadcast(broadCastIntent);

                }
            });
            final String remark =jsonObject.optString("congratulations");
            RimetHook.taskList.remove(remark);
        } catch (Throwable th) {
           XposedBridge.log("重新发送异常");
            th.printStackTrace();
        }
    }
}