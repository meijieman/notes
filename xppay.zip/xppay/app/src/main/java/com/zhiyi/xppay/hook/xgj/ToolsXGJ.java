package com.zhiyi.xppay.hook.xgj;

import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.yst.consts.Appconsts;


/**
 * Created by pc_mg on 2019/3/21.
 */

public class ToolsXGJ {
    public static boolean ishookeed;// hook到
    public static boolean isactivitystart;// activity开启

    public static void sendActivitystart(Context context) {
        Intent intent = new Intent();
        intent.setAction(AppConst.ACTION_ACTIVITYSTART);
        context.sendBroadcast(intent);
    }

    public static void tradequery(Context context) {
        if (isactivitystart && ishookeed) {
            PayHelperUtils.sendmsg(context, "星管家开启账单轮询");
            Intent broadCastIntent = new Intent();
            broadCastIntent.setAction(AppConst.ACTION_STARTTRADEQUERY);
            context.sendBroadcast(broadCastIntent);
        }
    }

    public static void sendTrade(Context context ,String time,String money,String remark){
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(AppConst.ACTION_SENDTRADE);
        broadCastIntent.putExtra("time", time);
        broadCastIntent.putExtra("money", money);
        broadCastIntent.putExtra("remark", remark);
        context.sendBroadcast(broadCastIntent);
    }
}
