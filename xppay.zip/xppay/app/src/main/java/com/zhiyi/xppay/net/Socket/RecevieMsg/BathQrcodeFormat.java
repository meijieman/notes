package com.zhiyi.xppay.net.Socket.RecevieMsg;

import android.icu.text.DecimalFormat;

import java.util.ArrayList;

/**
 * Created by pc_unity on 2018/11/5.
 */

public class BathQrcodeFormat {
    public ArrayList<String> money;

    public BathQrcodeFormat(String format,int produceType){
        money = new ArrayList<>();
        String[] strList = format.split(";");
        for(int i = 0;i<strList.length;i++){
            String[] min_max = strList[i].split(",");
            if(min_max.length==2){
                if(produceType==0){
                    double min = Double.parseDouble(min_max[0]);
                    double max = Double.parseDouble(min_max[1]);
                    long imax = (long) (max*100);
                    long imin = (long) (min*100);
                    for(;imin<=imax;imin+=1){
                        money.add(String.format("%.2f",((double)imin)/100));
                    }
                }else{
                    double mny = Double.parseDouble(min_max[0]);
                    int cnt = Integer.parseInt(min_max[1]);
                    long imny = (long)(mny*100);
                    for(int j = 0;j<cnt;j++){
                        money.add(String.format("%.2f",((double)imny)/100));
                    }
                }

            }else if(min_max.length==1){
                money.add(String.format("%.2f", min_max[0]));
            }
        }
    }
}
