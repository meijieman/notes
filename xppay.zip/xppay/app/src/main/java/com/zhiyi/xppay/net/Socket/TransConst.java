package com.zhiyi.xppay.net.Socket;

/**
 * Created by Administrator on 2019/3/16.
 */

public class TransConst {
    public static final int LOGIN = 1;
    public static final int HEAD_BEAT = 2;
    public static final int PAY_NOTIFY = 100;
    public static final int GET_QRCODE = 101;
    public static final int GET_QRCODE_ERR = 102;
    public static final int PAY_OVER_NOTIFY = 103;
    public static final int BATH_BULLID_QRCODE = 104;
    public static final int CreateBindCode = 105;
    public static final int CloseBindCode = 106;
    public static final int NewFriendBill = 107;
    public static final int IS_FRIEND = 108;
    public static final int PAY_NOTIFY_BACK = 201;
    public static final int PAY_APP_DISABLE = 501;
    public static final int PAY_APP_NO_LOGIN = 502;
    public static final int ServerError = 500;
    public static final int CPCHECKORDER = 888;
    public static final int DianDianChong = 109;
}
