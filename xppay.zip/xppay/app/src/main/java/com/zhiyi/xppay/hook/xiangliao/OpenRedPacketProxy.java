package com.zhiyi.xppay.hook.xiangliao;

import android.content.Context;
import android.content.Intent;


import com.zhiyi.xppay.consts.AppConst;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by Chenkai on 2019/3/26.
 */

public class OpenRedPacketProxy implements InvocationHandler {
    String RedPackAmount;
    String RedPackDesc;
    Context mContext;
    String redPackAgeID;

    public OpenRedPacketProxy(Context arg1, String arg2, String arg3, String arg4, String arg5) {
        super();
        this.mContext = arg1;
        this.redPackAgeID = arg2;
        this.RedPackAmount = arg4;
        this.RedPackDesc = arg5;
    }

    public Object invoke(Object arg7, Method arg8, Object[] arg9) throws Throwable {
        String v2 = arg8.getName();
        XposedBridge.log("调用的方法名称为:" + v2);
        XposedBridge.log("返回的类型为" + arg8.getReturnType().getName());
        if(v2.equals("onResponse")) {
            try {
                XposedBridge.log("onResponse----->" + arg9.length);
                XposedBridge.log("onResponse----->" + arg9[2] + "");
                if(arg9[1] == null) {
                    return null;
                }

                XposedBridge.log("拆开红包：redPackAgeID=" + this.redPackAgeID + "==" + this.RedPackAmount + "==" + this.RedPackDesc);
                Intent v0 = new Intent();
                v0.putExtra("bill_no", this.redPackAgeID);
                v0.putExtra("bill_money", this.RedPackAmount);
                v0.putExtra("bill_mark", this.RedPackDesc);
                v0.putExtra("bill_type", AppConst.TYPE_XiangLiao);
                v0.setAction(AppConst.BILLRECEIVED_ACTION);
                this.mContext.sendBroadcast(v0);
            }
            catch(Exception v1) {
                XposedBridge.log("OpenRedPacketProxy callBack  解析异常:" + v1);
                v1.printStackTrace();
            }
        }

        return null;
    }
}

