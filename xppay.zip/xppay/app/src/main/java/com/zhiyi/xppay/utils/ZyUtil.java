package com.zhiyi.xppay.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.CustomApplcation;
import com.zhiyi.xppay.ui.MainActivity;

import java.util.List;

/**
 * Created by Administrator on 2019/4/13.
 */

public class ZyUtil
{

    /*
 * 启动一个app
 */
    public static void startAPP() {
        try {
            Intent intent = new Intent(CustomApplcation.getInstance().getApplicationContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            CustomApplcation.getInstance().getApplicationContext().startActivity(intent);
        } catch (Exception e) {
            Log.e("ZYKJ","启动APP错误",e);
        }
    }

    public static boolean isAppRunning(Context context, String packageName) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> list = am.getRunningTasks(100);
        if (list.size() <= 0) {
            return false;
        }
        for (ActivityManager.RunningTaskInfo info : list) {
            if (info.baseActivity.getPackageName().equals(packageName)) {
                return true;
            }
        }
        return false;
    }

    /*
     * 启动一个app
     */
    public static void startAPP(Context context, String appPackageName) {
        try {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(appPackageName);
            context.startActivity(intent);
        } catch (Exception e) {
            sendmsg(context,"启动APP失败:");
            sendmsg(context,e.getMessage());
        }
    }

    public static void sendmsg(Context context, String msg) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("msg", msg);
        broadCastIntent.setAction(AppConst.MSGRECEIVED_ACTION);
        context.sendBroadcast(broadCastIntent);
    }

}
