package com.zhiyi.xppay.net.Socket;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.google.myjson.JsonElement;
import com.google.myjson.JsonObject;
import com.google.myjson.JsonParser;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.CustomApplcation;
import com.zhiyi.xppay.hook.ReqService;
import com.zhiyi.xppay.hook.mayou.QueryTrade;
import com.zhiyi.xppay.hook.mayou.ToolsMY;
import com.zhiyi.xppay.hook.mayou.TradeBean;
import com.zhiyi.xppay.item.ReqData;
import com.zhiyi.xppay.net.Socket.RecevieMsg.BuildQrcode;
import com.zhiyi.xppay.net.Socket.RecevieMsg.PayNotifyBackRecevie;
import com.zhiyi.xppay.net.Socket.SendMsg.DianDianChongToken;
import com.zhiyi.xppay.net.Socket.SendMsg.FriendOrder;
import com.zhiyi.xppay.net.Socket.SendMsg.FriendShip;
import com.zhiyi.xppay.net.Socket.SendMsg.LScreenError;
import com.zhiyi.xppay.net.Socket.SendMsg.PayAppDisable;
import com.zhiyi.xppay.net.Socket.SendMsg.TransMessage;
import com.zhiyi.xppay.ui.MainActivity;
import com.zhiyi.xppay.utils.AbSharedUtil;
import com.zhiyi.xppay.utils.AppUtil;
import com.zhiyi.xppay.net.Socket.RecevieMsg.BathBuildQrcode;
import com.zhiyi.xppay.net.Socket.RecevieMsg.BathQrcodeFormat;
import com.zhiyi.xppay.net.Socket.RecevieMsg.LoginReceive;
import com.zhiyi.xppay.net.Socket.SendMsg.LoginInfo;
import com.zhiyi.xppay.net.Socket.SendMsg.LoginSend;
import com.zhiyi.xppay.net.Socket.SendMsg.PayOverNotifySend;
import com.zhiyi.xppay.utils.DBManager;
import com.zhiyi.xppay.utils.JsonHelper;
import com.vilyever.socketclient.SocketClient;
import com.zhiyi.xppay.utils.OrderBean;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


/**
 * Created by zhiyi on 2018/10/19.
 */

public class ClientManager {

    public static final int LOGIN = 1;
    public static final int HEAD_BEAT = 2;
    public static final int PAY_NOTIFY = 100;
    public static final int GET_QRCODE = 101;
    public static final int GET_QRCODE_ERR = 102;
    public static final int PAY_OVER_NOTIFY = 103;
    public static final int BATH_BULLID_QRCODE = 104;
    public static final int CreateBindCode = 105;
    public static final int CloseBindCode = 106;
    public static final int NewFriendBill = 107;
    public static final int IS_FRIEND = 108;
    public static final int CREATE_BILL_IXL = 110;
    public static final int VISUAL_LOCATION = 111;//虚拟定位
    public static final int PAY_NOTIFY_BACK = 201;
    public static final int PAY_APP_DISABLE = 501;
    public static final int PAY_APP_NO_LOGIN = 502;
    public static final int PAY_COMPLETE = 503;
    public static final int ServerError = 500;
    public static final int CPCHECKORDER = 888;
    private static ClientManager server;
    protected ConnectClient connectClient;
    protected SocketClient socketClient;

    protected Context context;
    private boolean isstart;

    protected DBManager db;
    protected LoginInfoManager loginMng;
    protected BuildQrCode buildQrCode;

    private QueryTrade queryTrade;
    public static ClientManager getInstance() {
        if (server == null) {
            server = new ClientManager();
            server.init();
        }
        return server;
    }

    public boolean isStart(){
        return isstart;
    }

    public Context getContext(){return context;}

    protected ClientManager() {
        isstart = false;
        db = new DBManager(CustomApplcation.getContext());
        loginMng = new LoginInfoManager();
        buildQrCode = new BuildQrCode(this);
        //
        queryTrade = new QueryTrade(this);
    }

    public String getIp(){
        String ip = AbSharedUtil.getString(this.context, "connect_ip");
        if(ip!=null&&!ip.isEmpty()){
            return ip;
        }else{
            return "";
        }
    }

    protected String getPort(){
        return "9988";
    }

    public void init(){
        this.connectClient = new ConnectClient();
        this.socketClient = this.connectClient.getLocalSocketClient();
    }

    public void start(MainActivity main){
        this.context = main;
        if(!isstart&&!getIp().isEmpty()){
            connectClient.setIpAndPort(getIp(),getPort());
            connectClient.connect();
            isstart = true;
        }
    }

    public void reconnection(){
        if(!isstart){
            connectClient.setIpAndPort(getIp(),getPort());
            connectClient.connect();
            isstart = true;
        }else{
            this.socketClient.disconnect();
            connectClient.setIpAndPort(getIp(),getPort());
            connectClient.connect();
        }
    }

    public void onConnect() {
        Toast.makeText(context, "连接成功！", Toast.LENGTH_SHORT).show();
        MainActivity.sendmsg("Socket Connect:"+db.getAppid());
        //loginlist 中未登录的 加上
        for(LoginInfo info:loginMng.getLoginInfoList()){
            if(info.loginStatus== LoginInfo.LoginStatus.no){
                sendLogin(info.name,info.type);
                info.loginStatus = LoginInfo.LoginStatus.loading;
            }
        }
    }

    public void onDisConnect(){
        MainActivity.sendmsg("Socket Close");
        Toast.makeText(context, "连接关闭！"+getIp() , Toast.LENGTH_SHORT).show();
        loginMng.onDisconnect();
    }

    //--------------------------发送到Socket服务器-----------------------------------
    public void login(String name,String type) {
        if(loginMng.hasLogin(type)){
            return;
        }
        if(socketClient.isConnected()){
            //如果已经连接上 看是否 已经登录过了 如果已经登录过 不在登录
            sendLogin(name,type);
            loginMng.addLoginInfoNo(name,type,LoginInfo.LoginStatus.loading);
        }else{
            loginMng.addLoginInfoNo(name,type,LoginInfo.LoginStatus.no);
        }
    }

    protected void sendLogin(String name,String type){
        String device = db.getDeviceId();
        if(device == null || device.length()<1){
            device = AppUtil.getUniqueId(context);
            db.saveDeviceid(device);
        }

        String appid = db.getAppid();
        LoginSend login = new LoginSend(name, type,device,appid);
        String sendStr = JsonHelper.toJson(login);
        socketClient.sendString(sendStr);
        //
    }

    public void bindCode(){
        TransMessage msg = new TransMessage(CreateBindCode);
        socketClient.sendString(JsonHelper.toJson(msg));
    }

    public void closeBindCode(){
        TransMessage msg = new TransMessage(CloseBindCode);
        socketClient.sendString(JsonHelper.toJson(msg));
    }

    /**
     * 生成二维码(订单)成功
     * */
    public void OnGetQrcodeOver(String payurl, String mark, String money,String paytype,String img_url,String orderid) {
        BuildQrcode send = new BuildQrcode();
        send.type = GET_QRCODE;
        send.qrcode = payurl;
        send.money = money;
        send.remark = mark;
        send.paytype =paytype;
        send.img_url = img_url;
        send.orderId = orderid;
        buildQrCode.receiveQrCode(send);
        if(payurl.equals("")){
            return;
        }
        //发送到服务器
        String sendStr = JsonHelper.toJson(send);
        socketClient.sendString(sendStr);
    }

    public void sentFriendType(Intent intent){
        FriendShip friendShip = new FriendShip(intent);
        socketClient.sendString(friendShip.getJson());
    }

    public void sentFriendOrder(Intent intent){
        FriendOrder order = new FriendOrder(intent);
        socketClient.sendString(order.getJson());
    }


    public void sendPayOverNotify(String type, final String no, String money, String mark, String dt,String wh) {
        PayOverNotifySend send = new PayOverNotifySend();
        send.type = PAY_OVER_NOTIFY;
        send.paytype = type;
        send.no = no;
        send.money = money;
        send.mark = mark;
        send.dt = dt;
        send.wh = wh;
        String sendStr = JsonHelper.toJson(send);
        socketClient.sendString(sendStr);
    }

    public void onLoginPayAppDisable(String type){
        if(loginMng.hasLogin(type)){
            //发送服务器 掉线
            PayAppDisable data = new PayAppDisable();
            data.type = PAY_APP_DISABLE;
            data.paytype = type;
            String json = JsonHelper.toJson(data);
            socketClient.sendString(json);
        }
        loginMng.setLoginNoinfo(type);
    }
    //---------------------从socket服务器接收-----------------------------
    public void onReceive(byte[] packet) throws InterruptedException {
        String json = new String(packet);
        JsonElement pJosn = new JsonParser().parse(json);
        JsonObject obj = (JsonObject) pJosn;
        JsonElement type = obj.get("type");
        switch (type.getAsInt()) {
            case GET_QRCODE:
                OnGetQrCode(json);
                break;
            case LOGIN:
                OnLogin(json);
                break;
            case BATH_BULLID_QRCODE:
                OnBathBullidQrcode(json);
                break;
            case PAY_NOTIFY_BACK:
                OnPayNotifyBack(json);
                break;
            case CreateBindCode:
                onBindCode(obj);
                break;
            case PAY_APP_NO_LOGIN:
                relogin();
            case ServerError:
                Log.w("ZYXP","系统错误");
                break;
            case CPCHECKORDER:
//                onCpPayQuery(obj.get("img_url").getAsString());
                break;
            case NewFriendBill:
                newFriendBill(obj);
                break;
            case IS_FRIEND:
                isFriend(obj);
                break;
            case CREATE_BILL_IXL:
                newBill(obj);
                break;
            case VISUAL_LOCATION:
                setAliFixedpos(obj);
                break;
        }
    }

    private void setAliFixedpos(JsonObject json){
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(AppConst.ALIPAY_FIXED_POSITION);
        broadCastIntent.putExtra("latitude", json.get("latitude").getAsString());
        broadCastIntent.putExtra("longitude", json.get("longitude").getAsString());
        context.sendBroadcast(broadCastIntent);
    }

    private void isFriend(JsonObject json){
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(AppConst.ALIPAY_FRIEND_CHECK_ACTION);
        broadCastIntent.putExtra("payuid", json.get("pay_uid").getAsString());
        broadCastIntent.putExtra("localorderid", json.get("orderid").getAsString());
        context.sendBroadcast(broadCastIntent);
    }

    private void newBill(JsonObject json){
        Intent broadCastIntent = new Intent();
        String pType = json.get("paytype").getAsString();
        broadCastIntent.setAction(pType+AppConst.ACTION_BUILD_QRCODE);
        broadCastIntent.putExtra("json", json.toString());
        context.sendBroadcast(broadCastIntent);
    }

    private void newFriendBill(JsonObject json){
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(AppConst.ALIPAY_FRIEND_ORDER_ACTION);
        broadCastIntent.putExtra("pay_uid", json.get("pay_uid").getAsString());
        broadCastIntent.putExtra("money", json.get("pay_money").getAsString());
        broadCastIntent.putExtra("remark", json.get("remark").getAsString());
        broadCastIntent.putExtra("orderid", json.get("orderid").getAsString());
        context.sendBroadcast(broadCastIntent);
    }

    private void relogin(){
        for(LoginInfo info:loginMng.getLoginInfoList()){
            sendLogin(info.name,info.type);
            info.loginStatus = LoginInfo.LoginStatus.loading;
        }
    }

    public void onCpPayQuery(String orderid){
        PayHelperUtils.sendCPQuery(context,orderid);
    }

    public void onBindCode(JsonObject object){
        int code = object.get("code").getAsInt();
        Message msg = new Message();
        msg.what = CreateBindCode;
        msg.arg1 = code;
        MainActivity.handler.sendMessage(msg);
    }

    private void OnPayNotifyBack(String json) {
        PayNotifyBackRecevie data = JsonHelper.fromJson(json,PayNotifyBackRecevie.class);
        db.updateTradeStep3(data.no);
    }

    private void OnBathBullidQrcode(String json) {
        BathBuildQrcode bullid = JsonHelper.fromJson(json,BathBuildQrcode.class);
        String formatStr = bullid.format;
        BathQrcodeFormat format = new BathQrcodeFormat(formatStr,bullid.producetype);
        buildQrCode.batchBuildQrcode(bullid,format);
        MainActivity.sendmsg("bullid qrcode size = ["+ format.money.size() + "]");
    }

    protected void OnLogin(String json){
        LoginReceive login = JsonHelper.fromJson(json,LoginReceive.class);
        Message msg = new Message();
        msg.what = 2;
        msg.obj = login;
        MainActivity.handler.sendMessage(msg);
        loginMng.setLoginFinish(login.paytype);
        //保存 appid
        db.saveAppidInfo(login.appid,login.token);
        Toast.makeText(context, "登录成功！ 用户名：" + login.name , Toast.LENGTH_SHORT).show();
    }

    protected void OnGetQrCode(String json) throws InterruptedException {
        BuildQrcode getQrCode = JsonHelper.fromJson(json, BuildQrcode.class);
        buildQrCode.buildQrcode(getQrCode);
    }

    protected void OnLScreenError(int duputytype,String paytype,String mark,String failmessage){
        sendLScreenError(duputytype,paytype,mark);
        MainActivity.sendmsg(failmessage);
    }
    //
    private void sendLScreenError(int duputytype,String paytype,String mark){
        LScreenError send = new LScreenError(PAY_APP_DISABLE);
        send.duputytype = duputytype;
        send.paytype = paytype;
        send.mark = mark;
        //
        String sendStr = JsonHelper.toJson(send);
        socketClient.sendString(sendStr);
    }

    public void getExTradeResult(OrderBean bean){
        if(!bean.getResult().equals("0")){
            return;
        }
        final String tradeno = bean.getMoney();
        String cookie = bean.getMark();
        String url="https://tradeeportlet.alipay.com/wireless/tradeDetail.htm?tradeNo="+tradeno+"&source=channel&_from_url=https%3A%2F%2Frender.alipay.com%2Fp%2Fz%2Fmerchant-mgnt%2Fsimple-order._h_t_m_l_%3Fsource%3Dmdb_card";
        try {
            HttpUtils httpUtils=new HttpUtils(15000);
            httpUtils.configResponseTextCharset("GBK");
            RequestParams params=new RequestParams();
            params.addHeader("Cookie", cookie);

            httpUtils.send(HttpRequest.HttpMethod.GET, url,params, new RequestCallBack<String>() {

                @Override
                public void onFailure(HttpException arg0, String arg1) {
                    PayHelperUtils.sendmsg(context,"服务器异常"+arg1);
                    db.updateTradeStep0(tradeno);
                }

                @Override
                public void onSuccess(ResponseInfo<String> arg0) {
                    try {
                        if(db.isFinishedTradeNo(tradeno)){
                            return;
                        }
                        String result=arg0.result;
                        //
                        Document document= Jsoup.parse(result);
                        Elements elements=document.getElementsByClass("trade-info-value");
                        if(elements.size()>=5){
                            String money=elements.get(2).ownText();
                            String mark=elements.get(3).ownText();
                            String dt=elements.get(1).ownText();
                            db.updateTradeStep2(new OrderBean(money, mark, AppConst.TYPE_ALIPAY, tradeno, dt, "", 0));
                            MainActivity.sendmsg("收到支付宝订单,订单号："+tradeno+"金额："+money+"备注："+mark);
                            sendPayOverNotify(AppConst.TYPE_ALIPAY,tradeno,money,mark,dt,"");
                        }
                    } catch (Exception e) {
                        PayHelperUtils.sendmsg(context, "TRADENORECEIVED_ACTION-->>onSuccess异常"+e.getMessage());
                    }
                }
            });
        } catch (Exception e) {
            PayHelperUtils.sendmsg(context, "TRADENORECEIVED_ACTION异常"+e.getMessage());
        }
    }

    public void sendToken(Intent intent) {
        DianDianChongToken ddc = new DianDianChongToken(intent);
        socketClient.sendString(ddc.getJson());
    }

    public void sendBill(Intent intent){
        PayOverNotifySend data = new PayOverNotifySend(intent);
        socketClient.sendString(data.getJson());
    }

    public void setPayComplete(Intent intent){
        String no = intent.hasExtra("no")?intent.getStringExtra("no"):"";
        Log.i("ZYKJ","要对比的订单号》》》 "+ " = "+no);
        if(!TextUtils.isEmpty(no)){
            ReqData tdata = new ReqData(no);
            ReqService.compare(tdata);
        }
    }

    public boolean isLogin(String payType){
        return loginMng.hasLogin(payType);
    }
}
