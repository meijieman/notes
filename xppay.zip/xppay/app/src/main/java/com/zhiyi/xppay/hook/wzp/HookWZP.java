package com.zhiyi.xppay.hook.wzp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.concurrent.TimeUnit;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by pc_mg on 2019/6/17.
 */

public class HookWZP {
    private static ClassLoader mClassloader;
    private static Context mContext;
    private Handler mHandler;
    private final static String[] types = {"WFT_AL", "WFT_WX", "UNION"};
    private static OkHttpClient client;
    public void hook(final ClassLoader classLoader, final Context context) {
        final Class<?> clazz = XposedHelpers.findClass("com.stub.StubApp", classLoader); // onCreate
        XposedHelpers.findAndHookMethod(clazz, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log(" onCreate " + param.thisObject);
                Field field = XposedHelpers.findField(clazz, "ᵢˎ");
                XposedBridge.log(" onCreate field " + field.getClass().getName());
                field.setAccessible(true);
                Object obj = field.get(param.thisObject);
                Field fieldc = XposedHelpers.findField(clazz, "ᵢˑ");
                fieldc.setAccessible(true);
                Object objc = fieldc.get(param.thisObject);
                hook_real(obj.getClass().getClassLoader(), (Context) objc);
            }
        });
        initOkHttpClient();
    }

    public void hook_real(ClassLoader classLoader, final Context context) {
        mClassloader = classLoader;
        mContext = context;
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("当前 activity 》》》》》》》》" + param.thisObject.getClass().getName());
                if (param.thisObject.getClass().getName().equals("com.hkrt.wzp.presentation.screen.main.MainActivity")) {
                    GetUserInfo();
                    if (mHandler == null) {
                        mHandler = new Handler() {
                            @Override
                            public void handleMessage(Message msg) {
                                super.handleMessage(msg);
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        queryTrade();
                                    }
                                }).start();
                                mHandler.sendEmptyMessageDelayed(1001, 10000);
                            }
                        };
                        mHandler.sendEmptyMessageDelayed(1001, 10000);
                    } else {
                        mHandler.removeMessages(1001);
                    }
                }
            }
        });
        XposedHelpers.findAndHookMethod("com.hkrt.wzp.presentation.screen.main.MainActivity", classLoader, "l", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
            }
        });
    }

    private void initOkHttpClient(){
        OkHttpClient.Builder builder = new OkHttpClient().newBuilder();
        builder.connectTimeout(50, TimeUnit.SECONDS);
        builder.writeTimeout(50, TimeUnit.SECONDS);
        builder.readTimeout(50, TimeUnit.SECONDS);
        builder.sslSocketFactory(SSLSocketClient.getSSLSocketFactory())
                .hostnameVerifier(SSLSocketClient.getHostnameVerifier());
        client = builder.build();
    }

    public static void CreateQR(final Intent intent) {// UNION WFT_WX WFT_AL
        final String money = intent.getStringExtra("money");
        final String mark = intent.getStringExtra("mark");
        final String type = intent.getStringExtra("type");
        new Thread(new Runnable() {
            @Override
            public void run() {
                CreateQR(money, mark, type);
            }
        }).start();
    }

    private static void CreateQR(String amount, String mark, String type) {
        String[] temp = type.split("_");
        int index = Integer.parseInt(temp[1]);
        final String paytype = types[index - 1];
        XposedBridge.log("请求的 二维码 类型 》》》》》》》》" + type + "  amount  " + amount);
        String str2 = "https://posapp.icardpay.com/html5/mobile/merchant/pay/activePay?" +
                "equipment=" + getEquipment() +
                "&amount=" + amount +
                "&token=" + getToken() +
                "&channelType=" + paytype +
                "&version=" + getVersion();
        Request request = new Request.Builder()
                .url(str2).build();
        try {
            Response response = client.newCall(request).execute();
            String result = response.body().string();
            XposedBridge.log("请求QR结果》》》》》" + result);
//            {"payUrl":"weixin://wxpay/bizpayurl?pr\u003dd035J3j","code":"1","msg":"交易成功","flowId":"8651092019061714080230107"}
            JSONObject json = new JSONObject(result);
            String payurl = json.getString("payUrl");
            String img_url = json.getString("flowId");
            //
            Intent broadCastIntent = new Intent();
            broadCastIntent.putExtra("money", amount);
            broadCastIntent.putExtra("mark", mark);
            broadCastIntent.putExtra("type", type);
            broadCastIntent.putExtra("payurl", payurl);
            broadCastIntent.putExtra("img_url", img_url);
            broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
            mContext.sendBroadcast(broadCastIntent);
            //
        } catch (IOException e) {
            e.printStackTrace();
            XposedBridge.log("---------------------------");
            XposedBridge.log(e);
        } catch (JSONException e) {
            e.printStackTrace();
            XposedBridge.log("****************************");
            XposedBridge.log(e);
        }
    }

    private static void queryTrade() {
        String str2 = "https://posapp.icardpay.com/html5/mobile/merchant/user/tranRecordDayList?" +
                "equipment=" + getEquipment() +
                "&page=" + "1" +
                "&token=" + getToken() +
                "&pageSize=" + "10" +
                "&version=" + getVersion();
        Request request = new Request.Builder()
                .url(str2).build();
        try {
            Response response = client.newCall(request).execute();
            String result = response.body().string();
            JSONObject json = new JSONObject(result);
            String code = json.getString("code");
            XposedBridge.log("开始轮询微掌铺订单结果>>>>>"+json);
            if (code.equals("1")) {
                JSONArray o = json.getJSONArray("records");
                for (int i = 0; i < o.length(); i++) {
                    JSONObject p = o.getJSONObject(i);
                    String status = p.getString("tranStatus");
                    if (status.equals("0")) {
                        String paytime = p.getString("tranDate");
                        paytime = PayHelperUtils.dateToStamp(paytime, "yyyy-MM-dd hh:mm:ss");
                        String money = p.getString("tranAmount");
                        String remark = p.optString("flowId");
                        //
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("bill_no", remark);
                        broadCastIntent.putExtra("bill_money", money);
                        broadCastIntent.putExtra("bill_mark", remark);
                        broadCastIntent.putExtra("bill_type", AppConst.TYPE_WZP);
//                        broadCastIntent.putExtra("bill_dt", paytime);
                        //
                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                        mContext.sendBroadcast(broadCastIntent);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            XposedBridge.log("---------------------------");
            XposedBridge.log(e);
        } catch (JSONException e) {
            e.printStackTrace();
            XposedBridge.log("****************************");
            XposedBridge.log(e);
        }
    }

    private void GetUserInfo() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                getUserInfo();
            }
        }).start();
    }

    private void getUserInfo() {
        XposedBridge.log("开始获取商户信息");
        String str2 = "https://posapp.icardpay.com/html5/mobile/merchant/user/operatorInfo?" +
                "equipment=" + getEquipment() +
                "&token=" + getToken() +
                "&version=" + getVersion();
        Request request = new Request.Builder()
                .url(str2).build();
        try {
            Response response = client.newCall(request).execute();
            String result = response.body().string();
            JSONObject json = new JSONObject(result);
            String code = json.getString("code");
            XposedBridge.log("用户信息 》》》》》》》 " + json);
            if (code.equals("1")) {
                String phonenum = json.getString("phoneNum");
                PayHelperUtils.sendLoginId(phonenum, AppConst.TYPE_WZP, mContext);
            }
        } catch (IOException e) {
            e.printStackTrace();
            XposedBridge.log(e);
        } catch (JSONException e) {
            e.printStackTrace();
            XposedBridge.log("******** json *********");
            XposedBridge.log(e);
        }
    }

    private static String getToken() {
        SharedPreferences object = mContext.getSharedPreferences("wzp_SP", 0);
        return object.getString("token", "");
    }

    private static String getEquipment() {
        Class clazz = XposedHelpers.findClass("com.hkrt.wzp.presentation.utils.ac", mClassloader);
        String result = "" + XposedHelpers.callStaticMethod(clazz, "b", mContext);
        return result;
    }

    private static String getVersion() {
        Class clazz = XposedHelpers.findClass("com.hkrt.wzp.presentation.utils.ac", mClassloader);
        String result = "" + XposedHelpers.callStaticMethod(clazz, "a", mContext);
        return result;
    }
}
