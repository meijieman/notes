package com.zhiyi.xppay.net.Socket;


import com.vilyever.socketclient.helper.SocketClientAddress;

/**
 * Created by zhiyi on 2018/10/22.
 */

public class SocketClientAddr extends SocketClientAddress {

    @Override
    public void checkValidation() {

    }
}
