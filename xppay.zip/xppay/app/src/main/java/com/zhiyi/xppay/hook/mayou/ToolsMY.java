package com.zhiyi.xppay.hook.mayou;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/4/12.
 */

public class ToolsMY {
    private static ArrayList<TradeBean> listbeans = new ArrayList<TradeBean>();

    public static void addBean(TradeBean bean){
        if(listbeans == null){
            listbeans = new ArrayList<TradeBean>();
        }
        XposedBridge.log("增加一个新的订单》》"+bean.mark+"金額》》》"+bean.money);
        listbeans.add(bean);
    }

    public static boolean compareRemark(String mark){
        ArrayList listremoveed = new ArrayList();
        boolean result = false;
        for(int i = 0;i<listbeans.size();i++){
            if(!TextUtils.isEmpty(listbeans.get(i).mark)&&listbeans.get(i).mark.equals(mark)){
                result = true;
                break;
            }else if(TextUtils.isEmpty(listbeans.get(i).mark)){
                listremoveed.add(listbeans.get(i));
            }
        }
        if(listremoveed.size()>0){
            XposedBridge.log("清空mark为空的数据");
            listbeans.removeAll(listremoveed);
        }
        XposedBridge.log("对比订单结果 >>>>"+result);
        return result;
    }

    public static String removeBean(String mark){
        ArrayList<TradeBean> beansremove = new ArrayList<TradeBean>();
        String money = "";
        XposedBridge.log("removeBean当前订单数量 》》》》》 "+listbeans.size()+"要对比的备注"+mark);
        for(int i = 0;i<listbeans.size();i++){
            TradeBean tbean = listbeans.get(i);
            if(!TextUtils.isEmpty(tbean.mark)&&!tbean.mark.equals(mark)){
                if((System.currentTimeMillis() - listbeans.get(i).createtime>600000)){
                    tbean.mark = "";
                }else{
                    continue;
                }
            }
            beansremove.add(tbean);
        }
        XposedBridge.log("removeBean要删除的的订单数量 》》》》》》 "+beansremove.size());
        if(beansremove.size()>0){
            for(int j = 0;j<listbeans.size();j++){
                TradeBean tbean = listbeans.get(j);
                for(int i = 0;i<beansremove.size();i++){
                    TradeBean bean = beansremove.get(i);
                    if(listbeans.contains(bean)){
                        if(!TextUtils.isEmpty(bean.mark)&&bean.mark.equals(tbean.mark)){
                            money = tbean.money;
                            XposedBridge.log("removeBean订单的金额》》"+money+"备注》》"+tbean.mark);
                            break;
                        }
                    }
                }
            }
            listbeans.removeAll(beansremove);
            XposedBridge.log("removeBean删除之后订单数量》》》"+listbeans.size());
        }
        return money;
    }
}
