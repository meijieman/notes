package com.zhiyi.xppay.hook.mowang;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/4/13.
 */
// 失败调用
public class Function3MoTong implements InvocationHandler {
    @Override
    public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
        String methodName = method.getName();
        XposedBridge.log("Function3MoTong 调用的方法名称为:" + methodName);
        XposedBridge.log("Function3MoTong 返回的类型为" + method.getReturnType().getName());
        XposedBridge.log("Function1MoTong >>>>>>> 结果"+objects[1]);
        return null;
    }
}
