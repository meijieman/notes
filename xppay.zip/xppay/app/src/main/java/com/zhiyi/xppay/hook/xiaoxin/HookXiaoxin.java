package com.zhiyi.xppay.hook.xiaoxin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.webkit.WebView;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.xgj.TradeReqBodyXGJ;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by pc_mg on 2019/4/23.
 */

public class HookXiaoxin {
    private static ClassLoader mclassLoader;
    private static Context mcontext;

    public void hook(final ClassLoader classLoader, final Context context) {
        mclassLoader = classLoader;
        mcontext = context;
        if (groupids == null) {
            groupids = new ArrayList<String>();
        }
        XposedHelpers.findAndHookMethod("com.netease.nim.uikit.common.activity.UI", classLoader, "onResume", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if (param.thisObject.getClass().getName().equals("com.jishuo.xiaoxin.main.activity.MainActivity")) {
                    getAllTeams();
                    String loginid = getUserAccount();
                    PayHelperUtils.sendLoginId(loginid, AppConst.TYPE_XX, context);
//                    String token = getUserToken();
//                    token += "_"+getGroupid();
//                    PayHelperUtils.sendLoginId(token, AppConst.TYPE_XX,context);
                }
            }
        });
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("activity >>>>>>>>>>> " + param.thisObject.getClass().getName());
            }
        });
//        XposedHelpers.findAndHookMethod("com.jishuo.xiaoxin.session.action.JrmfRedPacketAction", classLoader, "sendRpMessage", Intent.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                XposedBridge.log("JrmfRedPacketAction >>>>>>> " + param.args[0]);
//            }
//        });
//        XposedHelpers.findAndHookMethod("com.jishuo.xiaoxin.session.extension.CustomAttachParser", classLoader, "parse", String.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                XposedBridge.log("CustomAttachParser  parse>>" + param.args[0]);
//            }
//        });
        XposedHelpers.findAndHookMethod("com.netease.nimlib.p.a", classLoader, "c", String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("str >>>>>>>>>>>>>>>>>>> " + param.args[0]);
                String content = "" + param.args[0];
                if (TextUtils.isEmpty(content)||content.equals("null")) return;
                JSONObject json = new JSONObject(content);
                JSONObject jsondata = json.optJSONObject("data");
                if (jsondata != null) {
                    final String redPacketId = jsondata.optString("redPacketId");
                    final String remark = jsondata.optString("content");
                    boolean isopen = jsondata.optBoolean("isRedPacketOpen");
                    if(isopen) return;
                    XposedBridge.log("----------------");
                    if (redPacketId != null) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                XposedBridge.log("开始打开红包");
                                checkRedPacket(redPacketId,remark);
                                XposedBridge.log("打开红包结束");
                            }
                        }).start();
                    }
                }
            }
        });
    }

    static ArrayList<String> groupids = new ArrayList<String>();

    public static void getAllTeams() {
        Class clazz = XposedHelpers.findClass("com.netease.nim.uikit.impl.NimUIKitImpl", mclassLoader);
        Object objteampro = XposedHelpers.callStaticMethod(clazz, "getTeamProvider");
        Object teams = XposedHelpers.callMethod(objteampro, "getAllTeams");
        String list = JsonHelper.toJson(teams);
        try {
            JSONArray grouparray = new JSONArray(list);
            for (int i = 0; i < grouparray.length(); i++) {
                JSONObject obj = grouparray.getJSONObject(i);
                String groupid = obj.optString("a");
                XposedBridge.log("群groupid>>>>>>>" + groupid);
                groupids.add(groupid);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static String getGroupid() {
        int index = (int) (Math.random() * (groupids.size()));
        String id = "" + groupids.get(index);
        return id;
    }

    public static void createQRCode(Intent intent) {
        final String money = intent.getStringExtra("money");
        final String mark = intent.getStringExtra("mark");
        int amount = (int) ((Float.parseFloat(money)) * 100);
        final String _amount = "" + amount;
        XposedBridge.log("_amount >>>>>>>> " + _amount);
        try {
            XposedBridge.log("开始 生成 qrcode");
            HttpUtils httpUtils = new HttpUtils(30000);
            XXQrCodeReq xxQrCodeReq = new XXQrCodeReq(mark, _amount, getGroupid());
            RequestParams params = new RequestParams();
            StringEntity entity = new StringEntity(xxQrCodeReq.toJson(), "UTF-8");
            params.setBodyEntity(entity);
            params.setContentType("application/json");
            params.addHeader("token", getUserToken());
            params.addHeader("Host", "appapi.aixiaoxinim.com");
            String url = "https://appapi.aixiaoxinim.com/yx-api/redPacket/sendRedPacket2";
            httpUtils.send(HttpRequest.HttpMethod.POST, url, params, new RequestCallBack<String>() {
                @Override
                public void onSuccess(ResponseInfo<String> responseInfo) {
                    String result = responseInfo.result;
                    XposedBridge.log("生成红包结果>>>>>>>>>>>>>" + result);
                    try {
                        JSONObject json = new JSONObject(result);
                        String code = json.optString("code");
                        String msg = json.optString("message");
                        if(code.equals("200")){
                            JSONObject jsondata = json.optJSONObject("data");
                            final String outorderNo = jsondata.optString("outOrderNo");
                            String qrcode = jsondata.optString("body");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("type", AppConst.TYPE_XX);
                            broadCastIntent.putExtra("mark", mark);
                            broadCastIntent.putExtra("money", money);
                            broadCastIntent.putExtra("payurl", "" + qrcode);
                            broadCastIntent.putExtra("img_url", outorderNo);
                            broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                            mcontext.sendBroadcast(broadCastIntent);
                            XposedBridge.log("小信生成红包成功>>>" + qrcode);
                        }else{
                            XposedBridge.log("小信生成红包失败>>>" + code+"msg>>"+msg);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        XposedBridge.log("======小信生成红包解析失败=========:" + e.toString());
                    }
                }

                @Override
                public void onFailure(HttpException e, String s) {
                    XposedBridge.log("======小信生成红包失败=========:" + e.toString());
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public static void openRedPacket(final String _outTradeNo, final String _remark) {
        try {
            XposedBridge.log("开始 打开红包_outTradeNo == " + _outTradeNo + "备注是" + _remark);
            HttpUtils httpUtils = new HttpUtils(30000);
            XXOpendRP xxOpendRP = new XXOpendRP(_outTradeNo);
            RequestParams params = new RequestParams();
            StringEntity entity = new StringEntity(xxOpendRP.toJson(), "UTF-8");
            params.setBodyEntity(entity);
            params.setContentType("application/json");
            params.addHeader("token", getUserToken());
            params.addHeader("Host", "appapi.aixiaoxinim.com");
            String url = "https://appapi.aixiaoxinim.com/yx-api/redPacket/disburse";
            httpUtils.send(HttpRequest.HttpMethod.POST, url, params, new RequestCallBack<String>() {
                @Override
                public void onSuccess(ResponseInfo<String> responseInfo) {
                    String result = responseInfo.result;
                    XposedBridge.log("小信打开红包结果" + result);
                    try {
                        JSONObject json = new JSONObject(result);
                        String code = json.optString("code");
                        if (!TextUtils.isEmpty(code) && code.equals("200")) {
                            JSONObject data = json.optJSONObject("data");
                            String money = data.getString("amount");
                            String amount = "" + Float.parseFloat(money) / 100f;
                            String remark = _remark;
                            String no = _outTradeNo;
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("bill_no", no);
                            broadCastIntent.putExtra("bill_money", amount);
                            broadCastIntent.putExtra("bill_mark", no);
                            broadCastIntent.putExtra("bill_type", AppConst.TYPE_XX);
                            broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                            mcontext.sendBroadcast(broadCastIntent);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(HttpException e, String s) {
                    XposedBridge.log("======onFailure=========:" + e.toString());
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }
    public static void checkRedPacket(final String _outTradeNo,final String remark) {
        try {
            XposedBridge.log("开始检测红包_outTradeNo == " + _outTradeNo);
            HttpUtils httpUtils = new HttpUtils(30000);
            XXOpendRP xxOpendRP = new XXOpendRP(_outTradeNo);
            RequestParams params = new RequestParams();
            StringEntity entity = new StringEntity(xxOpendRP.toJson(), "UTF-8");
            params.setBodyEntity(entity);
            params.setContentType("application/json");
            params.addHeader("token", getUserToken());
            params.addHeader("Host", "appapi.aixiaoxinim.com");
            String url = "https://appapi.aixiaoxinim.com/yx-api/redPacket/detail";
            httpUtils.send(HttpRequest.HttpMethod.POST, url, params, new RequestCallBack<String>() {
                @Override
                public void onSuccess(ResponseInfo<String> responseInfo) {
                    String result = responseInfo.result;
                    XposedBridge.log("小信检测红包结果" + result);
                    try {
                        JSONObject json = new JSONObject(result);
                        String code = json.optString("code");
                        if (!TextUtils.isEmpty(code) && code.equals("200")) {
                            JSONObject data = json.optJSONObject("data");
                            String orderTitle = data.optString("orderTitle");
                            JSONArray array = data.optJSONArray("list");
                            if(array.length()<=0){
                                openRedPacket(_outTradeNo,remark);
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(HttpException e, String s) {
                    XposedBridge.log("======onFailure=========:" + e.toString());
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public static String getUserAccount() {
        Class clazz = XposedHelpers.findClass("com.jishuo.xiaoxin.config.preference.Preferences", mclassLoader);
        String str = "" + XposedHelpers.callStaticMethod(clazz, "getUserAccount");
        return str;
    }

    public static String getUserToken() {
        Class clazz = XposedHelpers.findClass("com.jishuo.xiaoxin.commonlibrary.database.room.AppDatabase", mclassLoader);
        Object fielda = XposedHelpers.getStaticObjectField(clazz, "d");
        Object objCData = XposedHelpers.callMethod(fielda, "a", XposedHelpers.callStaticMethod(
                XposedHelpers.findClass("com.jishuo.xiaoxin.corelibrary.utils.AppExtKt", mclassLoader), "a")
        );
        Object objK = XposedHelpers.callMethod(objCData, "k");
        Object objA = XposedHelpers.callMethod(objK, "b");
        String str = "" + XposedHelpers.callMethod(objA, "getToken");
        XposedBridge.log("token >>>" + str);
        return str;
    }
}
