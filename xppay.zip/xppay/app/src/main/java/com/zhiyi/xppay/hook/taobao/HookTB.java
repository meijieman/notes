package com.zhiyi.xppay.hook.taobao;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/3/28.
 */

public class HookTB {
    private static ClassLoader mclassLoader;
    private static Context mcontext;

    public void hook(final ClassLoader classLoader, final Context context) {
        mclassLoader = classLoader;
        mcontext = context;
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if(param.thisObject.getClass().getName().equals("com.alibaba.mobileim.ui.tab.MainTabActivity")){
                    PayHelperUtils.sendLoginId(get_mid(), AppConst.TYPE_TBH,mcontext);
                    XposedBridge.log("getGroupId() >>>>>>>>>>>>>>>> "+getGroupId());
                }
            }
        });
//        XposedHelpers.findAndHookMethod("com.alibaba.mobileim.channel.util.WxLog", classLoader, "d", String.class, String.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                XposedBridge.log("TAG >>> " + param.args[0] + "content >>> " + param.args[1]);
//            }
//        });
        XposedHelpers.findAndHookMethod("com.alibaba.mobileim.lib.presenter.message.MessageList", classLoader, "pushMessage", String.class, List.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("param.args[0] >>>>>>>> " + param.args[1].toString());
                Object imsg = ((List) param.args[1]).get(0);
                Object objmsg = XposedHelpers.callMethod(param.thisObject, "unpackMsg", imsg);
                String msgid = "" + XposedHelpers.callMethod(objmsg, "getMsgId");
                String authorId = "" + XposedHelpers.callMethod(objmsg, "getAuthorId");
                String content = "" + XposedHelpers.callMethod(objmsg, "getContent");
                openRepackage(content, authorId);
            }
        });
//        XposedBridge.hookAllMethods(XposedHelpers.findClass("com.alibaba.mobileim.channel.service.WXServiceCallbackDefault", classLoader), "notify", new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                Object obj = XposedHelpers.getObjectField(param.thisObject, "mCls");
//                Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.channel.itf.mimsc.CascRspSiteApp", classLoader);
//                Object inst = clazz.newInstance();
//                Object count = XposedHelpers.callMethod(inst, "unpackData", (byte[]) param.args[1]);
//                if (Integer.parseInt("" + count) == 0) {
//                    JSONObject jSONObject = new JSONObject("" + XposedHelpers.callMethod(inst, "getRspData"));
//                    int optInt = jSONObject.optInt("code");
//                    if (optInt == 0) {
//                        JSONObject optJSONObject = jSONObject.optJSONObject("result");
//                        XposedBridge.log("optJSONObject >>>>>>>>>> " + optJSONObject.toString());
//                        if (optJSONObject != null) {
//                            JSONObject optJSONObject2 = optJSONObject.optJSONObject("alipay_param");
//                            if (optJSONObject2 != null) {
//                                String url = optJSONObject2.optString("url");
//                                url = url.replace("\"", "\\\"");
//                                Intent v2 = new Intent();
//                                v2.putExtra("type", AppConst.TYPE_TBH);
//                                v2.putExtra("mark", cuttentbean.remark);
//                                v2.putExtra("money",""+ (((float)cuttentbean.amount)/100));
//                                v2.putExtra("payurl", url);
//                                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
//                                mcontext.sendBroadcast(v2);
////                                XposedBridge.log(" 收到的消息 param.args[1] >>>>>>>>>>>>>>>>> " + url);
//                            } else { // 红包
//                                String note = optJSONObject.getString("note");
//                                String amount = optJSONObject.getString("amount");
//                                amount = "" + (Float.parseFloat(amount)) / 100;
//                                JSONArray array = optJSONObject.getJSONArray("details");
//                                JSONObject details = array.getJSONObject(0);
//                                String receiver = details.getString("receiver");
//                                String dt = details.getString("timestamp");
//                                Intent v2 = new Intent();
//                                v2.putExtra("bill_type", AppConst.TYPE_TBH);
//                                v2.putExtra("bill_mark", note);
//                                v2.putExtra("bill_money", amount);
//                                v2.putExtra("bill_no", "");
//                                v2.setAction(AppConst.BILLRECEIVED_ACTION);
//                                mcontext.sendBroadcast(v2);
//                                XposedBridge.log("收到淘宝红包，金额：" + amount + "收款账号：" + receiver + "时间戳：" + dt + "备注：" + note);
////                                PayHelperUtils.sendmsg(context, "收到淘宝红包，金额：" + amount + "收款账号：" + receiver + "时间戳：" + dt + "备注：" + note);
//                            }
//                        }
//                    }
//                }
//            }
//        });
    }

    public static void SendHongbao(final long amount, final String remark){
        SendHongbao(amount,""+getGroupId(),remark);
    }
    private static void SendHongbao(final long amount, String receiver, final String remark) {
        PayHelperUtils.sendmsg(mcontext,"当前群号:"+receiver);
        if(Long.parseLong(receiver)<=0){
            PayHelperUtils.sendmsg(mcontext,"请前往旺信建群");
            return;
        }
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.channel.SocketChannel", mclassLoader);
        Object o_instance = XposedHelpers.callStaticMethod(clazz, "getInstance");
        Object o_WXContext = XposedHelpers.callMethod(get_wxAccount(get_wxContext()), "getWXContext");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("method", "createHongbao");
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("amount", amount);
            jSONObject2.put("type", 1);
            jSONObject2.put("size", 1);
            jSONObject2.put("note", remark);
            jSONObject2.put("hongbao_id", get_HongbaoID());
            jSONObject2.put("receiver", receiver);
            jSONObject2.put("message_id", get_UUID());
            jSONObject2.put("sub_type", 0);
            jSONObject.put("params", jSONObject2);
            jSONObject.put("app_id", getAppId());
            jSONObject.put("version", getVersion());
            jSONObject.put("platform", "android");
        } catch (Exception e) {

        }
        Class<?> iWxCallback = XposedHelpers.findClass("com.alibaba.mobileim.channel.event.IWxCallback", mclassLoader);
        Object call = Proxy.newProxyInstance(mclassLoader, new Class[]{iWxCallback}, new WXCreatePacketProxy(amount, remark));
        XposedHelpers.callMethod(o_instance, "reqCascSiteApp", o_WXContext, call, jSONObject.toString(), "hongbao", "hongbao", 10);
    }

    private void openRepackage(String content, final String senderid) {
        try {
            if (TextUtils.isEmpty(content)) return;
            JSONObject jsoncon = new JSONObject(content);
            if (jsoncon != null) {
                String jsontitle = jsoncon.optString("红包");
                if (jsontitle != null) {// 是红包
                    JSONObject jsontemplate = jsoncon.optJSONObject("template");
                    JSONObject jsondata = jsontemplate.optJSONObject("data");
                    JSONObject jsonbody = jsondata.optJSONObject("body");
                    JSONArray jsonac = jsonbody.optJSONArray("ac");
                    String url = jsonac.optString(0);
                    Uri parse = Uri.parse(url);
                    if (parse != null) {
                        String queryParameter = parse.getQueryParameter("ActionExtraParam");
                        if (!TextUtils.isEmpty(queryParameter) && (queryParameter.startsWith("wangwang://hongbao/query") || queryParameter.startsWith("wangx://hongbao/query"))) {
                            Map access$600 = parseQueryString(queryParameter);
                            final String str2 = (String) access$600.get("hongbaoId");
                            final String str3 = (String) access$600.get("note");
                            int parseInt = Integer.parseInt((String) access$600.get("hongbaoType"));
                            String str4 = (String) access$600.get("hongbaoSubType");
                            XposedBridge.log("红包 》》》》 message 》》》 " + access$600.toString());
                            int i = 0;
                            if (!(TextUtils.isEmpty(str4) || "null".equals(str4))) {
                                i = Integer.parseInt(str4);
                                tryGetHongBao(str2, senderid, str3);
                                try {
                                } catch (Exception e) {
                                }
                            }
                        }
                    }

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void tryGetHongBao(final String hongbaoid, String hhupanid, final String remark) {
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.channel.SocketChannel", mclassLoader);
        Object o_instance = XposedHelpers.callStaticMethod(clazz, "getInstance");
        Object o_WXContext = XposedHelpers.callMethod(get_wxAccount(get_wxContext()), "getWXContext");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("method", "tryGetHongbao");
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("sender", hupanIdToTbId(hhupanid));
            jSONObject2.put("hongbao_id", hongbaoid);
            jSONObject.put("params", jSONObject2);
            jSONObject.put("app_id", getAppId());
            jSONObject.put("version", getVersion());
            jSONObject.put("platform", "android");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Class<?> iWxCallback = XposedHelpers.findClass("com.alibaba.mobileim.channel.event.IWxCallback", mclassLoader);
        Object call = Proxy.newProxyInstance(mclassLoader, new Class[]{iWxCallback}, new WXOpenPacketProxy(remark,hongbaoid));
        XposedHelpers.callMethod(o_instance, "reqCascSiteApp", o_WXContext, call, jSONObject.toString(), "hongbao", "hongbao", 10);
        //
    }

    private void queryHongbaoDetails(String hongbaoid, String sender) {
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.channel.SocketChannel", mclassLoader);
        Object o_instance = XposedHelpers.callStaticMethod(clazz, "getInstance");
        Object o_WXContext = XposedHelpers.callMethod(get_wxAccount(get_wxContext()), "getWXContext");
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("method", "queryHongbaoDetails");
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("next_key", "");
            jSONObject2.put("hongbao_id", hongbaoid);
            jSONObject2.put("size", 20);
            jSONObject2.put("sender", hupanIdToTbId(sender));
            jSONObject.put("params", jSONObject2);
            jSONObject.put("app_id", getAppId());
            jSONObject.put("version", getVersion());
            jSONObject.put("platform", "android");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        XposedHelpers.callMethod(o_instance, "reqCascSiteApp", o_WXContext, null, jSONObject.toString(), "hongbao", "hongbao", 10);
    }

    private Map<String, String> parseQueryString(String str) {
        Map<String, String> hashMap = new HashMap();
        if (!TextUtils.isEmpty(str)) {
            int indexOf = str.indexOf(63);
            String nextToken;
            if (indexOf >= 0) {
                StringTokenizer stringTokenizer = new StringTokenizer(str.substring(indexOf + 1), "&");
                while (stringTokenizer.hasMoreTokens()) {
                    nextToken = stringTokenizer.nextToken();
                    if (nextToken.contains("=")) {
                        StringTokenizer stringTokenizer2 = new StringTokenizer(nextToken, "=");
                        try {
                            if (stringTokenizer2.hasMoreTokens()) {
                                hashMap.put(stringTokenizer2.nextToken(), stringTokenizer2.nextToken());
                            }
                        } catch (Throwable e) {
                        }
                    }
                }
            } else {
                nextToken = "";
            }
        }
        return hashMap;
    }

    private static long getGroupId() {
        long id = 0;
        try {
            Object getContactManager = XposedHelpers.callMethod(get_mAccount(), "getTribeManager");
            Object getGroupContacts = XposedHelpers.callMethod(getContactManager, "getTribes");
            String str = JsonHelper.toJson(getGroupContacts);
            JSONArray json = new JSONArray(str);
            for (int i = 0; i < json.length(); i++) {
                JSONObject object = json.getJSONObject(i);
                String masterId = object.getString("masterId");
                if ((get_mAccount()+"").contains(masterId)) {
                    id = object.getLong("tribeId");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            XposedBridge.log("getGroupId异常>> "+e.fillInStackTrace());
        } finally {
            return id;
        }
    }

    public static Object get_mAccount() {
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.gingko.WangXinApi", mclassLoader);
        Object o_instance = XposedHelpers.callStaticMethod(clazz, "getInstance");
        Object o_accout = XposedHelpers.callMethod(o_instance, "getAccount");
        return o_accout;
    }

    public static String get_mid(){
        Object account = get_mAccount();
        String mid = ""+XposedHelpers.getObjectField(account,"mId");
        return mid;
    }

    public static Object get_wxContext() {
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.gingko.WangXinApi", mclassLoader);
        Object o_instance = XposedHelpers.callStaticMethod(clazz, "getInstance");
        Object o_IMKit = XposedHelpers.callMethod(o_instance, "getIMKit");
        Object o_usercontext = XposedHelpers.callMethod(o_IMKit, "getUserContext");
        return o_usercontext;
    }

    public static Object get_wxAccount(Object wxContext) {
        Object o_imcore = XposedHelpers.callMethod(wxContext, "getIMCore");
        Object o_wxaccount = XposedHelpers.callMethod(o_imcore, "getWxAccount");
        return o_wxaccount;
    }

    public static String get_HongbaoID() {
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.lib.presenter.hongbao.HongbaoManager", mclassLoader);
        Object o_instance = XposedHelpers.callStaticMethod(clazz, "getInstance");
        Object hongbaoid = XposedHelpers.callMethod(o_instance, "createHongbaoId", get_wxAccount(get_wxContext()));
        return "" + hongbaoid;
    }

    public static long get_UUID() {
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.channel.util.WXUtil", mclassLoader);
        Object o_uuid = XposedHelpers.callStaticMethod(clazz, "getUUID");
        long uuid = Long.parseLong("" + o_uuid);
        return uuid;
    }


    private static String getAppId() {
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.channel.IMChannel", mclassLoader);
        Object appid = XposedHelpers.callStaticMethod(clazz, "getAppId");
        return "" + appid;
    }

    private static String getVersion() {
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.wxlib.util.ApplicationBuildInfo", mclassLoader);
        Object version = XposedHelpers.callStaticMethod(clazz, "getAppVersionName");
        return "" + version;
    }

    private static String hupanIdToTbId(String string) {
        Class<?> clazz = XposedHelpers.findClass("com.alibaba.mobileim.channel.util.AccountUtils", mclassLoader);
        String result = "" + XposedHelpers.callStaticMethod(clazz, "hupanIdToTbId", string);
        return result;
    }
    static class WXCreatePacketProxy implements InvocationHandler {
        Long amount;
        String mark;

        public WXCreatePacketProxy(Long amount, String mark) {
            this.amount = amount;
            this.mark = mark;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] objects) throws Throwable {
            if (method.getName().contains("onSuccess")) {
                Object[] obs = (Object[]) objects[0];
                JSONObject jSONObject = new JSONObject("" + XposedHelpers.callMethod(obs[0], "getRspData"));
                JSONObject jsonreq = jSONObject.getJSONObject("result");
                JSONObject alipayParam = jsonreq.getJSONObject("alipay_param");
                String url = alipayParam.getString("url");
                url = url.replace("\"", "\\\"");
                Intent v2 = new Intent();
                v2.putExtra("type", AppConst.TYPE_TBH);
                v2.putExtra("mark", this.mark);
                v2.putExtra("money",""+ ((float)this.amount)/100);
                v2.putExtra("payurl", url);
                v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                mcontext.sendBroadcast(v2);
            } else if (method.getName().contains("onError")) {
                XposedBridge.log("onError==>" + objects[0] + "---" + objects[1]);
                String errorStr = (String) objects[1];
                if (errorStr.equals("系统忙，请重试")) {
                    PayHelperUtils.sendmsg(mcontext,"生成红包异常，请稍后。。。。。");
                    android.os.Process.killProcess(android.os.Process.myPid());
                    System.exit(0);
                }
            }
            return null;
        }
    }
    class WXOpenPacketProxy implements InvocationHandler {
        String  mMark;

        String  ID;
        public WXOpenPacketProxy(String mark,String  no)
        {
            ID=no;
            mMark=mark;
        }
        @Override
        public Object invoke(Object proxy, Method method, Object[] objects) throws Throwable {
            if (method.getName().contains("onSuccess")) {
                Object[] obs = (Object[]) objects[0];
//                String json = JsonHelper.toJson(obs[0]);
                JSONObject jSONObject = new JSONObject("" + XposedHelpers.callMethod(obs[0], "getRspData"));
//                JSONObject asJsonObject = new JSONObject(json);
                XposedBridge.log("json >>>>>>>> "+jSONObject);
                JSONObject jsonresult = jSONObject.getJSONObject("result");
                JSONArray arraydetails = jsonresult.getJSONArray("details");
                for(int i = 0;i<arraydetails.length();i++){
                    JSONObject json = arraydetails.getJSONObject(i);
                    String money = json.getString("amount");
                    Long dt = json.getLong("timestamp");

                    Intent v2 = new Intent();
                    v2.putExtra("bill_type", AppConst.TYPE_TBH);
                    v2.putExtra("bill_mark", mMark);
                    v2.putExtra("bill_money", ""+(Float.parseFloat(money)/100));
                    v2.putExtra("bill_no", ID);
                    v2.putExtra("bill_dt",""+dt);
                    v2.setAction(AppConst.BILLRECEIVED_ACTION);
                    mcontext.sendBroadcast(v2);
                }

                //  UploadUtils.httpUploadOrder(mark,url,"wx",0,context);

            } else if (method.getName().contains("onError")) {
                XposedBridge.log("openhongbao  onError==>" + objects[0] + "---" + objects[1]);
            }
            return null;
        }
    }
}
