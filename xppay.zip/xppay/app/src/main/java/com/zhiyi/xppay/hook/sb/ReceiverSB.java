package com.zhiyi.xppay.hook.sb;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/6/28.
 */

public class ReceiverSB extends BroadcastReceiver {
    public static String ACTION_CREATEQR = "com.zhiyi.sb.createqrcode";
    public IntentFilter filter;
    public ReceiverSB(){
        if(filter == null){
            filter = new IntentFilter();
            filter.addAction(ACTION_CREATEQR);
        }
    }
    @Override
    public void onReceive(Context context, final Intent intent) {
        if(intent.getAction().equals(ACTION_CREATEQR)){
            XposedBridge.log("扫呗收到生成QRCODE指令");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    HookSB.CreateQRCode(intent);
                }
            }).start();
        }
    }
}
