package com.zhiyi.xppay.yst.consts;

/**
 * Created by pc_mg on 2019/3/10.
 */

public class Appconsts {
    public final static String TYPE_YST = "YST";
    public final static String PACKAGENAME = "com.ysepay.mobileportal.activity";
    // activity
    public final static String ACTION_MSGRECEIVED = "com.zhiyi.ystmc.msg";
    public final static String ACTION_SENDQRCODE = "com.zhiyi.ystmc.sendqrcode";
    public final static String ACTION_SENDTRADE = "com.zhiyi.ystmc.sendtrade";
    public final static String ACTION_STARTTRADEQUERY = "com.zhiyi.ystmc.starttradequery";
    // main
    public final static String ACTION_CREATEQRCODE = "com.zhiyi.ystmc.createqr";
    public final static String ACTION_ACTIVITYSTART = "com.zhiyi.ystmc.activitystart";
    public final static String ACTION_TRADEQUERY = "com.zhiyi.ystmc.tradequery";
}
