package com.zhiyi.xppay.hook.skb;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.zhiyi.xppay.consts.AppConst;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/3/10.
 */

public class TradeQueryService_SKB extends Service implements Runnable {
    private static boolean isrunning;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(!isrunning){
            isrunning = true;
            new Thread(this).start();
        }
        return START_STICKY;
    }

    @Override
    public void run() {
        XposedBridge.log("收款宝订单查询服务启动");
        while(true){
            try {
                Thread.sleep(20000);
                XposedBridge.log("20秒 轮询一次");
                Intent intent = new Intent();
                intent.setAction(AppConst.ACTION_TRADEQUERY_SKB);
                sendBroadcast(intent);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public void onDestroy() {
        super.onDestroy();
        // 如果Service被杀死 重启自己
        Intent intent = new Intent(getApplicationContext(),TradeQueryService_SKB.class);
        startService(intent);
        isrunning = false;
    }
}
