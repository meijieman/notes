package com.zhiyi.xppay.hook.xiaoxin;

import com.zhiyi.xppay.utils.JsonHelper;

/**
 * Created by pc_mg on 2019/4/23.
 */

public class XXOpendRP {
    private String outOrderNo;
    public XXOpendRP(String _outTradeNo){
        outOrderNo = _outTradeNo;
    }
    public String toJson() {
        String sendStr = JsonHelper.toJson(this);
        return sendStr;
    }
}
