package com.zhiyi.xppay.hook.fshl;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/6/12.
 */

public class HookFSHL {
    private static ClassLoader mclassLoader;
    private static Context mcontext;
    public void hook(ClassLoader classLoader, final Context context) {
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("当前activity 》》》》》》》"+param.thisObject.getClass().getName());
            }
        });
        XposedHelpers.findAndHookMethod("com.yitong.http.AsyncHttpClient", classLoader, "post", String.class, String.class, String.class,
                XposedHelpers.findClass("com.yitong.http.ResponseHandlerInterface", classLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        XposedBridge.log("AsyncHttpClient param.args >>>>> str "+ param.args[0]+"\n>> str2 >>"+param.args[1]+"\n str3 >>"+param.args[2]);
                    }
                }
        );
        XposedHelpers.findAndHookMethod("com.yitong.service.http.d", classLoader, "a", String.class, String.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                super.beforeHookedMethod(param);
                XposedBridge.log("加密前数据 >>>>> str "+ param.args[0]+"\n>> str2 >>"+param.args[1]);
                XposedBridge.log(new Exception("-- 加密抛出异常 --"));
            }

            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
//                XposedBridge.log("加密后数据 >>>>>\n str "+ param.getResult());
            }
        });
    }
}
