package com.zhiyi.xppay.hook.xgj;

/**
 * Created by pc_mg on 2019/3/21.
 */

public class AppConst {
    public final static String TYPE_XGJ = "XPOS";
    // activity
    public final static String ACTION_STARTTRADEQUERY = "com.zhiyi.xgj.starttradequery";
    public final static String ACTION_SENDTRADE = "com.zhiyi.xgj.sendtrade";
    // main
    public final static String ACTION_ACTIVITYSTART = "com.zhiyi.xgj.activitystart";
    public final static String ACTION_TRADEQUERY = "com.zhiyi.xgj.tradequery";
}
