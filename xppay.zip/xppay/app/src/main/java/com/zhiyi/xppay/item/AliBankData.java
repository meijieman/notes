package com.zhiyi.xppay.item;

/**
 * Created by pc_mg on 2019/1/18.
 */

public class AliBankData {
    public String billno;
    public String money;
    public String cardno;
    public int time;
}
