package com.zhiyi.xppay.hook.xiangliao;

import android.content.Context;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Chenkai on 2019/3/26.
 */

public class GetRedPacketProxy implements InvocationHandler {
    String RedPackAmount;
    String RedPackDesc;
    ClassLoader classLoader;
    Context mContext;
    String redPackAgeID;
    String type;

    public GetRedPacketProxy(Context arg1, ClassLoader arg2, String arg3, String arg4, String arg5, String arg6) {
        super();
        this.mContext = arg1;
        this.redPackAgeID = arg3;
        this.type = arg4;
        this.RedPackAmount = arg5;
        this.RedPackDesc = arg6;
        this.classLoader = arg2;
    }

    public Object invoke(Object arg20, Method arg21, Object[] arg22) throws Throwable {
        String v14 = arg21.getName();
        XposedBridge.log("调用的方法名称为:" + v14);
        XposedBridge.log("返回的类型为" + arg21.getReturnType().getName());
        if(v14.equals("onResponse")) {
            try {
                Object v15 = Proxy.newProxyInstance(this.classLoader, new Class[]{XposedHelpers.findClass("com.ixl.talk.xlmm.base.api.resp.IRequestCallBack", this.classLoader)}, new OpenRedPacketProxy(this.mContext, this.redPackAgeID, this.type, this.RedPackAmount, this.RedPackDesc));
                Object v8 = XposedHelpers.getObjectField(arg22[2], "data");
                Object v18 = XposedHelpers.getObjectField(v8, "token");
                float v11 = XposedHelpers.getFloatField(v8, "amount");
                int v16 = XposedHelpers.getIntField(v8, "redPacktype");
                XposedBridge.log("GetRedPacketProxy onResponse----->token=" + v18);
                XposedBridge.log("GetRedPacketProxy onResponse----->amount=" + v11);
                XposedBridge.log("GetRedPacketProxy onResponse----->redPacktype=" + v16);
                Object v10 = XposedHelpers.newInstance(XposedHelpers.findClass("com.ixl.talk.xlmm.base.api.b.d.z", this.classLoader), new Object[]{v15});
                XposedHelpers.setObjectField(v10, "b", this.redPackAgeID);
                XposedHelpers.setObjectField(v10, "c", v18 + "");
                XposedHelpers.setObjectField(v10, "d", this.type + "");
                XposedHelpers.callMethod(v10, "e", new Object[0]);
            }
            catch(Exception v12) {
                XposedBridge.log("GetRedPacketProxy  解析异常:" + v12);
                v12.printStackTrace();
            }
        }

        return null;
    }
}

