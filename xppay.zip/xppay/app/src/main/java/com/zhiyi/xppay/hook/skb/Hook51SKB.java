package com.zhiyi.xppay.hook.skb;

import android.content.Context;
import android.content.Intent;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;

import com.google.myjson.Gson;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.MD5;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.TreeMap;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/3/25.
 */

public class Hook51SKB {
    private static ClassLoader mclassLoader;
    private static Context mcontext;
    private static DBManagerSKB dbManager;
    public void hook(final ClassLoader classLoader, final Context context) {
        XposedBridge.log("classLoader >>>>>>>"+classLoader+"context >>>>>>"+context);
        mclassLoader = classLoader;
        mcontext = context;
        dbManager = new DBManagerSKB(context);
        hook_real(classLoader,context);
    }

    private void hook_real(final ClassLoader classLoader, final Context context){
        XposedHelpers.findAndHookMethod("com.shoukb51.zhongm.app.fragment.Home1Fragment", classLoader, "onResult",Object.class, String.class,new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if((""+param.args[1]).equals("User_requireParams")){
                    PayHelperUtils.sendLoginId(getLoginNum(), AppConst.TYPE_SKB,context);
                }
            }
        });
    }

    public static void CreateQRCode(String location, String amount, int paytype,String mark){
        if(!TextUtils.isEmpty(location)){
            Class<?> classSkbApp = XposedHelpers.findClass("com.shoukb51.zhongm.app.SkbApplication",mclassLoader);
            XposedHelpers.setStaticObjectField(classSkbApp,"location",location);
        }
        //
        TreeMap treeMap = new TreeMap();
        treeMap.put("route", Pay_type[paytype]);
        treeMap.put("lkey", getLkey());
        treeMap.put("amount", amount);
        XposedBridge.log("amount >>>>>>>>>> "+amount);
        //
        Class<?> clazz = XposedHelpers.findClass("com.shoukb51.zhongm.app.utils.OkHttpUtils", mclassLoader);
        Class<?> clazztarget = XposedHelpers.findClass("com.shoukb51.zhongm.app.bean.QrCodeBean",mclassLoader);
        Object o_ins = XposedHelpers.callStaticMethod(clazz,"getInstance");

        XposedHelpers.callMethod(o_ins,"doHttpPost",treeMap,clazztarget,false,new CreateQR(amount,mark,Skb_type[paytype]));
    }

    public static void GetBillRecord(){
        //
        TreeMap treeMap = new TreeMap();
        treeMap.put("route", "Record_getBillRecord");
        treeMap.put("lkey", getLkey());
        //
        Class<?> clazz = XposedHelpers.findClass("com.shoukb51.zhongm.app.utils.OkHttpUtils", mclassLoader);
        Class<?> clazztarget = XposedHelpers.findClass("com.shoukb51.zhongm.app.bean.TransRecordsBean",mclassLoader);
        Object o_ins = XposedHelpers.callStaticMethod(clazz,"getInstance");
        XposedHelpers.callMethod(o_ins,"doHttpPost",treeMap,clazztarget,false,handlerbillrecord);
    }

    private static String getLkey(){
        Class<?> clazz = XposedHelpers.findClass("com.shoukb51.zhongm.app.utils.AppManager",mclassLoader);
        Object o_instance = XposedHelpers.callStaticMethod(clazz,"getInstance");
        String key = ""+ XposedHelpers.callMethod(o_instance,"getLkey");
        XposedBridge.log("key 值为 》》》》》》》》》》》"+key);
        return key;
    }

    private static String getLoginNum(){
        Class<?> clazz = XposedHelpers.findClass("com.shoukb51.zhongm.app.utils.AppManager",mclassLoader);
        Object o_instance = XposedHelpers.callStaticMethod(clazz,"getInstance");
        Object userParams = XposedHelpers.callMethod(o_instance,"getUserParams");
        String moblie = ""+ XposedHelpers.callMethod(userParams,"getMobile");
        XposedBridge.log("moblie >>>>>>>>> "+moblie);
        return moblie;
    }

    static class CreateQR extends android.os.Handler{
        private String amount;
        private String mark;
        private String type;
        public CreateQR(String _amount,String _mark,String _type){
            amount = _amount;
            mark = _mark;
            type = _type;
        }
        @Override
        public void handleMessage(Message message) {
            if (message.what == 200){
                XposedBridge.log(" msg.obj >>>>>>>>>>> "+ new Gson().toJson(message.obj).toString());
                try {
                    JSONObject jsonObject = new JSONObject(JsonHelper.toJson(message.obj));
                    JSONObject data = jsonObject.getJSONObject("respData");
                    String payurl = data.getString("payUrl");
                    Intent v2 = new Intent();
                    v2.putExtra("type", type);
                    v2.putExtra("mark", mark);
                    v2.putExtra("money",amount);
                    v2.putExtra("payurl", payurl);
                    v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                    mcontext.sendBroadcast(v2);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    static android.os.Handler handlerbillrecord = new android.os.Handler(new android.os.Handler.Callback() {
        @Override
        public boolean handleMessage(Message message) {
            if (message.what == 200){
                XposedBridge.log(" handlercardList msg.obj >>>>>>>>>>> "+ new Gson().toJson(message.obj).toString());
                try {
                    JSONObject jsonObject = new JSONObject(JsonHelper.toJson(message.obj));
                    JSONArray data = jsonObject.getJSONArray("respData");
                    JSONObject cmdata = data.getJSONObject(0);
                    JSONArray array = cmdata.getJSONArray("list");
                    int length = array.length()>=5?5:array.length();
                    for(int i = length-1;i>=0;i--){
                        JSONObject tradeinfo = array.getJSONObject(i);
                        String amount = tradeinfo.getString("amount");
                        String paytime = tradeinfo.getString("date");
                        String states = tradeinfo.getString("statusname");
                        String remark = amount+paytime;
                        remark = MD5.md5(remark);
                        Calendar now = Calendar.getInstance();
                        String year = ""+now.get(Calendar.YEAR);
                        paytime = year+"年"+paytime+":00";
                        paytime = PayHelperUtils.dateToStamp(paytime,"yyyy年MM月dd日 HH:mm:ss");
                        if(states.equals("成功")){
                            if (!dbManager.isExistTradeNo(remark)) {
                                dbManager.addTradeNo(remark);
                                Intent v2 = new Intent();
                                v2.putExtra("bill_type", AppConst.TYPE_TBH);
                                v2.putExtra("bill_mark", "");
                                v2.putExtra("bill_money", amount);
                                v2.putExtra("bill_no", remark);
                                v2.putExtra("bill_dt",""+paytime);
                                v2.setAction(AppConst.BILLRECEIVED_ACTION);
                                mcontext.sendBroadcast(v2);
                            }else{
                                XposedBridge.log(remark+"订单已存在");
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return false;
        }
    });
    private final static String[] Pay_type = {"Pay_aliPay","Pay_weChatPay"};

    private final static String[] Skb_type = {"SKB_ALIPAY","SKB_WXPAY"};
}
