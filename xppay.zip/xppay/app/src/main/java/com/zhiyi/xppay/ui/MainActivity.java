package com.zhiyi.xppay.ui;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.zhiyi.xppay.R;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.consts.AppConstsNxys;
import com.zhiyi.xppay.hook.AlarmReceiver;
import com.zhiyi.xppay.hook.AlipayHook38;
import com.zhiyi.xppay.hook.CustomApplcation;
import com.zhiyi.xppay.hook.DaemonService;
import com.zhiyi.xppay.hook.MBankService;
import com.zhiyi.xppay.hook.ReqService;
import com.zhiyi.xppay.hook.RestartAlipayService;
import com.zhiyi.xppay.hook.RestartCPayService;
import com.zhiyi.xppay.hook.RestartLXLService;
import com.zhiyi.xppay.hook.TradeQueryService;
import com.zhiyi.xppay.hook.mayou.ToolsMY;
import com.zhiyi.xppay.hook.mayou.TradeBean;
import com.zhiyi.xppay.hook.skb.ToolsSKB;
import com.zhiyi.xppay.hook.skb.TradeQueryService_SKB;
import com.zhiyi.xppay.hook.v138.Tools;
import com.zhiyi.xppay.hook.xgj.ServiceXGJTrade;
import com.zhiyi.xppay.hook.xgj.ToolsXGJ;
import com.zhiyi.xppay.item.ReqData;
import com.zhiyi.xppay.net.Socket.ClientManager;
//这个文件是版本忽略的.请.自己创建
//复制目录下的ConnectInfo2 重新命名下
import com.zhiyi.xppay.net.Socket.ConnectInfo;
import com.zhiyi.xppay.service.MainService;
import com.zhiyi.xppay.sms.SMSItem;
import com.zhiyi.xppay.sms.SmsService;
import com.zhiyi.xppay.utils.AbSharedUtil;
import com.zhiyi.xppay.utils.AlipayInfo;
import com.zhiyi.xppay.utils.DBManager;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.MD5;
import com.zhiyi.xppay.utils.OrderBean;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.QrCodeBean;
import com.zhiyi.xppay.net.Socket.RecevieMsg.LoginReceive;
import com.zhiyi.xppay.utils.StringUtils;
import com.zhiyi.xppay.utils.ToolsNxys;
import com.zhiyi.xppay.yst.consts.Appconsts;
import com.zhiyi.xppay.yst.utils.ToolsYST;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ScrollView;
import android.widget.TextView;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class MainActivity extends Activity {

    public static TextView console;
    private static ScrollView scrollView;
    private BillReceived billReceived;
    private AlarmReceiver alarmReceiver;
    private ScreenBroadcastReceiver screenReceiver;

    private String currentWechat = "";
    private String currentAlipay = "";
    private String currentQQ = "";
    private String currentCPay = "";
    private String currentLKL = "";
    private String currentNXYS = "";
    private String currentNXYS_WX = "";
    private String currentYST = "";
    private String currentXGJ = "";
    private String currentTBH = "";
    private String currentSKB = "";
    private String currentXXQG = "";
    private String currentMAYOU = "";
    private String currentXX = "";
    private String currentNXFJSH = "";
    private String currentJYES = "";
    private String currentHYBSYT = "";
    private String currentYZF = "";
    private String currentFL = "";
    private String currentWL = "";
    private String currentWZP = "";
    private String currentQN = "";
    private String currentSB = "";
    public static final String TYPE_ALIPAY = AppConst.TYPE_ALIPAY;
    public static final String TYPE_WX = AppConst.TYPE_WXPAY;
    public static final String TYPE_QQ = AppConst.TYPE_QQPAY;

    private String url = "https://xpapi.ukafu.com/appv2/start/index.html#";

    private WebView webView;

    private TextView textView;

    private static MainActivity slef;

    public boolean isWebViewLoad = false;
    // Req服务
    private ReqService reqService;

    private MainReceiver mainReceiver;
    private MainReceiverYST mainReceiverYST;
    private MainReceiverXGJ mainReceiverXGJ;
    private MainReceiverSKB mainReceiverSKB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        slef = this;
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (ConnectInfo.showLog) {
            setContentView(R.layout.activity_main_debug);
            console = (TextView) findViewById(R.id.console);
            scrollView = (ScrollView) findViewById(R.id.scrollview);
        } else {
            setContentView(R.layout.activity_main);
            initView();
        }

        try {
            AppConst.version = this.getPackageManager().getPackageInfo(this.getPackageName(),0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("ZYKJ","get app version",e);
        }
        //
        reqService = new ReqService();
        reqService.setMainContext(this);
//		startService(new Intent(this,ReqService.class));
        ClientManager.getInstance().start(MainActivity.this);
        ClientManager.getInstance().login("auto","APP");
        //
        //注册广播
        billReceived = new BillReceived();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AppConst.BILLRECEIVED_ACTION);
        intentFilter.addAction(AppConst.MSGRECEIVED_ACTION);
        intentFilter.addAction(AppConst.QRCODERECEIVED_ACTION);
        intentFilter.addAction(AppConst.TRADENORECEIVED_ACTION);
        intentFilter.addAction(AppConst.LOGINIDRECEIVED_ACTION);
        intentFilter.addAction(AppConst.NOT_LOGIN_ACTION);
        intentFilter.addAction(AppConst.PERSONALQRCODE);
        // 云闪付
        intentFilter.addAction(AppConst.CP_GETPAYERLIST);
        intentFilter.addAction(AppConst.CP_START);
        // 拉卡拉
        intentFilter.addAction(AppConst.LKL_START);
        // 网商银行
        intentFilter.addAction(AppConst.MBANK_SERVICE);
        //支付宝
        intentFilter.addAction(AppConst.HOOK_FRIEND_CHECK_ACTION);
        intentFilter.addAction(AppConst.HOOK_FRIEND_ORDER_ACTION);
        //
        registerReceiver(billReceived, intentFilter);

        alarmReceiver = new AlarmReceiver();
        IntentFilter alarmIntentFilter = new IntentFilter();
        alarmIntentFilter.addAction(AppConst.NOTIFY_ACTION);
        registerReceiver(alarmReceiver, alarmIntentFilter);
        startService(new Intent(this, DaemonService.class));
        String[] proms = new String[]{Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS};
        if(!checkPermission(this,proms)){
            ActivityCompat.requestPermissions(MainActivity.this, proms,2);
        }else{
            startService(new Intent(this, SmsService.class));
        }

        ComponentName name = startService(new Intent(MainActivity.this,MainService.class));
        Log.w("ZYKJ",name.toString());

        // 注册屏幕状态Receiver
        screenReceiver = new ScreenBroadcastReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        registerReceiver(screenReceiver, filter);

        registerReceiverNxys();
        registerReceiverYST();
        registerReceiverXGJ();
        registerReceiverSKB();
        ToolsNxys.sendActivitystart(slef);
//        ToolsYST.sendActivitystart(slef);
        //
//        ToolsMY.queryBean(slef);
        //
        //handler.sendMessageDelayed(Message.obtain(handler, 5000), 500);

    }

    private void registerReceiverNxys(){
        mainReceiver = new MainReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AppConstsNxys.ACTION_MSGRECEIVED);
        intentFilter.addAction(AppConstsNxys.ACTION_SENDTRADE);
        intentFilter.addAction(AppConstsNxys.ACTION_STARTTRADEQUERY);
        intentFilter.addAction(AppConstsNxys.ACTION_LOGINED);
        slef.registerReceiver(mainReceiver,intentFilter);
    }


    private void registerReceiverYST(){
        mainReceiverYST = new MainReceiverYST();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Appconsts.ACTION_MSGRECEIVED);
        intentFilter.addAction(Appconsts.ACTION_SENDQRCODE);
        intentFilter.addAction(Appconsts.ACTION_SENDTRADE);
        intentFilter.addAction(Appconsts.ACTION_STARTTRADEQUERY);
        slef.registerReceiver(mainReceiverYST,intentFilter);
    }

    private void registerReceiverXGJ(){
        mainReceiverXGJ = new MainReceiverXGJ();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(com.zhiyi.xppay.hook.xgj.AppConst.ACTION_STARTTRADEQUERY);
        intentFilter.addAction(com.zhiyi.xppay.hook.xgj.AppConst.ACTION_SENDTRADE);
        slef.registerReceiver(mainReceiverXGJ,intentFilter);
    }

    private void registerReceiverSKB(){
        mainReceiverSKB = new MainReceiverSKB();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AppConst.ACTION_STARTTRADEQUERY_SKB);
        slef.registerReceiver(mainReceiverSKB,intentFilter);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus){
        if (hasFocus){
            String ip = AbSharedUtil.getString( MainActivity.slef.getApplicationContext(),"connect_ip");
            if(ip==null||ip.isEmpty()){
//                AbSharedUtil.putString(this,"connect_ip","119.23.108.252");
                SettingConnectActivity.showNetSettingDialog(this).show();
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
//        unregisterReceiver(billReceived);
//        unregisterReceiver(alarmReceiver);
//        unregisterReceiver(screenReceiver);
    }

    private boolean isServiceRunning(Context mContext, String className) {
        boolean isRunning = false;
        ActivityManager activityManager = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);

        List<ActivityManager.RunningServiceInfo> serviceList = activityManager.getRunningServices(100);
        if (serviceList.size() == 0) {
            return false;
        }
        for (int i = 0; i < serviceList.size(); i++) {
                if (serviceList.get(i).service.getClassName().equals(className) == true) {
                isRunning = true;
                break;
            }
        }
        return isRunning;
    }

    private void initView() {
        webView = findViewById(R.id.pay_web);
        if (webView == null) {
            return;
        }
        //支持javascript
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);

        // 设置可以支持缩放
        webView.getSettings().setSupportZoom(true);
        // 设置出现缩放工具
        webView.getSettings().setBuiltInZoomControls(true);
        //扩大比例的缩放
        webView.getSettings().setUseWideViewPort(true);
        //自适应屏幕
        webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webView.getSettings().setLoadWithOverviewMode(true);

        //如果不设置WebViewClient，请求会跳转系统浏览器
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                //该方法在Build.VERSION_CODES.LOLLIPOP以前有效，从Build.VERSION_CODES.LOLLIPOP起，建议使用shouldOverrideUrlLoading(WebView, WebResourceRequest)} instead
                //返回false，意味着请求过程里，不管有多少次的跳转请求（即新的请求地址），均交给webView自己处理，这也是此方法的默认处理
                //返回true，说明你自己想根据url，做新的跳转，比如在判断url符合条件的情况下，我想让webView加载http://ask.csdn.net/questions/178242
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                //返回false，意味着请求过程里，不管有多少次的跳转请求（即新的请求地址），均交给webView自己处理，这也是此方法的默认处理
                //返回true，说明你自己想根据url，做新的跳转，比如在判断url符合条件的情况下，我想让webView加载http://ask.csdn.net/questions/178242
                return false;
            }
        });

        textView = findViewById(R.id.help_text);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        String packageName = "com.eg.android.AlipayGphone";
        switch (item.getItemId()) {
            case R.id.setting_alipay:
                packageName = "com.eg.android.AlipayGphone";
                boolean isserrunningali = isServiceRunning(this, "com.zhiyi.xppay.hook.RestartAlipayService");
                if(isserrunningali){
                    startService(new Intent(this, RestartAlipayService.class));
                    //
                }
                break;
            case R.id.setting_qq:
                packageName = "com.tencent.mobileqq";
                break;
            case R.id.setting_wechat:
                packageName = "com.tencent.mm";
                break;
            case R.id.setting_nxyspay:
                boolean isnxysruning = PayHelperUtils.isAppRunning(slef,"com.buybal.buybalpay.nxy");
                if(isnxysruning){
                    PayHelperUtils.startAppNXYS(MainActivity.slef);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(5000);
                                PayHelperUtils.forceOpenSelf(MainActivity.slef);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }).start();
                }else{
                    sendmsg("请先打开农信易扫，登录");
                }
                return false;
            case R.id.setting_cloudpay:
                Intent intent1 = new Intent();
                intent1.setAction(AppConst.CP_START);
                this.sendBroadcast(intent1);
                PayHelperUtils.sendLogin(MainActivity.slef);
                boolean isserrunningcp = isServiceRunning(this, "com.zhiyi.xppay.hook.RestartCPayService");
                if(!isserrunningcp){
                    startService(new Intent(this, RestartCPayService.class));
                }
                return false;
            case R.id.setting_lklpaypay:
                PayHelperUtils.startAppLKL(this);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(5000);
                            PayHelperUtils.forceOpenSelf(MainActivity.slef);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                boolean isserlrunninglxl = isServiceRunning(this,"com.zhiyi.xppay.hook.RestartLXLService");
                if(!isserlrunninglxl){
                    startService(new Intent(this, RestartLXLService.class));
                }
                return false;
            case R.id.setting_dingding:
                PayHelperUtils.startAPP(this,AppConst.APP_DINGDING);
                return false;
            case R.id.setting_bind:
                ClientManager.getInstance().bindCode();
                return false;
            case R.id.setting_connectinfo:
                SettingConnectActivity.showNetSettingDialog(this).show();
                return false;
//            case R.id.setting_withdrawall:
//                Intent intent = new Intent(MainActivity.this, SettingAlipayInfoActivity.class);
//                startActivity(intent);
//
//                return false;
        }
        sendmsg("open : " + packageName);
        PayHelperUtils.startAPP(this, packageName);

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                PayHelperUtils.startAPP();
            }
        }).start();
        return super.onOptionsItemSelected(item);
    }

    public static Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            String txt = msg.getData().getString("log");
            if (msg.what == 1) {
                if (console != null) {
                    if (console.getText() != null) {
                        if (console.getText().toString().length() > 5000) {
                            console.setText("日志定时清理完成..." + "\n\n" + txt);
                        } else {
                            console.setText(console.getText().toString() + "\n\n" + txt);
                        }
                    } else {
                        console.setText(txt);
                    }
                    scrollView.post(new Runnable() {
                        public void run() {
                            scrollView.fullScroll(View.FOCUS_DOWN);
                        }
                    });
                }
            } else if (msg.what == 2) {
                if (MainActivity.slef.webView != null && !MainActivity.slef.isWebViewLoad) {
                    if (MainActivity.slef.textView != null) {
                        MainActivity.slef.textView.setVisibility(View.GONE);
                    }
                    LoginReceive login = (LoginReceive) msg.obj;
                    if (login.weburl != null && login.weburl.length() > 1) {
                        MainActivity.slef.url = login.weburl;
                    }
                    String loadUrl = MainActivity.slef.url + "/token=" + login.token + "/appid=" + login.appid;
                    MainActivity.slef.webView.loadUrl(loadUrl);
                    MainActivity.slef.isWebViewLoad = true;
                }
            } else if (msg.what == 105) {
                MainActivity.slef.ShowBindCode(msg.arg1);
            }else if(msg.what == 123){
            }
            super.handleMessage(msg);
        }

    };

    public void ShowBindCode(int code) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("绑定码").setMessage("您得绑定码为: " + code + " ,请通过商户后台添加绑定,在绑定成功之前.请勿关闭").setIcon(R.drawable.icon)
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        ClientManager.getInstance().closeBindCode();
                    }
                }).show();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(alarmReceiver);
        unregisterReceiver(billReceived);
        unregisterReceiver(mainReceiver);
        unregisterReceiver(mainReceiverYST);
        unregisterReceiver(mainReceiverXGJ);
        unregisterReceiver(mainReceiverSKB);
        // 停止服务
        stopService(new Intent(this, DaemonService.class));
        stopService(new Intent(this, ReqService.class));
        stopService(new Intent(this, RestartAlipayService.class));
        stopService(new Intent(this,TradeQueryService.class));
        stopService(new Intent(this, com.zhiyi.xppay.yst.hook.TradeQueryService.class));
        stopService(new Intent(this,TradeQueryService_SKB.class));
        //
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        ToolsNxys.sendActivitystart(slef);
        ToolsYST.sendActivitystart(slef);
        ToolsXGJ.sendActivitystart(slef);
        ToolsSKB.sendActivitystart(slef);
    }

    public static void sendmsg(String txt) {
        Message msg = new Message();
        msg.what = 1;
        Bundle data = new Bundle();
        long l = System.currentTimeMillis();
        Date date = new Date(l);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String d = dateFormat.format(date);
        data.putString("log", d + ":" + "  结果:" + txt);
        msg.setData(data);
        try {
            handler.sendMessage(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class ScreenBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Intent.ACTION_SCREEN_ON.equals(action)) {
            } else if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                // 锁屏
                AppConst.LOCKSCREEN = true;
//				releaseWakeLock();
            } else if (Intent.ACTION_USER_PRESENT.equals(action)) {
                // 解锁
                AppConst.LOCKSCREEN = false;
            }
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // 过滤按键动作
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true);
        }
        return super.onKeyDown(keyCode, event);
    }

    //自定义接受订单通知广播
    class BillReceived extends BroadcastReceiver {
        @Override
        public void onReceive(final Context context, Intent intent) {
            try {
                String action = intent.getAction();
                if (intent.getAction().contentEquals(AppConst.BILLRECEIVED_ACTION)) {
                    String no = intent.getStringExtra("bill_no");
                    String money = intent.getStringExtra("bill_money");
                    String mark = intent.getStringExtra("bill_mark");
                    String type = intent.getStringExtra("bill_type");
                    //
                    boolean ispersonal = intent.getBooleanExtra("ispersonal", true);
                    DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                    //
                    if (type.equals(TYPE_ALIPAY)) {
                        AlipayInfo alipayInfo = new AlipayInfo();
                        alipayInfo.alipaypwd = dbManager.getAlipwd();
                        alipayInfo.withdrawcount = dbManager.getAliwithcount();
                        alipayInfo.bankaccount = dbManager.getBankaccount();
                        alipayInfo.bankcardno = dbManager.getBankcardno();
                        alipayInfo.alipayaccount = dbManager.getAlipayaccount();
                        alipayInfo.withdrawtype = dbManager.getWithdrawtype();
                        //
                        if (alipayInfo.withdrawtype >= 0) {
                            PayHelperUtils.startAppToBanlance(context, alipayInfo);
                        } else {
                            Log.i("yyk","未设置自动提现信息");
                        }
                        //
                    }
                    if (ispersonal) {
//					 	 String dt=System.currentTimeMillis()+"";
//					 	 dbManager.addOrder(new OrderBean(money, mark, type, no, dt, "", 0));
                        //
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        Date date = new Date(System.currentTimeMillis());
                        String intent_dt = intent.getStringExtra("bill_dt");
                        if(intent_dt!=null){
                            if(intent_dt.length()<13){
                                intent_dt += "000";
                            }
                            date = new Date(Long.parseLong(intent_dt));
                        }
                        String dt = simpleDateFormat.format(date);
                        XposedBridge.log("---- BillReceived check start-----");
                        if (dbManager.isExistTradeNo(no)&&!no.equals("")) {
                            //
                            return;
                        }
                        String typestr = "";
                        String payer = intent.getStringExtra("bill_payer");
                        if (type.equals(TYPE_ALIPAY)) {
                            typestr = "支付宝";
                        } else if (type.equals(TYPE_WX)) {
                            typestr = "微信";
                        } else if (type.equals(TYPE_QQ)) {
                            typestr = "QQ";
                        } else if (type.equals(AppConst.TYPE_CPPAY)) {
                            typestr = "云闪付";
//                            dt = intent.getStringExtra("bill_dt");
                        }else if(type.equals(AppConst.TYPE_BANK)){
                            typestr = "短信";
                        }else if(type.equals(AppConst.TYPE_DingDing)){
                            typestr = "钉钉";
                        }else if(type.equals(AppConstsNxys.TYPE_NXYS)){
                            typestr = "农信易扫";
                        }
                        String wh = "";
                        if(intent.hasExtra("bill_wh") && intent.getStringExtra("bill_wh")!=null){
                            wh = intent.getStringExtra("bill_wh");
                        }
                        dbManager.addOrder(new OrderBean(money, mark+"/"+wh, type, no, dt, "2", 0));
                        XposedBridge.log("收到" + typestr + "订单,订单号：" + no + (payer != null ? "支付人：" + payer : "") + "金额：" + money + "备注：" + mark+"支付时间"+dt);
                        sendmsg("收到" + typestr + "订单,订单号：" + no + (payer != null ? "支付人：" + payer : "") + "金额：" + money + "备注：" + mark);
                        notifyapi(type, no, money, mark, dt,wh);
                    }

                } else if (intent.getAction().contentEquals(AppConst.QRCODERECEIVED_ACTION)) {
                    String money = intent.getStringExtra("money");
                    String mark = intent.getStringExtra("mark");
                    String type = intent.getStringExtra("type");
                    String payurl = intent.getStringExtra("payurl");
                    String orderid = intent.hasExtra("orderid")?intent.getStringExtra("orderid"):"";
                    // 云闪付
                    String img_url = TextUtils.isEmpty(intent.getStringExtra("img_url"))?"":intent.getStringExtra("img_url");
                    DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                    String dt = System.currentTimeMillis() + "";
                    DecimalFormat df = new DecimalFormat("0.00");
                    money = df.format(Double.parseDouble(money));
                    dbManager.addQrCode(type.equals(AppConst.TYPE_CPPAY) ? new QrCodeBean(money, mark, type, payurl, dt, img_url) : new QrCodeBean(money, mark, type, payurl, dt));

                    XposedBridge.log("生成成功,金额:" + money + "备注:" + mark + "二维码:" + payurl + "支付平台：" + type);
                    ClientManager.getInstance().OnGetQrcodeOver(payurl, mark, money, type, img_url,orderid);
                    sendmsg("生成成功,金额:" + money + "备注:" + mark + "二维码:" + ((type.equals(AppConst.TYPE_TBH)||type.equals(AppConst.TYPE_XXQG)||type.equals(AppConst.TYPE_MY))?"":payurl));
                } else if (intent.getAction().contentEquals(AppConst.MSGRECEIVED_ACTION)) {
                    String msg = intent.getStringExtra("msg");
                    sendmsg(msg);
                } else if (intent.getAction().contentEquals(AppConst.LOGINIDRECEIVED_ACTION)) {
                    String loginid = intent.getStringExtra("loginid");
                    String type = intent.getStringExtra("type");
                    if (!TextUtils.isEmpty(loginid)) {
                        if (type.equals(TYPE_WX) && !loginid.equals(currentWechat)) {
                            sendmsg("当前登录微信账号：" + loginid);
                            currentWechat = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        } else if (type.equals(TYPE_ALIPAY) && !loginid.equals(currentAlipay)) {
                            sendmsg("当前登录支付宝账号：" + loginid);
                            currentAlipay = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                            //发送登录消息
                        } else if (type.equals(TYPE_QQ) && !loginid.equals(currentQQ)) {
                            sendmsg("当前登QQ账号：" + loginid);
                            currentQQ = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        } else if (type.equals(AppConst.TYPE_CPPAY) && !loginid.equals(currentCPay)) {
                            sendmsg("当前登录云闪付账号：" + loginid);
                            currentCPay = loginid;
//                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        }else if(type.equals(AppConst.TYPE_LKLPAY)&&!loginid.equals(currentLKL)){
                            sendmsg("当前登录拉卡拉账号：" + loginid);
                            currentLKL = loginid;
                        }else if((type.equals(AppConstsNxys.TYPE_NXYS)&&!loginid.equals(currentNXYS))){
                            sendmsg("当前登录农信易扫账号："+loginid);
                            currentNXYS = loginid;
                        }else if(type.equals(Appconsts.TYPE_YST)&&!loginid.equals(currentYST)){
                            sendmsg("当前登录银盛通账号："+loginid);
                            currentYST = loginid;
                        }else if(type.equals(com.zhiyi.xppay.hook.xgj.AppConst.TYPE_XGJ)&&!loginid.equals(currentXGJ)){
                            sendmsg("当前登录星管家账号："+loginid);
                            currentXGJ = loginid;
                        }else if(type.equals(AppConst.TYPE_DIANDIANCHONG)){
                            sendmsg("当前登录点点虫账号："+loginid);
                            DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                            ClientManager.getInstance().login(dbManager.getAppid(), type);
                        }else if(type.equals(AppConst.TYPE_XiangLiao)){
                            sendmsg("当前登录乡聊账号："+loginid);
                            ClientManager.getInstance().login(loginid, type);
                        }else if(type.equals(AppConst.TYPE_TBH)&&!loginid.equals(currentTBH)){
                            sendmsg("当前旺信账号："+loginid);
                            currentTBH = loginid;
//                            ClientManager.getInstance().login(loginid, type);
                        }else if(type.equals(AppConst.TYPE_SKB)&&!loginid.equals(currentSKB)) {
                            sendmsg("当前收款宝账号：" + loginid);
                            currentSKB = loginid;
                        }else if(type.equals(AppConst.TYPE_XXQG)&&!loginid.equals(currentXXQG)){
                            sendmsg("当前学习强国账号：" + loginid);
                            currentXXQG = loginid;
                        }else if (type.equals(AppConst.TYPE_MY)&&!loginid.equals(currentMAYOU)){
                            sendmsg("当前默往账号："+loginid);
                            currentMAYOU = loginid;
                        }else if(type.equals(AppConst.TYPE_XX)&&!loginid.equals(currentXX)){
                            sendmsg("当前小信账号："+loginid);
                            currentXX = loginid;
                        }else if(type.equals(AppConst.TYPE_NXFJSH)&&!loginid.equals(currentNXFJSH)){
                            sendmsg("当前福建农信商户账号："+loginid);
                            currentNXFJSH = loginid;
                        }else if(type.equals(AppConst.TYPE_JYES)&&!loginid.equals(currentJYES)){
                            sendmsg("当前河南农信金燕E商账号："+loginid);
                            currentJYES = loginid;
                        }else if(type.equals(AppConst.TYPE_HYBSYT)&&!loginid.equals(currentHYBSYT)){
                            sendmsg("当前会员宝收银台账号："+loginid);
                            currentHYBSYT = loginid;
                        }else if(type.equals(AppConst.TYPE_YZF)&&!loginid.equals(currentYZF)){
                            sendmsg("当前益支付商戶号："+loginid);
                            currentYZF = loginid;
                        }else if(type.equals(AppConst.TYPE_FL)&&!loginid.equals(currentFL)){
                            sendmsg("当前飞聊账号："+loginid);
                            currentFL = loginid;
                        }else if(type.equals(AppConst.TYPE_WL)&&!loginid.equals(currentWL)){
                            sendmsg("当前微聊账号："+loginid);
                            currentWL = loginid;
                        }else if(type.equals(AppConst.TYPE_WZP)&&!loginid.equals(currentWZP)){
                            sendmsg("当前微掌铺账号："+loginid);
                            currentWZP = loginid;
                        }else if (type.equals(AppConst.TYPE_QN)&&!loginid.equals(currentQN)){
                            sendmsg("当前黔农商户宝账号："+loginid);
                            currentQN = loginid;
                        }else if(type.equals(AppConst.TYPE_SB)&&!loginid.equals(currentSB)){
                            sendmsg("当前扫呗账号："+loginid);
                            currentSB = loginid;
                        }
                        else{
                            return;
                        }

                        ClientManager.getInstance().login(loginid, type);
                    }
                } else if (intent.getAction().contentEquals(AppConst.TRADENORECEIVED_ACTION)) {
                    //商家服务
                    final String tradeno = intent.getStringExtra("tradeno");
                    final DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                    //
                    if (dbManager.isExistTradeNo(tradeno)) {
                        XposedBridge.log("本地数据库已经包含 "+tradeno);
                        return;
                    }
                    //
                    String cookie = intent.getStringExtra("cookie");
                    dbManager.addOrder(new OrderBean("", cookie, MainActivity.TYPE_ALIPAY, tradeno, "", "1", 0));
                    //
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("tradeno", tradeno);
                    broadCastIntent.setAction(AppConst.TRADEDETAIL_ACTION);
                    slef.sendBroadcast(broadCastIntent);
                    if(true) return;
                    //
                    ReqData data = new ReqData(tradeno);
                    ReqData.cookie = cookie;
                    //
                    String str = JsonHelper.toJson(data);
                    Intent _intent = new Intent(context, ReqService.class);
                    _intent.putExtra("reqdata", str);
                    startService(_intent);
                    //

//					final DBManager dbManager=new DBManager(CustomApplcation.getInstance().getApplicationContext());
//	     			if(!dbManager.isExistTradeNo(tradeno)){
//
//	     			}
                } else if (intent.getAction().contentEquals(AppConst.NOT_LOGIN_ACTION)) {
                    String type = intent.getStringExtra("type");
                    sendmsg("app ：" + type + " unenable");
                    if (!type.isEmpty()) {
                        ClientManager.getInstance().onLoginPayAppDisable(type);
                    }
                } else if (intent.getAction().contentEquals(AppConst.CP_GETPAYERLIST)) {
                    String orderid = intent.getStringExtra("orderid");
                    PayHelperUtils.sendCPDetail(CustomApplcation.getContext(), orderid);
                } else if (intent.getAction().contentEquals(AppConst.CP_START)) {
                    PayHelperUtils.startAppCP(context);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(500);
                                PayHelperUtils.forceOpenSelf(MainActivity.slef);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }).start();
                }else if(intent.getAction().contentEquals(AppConst.LKL_START)){

                }else if(intent.getAction().contentEquals(AppConst.MBANK_SERVICE)){
                    if(!isServiceRunning(MainActivity.slef,"com.zhiyi.xppay.hook.MBankService")){
                        startService(new Intent(MainActivity.slef, MBankService.class));
                    }
                }else if(intent.getAction().contentEquals(AppConst.PERSONALQRCODE)){
                    String qrcode = intent.getStringExtra("qrcode");
                    XposedBridge.log("私人 qrcode 》》》》》》》》"+qrcode);
                }else{

                }

            } catch (Exception e) {
                PayHelperUtils.sendmsg(context, "BillReceived异常" + e.getMessage());
                XposedBridge.log(e);
            }
        }

        public void notifyapi(String type, final String no, String money, String mark, String dt,String wh) {
            try {
                ClientManager.getInstance().sendPayOverNotify(type, no, money, mark, dt,wh);
            } catch (Exception e) {
                sendmsg("notifyapi异常" + e.getMessage());
            }
        }

//		private void update(String no,String result){
//			 DBManager dbManager=new DBManager(CustomApplcation.getInstance().getApplicationContext());
//			 dbManager.updateOrder(no,result);
//		}
    }


    private boolean checkPermission(Activity activity, String[]  permissions){
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        startService(new Intent(this, SmsService.class));
    }

    private void goIntentSetting() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", this.getPackageName(), null);
        intent.setData(uri);
        try {
            this.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void showNormalDialog(){
        /* @setIcon 设置对话框图标
         * @setTitle 设置对话框标题
         * @setMessage 设置对话框消息提示
         * setXXX方法返回Dialog对象，因此可以链式设置属性
         */
        final AlertDialog.Builder normalDialog =
                new AlertDialog.Builder(MainActivity.this);
        normalDialog.setTitle("提示");
        normalDialog.setMessage("请开启读取短信权限");
        normalDialog.setPositiveButton("确定",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //...To-do
                        goIntentSetting();
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS},2);
                    }
                });
        normalDialog.setNegativeButton("关闭",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //...To-do
                    }
                });
        // 显示
        normalDialog.show();
    }
    // 农信易扫
    class MainReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equals(AppConstsNxys.ACTION_MSGRECEIVED)){
                String msg = intent.getStringExtra("msg");
                sendmsg(msg);
            }else if(intent.getAction().equals(AppConstsNxys.ACTION_SENDTRADE)){
                String payTime = intent.getStringExtra("payTime");
                String orderId = intent.getStringExtra("orderId");
                String realAmount = intent.getStringExtra("realAmount");
                String merName = intent.getStringExtra("merName");
                sendmsg("农信易扫收款\n收款时间："+payTime+"\n订单号："+orderId+"\n到账金额："+realAmount+"\n收款方："+merName);
                ClientManager.getInstance().sendPayOverNotify(AppConstsNxys.TYPE_NXYS, orderId, realAmount, orderId, payTime,"");
            }else if(intent.getAction().equals(AppConstsNxys.ACTION_STARTTRADEQUERY)){
                Intent intent1 = new Intent(slef, TradeQueryService.class);
                String appname = intent.getStringExtra("appname");
                intent1.putExtra("appname",appname);
                slef.startService(intent1);
            }else if(intent.getAction().equals(AppConstsNxys.ACTION_LOGINED)){
                XposedBridge.log("农信易扫登录了~~~~~~~~~~~~");
//                ToolsNxys.isLogined = true;
            }
        }
    }

    class MainReceiverXGJ extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equals(com.zhiyi.xppay.hook.xgj.AppConst.ACTION_STARTTRADEQUERY)){
                XposedBridge.log("星管家----------開始輪詢");
                XposedBridge.log("slef >>>>>>>>>>> "+slef);
                Intent intent1 = new Intent(slef, ServiceXGJTrade.class);
                slef.startService(intent1);
            }else if(intent.getAction().equals(com.zhiyi.xppay.hook.xgj.AppConst.ACTION_SENDTRADE)){
                String time = intent.getStringExtra("time");
                XposedBridge.log("星管家收到订单 支付时间1 》》》》》》 "+time);
                time = PayHelperUtils.dateToStamp(time,"yyyyMMddHHmmss");
                time = PayHelperUtils.stampToDate(time);
                XposedBridge.log("星管家收到订单 支付时间2 》》》》》》 "+time);
                String money = intent.getStringExtra("money");
                String remark = intent.getStringExtra("remark");
                PayHelperUtils.sendmsg(context,"星管家收到订单 支付时间:"+time+"支付金额："+money+"备注："+remark);
                ClientManager.getInstance().sendPayOverNotify(com.zhiyi.xppay.hook.xgj.AppConst.TYPE_XGJ, "", money, remark, time,"");
            }
        }
    }

    // 银盛通
    class MainReceiverYST extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equals(Appconsts.ACTION_SENDQRCODE)){
                String qrlink = intent.getStringExtra("qrlink");
                String remark = intent.getStringExtra("mark");
                String money = intent.getStringExtra("money");
                sendmsg("订单生成成功，\n二维码地址："+qrlink+"\n 金额："+money+"\n 备注："+remark);
                ClientManager.getInstance().OnGetQrcodeOver(qrlink, remark, money,Appconsts.TYPE_YST, "","");
            }else if(intent.getAction().equals(Appconsts.ACTION_SENDTRADE)){
                String payTime = intent.getStringExtra("payTime");
                String orderId = intent.getStringExtra("orderId");
                String realAmount = intent.getStringExtra("realAmount");
                String merName = intent.getStringExtra("merName");
                String type = intent.getStringExtra("type");
                sendmsg("银盛通收款，\n收款时间："+payTime+"\n订单号："+orderId+"\n到账金额："+realAmount+"\n收款方："+merName+"\n支付方式："+type);
                ClientManager.getInstance().sendPayOverNotify(Appconsts.TYPE_YST, "", realAmount, orderId, payTime,"");
            }else if(intent.getAction().equals(Appconsts.ACTION_STARTTRADEQUERY)){
                Intent intent1 = new Intent(slef, com.zhiyi.xppay.yst.hook.TradeQueryService.class);
                slef.startService(intent1);
            }
        }
    }

    class MainReceiverSKB extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equals(AppConst.ACTION_STARTTRADEQUERY_SKB)){
                Intent intent1 = new Intent(slef, TradeQueryService_SKB.class);
                slef.startService(intent1);
            }
        }
    }
}
