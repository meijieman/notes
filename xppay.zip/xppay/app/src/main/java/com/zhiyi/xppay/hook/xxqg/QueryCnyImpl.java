package com.zhiyi.xppay.hook.xxqg;

import android.content.Context;
import android.os.Handler;

import com.google.myjson.Gson;
import com.zhiyi.xppay.hook.RimetHook;
import com.zhiyi.xppay.hook.xxqg.OpenRedpacketThread2;
import com.zhiyi.xppay.hook.xxqg.SendMsgThread;

import java.util.List;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class QueryCnyImpl {
    private ClassLoader classLoader;
    private Handler handler;
    private Context context;

    public QueryCnyImpl(ClassLoader classLoader, Handler handler,Context context) {
        this.classLoader = classLoader;
        this. context =context;
        this.handler =handler;
    }

    void onDataReceived(Object obj) {

        if (obj != null) {
            try {
                if (XposedHelpers.getObjectField(obj, "mSentList") != null) {
                  List list=     (List)XposedHelpers.getObjectField(obj, "mSentList");
                    for (Object next : list) {
//                        XposedBridge.log(new Gson().toJson(next));
                        String obj2 = ""+XposedHelpers.getObjectField(next, "status");
                        String obj3 = ""+XposedHelpers.getObjectField(next, "sender");
                        String obj4 = ""+XposedHelpers.getObjectField(next, "clusterId");
                        if (obj2.equals("1") || obj2.equals("0")) {
                            new SendMsgThread(this.classLoader, next,handler,context).start();
                        } else if (obj2.equals("2")) {
                            String congratulations =""+XposedHelpers.getObjectField(next,"congratulations");
                            new OpenRedpacketThread2(this.classLoader, obj3, obj4, 0).start();
                            HookXxqg.taskList.remove(congratulations);
                        }
                    }
                  XposedBridge.log("QueryCnyImpl onDataReceived "+list.size());
                }
            } catch (Throwable th) {
                XposedBridge.log(th);
            }
        }
    }

    void onException(String str, String str2) {
      XposedBridge.log("QueryCnyImpl onException");
    }

    void onProgress(Object obj, int i) {
      XposedBridge.log("QueryCnyImpl onProgress");
    }
}