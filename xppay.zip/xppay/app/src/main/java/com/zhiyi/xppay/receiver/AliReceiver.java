package com.zhiyi.xppay.receiver;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.service.MainService;

public class AliReceiver extends BroadcastReceiver {

    private MainService service;

    public AliReceiver(MainService service){
        this.service = service;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        service.receiveBroadcast(context,intent);
    }
}
