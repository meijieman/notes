package com.zhiyi.xppay.net.Socket;

import com.zhiyi.xppay.net.Socket.SendMsg.LoginInfo;

import java.util.ArrayList;

/**
 * Created by pc_unity on 2018/11/10.
 */

public class LoginInfoManager{

    protected ArrayList<LoginInfo> data;

    public LoginInfoManager(){
        data = new ArrayList<>();
    }

    public ArrayList<LoginInfo> getLoginInfoList(){
        return data;
    }

    protected LoginInfo getLoginInfoByType(String type){
        for (LoginInfo info:data ) {
            if(info.type.equals(type)){
                return info;
            }

        }
        return null;
    }

    public void addLoginInfoNo(String name, String type,LoginInfo.LoginStatus status){
        LoginInfo info = getLoginInfoByType(type);
        if(info == null){
            info = new LoginInfo(name,type);
        }else{
            if(info.hasInfo()){
                return;
            }
        }
        info.loginStatus = status;
        data.add(info);
    }


    public LoginInfo.LoginStatus getLoginStutse(String type){
        LoginInfo info = getLoginInfoByType(type);
        if(info != null){
            return info.loginStatus;
        }
        return LoginInfo.LoginStatus.noinfo;
    }

    public void setLoginFinish(String type){
        LoginInfo info = getLoginInfoByType(type);
        if(info == null){
            return;
        }
        info.loginStatus = LoginInfo.LoginStatus.finish;
    }

    public void setLoginNoinfo(String type){
        LoginInfo info = getLoginInfoByType(type);
        if(info == null){
            return;
        }
        info.loginStatus = LoginInfo.LoginStatus.no;
    }

    public void onDisconnect(){
        for(LoginInfo info:data){
            info.loginStatus = LoginInfo.LoginStatus.no;
        }
    }

    public boolean hasLogin(String type){
        for(LoginInfo info:data){
            if(info!=null&&info.hasInfo()&&info.type.equals(type)){
                return info.hasLogin();
            }
        }
        return false;
    }
}
