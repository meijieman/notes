package com.zhiyi.xppay.utils;

/**
 * Created by pc_mg on 2018/12/21.
 */

public class AlipayInfo{
    public String alipaypwd;
    public String withdrawcount;
    public String bankcardno;
    public String bankaccount;
    public String alipayaccount;
    public int withdrawtype;
    public AlipayInfo(){}
    @Override
    public String toString() {
        return "AlipayInfo:{" +
                "alipaypwd='" + alipaypwd + '\'' +
                ",withdrawcount='" + withdrawcount + '\'' +
                ",bankcardno=" + bankcardno +
                ",bankaccount='" + bankaccount + '\'' +
                ",alipayaccount='" + alipayaccount + '\'' +
                ",withdrawtype='"+withdrawtype+'\''+
                "}";
    }
}
