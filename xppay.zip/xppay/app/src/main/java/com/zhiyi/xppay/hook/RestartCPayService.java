package com.zhiyi.xppay.hook;

import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.main.Main;
import com.zhiyi.xppay.utils.PayHelperUtils;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/1/7.
 */

public class RestartCPayService extends Service implements Runnable {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    public void onCreate(){
        new Thread(this).start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
    @Override
    public void run() {
        // 商户界面之后返回到监控
        while(true){
            try {
                Thread.sleep(3000);
                if(!PayHelperUtils.isAppRunning(CustomApplcation.getContext(),"com.unionpay")){
                    PayHelperUtils.sendmsg(CustomApplcation.getContext(),"重启云闪付");
                    PayHelperUtils.startAPP(CustomApplcation.getContext(),"com.unionpay");
//                    PayHelperUtils.startAppCP(CustomApplcation.getContext());
                    Thread.sleep(10000);
                    if(!AppConst.LOCKSCREEN){
                        PayHelperUtils.forceOpenSelf(CustomApplcation.getContext());
//                        PayHelperUtils.startAPP();
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //
    }
}
