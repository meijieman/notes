package com.zhiyi.xppay.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.consts.AppConstsNxys;
import com.zhiyi.xppay.hook.AlipayHook38;
import com.zhiyi.xppay.hook.AlipayMBhook;
import com.zhiyi.xppay.hook.CustomApplcation;
import com.zhiyi.xppay.hook.sb.ReceiverSB;
import com.zhiyi.xppay.hook.v138.Tools;
import com.zhiyi.xppay.hook.wzp.ReceiverWZP;
import com.zhiyi.xppay.item.AliBankData;
import com.zhiyi.xppay.ui.MainActivity;
import com.zhiyi.xppay.yst.consts.Appconsts;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 *
 *
 */
public class PayHelperUtils {


    public static List<QrCodeBean> qrCodeBeans = new ArrayList<QrCodeBean>();
    public static List<OrderBean> orderBeans = new ArrayList<OrderBean>();

    private static ClassLoader classLoaderAli;

    /*
     * 启动一个app
     */
    public static void startAPP() {
        try {
            Intent intent = new Intent(CustomApplcation.getInstance().getApplicationContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            CustomApplcation.getInstance().getApplicationContext().startActivity(intent);
        } catch (Exception e) {
        }
    }

    public static void forceOpenSelf(Context context) {
        Intent intent = new Intent();
        intent.setClassName("com.zhiyi.xppay", "com.zhiyi.xppay.ui.MainActivity");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public static void getAlipayPersonQRCode(Context context){
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(AppConst.ALIPAYPERSONALQRCODE_ACTION);
        context.sendBroadcast(broadCastIntent);
    }

    /**
     * 将图片转换成Base64编码的字符串
     *
     * @param path
     * @return base64编码的字符串
     */
    public static String imageToBase64(String path) {
        if (TextUtils.isEmpty(path)) {
            return null;
        }
        InputStream is = null;
        byte[] data = null;
        String result = null;
        try {
            is = new FileInputStream(path);
            // 创建一个字符流大小的数组。
            data = new byte[is.available()];
            // 写入数组
            is.read(data);
            // 用默认的编码格式进行编码
            result = Base64.encodeToString(data, Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != is) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
        result = "\"data:image/gif;base64," + result + "\"";
        return result;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    public static void sendAppMsg(String money, String mark, String type, Context context) {
        Intent broadCastIntent = new Intent();
        if (type.equals(AppConst.TYPE_ALIPAY)) {
            broadCastIntent.setAction(AppConst.ALIPAYSTART_ACTION);
        } else if (type.equals(AppConst.TYPE_WXPAY)) {
            broadCastIntent.setAction(AppConst.WECHATSTART_ACTION);
        } else if (type.equals(AppConst.TYPE_QQPAY)) {
            broadCastIntent.setAction(AppConst.QQSTART_ACTION);
        } else if (type.contains(AppConst.TYPE_CPPAY)) {
            broadCastIntent.setAction(AppConst.CP_QRCODE);
            broadCastIntent.putExtra("type", type);
        } else if (type.equals(AppConst.TYPE_LKLPAY)) {
            broadCastIntent.setAction(AppConst.LKL_QRCODE);
        } else if (type.equals(AppConst.TYPE_DingDing)) {
            broadCastIntent.setAction(AppConst.DINGDING_ACTION);
            broadCastIntent.putExtra("type","QRCODE");
        }else if (type.equals(Appconsts.TYPE_YST)){
            broadCastIntent.setAction(Appconsts.ACTION_CREATEQRCODE);
        }else if(type.equals(AppConst.TYPE_TBH)){
            broadCastIntent.setAction(AppConst.TBH_ACTION);
        }else if(type.contains(AppConst.TYPE_SKB)){
            broadCastIntent.setAction(AppConst.ACTION_CREATEQRCODE_SKB);
            broadCastIntent.putExtra("type", type);
        }else if(type.equals(AppConst.TYPE_XXQG)){
            broadCastIntent.setAction(AppConst.ACTION_CREATEQRCODE_XXQG);
        }else if(type.contains(AppConstsNxys.TYPE_NXYS)||type.contains(AppConst.TYPE_NXFJSH)||type.contains(AppConst.TYPE_JYES)){
            broadCastIntent.setAction(AppConstsNxys.ACTION_CREATEQRCODE);
            broadCastIntent.putExtra("type",type);
        }else if(type.equals(AppConst.TYPE_MY)){
            broadCastIntent.setAction(AppConst.ACTION_CREATEQRCODE_MAYOU);
        }else if(type.equals(AppConst.TYPE_XX)){
            broadCastIntent.setAction(AppConst.ACTION_CREATEQRCODE_XIAOXIN);
        }else if(type.equals(AppConst.TYPE_HYBSYT)){
            broadCastIntent.setAction(AppConst.ACTION_CREATEQRCODE_HYBSYT);
        }else if (type.equals(AppConst.TYPE_YZF)){
            broadCastIntent.setAction(AppConst.ACTION_CREATEQRCODE_YZF);
        }else if(type.equals(AppConst.TYPE_FL)){
            broadCastIntent.setAction(AppConst.ACTION_CREATEQRCODE_FL);
        }else if (type.equals(AppConst.TYPE_WL)){
            broadCastIntent.setAction(AppConst.ACTION_CREATEQRCODE_WL);
        }else if(type.contains(AppConst.TYPE_WZP)){
            broadCastIntent.setAction(ReceiverWZP.ACTION_CREATEQR);
            broadCastIntent.putExtra("type",type);
        }else if(type.contains(AppConst.TYPE_SB)){
            broadCastIntent.setAction(ReceiverSB.ACTION_CREATEQR);
            broadCastIntent.putExtra("type",type);
        }
        else{
            broadCastIntent.setAction(type+AppConst.ACTION_BUILD_QRCODE);
        }
        broadCastIntent.putExtra("mark", mark);
        broadCastIntent.putExtra("money", money);
        context.sendBroadcast(broadCastIntent);
    }

    public static void sendLogin(Context context) {
//		AppConst.cpid =id;
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(AppConst.CP_LOGIN);
        context.sendBroadcast(broadCastIntent);
    }

    public static void sendCPQuery(Context context, String orderid) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("orderid", orderid);
        broadCastIntent.setAction(AppConst.CP_GETPAYERLIST);
        context.sendBroadcast(broadCastIntent);
    }

    public static void sendCPDetail(Context context, String orderid) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("orderid", orderid);
        broadCastIntent.setAction(AppConst.CP_GETPAYER);
        context.sendBroadcast(broadCastIntent);
    }

    public static void sendGetTradeList(String type, Context context) {
        Intent broadCastIntent = new Intent();
        if (type.equals(AppConst.TYPE_ALIPAY)) {
            broadCastIntent.setAction(AppConst.ALIPAY_GET_TRADE_ACTION);
        } else if (type.equals(AppConst.TYPE_WXPAY)) {

        } else if (type.equals(AppConst.TYPE_QQPAY)) {

        }
        context.sendBroadcast(broadCastIntent);
    }


    /*
     * 将时间戳转换为时间
     */
    public static String stampToDate(String s) {
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long lt = new Long(s);
        Date date = new Date(lt);
        res = simpleDateFormat.format(date);
        return res;
    }
    public static String stampToDate(String s,String format) {
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        long lt = new Long(s);
        Date date = new Date(lt);
        res = simpleDateFormat.format(date);
        return res;
    }
    public static String dateToStamp(String d, String format) {
        String res = "";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        try {
            return res = String.valueOf(simpleDateFormat.parse(d).getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return res;
    }

    /**
     * 方法描述：判断某一应用是否正在运行
     *
     * @param context     上下文
     * @param packageName 应用的包名
     * @return true 表示正在运行，false表示没有运行
     */
    public static boolean isAppRunning(Context context, String packageName) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> list = am.getRunningTasks(100);
        if (list.size() <= 0) {
            return false;
        }
        for (ActivityManager.RunningTaskInfo info : list) {
            if (info.baseActivity.getPackageName().equals(packageName)) {
                return true;
            }
        }
        return false;
    }

    /*
     * 启动一个app
     */
    public static void startAPP(Context context, String appPackageName) {
        try {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(appPackageName);
            context.startActivity(intent);
        } catch (Exception e) {
            sendmsg(context, "startAPP异常" + e.getMessage());
        }
    }

    public static void startAppCP(Context context) {
        try {
            Intent _intent = context.getPackageManager().getLaunchIntentForPackage("com.unionpay");
            _intent.setClassName("com.unionpay", "com.unionpay.activity.UPActivityMain");
            context.startActivity(_intent);
        } catch (Exception e) {
            sendmsg(context, "startAPP异常" + e.getMessage());
        }
    }

    public static void startAppHYB(Context context) {
        try {
            Intent _intent = context.getPackageManager().getLaunchIntentForPackage(AppConst.APP_HYBSYT);
            _intent.setClassName(AppConst.APP_HYBSYT, "com.hybunion.MainActivity");
            context.startActivity(_intent);
        } catch (Exception e) {
            sendmsg(context, "startAPP异常" + e.getMessage());
        }
    }

    public static void startAppLKL(Context context) {
        try {
            Intent _intent = context.getPackageManager().getLaunchIntentForPackage("com.lakala.cloudpos.qcodeapp");
            _intent.setClassName("com.lakala.cloudpos.qcodeapp", "com.lakala.qcodeapp.module.home.MainActivity");//
            context.startActivity(_intent);
        } catch (Exception e) {
            sendmsg(context, "startAPP异常" + e.getMessage());
        }
    }

    public static void startAppNXYS(Context context) {
        try {
            Intent _intent = context.getPackageManager().getLaunchIntentForPackage(AppConstsNxys.PACKAGENAME);
            _intent.setClassName(AppConstsNxys.PACKAGENAME, "com.buybal.buybalpay.activity.HomeActivity");//
            _intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(_intent);
        } catch (Exception e) {
            sendmsg(context, "startAPP异常" + e.getMessage());
        }
    }
    public static void traceObject(Object o){
        if(o == null){
            return;
        }
        List<Field> fieldList = new ArrayList<>() ;
        Field[] fs = o.getClass().getFields();
        Field[] fs1 = o.getClass().getDeclaredFields();
        for (Field f:fs) {
            fieldList.add(f);
        }
        for (Field f:fs1) {
            fieldList.add(f);
        }

        Class tempClass = o.getClass();
        while (tempClass != null) {//当父类为null的时候说明到达了最上层的父类(Object类).
            fieldList.addAll(Arrays.asList(tempClass .getDeclaredFields()));
            tempClass = tempClass.getSuperclass(); //得到父类,然后赋给自己
        }
        for (Field f : fieldList) {
            try {
                XposedBridge.log("getFields---"+f.getName()+"="+f.get(o));
            } catch (IllegalAccessException e) {
                //XposedBridge.log(e);
            }
        }
    }

    public static void notify(final Context context, String type, final String no, String money, String mark,
                              String dt) {
//		update(no, "success");

//		String notifyurl = AbSharedUtil.getString(context, "notifyurl");
//		String signkey = AbSharedUtil.getString(context, "signkey");
//		sendmsg(context, "订单" + no + "重试发送异步通知...");
//		if (TextUtils.isEmpty(notifyurl) || TextUtils.isEmpty(signkey)) {
//			sendmsg(context, "发送异步通知异常，异步通知地址为空");
//			update(no, "异步通知地址为空");
//			return;
//		}
//
//		String account="";
//		if(type.equals("alipay")){
//			account=AbSharedUtil.getString(context, "alipay");
//		}else if(type.equals("wechat")){
//			account=AbSharedUtil.getString(context, "wechat");
//		}else if(type.equals("qq")){
//			account=AbSharedUtil.getString(context, "qq");
//		}
//
//		HttpUtils httpUtils = new HttpUtils(15000);
//
//		String sign = MD5.md5(dt + mark + money + no + type + signkey);
//		RequestParams params = new RequestParams();
//		params.addBodyParameter("type", type);
//		params.addBodyParameter("no", no);
//		params.addBodyParameter("money", money);
//		params.addBodyParameter("mark", mark);
//		params.addBodyParameter("dt", dt);
//		if (!TextUtils.isEmpty(account)) {
//			params.addBodyParameter("account", account);
//		}
//		params.addBodyParameter("sign", sign);
//		httpUtils.send(HttpMethod.POST, notifyurl, params, new RequestCallBack<String>() {
//
//			@Override
//			public void onFailure(HttpException arg0, String arg1) {
//				sendmsg(context, "发送异步通知异常，服务器异常" + arg1);
//				update(no, arg1);
//			}
//
//			@Override
//			public void onSuccess(ResponseInfo<String> arg0) {
//				String result = arg0.result;
//				if (result.contains("success")) {
//					sendmsg(context, "发送异步通知成功，服务器返回" + result);
//				} else {
//					sendmsg(context, "发送异步通知失败，服务器返回" + result);
//				}
//				update(no, result);
//			}
//		});
    }

    //	private static void update(String no, String result) {
//		DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
//		dbManager.updateOrder(no, result);
//	}
    // 设置下aliclassloader
    private static void setClassLoaderAli(ClassLoader appClassLoader) {
        if (classLoaderAli == null)
            classLoaderAli = appClassLoader;
    }

    // 重新获取cookie
    private static String regetCookieStr() {
        return getCookieStr(classLoaderAli);
    }

    private static boolean isregettingcookie;

    // 重新获取订单详情列表
    private static void regetTradeInfo(final Context context, final String cookie) {
        startAppAutostartself(context, "com.eg.android.AlipayGphone");
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (isregettingcookie) {
                    try { // 5秒重新获取一次cookie
                        Thread.sleep(5000);
                        String _cookie = regetCookieStr();
                        if (!_cookie.equals(cookie)) {
                            getTradeInfo(context, _cookie);
                            XposedBridge.log("重新获取cookie成功");
                            isregettingcookie = false;
                            return;
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    public static String getCookieStr(ClassLoader appClassLoader) {
        setClassLoaderAli(appClassLoader);
        String cookieStr = "";
        // 获得cookieStr
        XposedHelpers.callStaticMethod(XposedHelpers.findClass(
                "com.alipay.mobile.common.transportext.biz.appevent.AmnetUserInfo", appClassLoader), "getSessionid");
        Context context = (Context) XposedHelpers.callStaticMethod(XposedHelpers.findClass(
                "com.alipay.mobile.common.transportext.biz.shared.ExtTransportEnv", appClassLoader), "getAppContext");
        if (context != null) {
            Object readSettingServerUrl = XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("com.alipay.mobile.common.helper.ReadSettingServerUrl", appClassLoader),
                    "getInstance");
            if (readSettingServerUrl != null) {
                // String gWFURL = (String)
                // XposedHelpers.callMethod(readSettingServerUrl, "getGWFURL",
                // context);
                String gWFURL = ".alipay.com";
                cookieStr = (String) XposedHelpers.callStaticMethod(XposedHelpers
                                .findClass("com.alipay.mobile.common.transport.http.GwCookieCacheHelper", appClassLoader),
                        "getCookie", gWFURL);
            } else {
                sendmsg(context, "异常readSettingServerUrl为空");
            }
        } else {
            XposedBridge.log("异常context为空");
        }
        return cookieStr;
    }

    public static void getTradeInfo(final Context context, final String cookie) {
        //
        long current = System.currentTimeMillis();
        long s = current - 86400000;
        String c = getCurrentDate();
        String url = "https://mbillexprod.alipay.com/enterprise/simpleTradeOrderQuery.json?beginTime=" + s
                + "&limitTime=" + current + "&pageSize=20&pageNum=1&channelType=ALL";
        HttpUtils httpUtils = new HttpUtils(15000);
        httpUtils.configResponseTextCharset("GBK");
        RequestParams params = new RequestParams();
        params.addHeader("Cookie", cookie);
        params.addHeader("Referer", "https://render.alipay.com/p/z/merchant-mgnt/simple-order.html?beginTime=" + c
                + "&endTime=" + c + "&fromBill=true&channelType=ALL");
        XposedBridge.log("支付宝请求订单列表》》》》》》》》》》");
        httpUtils.send(HttpMethod.GET, url, params, new RequestCallBack<String>() {

            @Override
            public void onFailure(HttpException arg0, String arg1) {
                sendmsg(context, "服务器异常" + arg1);
            }

            @Override
            public void onSuccess(ResponseInfo<String> arg0) {
                String result = arg0.result;
                XposedBridge.log("支付宝订单信息:" + result);
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    if(jsonObject.has("status")&&jsonObject.optString("status").equals("failed")){
                        return;
                    }
                    JSONObject res = jsonObject.getJSONObject("result");
                    JSONArray jsonArray = res.getJSONArray("list");
                    //
                    if (isregettingcookie) isregettingcookie = false;
                    int length = Math.min(5, jsonArray.length());
                    if (jsonArray != null && jsonArray.length() > 0) {
                        for (int i = 0; i <length; i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String tradeNo = object.getString("tradeNo");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("tradeno", tradeNo);
                            broadCastIntent.putExtra("cookie", cookie);
                            broadCastIntent.setAction(AppConst.TRADENORECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                        }
//						JSONObject object = jsonArray.getJSONObject(0);
//						String tradeNo = object.getString("tradeNo");
//						Intent broadCastIntent = new Intent();
//						broadCastIntent.putExtra("tradeno", tradeNo);
//						broadCastIntent.putExtra("cookie", cookie);
//						broadCastIntent.setAction(AppConst.TRADENORECEIVED_ACTION);
//						context.sendBroadcast(broadCastIntent);
                    }

                } catch (Exception e) {
                    //
                    sendmsg(context, "getTradeInfo异常" + e.getMessage() + "重新获取");
                    if (!isregettingcookie) {
                        isregettingcookie = true;
                        // 重新获取交易列表
                        regetTradeInfo(context, cookie);
                    } else {
                        XposedBridge.log("正在重新获取cookie......");
                    }
                    //
                }

            }
        });
    }

    public static String getCurrentDate() {
        long l = System.currentTimeMillis();
        Date date = new Date(l);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String d = dateFormat.format(date);
        return d;
    }

    public static void sendmsg(Context context, String msg) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("msg", msg);
        broadCastIntent.setAction(AppConst.MSGRECEIVED_ACTION);
        context.sendBroadcast(broadCastIntent);
    }

    /**
     * 获取当前本地apk的版本
     *
     * @param mContext
     * @return
     */
    public static int getVersionCode(Context mContext) {
        int versionCode = 0;
        try {
            // 获取软件版本号，对应AndroidManifest.xml下android:versionCode
            versionCode = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            sendmsg(mContext, "getVersionCode异常" + e.getMessage());
        }
        return versionCode;
    }

    /**
     * 获取版本号名称
     *
     * @param context 上下文
     * @return
     */
    public static String getVerName(Context context) {
        String verName = "";
        try {
            verName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            sendmsg(context, "getVerName异常" + e.getMessage());
        }
        return verName;
    }

    public static boolean isreg(Activity activity, String name) {
        Intent intent = new Intent();
        intent.setAction(name);
        PackageManager pm = activity.getPackageManager();
        List<ResolveInfo> resolveInfos = pm.queryBroadcastReceivers(intent, 0);
        if (resolveInfos != null && !resolveInfos.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 判断某activity是否处于栈顶
     *
     * @return true在栈顶 false不在栈顶
     */
    public static int isActivityTop(Context context) {
        try {
            ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            List<RunningTaskInfo> infos = manager.getRunningTasks(100);
            for (RunningTaskInfo runningTaskInfo : infos) {
                if (runningTaskInfo.topActivity.getClassName()
                        .equals("cooperation.qwallet.plugin.QWalletPluginProxyActivity")) {
                    return runningTaskInfo.numActivities;
                }
            }
            return 0;
        } catch (SecurityException e) {
            sendmsg(context, e.getMessage());
            return 0;
        }
    }

    public static String getAlipayLoginId(ClassLoader classLoader) {
        try {
            Class<?> AlipayApplication = XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication",
                    classLoader);
            Class<?> SocialSdkContactService = XposedHelpers
                    .findClass("com.alipay.mobile.personalbase.service.SocialSdkContactService", classLoader);
            Object instace = XposedHelpers.callStaticMethod(AlipayApplication, "getInstance");
            Object MicroApplicationContext = XposedHelpers.callMethod(instace, "getMicroApplicationContext");
            Object service = XposedHelpers.callMethod(MicroApplicationContext, "findServiceByInterface",
                    SocialSdkContactService.getName());
            Object MyAccountInfoModel = XposedHelpers.callMethod(service, "getMyAccountInfoModelByLocal");
            String userId = XposedHelpers.getObjectField(MyAccountInfoModel, "userId").toString();
//			XposedBridge.log("userid is "+userId);
            return userId;
        } catch (Exception e) {
        }
        return "";
    }

    public static String getBanlance(Context context, ClassLoader classLoader) {
        Class<?> cljsmanger = XposedHelpers.findClass("com.alipay.android.app.template.JSPluginManager", classLoader);
        Object jsmangerins = XposedHelpers.callStaticMethod(cljsmanger, "getInstanse");
        Object prop = XposedHelpers.callMethod(jsmangerins, "performGetProp", context, "userPreferences", "{\"key\":\"WealthAccountHome\",\"business\":\"WealthAccount\"}");
        return (String) prop;
    }


    public static String getWechatLoginId(Context context) {
        String loginId = "";
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences("com.tencent.mm_preferences", 0);
            loginId = sharedPreferences.getString("login_weixin_username", "");
        } catch (Exception e) {
            PayHelperUtils.sendmsg(context, e.getMessage());
        }
        return loginId;
    }

    public static String getQQLoginId(Context context) {
        String loginId = "";
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences("Last_Login", 0);
            loginId = sharedPreferences.getString("uin", "");
        } catch (Exception e) {
            PayHelperUtils.sendmsg(context, e.getMessage());
        }
        return loginId;
    }

    public static void sendLoginId(String loginId, String type, Context context) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(AppConst.LOGINIDRECEIVED_ACTION);
        broadCastIntent.putExtra("type", type);
        broadCastIntent.putExtra("loginid", loginId);
        context.sendBroadcast(broadCastIntent);
    }

    public static void startAppAutostartself(final Context context, String packagename) {
        startAPP(context, packagename);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                forceOpenSelf(context);
            }
        }).start();
    }

    public static void startAppToBanlance(final Context context, final AlipayInfo alipayInfo) {
        startAPP(context, "com.eg.android.AlipayGphone");
        //
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(100);
                    XposedBridge.log("进入余额窗口");
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.setAction("com.payhelper.alipay.tobanlance");
                    Bundle bundle = new Bundle();
                    bundle.putString("alipayinfo", JsonHelper.toJson(alipayInfo));
                    broadCastIntent.putExtras(bundle);
                    context.sendBroadcast(broadCastIntent);
                } catch (Error | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    // 提现 3种方式 全额提现 转账到银行卡 转账到支付宝账户
    public static void withDraw(Context context, AlipayInfo info, float banlance) {
        int withdrawtyep = info.withdrawtype;
        XposedBridge.log("提现数据" + info.toString());
        switch (withdrawtyep) {
            case 0:
                startAppwithdraw(context, info.alipaypwd);
                break;
            case 1:
                float t = banlance * 0.001f;
                banlance = banlance - t;// 银行卡扣掉手续费
                if (banlance > 0)
                    startAppwithdraw(context, info.bankaccount, info.bankcardno, "" + banlance, info.alipaypwd);
                break;
            case 2:
                startAppwithdraw(context, info.alipayaccount, info.alipaypwd, "" + banlance);
                break;
        }
    }

    public static void startAppwithdraw(final Context context, final String pwd) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction("com.payhelper.alipay.withdraw");
        broadCastIntent.putExtra("passward", pwd);// 密码
        context.sendBroadcast(broadCastIntent);
    }

    public static void startAppwithdraw(Context context, String aliaccount, String pwd, String money) {
        Intent broadCastIntent = new Intent();
        XposedBridge.log("开始转账到支付宝账户");
        broadCastIntent.setAction("com.payhelper.alipay.transfertoaliaccount");
        broadCastIntent.putExtra("aliaccount", aliaccount);// 支付宝账户
        broadCastIntent.putExtra("passward", pwd);// 密码
        broadCastIntent.putExtra("money", money);// 钱
        context.sendBroadcast(broadCastIntent);
    }

    public static void startAppwithdraw(final Context context, String account, String cardno, String money, String passward) {
        XposedBridge.log("开始提现到银行卡广播");
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction("com.payhelper.alipay.transfertobank");
        broadCastIntent.putExtra("account", account);//"杨元侃");// 账户 真实名字
        broadCastIntent.putExtra("cardno", cardno);//"6217000780051805571");// 卡号
        broadCastIntent.putExtra("money", money);//"100");// 额度
        broadCastIntent.putExtra("passward", passward);// "251413");// 密码
        context.sendBroadcast(broadCastIntent);
    }

    public static void SendChatMessage(ClassLoader classLoader, String userid, String usertype, String content) {
        Class<?> clazz = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.sender.MessageFactory", classLoader);
        XposedHelpers.callStaticMethod(clazz, "createTextMsg", userid, usertype, content, null, null, false);
    }

    // 网商银行
    public static void getBankDetailInfo(final ClassLoader classLoader, final Context context) {
        try{
            String orderList = new AlipayMBhook(classLoader).getOrderList(context);
            sendMYBnakInfo(orderList,context);
        }catch(Exception e){
            XposedBridge.log("Exception e === "+e.getMessage());
        }
    }

    private static void sendMYBnakInfo(String orderlist,Context context){
        try {
            if(dbManage==null) dbManage = new DBManager(context);
            JSONArray redum = removeDuplicateOrder(new JSONObject(orderlist).optJSONObject("billListView").optJSONArray("billDetailView"));
            JSONArray billDetailView = redum;
            for (int i = 0; i < billDetailView.length(); i++) {
                JSONObject json = billDetailView.getJSONObject(i);
                JSONObject jsonamount = json.getJSONObject("amount");
                String money = jsonamount.getString("amt");
                String billno = json.getString("transactionNo");
                String cardno = json.getString("sensitiveCardNo");
                cardno = cardno.substring(3);
                String ymd = json.getString("transactionCreatedDate");
                ymd = ymd.replace(".", "-");
                String time = json.getString("transactionCreatedTime");
                String dt = ymd + " " + time;

                XposedBridge.log("billno == "+billno+"money == "+money+"dt == "+dt);
                Intent broadCastIntent = new Intent();
                broadCastIntent.putExtra("bill_no", billno);
                broadCastIntent.putExtra("bill_money", money);
                broadCastIntent.putExtra("bill_mark", "false");
                broadCastIntent.putExtra("bill_dt", dt);
                broadCastIntent.putExtra("bill_wh",cardno);
                broadCastIntent.putExtra("bill_type", AppConst.TYPE_BANK);
                broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                context.sendBroadcast(broadCastIntent);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    static DBManager dbManage;
    private static JSONArray removeDuplicateOrder(JSONArray array) {
        try {
            for (int i = 0; i < array.length(); i++) {
                JSONObject json = array.getJSONObject(i);
                String billno = json.getString("transactionNo");
                if (dbManage.isExistAliBOrder(billno)) {
                    array.remove(i);
                    i--;
                    continue;
                }
                JSONObject jsonamount = json.getJSONObject("amount");
                String money = jsonamount.getString("amt");
                AliBankData data = new AliBankData();
                data.billno = billno;
                data.money = money;
                dbManage.addAliBOrder(data);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return array;
    }

    public static void SendBillMsg(final String userid,final String money,final String remark,final String orderid,final Context context){
        try{
            final Object objcAccount = Tools.compareFriend(userid,context.getClassLoader());
            boolean isfriend = objcAccount!=null && true == (boolean)XposedHelpers.callMethod(objcAccount,"isMyFriend");
            if(!isfriend){// 对象为空 或者 friendStatus 为0不是好友 //||!new JSONObject(JSON.toJSONString(objcAccount)).getBoolean("myFriend")
                sendmsg(context,"当前"+userid+"还不是您的好友");
                sendTrade(false,orderid,context);
                if(objcAccount!=null){
                    sendmsg(context, JSON.toJSONString(objcAccount));
                }
                return;
            }
            sendmsg(context,"生成订单金额"+money+"备注"+remark+"服务器订单id"+orderid);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Tools.sendBillMsg(userid,money,remark,orderid,context);
                }
            }).start();
        }catch(Exception e){
            XposedBridge.log(e);
        }
    }

    public static void sendTrade(boolean isFriend, String orderid, Context context){
        Intent intent = new Intent();
        intent.setAction(AppConst.HOOK_FRIEND_CHECK_ACTION);
        intent.putExtra("friend",isFriend);
        intent.putExtra("orderid",orderid);
        context.sendBroadcast(intent);
    }

    public static void LogMsg(String str){
        Log.e("Xposed",str);
    }
}
