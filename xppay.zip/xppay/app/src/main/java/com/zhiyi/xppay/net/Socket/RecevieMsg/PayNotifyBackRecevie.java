package com.zhiyi.xppay.net.Socket.RecevieMsg;

/**
 * Created by zhiyi on 2018/11/8.
 */

public class PayNotifyBackRecevie {
    public String no;

    @Override
    public String toString() {
        return "PayNotifyBackRecevie:{" +
                "no='" + no + "\'" +
                "}";
    }
}
