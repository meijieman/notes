package com.zhiyi.xppay.net.Socket.SendMsg;

import android.content.Intent;

import com.zhiyi.xppay.net.Socket.TransConst;

/**
 * Created by Administrator on 2019/3/22.
 */

public class DianDianChongToken extends TransMessage {
    public DianDianChongToken(Intent intent) {
        super(TransConst.DianDianChong);
        token = intent.getStringExtra("token");
    }
    public String token;
}
