package com.zhiyi.xppay.yst.hook;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebView;

import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.yst.consts.Appconsts;
import com.zhiyi.xppay.yst.utils.DBManagerYST;
import com.zhiyi.xppay.yst.utils.ToolsYST;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.HashMap;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/3/10.
 */

public class Hookyst {
    boolean isgetqrcode;
    private Object jsb;
    private static ClassLoader mclassLoader;
    private static Context mcontext;
    private static DBManagerYST dbManager;
    public void hook(final ClassLoader classLoader, final Context context) {
        dbManager = new DBManagerYST(context);
        final Class<?> clazz = XposedHelpers.findClass("com.stub.StubApp", classLoader); // onCreate
        XposedHelpers.findAndHookMethod(clazz, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log(" onCreate " + param.thisObject);
                Field field = XposedHelpers.findField(clazz, "ᵢˎ");
                XposedBridge.log(" onCreate field " + field.getClass().getName());
                field.setAccessible(true);
                Object obj = field.get(param.thisObject);
                Field fieldc = XposedHelpers.findField(clazz, "ᵢˑ");
                fieldc.setAccessible(true);
                Object objc = fieldc.get(param.thisObject);
                new Hookyst().hook(obj.getClass().getClassLoader(), (Context) objc);
                hook_real(classLoader,context);
            }
        });
    }

    private void hook_real(final ClassLoader classLoader, final Context context) {
        mclassLoader = classLoader;
        mcontext = context;
        PayHelperUtils.sendLoginId(getUserCode(mcontext), Appconsts.TYPE_YST,mcontext);
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    if (param.thisObject.getClass().getName().equals("com.ysepay.mobileportal.activity.html.JsBridgeHtml")) {
                        jsb = param.thisObject;
                    }
                }
            });
//            XposedHelpers.findAndHookMethod("com.ysepay.mobileportal.activity.html.HtmlPageShareBase", classLoader, "getScreenQrCode", new XC_MethodHook() {
//                @SuppressLint("ResourceType")
//                @Override
//                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    super.afterHookedMethod(param);
//                    Object o = param.getResult();// 2131691349
//                    if (o != null && !TextUtils.isEmpty(o.toString())) {
//                        String qrlink = param.getResult().toString();
//                    }
//                }
//            });
            XposedHelpers.findAndHookConstructor("com.ysepay.mobileportal.popupwindow.ShareFromBottomPopup", classLoader, Activity.class, WebView.class, String.class, String.class, java.util.Map.class, java.util.Map.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    XposedHelpers.callMethod(param.thisObject, "dismiss");
                }
            });
            XposedHelpers.findAndHookMethod("com.ysepay.mobileportal.popupwindow.ShareFromBottomPopup", classLoader, "executeShowPopWindow", View.class, String.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    XposedHelpers.callMethod(param.thisObject, "dismiss");
                }
            });
            XposedHelpers.findAndHookMethod("com.ysepay.mobileportal.activity.html.HtmlPageShareBase", classLoader, "hideOrShowRightImg", boolean.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    super.beforeHookedMethod(param);
                    boolean is = (boolean) param.args[0];
                    if (is) {
                        param.args[0] = false;
                    }
                }
            });
            XposedHelpers.findAndHookMethod("com.ysepay.mobileportal.activity.html.JsBridgeHtml$61", classLoader, "handler", String.class,
                    XposedHelpers.findClass("com.ysepay.mobileportal.webview.jsbridge.CallBackFunction", classLoader), new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            super.afterHookedMethod(param);
                            checkQRcode();
                        }
                    });
            XposedHelpers.findAndHookMethod("com.ysepay.mobileportal.http.AsyncHttpResponseHandler", classLoader, "sendSuccessMessage", int.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    String response = param.args[1].toString();
                    Class<?> base64 = XposedHelpers.findClass("com.ysepay.mobileportal.util.Base64",mclassLoader);
                    Object result = XposedHelpers.callStaticMethod(base64,"decode",response.substring(401), "UTF-8");
                    JSONObject object = new JSONObject(result.toString());
                    if(result.toString().contains("支付")){
                        object = object.getJSONObject("body");
                        if(object.has("contentList")){
                            JSONArray array = object.getJSONArray("contentList");
                            if(array.length()>0){
                                for(int i = 0;i<array.length();i++){
                                    JSONObject jsonObject = array.getJSONObject(i);
                                    String orderid = jsonObject.getString("logNo");// 订单ID
                                    if(dbManager.isExistTradeNo(orderid)){
                                        continue;
                                    }
                                    dbManager.addTradeNo(orderid);
                                    String mercId = jsonObject.getString("mercId");// 商户号
                                    String amount = ""+Float.parseFloat(jsonObject.getString("amount"))/100;// 金额
                                    String paytype = jsonObject.getString("txnCdDesc");// 支付宝支付还是微信支付
                                    String orderTime = jsonObject.getString("createTime");// 支付时间
                                    XposedBridge.log("一笔新订单 支付时间："+orderTime+"金额："+amount+"支付方式："+paytype);
                                    ToolsYST.sendtrade(mcontext,orderTime,orderid,amount,mercId,paytype);
                                }
                            }
                        }
                    }

                }
            });
        } catch (Exception e) {
            XposedBridge.log("e >>>>>>>>>>>>>>>> " + e);
        }
    }


    public static String getLocation(){
        Class<?> clazz = XposedHelpers.findClass("com.ysepay.mobileportal.util.AMapLocationUtils",mclassLoader);
        Object o = XposedHelpers.getStaticObjectField(clazz,"infomation");
        Object lo = XposedHelpers.getDoubleField(o,"longitude");
        Object la = XposedHelpers.getDoubleField(o,"latitude");
        Object add = XposedHelpers.getObjectField(o,"address");
        XposedBridge.log("当前 位置 "+add+"，经纬度 "+lo+","+la);
        PayHelperUtils.sendmsg(mcontext,"当前 位置 "+add+"，经纬度 "+lo+","+la);
        return lo+","+la;
    }

    private void checkQRcode() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (!isgetqrcode) {
                    try {
                        ((Activity) jsb).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                @SuppressLint("ResourceType")
                                Object o = ((Activity) jsb).findViewById(2131690373);
                                ((View) o).performClick();
                                Object oo = XposedHelpers.getObjectField(jsb, "qrCode");
                                if (oo != null) {
//                                    ToolsYST.sendqrcod((Activity) jsb,"","",oo.toString(),"",Appconsts.TYPE_YST);
                                    isgetqrcode = true;
                                }
                            }
                        });
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                XposedBridge.log("线程结束");
                isgetqrcode = false;
            }
        }).start();
    }

    public static void TradeQuery() {
        HashMap<String, String> reqParam = new HashMap();
        String usercode = Hookyst.getUserCode(mcontext);
        usercode = usercode.contains("m")?Hookyst.getMerCId(mcontext):usercode;
        reqParam.put("msgCode", "PS060");
        HashMap<String, Object> body = new HashMap();
        body.put("userCode", usercode);
        body.put("createTime", null);
        body.put("currPage", 1 + "");
        body.put("dateFlag", "day0");
        body.put("startDate", null);
        body.put("endDate", null);
        body.put("tranFlag", "");
        body.put("upOrDown", null);
        body.put("tradeSn", null);
        body.put("cardType", null);
        body.put("trmNo", null);
        body.put("logNo", null);
        body.put("tradeState", null);
        body.put("createTime", null);
        body.put("terminalType", null);
        body.put("merchantType", 1);
        body.put("mercId", null);
        body.put("businessType", null);
        body.put("sortId", null);
        body.put("operationType", "00");
        body.put("entryType", "PS060");
        body.put("risk_custName", getCustName(mcontext));
        body.put("risk_custId", getCurId(mcontext));
        body.put("risk_certifino", getCertifino(mcontext));
        body.put("risk_mobile", getMobile(mcontext));
        body.put("risk_userCode", usercode);

        Class<?> httpfactory = XposedHelpers.findClass("com.ysepay.mobileswipcard.util.PubHttpFactory", mclassLoader);
        Object objectFac = XposedHelpers.callStaticMethod(httpfactory, "create", mcontext);
        XposedHelpers.callMethod(objectFac, "sendHttp2", mcontext,reqParam, body, true, null);
    }

    public static String getUserInfo(Context context, String key) {
        Class<?> clazz = XposedHelpers.findClass("com.ysepay.mobileportal.http.pub.Session", mclassLoader);
        Object objSession = XposedHelpers.callStaticMethod(clazz, "getSession");
        Object objUser = XposedHelpers.callMethod(objSession, "getUser");
        Object objvalue = XposedHelpers.callMethod(objUser, "get", key, context);
        String value = objvalue.toString();
        return value;
    }

    public static String getCustName(Context context) {
        return getUserInfo(mcontext, "custName");
    }

    public static String getCurId(Context context) {
        return getUserInfo(mcontext, "custId");
    }

    public static String getAccountId(Context context){return getUserInfo(mcontext, "accountId");}

    public static String getCustId(Context context){return getUserInfo(mcontext,"custId");}

    public static String getMerCId(Context context){ return getUserInfo(mcontext,"mercId");}

    public static String getCertifino(Context context) {
        return getUserInfo(mcontext, "certifino");
    }

    public static String getMobile(Context context) {
        return getUserInfo(mcontext, "mobile");
    }

    public static String getUserCode(Context context) {
        return getUserInfo(mcontext, "userCode");
    }


//    this.content.put("risk_custName", Session.getSession().getUser().get("custName", context));
//        this.content.put("risk_custId", Session.getSession().getUser().get("custId", context));
//        this.content.put("risk_certifino", Session.getSession().getUser().get("certifino", context));
//        this.content.put("risk_mobile", Session.getSession().getUser().get("mobile", context));
//        this.content.put("risk_userCode", Session.getSession().getUser().get("userCode", context));


}
