package com.zhiyi.xppay.hook.alihook;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.alibaba.fastjson.JSON;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.v138.ChatMsgObjCon;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.MD5;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.StringUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/6/25.
 */

public class AlipayHook65 {
    public static ClassLoader mClassLoader;

    public void hook(ClassLoader classLoader, Context context) {
        baseinfo(classLoader,context);
        checkTrade(classLoader,context);
        checkBank(classLoader,context);
        redPacket(classLoader,context);
        securityCheckHook(classLoader);
        hookH5RpcUtil(classLoader);
        setQRCode(classLoader,context);
        hookHttpRequest(classLoader);
        log(classLoader);
    }

    private void baseinfo(final ClassLoader classLoader,final Context context){
        XposedHelpers.findAndHookMethod("com.alipay.mobile.quinox.LauncherActivity", classLoader, "onResume",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        String loginid = PayHelperUtils.getAlipayLoginId(classLoader);
                        PayHelperUtils.sendLoginId(loginid, AppConst.TYPE_ALIPAY, context);
                    }
                });
    }

    private void redPacket(ClassLoader classLoader, Context context){
        try {
            Class ChatMsgObj = classLoader.loadClass("com.alipay.mobile.socialcommonsdk.bizdata.chat.model.ChatMsgObj");
            Class SyncChatMsgModel = classLoader.loadClass("com.alipay.mobile.socialcommonsdk.bizdata.chat.model.SyncChatMsgModel");
            XposedHelpers.findAndHookConstructor(ChatMsgObj, String.class, SyncChatMsgModel, new ChatMsgObjCon(classLoader, context));//针对红包的
        }catch(ClassNotFoundException e){
            XposedBridge.log(e);
        }
    }

    private void checkBank(final ClassLoader classLoader, final Context context) {
        Class<?> insertServiceMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.ServiceDao", classLoader);
        Set<?> hooks = XposedBridge.hookAllMethods(insertServiceMessageInfo, "insertMessageInfo", new XC_MethodHook() {
            @SuppressLint("WrongConstant")
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                try {
                    Object object = param.args[0];
                    String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                    String content = StringUtils.getTextCenter(MessageInfo, "extraInfo='", "'").replace("\\", "");
                    XposedBridge.log("商家 MessageInfo >>"+MessageInfo);
                    if(content.contains("商家服务·店员通")){
                        Pattern moneyPattern = Pattern.compile("\"(\\d+\\.\\d+)\"");
                        Pattern timePattern = Pattern.compile("gmtCreate=(\\d+)");
                        Matcher mt = moneyPattern.matcher(content);
                        Matcher timemt = timePattern.matcher(MessageInfo);
                        if(mt.find() && timemt.find()){
                            Matcher markMt = Pattern.compile("今日第\\d笔收款，共计￥\\d+\\.\\d+").matcher(MessageInfo);
                            String mark = "店员通";
                            if(markMt.find()){
                                mark = markMt.group();
                            }
                            String money = mt.group(1);
                            String time = timemt.group(1);
                            String no = MD5.md5(money+time);
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("dt", time);
                            broadCastIntent.putExtra("no", no);
                            broadCastIntent.putExtra("money", money);
                            broadCastIntent.putExtra("mark", mark);
                            broadCastIntent.putExtra("dianyuan", "1");
                            broadCastIntent.putExtra("paytype", AppConst.TYPE_ALIPAY);
                            broadCastIntent.setAction(AppConst.HOOK_BILL_RECEIVED);
                            context.sendBroadcast(broadCastIntent);
                        }
                    }
                    if (content.contains("银行卡收款通知")) {
                        XposedBridge.log("======>银行卡到账通知");
                        String TFDetail = StringUtils.getTextCenter(MessageInfo, "assistMsg1\":", "已到账");
                        String name = StringUtils.getTextCenter(TFDetail, "\"", "通过");
                        String money = StringUtils.getTextCenter(TFDetail, "转账", "元");
                        String cardNo = StringUtils.getTextCenter(TFDetail, "尾号", "）");
                        //
                        XposedBridge.log("===>" + "付款人:" + name);
                        XposedBridge.log("===>" + "金额:" + money);
                        XposedBridge.log("===>" + "卡号:" + cardNo);
                        //
                        XposedBridge.log("支付宝监听银行卡");
                        long dt = System.currentTimeMillis();
                        String no = MD5.md5("alipay" + dt + cardNo + money);
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("bill_no", no);
                        broadCastIntent.putExtra("bill_money", money);
                        broadCastIntent.putExtra("bill_mark", "false");
                        broadCastIntent.putExtra("bill_wh", cardNo);
                        broadCastIntent.putExtra("bill_dt", dt);
                        broadCastIntent.putExtra("bill_type", AppConst.TYPE_BANK);
                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                        context.sendBroadcast(broadCastIntent);
                        //
                    }
                } catch (Exception e) {
                    PayHelperUtils.sendmsg(context, e.getMessage());
                }
                super.beforeHookedMethod(param);
            }
        });
        XposedBridge.log("----------商家订单:" + hooks.size() + "-----------");
    }

    private void checkTrade(final ClassLoader classLoader, final Context context) {
        Class<?> insertTradeMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.TradeDao", classLoader);
        XposedBridge.hookAllMethods(insertTradeMessageInfo, "insertMessageInfo", new XC_MethodHook() {
            @SuppressLint("WrongConstant")
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                try {
                    XposedBridge.log("======start=========");
                    //获取全部字段
                    Object object = param.args[0];
                    String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                    XposedBridge.log(JSON.toJSONString(object));
                    String content = MessageInfo;
                    //
                    String str = (String) XposedHelpers.callMethod(param.args[0], "toString", new Object[0]);
                    String midText = StringUtils.getTextCenter(str, "content='", "'");
                    String midText2 = StringUtils.getTextCenter(str, "link='", "'");
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("link===");
                    stringBuilder.append(midText2);
                    XposedBridge.log(stringBuilder.toString());
                    if (content.contains("收款到账") || content.contains("二维码收款")|| content.contains("收到一笔转账")) {
//                        //
                        JSONObject jsonObject = new JSONObject(JSON.toJSONString(object));
                        String dt = jsonObject.getString("gmtCreate");
                        JSONObject contentJson = new JSONObject(jsonObject.getString("content"));
                        String receiveAmount = contentJson.getString("content").replace("￥", "");
                        String remark = contentJson.getString("assistMsg2");
                        String crowdNo = jsonObject.optString("msgId");
                        Pattern p = Pattern.compile("tradeNO=(\\d+)&bizType");
                        Matcher mt = p.matcher(jsonObject.getString("link"));
                        if (mt.find()) {
                            crowdNo = mt.group(1);
                        }
                        getDetailTrade(crowdNo,context,"D_TRANSFER",classLoader);
                    }
                    XposedBridge.log("======end=========");
                } catch (Exception e) {
                    XposedBridge.log(e.getMessage());
                }
                super.beforeHookedMethod(param);
            }
        });
    }

    static class h5 implements InvocationHandler {
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            return null;
        }
    }

    public static void getDetailTrade(final String tradeno,final Context context,final String biztype,final ClassLoader mClassLoader) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    XposedBridge.log("开始获取订单结果");
                    Class clazz = XposedHelpers.findClass("com.alipay.mobile.h5container.api.H5Page",mClassLoader);
                    h5 _h = new h5();
                    Object objfunc3 = Proxy.newProxyInstance(mClassLoader, new Class[]{clazz}, _h);
                    Class clazzz = XposedHelpers.findClass("com.alipay.mobile.nebulaappproxy.api.rpc.H5RpcUtil", mClassLoader);
                    Object obj = XposedHelpers.callStaticMethod(clazzz,"rpcCall",
                            "alipay.mobile.bill.QuerySingleBillDetailForH5",
                            "[{\"bizType\":\""+biztype+"\",\"tradeNo\":\""+tradeno+"\"}]",
                            "",
                            Boolean.valueOf(true),
                            XposedHelpers.findClass("com.alibaba.fastjson.JSONObject", mClassLoader).newInstance(),
                            "",
                            Boolean.valueOf(false),
                            objfunc3,
                            Integer.valueOf(0),"",Boolean.valueOf(false), Integer.valueOf(-1));
                    Object objresponse = XposedHelpers.callMethod(obj,"getResponse");
                    Class classh5utils = XposedHelpers.findClass("com.alipay.mobile.nebula.util.H5Utils",mClassLoader);
                    Object result = XposedHelpers.callStaticMethod(classh5utils,"parseObject",objresponse);
                    XposedBridge.log("result >>>>>>>>> "+result);
                    try {
                        JSONObject response = new JSONObject(JsonHelper.toJson(result));
                        String code = response.optString("code");
                        JSONObject objextension = response.optJSONObject("extension");
                        String dt = objextension.getString("gmtBizCreateTime");
                        String strmdata = objextension.getString("mdata");
                        JSONObject objmdata = new JSONObject(strmdata);
                        String userid = objmdata.getString("conbiz_opp_uid");
                        String tradeNo =  objmdata.getString("conbiz_bizinno");
                        JSONArray objfields = response.getJSONArray("fields");
                        JSONObject userinfo = objfields.getJSONObject(0);
                        String struserinfo = userinfo.getString("value");
                        String usernick = new JSONObject(struserinfo).getString("content");// 昵称
                        JSONObject tradeinfo = objfields.getJSONObject(1);
                        String strtradeinfo = tradeinfo.getString("value");
                        JSONObject _tradeinfo = new JSONObject(strtradeinfo);
                        String amount = _tradeinfo.getString("amount");//金额
                        String states = _tradeinfo.getString("statusColor");// 颜色
                        JSONObject tradeinfo_1 = objfields.getJSONObject(3);
                        String strtradeinfo_1 = tradeinfo_1.getString("value");
                        String remark = new JSONObject(strtradeinfo_1).getJSONArray("data").getJSONObject(0).optString("content");
                        if(states.equals("#A5A5A5")){// 金额增加的
                            amount = amount.replace("+","");
                            Intent intent = new Intent();
                            intent.setAction(AppConst.HOOK_BILL_RECEIVED);
                            intent.putExtra("dt",PayHelperUtils.stampToDate(dt));
                            intent.putExtra("no", tradeNo);
                            intent.putExtra("uid",userid);
                            intent.putExtra("money", amount);
                            intent.putExtra("paytype", AppConst.TYPE_ALIPAY);
                            intent.putExtra("mark", remark);
                            intent.putExtra("wh",usernick);
                            XposedBridge.log("获取到的订单详情 支付时间："+dt+"\n订单号："+tradeNo+"\n付款者id："+userid+"\n金额："+amount+"\n备注："+remark+"\nwh"+usernick);
                            context.sendBroadcast(intent);
                        }else{
                            XposedBridge.log("支出的订单"+tradeNo+"备注"+remark);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
    private void log(ClassLoader classLoader){
        XposedHelpers.findAndHookMethod("com.alipay.mobile.common.transport.utils.LogCatUtil", classLoader, "info", String.class,String.class,new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if("HttpCaller".equals(""+param.args[0])){
                    XposedBridge.log("LogCatUtil info >>>> "+param.args[1]);
                }
            }
        });
        XposedHelpers.findAndHookMethod("com.alipay.mobile.common.transport.utils.LogCatUtil", classLoader, "printInfo", String.class,String.class,new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if("RpcInvoker".equals(""+param.args[0])){
                    XposedBridge.log("LogCatUtil printInfo >>>> "+param.args[1]);
                }
            }
        });
    }

    private void setQRCode(ClassLoader classLoader,final Context context){
        XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                XposedBridge.log("========支付宝设置金额start=========");
                Intent intent = ((Activity) param.thisObject).getIntent();
                if(intent == null){
                    XposedBridge.log("正在手动设置金额");
                    return;
                }
                Field jinErField = XposedHelpers.findField(param.thisObject.getClass(), "b");
                final Object jinErView = jinErField.get(param.thisObject);
                Field beiZhuField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                final Object beiZhuView = beiZhuField.get(param.thisObject);
//                Intent intent = ((Activity) param.thisObject).getIntent();
                String mark = intent.getStringExtra("mark");
                String money = intent.getStringExtra("money");
                //设置支付宝金额和备注
                XposedHelpers.callMethod(jinErView, "setText", money);
                XposedHelpers.callMethod(beiZhuView, "setText", mark);
                //点击确认
                Field quRenField = XposedHelpers.findField(param.thisObject.getClass(), "e");
                final Button quRenButton = (Button) quRenField.get(param.thisObject);
                quRenButton.performClick();
                XposedBridge.log("=========支付宝设置金额end========");
            }
        });

        // hook获得二维码url的回调方法
        XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "a",
                XposedHelpers.findClass("com.alipay.transferprod.rpc.result.ConsultSetAmountRes", classLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        XposedBridge.log("=========支付宝生成完成start========");
                        Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "g");
                        String money = (String) moneyField.get(param.thisObject);

                        Field markField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                        Object markObject = markField.get(param.thisObject);
                        String mark = (String) XposedHelpers.callMethod(markObject, "getUbbStr");

                        Object consultSetAmountRes = param.args[0];
                        Field consultField = XposedHelpers.findField(consultSetAmountRes.getClass(), "qrCodeUrl");
                        String payurl = (String) consultField.get(consultSetAmountRes);
                        XposedBridge.log(money + "  " + mark + "  " + payurl);

                        if (money != null) {
                            XposedBridge.log("调用增加数据方法==>支付宝");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("money", money);
                            broadCastIntent.putExtra("mark", mark);
                            broadCastIntent.putExtra("type", AppConst.TYPE_ALIPAY);
                            broadCastIntent.putExtra("payurl", payurl);
                            broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                        }
                        XposedBridge.log("=========支付宝生成完成end========");
                    }
                });
    }

    private void hookHttpRequest(ClassLoader classLoader){
        Class clazz = XposedHelpers.findClass("com.alipay.mobile.common.transport.http.HttpUrlRequest", classLoader);
        XposedHelpers.findAndHookConstructor(clazz, String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("HttpUrlRequest 构造 》》》 "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setReqData", byte[].class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setReqData "+new String((byte[])param.args[0],"utf-8"));
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setContentType", String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setContentType "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setResetCookie", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setResetCookie "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setCompress", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setCompress "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setBgRpc", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setBgRpc "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setUrgentFlag", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setUrgentFlag "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setTimeout", long.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setTimeout "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setAllowNonNet", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setAllowNonNet "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setSwitchLoginRpc", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setSwitchLoginRpc "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setDisableEncrypt", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setDisableEncrypt "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setEnableEncrypt", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setEnableEncrypt "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setBizLog", String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setBizLog "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setRpcHttp2", boolean.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setRpcHttp2 "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "addTags", String.class, String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest addTags id "+param.args[0]+" value "+param.args[1]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setRequestMethod", String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setRequestMethod "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "addHeader", XposedHelpers.findClass("org.apache.http.Header",classLoader), new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest addHeader "+param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod(clazz, "setHeader", XposedHelpers.findClass("org.apache.http.Header",classLoader), new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("hookHttpRequest setHeader "+param.args[0]);
            }
        });
    }

    private void hookH5RpcUtil( ClassLoader classLoader){
        Class clazzz = XposedHelpers.findClass("com.alipay.mobile.nebulaappproxy.api.rpc.H5RpcUtil", classLoader);
        XposedHelpers.findAndHookConstructor("com.alipay.mobile.common.rpc.transport.http.HttpCaller", classLoader,
                XposedHelpers.findClass("com.alipay.mobile.common.rpc.Config", classLoader),
                Method.class, int.class, String.class, byte[].class, String.class, Context.class,
                XposedHelpers.findClass("com.alipay.mobile.common.rpc.transport.InnerRpcInvokeContext", classLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        XposedBridge.log("HttpCaller 构造 >>>>>>>>>>\n Config >>"+param.args[0]+"\n Method>> "+param.args[1]+"\n int >> "+param.args[2]+"\n String >>"+param.args[3]+"\n byte[]>>"+new String((byte[])param.args[4])+"\n String >>"+param.args[5]+"\n Context >."+param.args[6]+"\n "+param.args[7]);
                    }
                });
        XposedHelpers.findAndHookMethod("com.alipay.mobile.common.rpc.transport.http.HttpCaller", classLoader, "call", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("HttpCaller call >>>>>>>>>> "+param.getResult());
            }
        });
        XposedHelpers.findAndHookMethod("com.alipay.mobile.common.rpc.RpcInvoker", classLoader, "a", Method.class,
                XposedHelpers.findClass("com.alipay.mobile.common.transport.Response", classLoader),
                XposedHelpers.findClass("com.alipay.mobile.common.rpc.protocol.util.RPCProtoDesc", classLoader), Object[].class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        XposedBridge.log("RpcInvoker a 解密的对象"+param.args[1]+"\n 解密后的内容："+JsonHelper.toJson(param.getResult()));
                    }
                });
//        XposedHelpers.findAndHookMethod("com.alipay.mobile.nebula.util.H5Utils", classLoader, "findServiceByInterface", String.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                super.afterHookedMethod(param);
//                XposedBridge.log("H5Utils findServiceByInterface >>>>>>>>>> "+param.args[0]+"\n result >>>>>>>>>>>>>>>"+param.getResult().getClass().getName());
//            }
//        });
        XposedHelpers.findAndHookMethod("com.alipay.mobile.nebulaappproxy.api.rpc.H5SimpleRpcService", classLoader, "setWalletSimpleService",
                XposedHelpers.findClass("com.alipay.mobile.framework.service.ext.SimpleRpcService", classLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                    }
                });
    }

    private void securityCheckHook(ClassLoader classLoader) {
        try {
            Class<?> securityCheckClazz = XposedHelpers.findClass("com.alipay.apmobilesecuritysdk.scanattack.common.ScanAttack", classLoader);
            XposedBridge.log("securityCheckClazz >>>> " + securityCheckClazz);
            XposedHelpers.findAndHookMethod(securityCheckClazz, "getAD104", Context.class, int.class, int.class, boolean.class,
                    int.class, int.class, String.class, new XC_MethodReplacement() {
                        @Override
                        protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                            XposedBridge.log("getAD104 param????????? " + methodHookParam.args[3]);
                            return null;
                        }
                    });

        } catch (Error | Exception e) {
            e.printStackTrace();
        }
    }
}
