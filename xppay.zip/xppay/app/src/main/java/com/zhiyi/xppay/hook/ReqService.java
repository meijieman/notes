package com.zhiyi.xppay.hook;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.item.ReqData;
import com.zhiyi.xppay.net.Socket.ClientManager;
import com.zhiyi.xppay.ui.MainActivity;
import com.zhiyi.xppay.utils.DBManager;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.OrderBean;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2018/11/20.
 */

public class ReqService extends Service implements Runnable{

    private static LinkedList<ReqData> reqlist;

    private Context mainContext;

    public void setMainContext(Context mainContext) {
        this.mainContext = mainContext;
    }

    public static void compare(ReqData data){
        for(ReqData tdate:reqlist){
            if(tdate.equals(data)){
                tdate.status = ReqData.Status_Comp;
            }
        }
    }

    public void addLast(ReqData data){
        if(!reqlist.contains(data)){
            reqlist.addLast(data);
        }
    }
    // 线程控制
    boolean isrunnig;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate(){
        //
        isrunnig = true;
        reqlist = new LinkedList<ReqData>();
        new Thread(this).start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(mainContext == null) setMainContext(getApplicationContext());
        String strData = intent.getStringExtra("reqdata");
        DBManager dbManager=new DBManager(CustomApplcation.getInstance().getApplicationContext());
        if(!strData.equals("")){
            ReqData data = JsonHelper.fromJson(strData,ReqData.class);
            addLast(data);
        }
        return START_STICKY;
    }

    @Override
    public void run() {
        while(isrunnig){
            try{
                do {
                    long now = System.currentTimeMillis();
                    if (reqlist.isEmpty()) {
                        break;
                    }
                    for (Iterator<ReqData> item = reqlist.iterator(); item.hasNext();){
                        ReqData data = item.next();
                        if(data.status == ReqData.Status_Query){
                            continue;
                        }
                        if(data.status == ReqData.Status_Error){
                            data.times++;
                        }
                        if(data.times>3 || data.status == ReqData.Status_Comp){
                            item.remove();
                            continue;
                        }
                        if(data.reqTime<now-10000){
                            data.reqTime = now;
                            postReq(data);
                            break;
                        }
                    }
                }
                while(false);
                Thread.sleep(5000);
            }
            catch (Throwable t){
                XposedBridge.log(t);
            }
        }
    }
    private void postReq(final ReqData data){
        XposedBridge.log("postReq订单轮询");
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("tradeno", data.getTradeno());
        broadCastIntent.setAction(AppConst.TRADEDETAIL_ACTION);
        mainContext.sendBroadcast(broadCastIntent);
        if(true) return;
		final String tadeo = data.getTradeno();
		String url="https://tradeeportlet.alipay.com/wireless/tradeDetail.htm?tradeNo="+tadeo+"&source=channel&_from_url=https%3A%2F%2Frender.alipay.com%2Fp%2Fz%2Fmerchant-mgnt%2Fsimple-order._h_t_m_l_%3Fsource%3Dmdb_card";
        final DBManager dbManager=new DBManager(CustomApplcation.getInstance().getApplicationContext());
		try {

			HttpUtils httpUtils=new HttpUtils(15000);
			httpUtils.configResponseTextCharset("GBK");
			RequestParams params=new RequestParams();
			params.addHeader("Cookie", data.cookie);
			data.status = 1;
			httpUtils.send(HttpRequest.HttpMethod.GET, url,params, new RequestCallBack<String>() {

				@Override
				public void onFailure(HttpException arg0, String arg1) {
					data.status = ReqData.Status_Error;
					PayHelperUtils.sendmsg(mainContext,"服务器异常"+arg1);
                    dbManager.updateTradeStep0(tadeo);
				}

				@Override
				public void onSuccess(ResponseInfo<String> arg0) {
					try {
					    // 判断
                        if(dbManager.isFinishedTradeNo(tadeo)){
                            return;
                        }
						String result=arg0.result;
						Document document= Jsoup.parse(result);
						Elements elements=document.getElementsByClass("trade-info-value");

						if(elements.size()>=5){
							String money=elements.get(2).ownText();
							String mark=elements.get(3).ownText();
							String dt=elements.get(1).ownText();
							DBManager dbManager=new DBManager(CustomApplcation.getInstance().getApplicationContext());
//							dbManager.addOrder(new OrderBean(money, mark, MainActivity.TYPE_ALIPAY, tadeo, dt, "", 0));
                            dbManager.updateTradeStep2(new OrderBean(money, mark, MainActivity.TYPE_ALIPAY, tadeo, dt, "", 0));
                            MainActivity.sendmsg("收到支付宝订单,订单号："+tadeo+"金额："+money+"备注："+mark);
							data.status = ReqData.Status_Comp;
							ClientManager.getInstance().sendPayOverNotify(MainActivity.TYPE_ALIPAY,tadeo,money,mark,dt,"");
						}
					} catch (Exception e) {
						PayHelperUtils.sendmsg(mainContext, "TRADENORECEIVED_ACTION-->>onSuccess异常"+e.getMessage());
					}
				}
			});
		} catch (Exception e) {
			PayHelperUtils.sendmsg(mainContext, "TRADENORECEIVED_ACTION异常"+e.getMessage());
		}
	}
    @Override
    public void onDestroy() {
        super.onDestroy();
        isrunnig = false;
        // 如果Service被杀死 重启自己
        Intent intent = new Intent(getApplicationContext(),ReqService.class);
        startService(intent);
    }
}
