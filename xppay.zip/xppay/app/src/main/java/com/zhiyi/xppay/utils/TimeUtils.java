package com.zhiyi.xppay.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Administrator on 2019/4/1.
 */

public class TimeUtils {
    private static long l;

    // 将字符串转为时间戳
    public static long getTime(String user_time,String pattern) {
        String re_time = null;
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        Date d;
        try {
            d = sdf.parse(user_time);
            l = d.getTime();

            String str = String.valueOf(l);
            re_time = str.substring(0, str.length());

        } catch (java.text.ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return l;
    }

    // 将时间戳转为字符串
    public static String getStrTime(long cc_time) {
        String re_StrTime = null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // 例如：cc_time=1291778220
        long lcc_time = Long.valueOf(cc_time);
        re_StrTime = sdf.format(new Date(lcc_time));

        return re_StrTime;

    }

    public static String getCurrentYear(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年");
        Date date = new Date();
        return sdf.format(date);
    }
}
