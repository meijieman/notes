package com.zhiyi.xppay.net.Socket;

//copy this and rename to ConnectInfo
public  class ConnectInfo2 {
    public static String ip="xpapi.ukafu.com";
    public static String port="9988";
    public static final boolean isDebug = false;
}
