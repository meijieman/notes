package com.zhiyi.xppay.hook.v138;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.StringUtils;

import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class ChatMsgObjCon extends XC_MethodHook {

    ClassLoader classLoader;
    Context context;
    public String transRemark;
    public String transTradeNo;

    public ChatMsgObjCon(ClassLoader classLoader, Context context) {
        this.classLoader = classLoader;
        this.context = context;
    }

    @Override
    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
        Object SyncChatMsgModel = param.args[1];
        if (SyncChatMsgModel == null) {
            return;
        }
        XposedBridge.log("SyncChatMsgModel>>>>>>>>>>>>>>>" + SyncChatMsgModel + "》》》》》》》》》》" + XposedHelpers.getObjectField(SyncChatMsgModel, "toType"));
        String bizType = (String) XposedHelpers.getObjectField(SyncChatMsgModel, "bizType");
        String clientMsgId = (String) XposedHelpers.getObjectField(SyncChatMsgModel, "clientMsgId");
        String link = (String) XposedHelpers.getObjectField(SyncChatMsgModel, "link");
        String templatedata = (String) XposedHelpers.getObjectField(SyncChatMsgModel, "templateData");
        String dt = XposedHelpers.getObjectField(SyncChatMsgModel, "createTimeMills") + "";
        if (TextUtils.isEmpty(bizType) || !bizType.equals("GIFTSHARE")) {
            return;
        }

        if (TextUtils.isEmpty(link)) {
            PayHelperUtils.sendmsg(context, "link为空");
            return;
        }
        Uri uri = Uri.parse(link);
        String prevBiz = uri.getQueryParameter("prevBiz");
        String sign = uri.getQueryParameter("sign");
        String crowdNo = uri.getQueryParameter("crowdNo");
        new ReceiveCrowdTask(
                classLoader, crowdNo, null,
                sign, prevBiz, clientMsgId,
                "1", "",
                null, null, context, dt).execute();

    }
}
