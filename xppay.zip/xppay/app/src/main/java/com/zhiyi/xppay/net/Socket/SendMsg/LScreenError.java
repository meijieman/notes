package com.zhiyi.xppay.net.Socket.SendMsg;

/**
 * 锁屏产生的异常
 * Created by pc_mg on 2018/11/29.
 */

public class LScreenError extends TransMessage {
    public int duputytype;
    public String paytype;
    public String mark;
    public LScreenError(int type) {
        super(type);
    }
    public String toString() {
        return "LScreenError{" +
                "type=" + type +
                ",duputytype='" + duputytype + '\'' +
                ",paytype='" + paytype +'\''+
                ",mark='"+mark+'\''+
                "}";
    }
}
