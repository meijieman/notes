package com.zhiyi.xppay.hook.mayou;

import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.net.Socket.ClientManager;
import com.zhiyi.xppay.utils.PayHelperUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/4/12.
 */

public class QueryTrade {
    protected LinkedList<TradeBean> getTradeList;
    protected ArrayList<TradeBean> reciveTradeList;

    protected boolean isStart;

    protected ClientManager mng;

    public QueryTrade(ClientManager mng) {
        isStart = false;
        getTradeList = new LinkedList<>();
        reciveTradeList = new ArrayList<>();
        this.mng = mng;
    }
    public void CreateTrade(String money,String remark){
        TradeBean bean = new TradeBean();
        bean.mark = remark;
        bean.state = 0;
        getTradeList.addFirst(bean);
        XposedBridge.log(">>>>>>> 添加了一个新的轮询订单 >>>>>>> "+bean);
        if (!isStart){
            isStart = true;
            startQueryTrade();
        }
    }

    public void receiveOrderBean(TradeBean data) {
        XposedBridge.log("收到订单反馈》》》》");
        reciveTradeList.add(data);
    }

    private void SendOrderBean(String orderbean){
        XposedBridge.log(">>>>>>> 开始轮询订单 >>>>>>> "+orderbean);
        Context context = mng.getContext();
        Intent intent = new Intent();
        intent.setAction(AppConst.ACTION_ORDERCOMPLETE_MAYOU);
        intent.putExtra("orderno", orderbean);
        context.sendBroadcast(intent);
    }

    private TradeBean bean;

    private void startQueryTrade(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (!getTradeList.isEmpty()) {
                    try {
                        bean = getTradeList.getLast();
                        //
                        XposedBridge.log("遍历收到的订单");
//                        SendOrderBean(bean.orderno);
                        long time = System.currentTimeMillis();
                        while (true) {
                            TradeBean receive = getOrderBeanByState(bean);
                            float t_wait= 10;
                            if (receive == null && System.currentTimeMillis() - time < t_wait * 1000) {
                                Thread.sleep(200);
                            } else {
                                if (receive != null) {
                                    getTradeList.removeLast();
                                    reciveTradeList.remove(receive);
                                }
                                break;
                            }
                        }
                        if (!getTradeList.isEmpty()) {
                            Thread.sleep(1500);
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                isStart = false;
            }
        }).start();
    }
    public synchronized TradeBean getOrderBeanByState(TradeBean bcode) {
        TradeBean rcode = null;
        for (Iterator<TradeBean> o = reciveTradeList.iterator(); o.hasNext(); ) {
            TradeBean code = o.next();
            if(code.mark.equals(bcode.mark)&&code.state == 1){
                XposedBridge.log("完成的订单号》》》");
                return code;
            }
        }
        return rcode;
    }
}
