package com.zhiyi.xppay.hook.v138;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.AbSharedUtil;
import com.zhiyi.xppay.utils.JsonHelper;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/4/27.
 */

public class AliFixedPosition {
    private static Context mContext;
    public static void setFixedPosition(String _latitude,String _longitude){
        try {
            SaveFixedPosition(mContext,_latitude,_longitude);
            XposedBridge.log("要修改的坐标lat"+_latitude+"longit"+_longitude);
        }catch(Exception e){
            XposedBridge.log("经纬度信息错误");
        }
    }

    private static void SaveFixedPosition(Context context, String _latitude,String _longitude){
        String info = AbSharedUtil.getString(context,"latitude");
        if(!info.equals(_latitude)){
            AbSharedUtil.putString(context,"latitude",_latitude);
        }
        info = AbSharedUtil.getString(context,"longitude");
        if(!info.equals(_longitude)){
            AbSharedUtil.putString(context,"longitude",_longitude);
        }
        XposedBridge.log("SaveFixedPosition保存的位置信息 _latitude"+_latitude+"_longitude"+_longitude);
    }

    public static boolean isFiexed(double _latitude,double _longitude){
        return (_latitude>0&&_longitude>0);
    };
    private static void fixed(Object object){
        String lat = AbSharedUtil.getString(mContext,"latitude");
        String lon = AbSharedUtil.getString(mContext,"longitude");
        if(TextUtils.isEmpty(lat)||TextUtils.isEmpty(lon)) return;
        double _latitude = Double.parseDouble(lat);
        double _longitude = Double.parseDouble(lon);
        if(isFiexed(_latitude,_longitude)&&object!=null){
            XposedHelpers.callMethod(object,"setLatitude",_latitude);
            XposedHelpers.callMethod(object,"setLongitude",_longitude);
        }
    }
    public static void fixedpostition(ClassLoader classLoader, Context context){
        mContext = context;
        XposedHelpers.findAndHookMethod(XposedHelpers.findClass("com.alipay.mobile.common.lbs.LBSLocationCustomManager", classLoader),"getLBSLocation",
                XposedHelpers.findClass("com.alipay.mobile.common.lbs.LBSLocationRequest",classLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Object location = param.getResult();
                        fixed(location);
                    }
                });
        XposedHelpers.findAndHookMethod("com.alipay.mobilelbs.biz.util.c", classLoader, "a", SharedPreferences.class,
                XposedHelpers.findClass("com.alipay.mobile.common.lbs.LBSLocation", classLoader), boolean.class, String.class, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        super.beforeHookedMethod(param);
                        fixed(param.args[1]);
                    }
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Object lat = XposedHelpers.callMethod(param.args[1],"getLatitude");
                        Object longit = XposedHelpers.callMethod(param.args[1],"getLongitude");
                        XposedBridge.log("修改后的坐标的lat"+lat+"longit"+longit);
                    }
                });
    }
}
