package com.zhiyi.xppay.item;

/**
 * Created by Administrator on 2018/11/19.
 */

public class ReqData {
    public final static int Status_New = 0;
    public final static int Status_Query = 1;
    public final static int Status_Error = 5;
    public final static int Status_Comp = 200;
    public ReqData(String tradeno){
        if(tradeno == null){
            tradeno = "what?";
        }
        this.tradeno = tradeno;
        status = Status_New;
    }
    private String tradeno;
    public String getTradeno(){
        return tradeno;
    }
    public static String cookie;
    public int status;
    public int times;
    public long reqTime;

    @Override
    public String toString() {
        return tradeno;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof ReqData){
            if(tradeno == null){
                return false;
            }
            if(tradeno.equals(obj.toString())){
                return true;
            }
        }
        return false;
    }
}
