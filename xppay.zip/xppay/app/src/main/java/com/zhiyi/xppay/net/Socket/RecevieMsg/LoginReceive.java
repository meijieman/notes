package com.zhiyi.xppay.net.Socket.RecevieMsg;

/**
 * Created by pc_unity on 2018/10/25.
 */

public class LoginReceive {
    public String token;
    public String appid;
    public String weburl;
    public String name;
    public String paytype;
    public int type;
    @Override
    public String toString() {
        return "LoginReceive:{" +
                "token='" + token + '\'' +
                ",appid='" + appid + '\'' +
                ",type=" + type +
                ",name='" + name + '\'' +
                ",paytype='" + paytype + '\'' +
                "}";
    }
}
