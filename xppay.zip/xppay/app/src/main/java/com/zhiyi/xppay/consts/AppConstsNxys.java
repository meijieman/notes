package com.zhiyi.xppay.consts;

/**
 * Created by pc_mg on 2019/3/9.
 */

public class AppConstsNxys {
    public final static String TYPE_NXYS = "NXYS";
    public final static String TYPE_NXYS_WX = "NXYSWX";
    public final static String PACKAGENAME = "com.buybal.buybalpay.nxy";
    // activity
    public final static String ACTION_MSGRECEIVED = "com.zhiyi.nxysmc.msg";
    public final static String ACTION_SENDQRCODE = "com.zhiyi.nxysmc.sendqrcode";
    public final static String ACTION_SENDTRADE = "com.zhiyi.nxysmc.sendtrade";
    public final static String ACTION_STARTTRADEQUERY = "com.zhiyi.nxysmc.starttradequery";
    // main
    public final static String ACTION_CREATEQRCODE = "com.zhiyi.nxysmc.createqr";
    public final static String ACTION_ACTIVITYSTART = "com.zhiyi.nxysmc.activitystart";
    public final static String ACTION_TRADEQUERY = "com.zhiyi.nxysmc.tradequery";
    public final static String ACTION_LOGINED = "com.zhiyi.nxysmc.logined";
}
