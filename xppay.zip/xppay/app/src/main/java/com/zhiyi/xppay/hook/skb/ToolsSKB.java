package com.zhiyi.xppay.hook.skb;

import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;

/**
 * Created by pc_mg on 2019/4/1.
 */

public class ToolsSKB {
    public static boolean ishookeed;// hook到
    public static boolean isactivitystart;// activity开启
    public static void CreateQRCode(String loation,String amount,int paytype,String mark){
        Hook51SKB.CreateQRCode(loation,amount,paytype,mark);
    }

    public static void QueryTrade(Context context){
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(AppConst.ACTION_STARTTRADEQUERY_SKB);
        context.sendBroadcast(broadCastIntent);
    }
    public static void sendActivitystart(Context context) {
        Intent intent = new Intent();
        intent.setAction(AppConst.ACTION_ACTIVITYSTART_SKB);
        context.sendBroadcast(intent);
    }
}
