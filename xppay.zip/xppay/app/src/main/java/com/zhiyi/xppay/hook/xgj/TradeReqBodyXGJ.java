package com.zhiyi.xppay.hook.xgj;

import com.zhiyi.xppay.utils.JsonHelper;

/**
 * Created by pc_mg on 2019/3/21.
 */

public class TradeReqBodyXGJ {
    String usr_no;
    String token_id;
    String eqm_type;
    String version;
    String characterSet;
    String opSys;
    String channel;
    String sys_cnl;

    public TradeReqBodyXGJ(String userno, String token_id, String eqm_type, String version, String characterSet, String opSys, String channel, String sys_cnl) {
        this.usr_no = userno;
        this.token_id = token_id;
        this.eqm_type = eqm_type;
        this.version = version;
        this.characterSet = characterSet;
        this.opSys = opSys;
        this.channel = channel;
        this.sys_cnl = sys_cnl;

    }

    public String toJson() {
        String sendStr = JsonHelper.toJson(this);
        return sendStr;
    }
}
