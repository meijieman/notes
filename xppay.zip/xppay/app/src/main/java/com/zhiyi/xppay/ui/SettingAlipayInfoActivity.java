package com.zhiyi.xppay.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;

import com.zhiyi.xppay.R;
import com.zhiyi.xppay.hook.CustomApplcation;
import com.zhiyi.xppay.utils.DBManager;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2018/12/18.
 */

public class SettingAlipayInfoActivity extends Activity implements View.OnClickListener {
    private EditText et_passward, et_money, et_alipayaccount, et_bankaccount, et_bankcardno;
    RadioGroup radioGroupwithdraw;
    DBManager dbManager;
    int withdrawtype = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
        setContentView(R.layout.activity_settingalipay);
        //
        et_passward = (EditText) findViewById(R.id.passward);
        et_passward.setText(dbManager.getAlipwd());
        //
        et_money = (EditText) findViewById(R.id.money);
        et_money.setText(dbManager.getAliwithcount());
        //
        et_alipayaccount = (EditText) findViewById(R.id.alipayaccount);
        et_alipayaccount.setText(dbManager.getAlipayaccount());
        //
        et_bankaccount = (EditText) findViewById(R.id.bankaccount);
        et_bankaccount.setText(dbManager.getBankaccount());
        //
        et_bankcardno = (EditText) findViewById(R.id.bankcardno);
        et_bankcardno.setText(dbManager.getBankcardno());
        //
        radioGroupwithdraw = (RadioGroup) findViewById(R.id.withdrawtype);
        radioGroupwithdraw.setOnCheckedChangeListener(listen);
        radioGroupwithdraw.check(R.id.withdrawalipay);
        //
        Button butconfirm = (Button) findViewById(R.id.savealipay);
        butconfirm.setOnClickListener(this);
        //
        ImageButton butback = (ImageButton) findViewById(R.id.ialp_withdraw_back);
        butback.setOnClickListener(this);
    }

    private RadioGroup.OnCheckedChangeListener listen = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            int id = group.getCheckedRadioButtonId();
            switch (group.getCheckedRadioButtonId()) {
                case R.id.withdrawalipay:
                    withdrawtype = 0;
                    break;
                case R.id.transfertobank:
                    withdrawtype = 1;
                    break;
                case R.id.transfertoalipay:
                    withdrawtype = 2;
                    break;
            }
        }
    };

    @Override
    public void onClick(View view) {
        XposedBridge.log("view == "+view.getId());
        switch (view.getId()) {
            case R.id.savealipay:
                if (et_passward.getText().length() != 6) {
                    XposedBridge.log("密码长度不对");
                    return;
                }
                if (et_money.getText().equals("") || Float.parseFloat(et_money.getText().toString()) <= 0.11) {
                    XposedBridge.log("金额过小，请重新设置");
                    return;
                }
                if(withdrawtype<0){
                    XposedBridge.log("未选择支付方式");
                    return;
                }
                //
                DBManager dbManager = new DBManager(CustomApplcation.getContext());
                dbManager.setAlipayInfo(
                        et_passward.getText().toString().trim(),
                        et_money.getText().toString().trim(),
                        et_bankcardno.getText().toString().trim(),
                        et_bankaccount.getText().toString().trim(),
                        et_alipayaccount.getText().toString().trim(),
                        withdrawtype);
                finish();
                break;
            case R.id.ialp_withdraw_back:
                finish();
                break;
        }
    }
}
