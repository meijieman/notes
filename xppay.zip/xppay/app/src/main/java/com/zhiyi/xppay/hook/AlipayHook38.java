package com.zhiyi.xppay.hook;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.widget.Button;

import com.alibaba.fastjson.JSON;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.v138.AliFixedPosition;
import com.zhiyi.xppay.hook.v138.ChatMsgObjCon;
import com.zhiyi.xppay.hook.v138.ScanOrder;
import com.zhiyi.xppay.hook.v138.Tools;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.MD5;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.StringUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;


public class AlipayHook38 {


    public static ClassLoader mClassLoader;

    public static void sendMsg(String userid, String content) {
        final Class<?> msgFac = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.sender.MessageFactory", mClassLoader);

        XposedHelpers.callStaticMethod(msgFac, "createTextMsg", userid, "1", content, null, null, false);
    }

    public void hook(final ClassLoader classLoader, final Context context) {
        securityCheckHook(classLoader);
        mClassLoader = classLoader;
        try {
            Class<?> chatCallback = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.data.ChatDataSyncCallback", classLoader);

            Class ChatMsgObj = classLoader.loadClass("com.alipay.mobile.socialcommonsdk.bizdata.chat.model.ChatMsgObj");
            Class SyncChatMsgModel = classLoader.loadClass("com.alipay.mobile.socialcommonsdk.bizdata.chat.model.SyncChatMsgModel");
            XposedHelpers.findAndHookConstructor(ChatMsgObj, String.class, SyncChatMsgModel, new ChatMsgObjCon(classLoader, context));//针对红包的
//            // hook获取loginid
            XposedHelpers.findAndHookMethod("com.alipay.mobile.quinox.LauncherActivity", classLoader, "onResume",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            String loginid = PayHelperUtils.getAlipayLoginId(classLoader);
                            PayHelperUtils.sendLoginId(loginid, AppConst.TYPE_ALIPAY, context);
                        }
                    });
            final Class<?> syncmsg = XposedHelpers.findClass("com.alipay.mobile.rome.longlinkservice.syncmodel.SyncMessage", classLoader);
            final Class<?> msgFac = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.sender.MessageFactory", classLoader);
            final Class<?> chatP = XposedHelpers.findClass("com.alipay.mobile.chatapp.ui.PersonalChatMsgActivity_", classLoader);
            final Class<?> wire = XposedHelpers.findClass("com.squareup.wire.Wire", classLoader);
            final Class<?> msgPModel = XposedHelpers.findClass("com.alipay.mobilechat.core.model.message.MessagePayloadModel", classLoader);
            XposedHelpers.findAndHookMethod(chatP, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Intent intent = ((Activity) param.thisObject).getIntent();
                    Bundle bundle = intent.getExtras();
                    Set<String> set = bundle.keySet();
                    for (String string : set) {
                        XposedBridge.log("key=" + string + "--value=" + bundle.get(string));
                    }
                }
            });
            XposedBridge.hookAllMethods(msgFac, "createCommonMessage", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log(" createCommonMessage " + Arrays.toString(param.args));
                    if (param.args.length >= 4) {
                        Object o = param.args[3];
                        if (o.getClass().toString().contains("CommonMediaInfo")) {
                            XposedBridge.log("CommonMediaInfo " + JSON.toJSONString(o));
                        }
                    }
                }
            });


            XposedHelpers.findAndHookMethod(chatCallback, "onReceiveMessage", syncmsg,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            super.afterHookedMethod(param);
                            Object object = param.args[0];
                            JSONArray msgArr = new JSONArray(syncmsg.getField("msgData").get(object).toString());
                            JSONObject msg1 = msgArr.getJSONObject(0);
                            XposedBridge.log("消息 " + msgArr);
                            String pl = msg1.getString("pl");
                            Object wireIns = XposedHelpers.newInstance(wire, new ArrayList<Class>());
                            Object decode_pl = XposedHelpers.callMethod(wireIns, "parseFrom", Base64.decode(pl, 0), msgPModel);
                            String decode_pl_str = JSON.toJSONString(decode_pl);
                            com.alibaba.fastjson.JSONObject decode_pl_json = JSON.parseObject(decode_pl_str);
                            String biz_type = decode_pl_json.getString("biz_type");
                            String content = decode_pl_json.getJSONObject("template_data").getString("m");
                            final String userid = decode_pl_json.getString("from_u_id");
                            //自动回复
                            if (biz_type.equals("CHAT")) {
                                if (content.contains("a")) {
                                    String money = content.split("a")[0];
                                    String remark = content.split("a")[1];
                                    Tools.sendBillMsg(userid, money, remark,classLoader);
                                    PayHelperUtils.sendmsg(context, "获取到支付消息，金额" + money + "，备注" + remark);
                                }


                            } else if (biz_type.equals("GIFTSHARE")) {
                                //sendMsg(userid,"感谢您的充值！正在自动领取 >>>>>");

                            }

                        }
                    });
            //*************************
            checkTrade(classLoader, context);
            checkBank(classLoader, context);
//            scanQrcode(classLoader, context);
            hookH5Response(classLoader, context);
            hookPersonalQrcode(classLoader, context);
            fixedPosition(classLoader,context);
            setQRCode(classLoader,context);
            //**************************
        } catch (Error | Exception e) {
            PayHelperUtils.sendmsg(context, e.getMessage());
        }
        Class clazzz = XposedHelpers.findClass("com.alipay.mobile.nebulabiz.rpc.H5RpcUtil", mClassLoader);
        XposedBridge.hookAllMethods(clazzz, "rpcCall", new XC_MethodHook() {
//            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if(param.args.length>11)
                    XposedBridge.log("rpcCall 参数 str>>"+param.args[0]+"\nstr2"+param.args[1]+"\nstr3"+param.args[2]+"\nz"+param.args[3]
                            +"\njSONObject"+param.args[4]+"\nstr4"+param.args[5]+"\nz2"+param.args[6]
                            +"\nh5Page"+param.args[7]+"\n"+param.args[8]+"\nstr5"+param.args[9]+"\nz3"+param.args[10]+"\ni2"+param.args[11]+"\n result >>"+JsonHelper.toJson(param.getResult()));
            }
        });
    }

    public static void setQRCode(ClassLoader classLoader,final Context context){
        XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                XposedBridge.log("========支付宝设置金额start=========");
                Field jinErField = XposedHelpers.findField(param.thisObject.getClass(), "b");
                final Object jinErView = jinErField.get(param.thisObject);
                Field beiZhuField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                final Object beiZhuView = beiZhuField.get(param.thisObject);
                Intent intent = ((Activity) param.thisObject).getIntent();
                String mark = intent.getStringExtra("mark");
                String money = intent.getStringExtra("money");
                //设置支付宝金额和备注
                XposedHelpers.callMethod(jinErView, "setText", money);
                XposedHelpers.callMethod(beiZhuView, "setText", mark);
                //点击确认
                Field quRenField = XposedHelpers.findField(param.thisObject.getClass(), "e");
                final Button quRenButton = (Button) quRenField.get(param.thisObject);
                quRenButton.performClick();
                XposedBridge.log("=========支付宝设置金额end========");
            }
        });

        // hook获得二维码url的回调方法
        XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "a",
                XposedHelpers.findClass("com.alipay.transferprod.rpc.result.ConsultSetAmountRes", classLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        XposedBridge.log("=========支付宝生成完成start========");
                        Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "g");
                        String money = (String) moneyField.get(param.thisObject);

                        Field markField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                        Object markObject = markField.get(param.thisObject);
                        String mark = (String) XposedHelpers.callMethod(markObject, "getUbbStr");

                        Object consultSetAmountRes = param.args[0];
                        Field consultField = XposedHelpers.findField(consultSetAmountRes.getClass(), "qrCodeUrl");
                        String payurl = (String) consultField.get(consultSetAmountRes);
                        XposedBridge.log(money + "  " + mark + "  " + payurl);

                        if (money != null) {
                            XposedBridge.log("调用增加数据方法==>支付宝");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("money", money);
                            broadCastIntent.putExtra("mark", mark);
                            broadCastIntent.putExtra("type", AppConst.TYPE_ALIPAY);
                            broadCastIntent.putExtra("payurl", payurl);
                            broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                        }
                        XposedBridge.log("=========支付宝生成完成end========");
                    }
                });
    }

    public static void setFixedPosition(String latitude,String longitude){
        AliFixedPosition.setFixedPosition(latitude,longitude);
    }

    void fixedPosition(ClassLoader classLoader,Context context){
        AliFixedPosition.fixedpostition(classLoader,context);
    }

    static class h5 implements InvocationHandler {
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            String methodName = method.getName();
            return null;
        }
    }

    public static void getDetailTrade(final String tradeno,final Context context,final String biztype) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    XposedBridge.log("开始获取订单结果");
                    Class clazz = XposedHelpers.findClass("com.alipay.mobile.h5container.api.H5Page",mClassLoader);
                    h5 _h = new h5();
                    Object objfunc3 = Proxy.newProxyInstance(mClassLoader, new Class[]{clazz}, _h);
                    Class clazzz = XposedHelpers.findClass("com.alipay.mobile.nebulabiz.rpc.H5RpcUtil", mClassLoader);
                    Object obj = XposedHelpers.callStaticMethod(clazzz,"rpcCall",
                            "alipay.mobile.bill.QuerySingleBillDetailForH5",
                            "[{\"bizType\":\""+biztype+"\",\"tradeNo\":\""+tradeno+"\"}]",
                            "",
                            Boolean.valueOf(true),
                            XposedHelpers.findClass("com.alibaba.fastjson.JSONObject", mClassLoader).newInstance(),
                            "",
                            Boolean.valueOf(false),
                            objfunc3,
                            Integer.valueOf(0),"",Boolean.valueOf(false), Integer.valueOf(-1));
                    Object objresponse = XposedHelpers.callMethod(obj,"getResponse");
                    Class classh5utils = XposedHelpers.findClass("com.alipay.mobile.nebula.util.H5Utils",mClassLoader);
                    Object result = XposedHelpers.callStaticMethod(classh5utils,"parseObject",objresponse);
                    XposedBridge.log("result >>>>>>>>> "+result);
                    try {
                        JSONObject response = new JSONObject(JsonHelper.toJson(result));
                        String code = response.optString("code");
                        JSONObject objextension = response.optJSONObject("extension");
                        String dt = objextension.getString("gmtBizCreateTime");
                        String strmdata = objextension.getString("mdata");
                        JSONObject objmdata = new JSONObject(strmdata);
                        String userid = objmdata.getString("conbiz_opp_uid");
                        String tradeNo =  objmdata.getString("conbiz_bizinno");
                        JSONArray objfields = response.getJSONArray("fields");
                        JSONObject userinfo = objfields.getJSONObject(0);
                        String struserinfo = userinfo.getString("value");
                        String usernick = new JSONObject(struserinfo).getString("content");// 昵称
                        JSONObject tradeinfo = objfields.getJSONObject(1);
                        String strtradeinfo = tradeinfo.getString("value");
                        JSONObject _tradeinfo = new JSONObject(strtradeinfo);
                        String amount = _tradeinfo.getString("amount");//金额
                        String states = _tradeinfo.getString("statusColor");// 颜色
                        JSONObject tradeinfo_1 = objfields.getJSONObject(3);
                        String strtradeinfo_1 = tradeinfo_1.getString("value");
                        String remark = new JSONObject(strtradeinfo_1).getJSONArray("data").getJSONObject(0).optString("content");
                        if(states.equals("#A5A5A5")){// 金额增加的
                            amount = amount.replace("+","");
                            Intent intent = new Intent();
                            intent.setAction(AppConst.HOOK_BILL_RECEIVED);
                            intent.putExtra("dt",PayHelperUtils.stampToDate(dt));
                            intent.putExtra("no", tradeNo);
                            intent.putExtra("uid",userid);
                            intent.putExtra("money", amount);
                            intent.putExtra("paytype", AppConst.TYPE_ALIPAY);
                            intent.putExtra("mark", remark);
                            intent.putExtra("wh",usernick);
                            XposedBridge.log("获取到的订单详情 支付时间："+dt+"\n订单号："+tradeNo+"\n付款者id："+userid+"\n金额："+amount+"\n备注："+remark+"\nwh"+usernick);
                            context.sendBroadcast(intent);
//                            if(biztype.equals("TRADE")){
//                                intent.removeExtra("dt");
//                                intent.removeExtra("uid");
//                                intent.removeExtra("money");
//                                intent.removeExtra("paytype");
//                                intent.removeExtra("mark");
//                                intent.removeExtra("wh");
//                                intent.setAction(AppConst.HOOK_COMPAREORDER_ACTION);
//                                context.sendBroadcast(intent);
//                            }
                        }else{
                            XposedBridge.log("支出的订单"+tradeNo+"备注"+remark);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void hookPersonalQrcode(ClassLoader classLoader, final Context context) {
        XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRActivity", classLoader, "a",
                XposedHelpers.findClass("com.alipay.transferprod.rpc.result.CreateSessionRes", classLoader), new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        super.beforeHookedMethod(param);
                        String url = "" + XposedHelpers.getObjectField(param.args[0], "printQrCodeUrl");
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("qrcode", url);
                        broadCastIntent.setAction(AppConst.PERSONALQRCODE);
                        context.sendBroadcast(broadCastIntent);
                        PayHelperUtils.startAPP();
                    }
                });
    }

    private void scanQrcode(ClassLoader classLoader, Context context) {
        ScanOrder.HookH5Activity(classLoader, context);
    }

    private void hookH5Response(ClassLoader classLoader, final Context context) {
        try {
            XposedBridge.hookAllConstructors(XposedHelpers.findClass("com.alipay.mobile.nebulabiz.rpc.H5Response", classLoader), new XC_MethodHook() {
                protected void beforeHookedMethod(final MethodHookParam methodHookParam) throws Throwable {
                    super.beforeHookedMethod(methodHookParam);
                    if (methodHookParam.args.length > 1 && methodHookParam.args[1] != null) {
                        //
                        String str = (String) methodHookParam.args[1];
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("获取到网页请求结果： ");
                        stringBuilder.append(str + " ===== " + methodHookParam.args[2]);
                        XposedBridge.log(stringBuilder.toString());
                        if (!TextUtils.isEmpty(str) && str.contains("actionType=toAccount&userId")) {
                            String midText = StringUtils.getTextCenter(str, "actionType=toAccount&userId=", "&sourceId=bill");
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("aliUserId");
                            stringBuilder2.append(midText);
                            XposedBridge.log(stringBuilder2.toString());
                            String midText2 = StringUtils.getTextCenter(str, "+", "\\\"");
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("money");
                            stringBuilder3.append(midText2);
                            XposedBridge.log(stringBuilder3.toString());
                            str = StringUtils.getTextCenter(str, "\"bizInNo\":\"", "\"");
                            stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("tradeNo");
                            stringBuilder3.append(str);
                            XposedBridge.log(stringBuilder3.toString());
                            int intValue = new BigDecimal(midText2.trim().replace(",", "")).multiply(new BigDecimal(100)).intValue();
                            JSONObject jSONObject = new JSONObject();
                            jSONObject.put("actualMoney", intValue);
                            jSONObject.put("orderNo", str);
                            jSONObject.put("payNo", midText);
                            XposedBridge.log("json>>>" + jSONObject.toString());
//                            Intent intent = new Intent();
//                            intent.putExtra("data", jSONObject.toString());
//                            intent.setAction(HookMain.RECEIVE_BILL_ALIPAY);
//                            context.sendBroadcast(intent);
                        }
                    }
                }
            });
        } catch (Error unused) {
        }
    }


    private void checkBank(final ClassLoader classLoader, final Context context) {
        Class<?> insertServiceMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.ServiceDao", classLoader);
        Set<?> hooks = XposedBridge.hookAllMethods(insertServiceMessageInfo, "insertMessageInfo", new XC_MethodHook() {
            @SuppressLint("WrongConstant")
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                try {
                    Object object = param.args[0];
                    //XposedHelpers.
                    String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                    String content = StringUtils.getTextCenter(MessageInfo, "extraInfo='", "'").replace("\\", "");
                    XposedBridge.log("商家 MessageInfo >>"+MessageInfo);
                    if(content.contains("商家服务·店员通")){
                        Pattern moneyPattern = Pattern.compile("\"(\\d+\\.\\d+)\"");
                        Pattern timePattern = Pattern.compile("gmtCreate=(\\d+)");
                        Matcher mt = moneyPattern.matcher(content);
                        Matcher timemt = timePattern.matcher(MessageInfo);
                        if(mt.find() && timemt.find()){
                            Matcher markMt = Pattern.compile("今日第\\d笔收款，共计￥\\d+\\.\\d+").matcher(MessageInfo);
                            String mark = "店员通";
                            if(markMt.find()){
                                mark = markMt.group();
                            }
                            String money = mt.group(1);
                            String time = timemt.group(1);
                            String no = MD5.md5(money+time);
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("dt", time);
                            broadCastIntent.putExtra("no", no);
                            broadCastIntent.putExtra("money", money);
                            broadCastIntent.putExtra("mark", mark);
                            broadCastIntent.putExtra("dianyuan", "1");
                            broadCastIntent.putExtra("paytype", AppConst.TYPE_ALIPAY);
                            broadCastIntent.setAction(AppConst.HOOK_BILL_RECEIVED);
                            context.sendBroadcast(broadCastIntent);
                        }
                    }
                    if (content.contains("收钱到账") || content.contains("收款到账")) {
                        XposedBridge.log("======支付宝商家服务订单start=========");
                        String cookie = PayHelperUtils.getCookieStr(classLoader);
                        PayHelperUtils.getTradeInfo(context, cookie);
                        // 收钱到账发送广播
//                        Intent broadCastIntent = new Intent();
//                        broadCastIntent.putExtra("ispersonal", false);
//                        broadCastIntent.putExtra("bill_type", AppConst.TYPE_ALIPAY);
//                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
//                        context.sendBroadcast(broadCastIntent);
                        //
                        XposedBridge.log("======支付宝商家服务订单end=========");
                    }
                    if (content.contains("银行卡收款通知")) {
                        XposedBridge.log("======>银行卡到账通知");
                        String TFDetail = StringUtils.getTextCenter(MessageInfo, "assistMsg1\":", "已到账");
                        String name = StringUtils.getTextCenter(TFDetail, "\"", "通过");
                        String money = StringUtils.getTextCenter(TFDetail, "转账", "元");
                        String cardNo = StringUtils.getTextCenter(TFDetail, "尾号", "）");
                        //
                        XposedBridge.log("===>" + "付款人:" + name);
                        XposedBridge.log("===>" + "金额:" + money);
                        XposedBridge.log("===>" + "卡号:" + cardNo);
                        //
                        XposedBridge.log("支付宝监听银行卡");
                        long dt = System.currentTimeMillis();
                        String no = MD5.md5("alipay" + dt + cardNo + money);
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("bill_no", no);
                        broadCastIntent.putExtra("bill_money", money);
                        broadCastIntent.putExtra("bill_mark", "false");
                        broadCastIntent.putExtra("bill_wh", cardNo);
                        broadCastIntent.putExtra("bill_dt", dt);
                        broadCastIntent.putExtra("bill_type", AppConst.TYPE_BANK);
                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                        context.sendBroadcast(broadCastIntent);
                        //
                    }
                } catch (Exception e) {
                    PayHelperUtils.sendmsg(context, e.getMessage());
                }
                super.beforeHookedMethod(param);
            }
        });
        XposedBridge.log("----------商家订单:" + hooks.size() + "-----------");
    }

    private void checkTrade(final ClassLoader classLoader, final Context context) {
        Class<?> insertTradeMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.TradeDao", classLoader);
        XposedBridge.hookAllMethods(insertTradeMessageInfo, "insertMessageInfo", new XC_MethodHook() {
            @SuppressLint("WrongConstant")
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                try {
                    XposedBridge.log("======start=========");

                    //获取全部字段
                    Object object = param.args[0];
                    String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                    XposedBridge.log(JSON.toJSONString(object));
                    //PayHelperUtils.sendmsg(context, (String) XposedHelpers.getObjectField(param.args[0], "content"));
                    String content = MessageInfo;
                    //
                    String str = (String) XposedHelpers.callMethod(param.args[0], "toString", new Object[0]);
                    String midText = StringUtils.getTextCenter(str, "content='", "'");
                    String midText2 = StringUtils.getTextCenter(str, "link='", "'");
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("link===");
                    stringBuilder.append(midText2);
                    XposedBridge.log(stringBuilder.toString());

                    //|| content.contains("收到一笔转账")
                    if (content.contains("收款到账") || content.contains("二维码收款")|| content.contains("收到一笔转账")) {
//                        //
                        JSONObject jsonObject = new JSONObject(JSON.toJSONString(object));
                        String dt = jsonObject.getString("gmtCreate");
                        JSONObject contentJson = new JSONObject(jsonObject.getString("content"));
                        String receiveAmount = contentJson.getString("content").replace("￥", "");
                        String remark = contentJson.getString("assistMsg2");
                        String crowdNo = jsonObject.optString("msgId");
                        Pattern p = Pattern.compile("tradeNO=(\\d+)&bizType");
                        Matcher mt = p.matcher(jsonObject.getString("link"));
                        if (mt.find()) {
                            crowdNo = mt.group(1);
                        }
                        getDetailTrade(crowdNo,context,"D_TRANSFER");
                        //
//                        PayHelperUtils.sendmsg(context, "支付宝收款到账" + "\n时间" + PayHelperUtils.stampToDate(dt) + "\n金额：" + receiveAmount + "\n备注：" + remark + "\n订单号:" + crowdNo);
                    }
                    XposedBridge.log("======end=========");
                } catch (Exception e) {
                    XposedBridge.log(e.getMessage());
                }
                super.beforeHookedMethod(param);
            }
        });
    }

    public static Object compareFriend(String userid) {
        Class appclazz = XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", mClassLoader);
        Object mapp2 = XposedHelpers.callStaticMethod(appclazz, "getInstance");
        Object bundleContext = XposedHelpers.callMethod(mapp2, "getBundleContext");
        ClassLoader classload = (ClassLoader) XposedHelpers.callMethod(bundleContext, "findClassLoaderByBundleName", "android-phone-wallet-socialpayee");
        Object contactAccount = Tools.getContactAccount(classload, userid);
        return contactAccount;
    }

    /**
     * 生成好友收款
     *
     * @param userid
     * @param money
     * @param remark
     * @return
     */
    private static Object sendBillMsg(final String userid, final String money, final String remark) {
        Class appclazz = XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", mClassLoader);
        Object mapp2 = XposedHelpers.callStaticMethod(appclazz, "getInstance");
        Object bundleContext = XposedHelpers.callMethod(mapp2, "getBundleContext");
        ClassLoader classload = (ClassLoader) XposedHelpers.callMethod(bundleContext, "findClassLoaderByBundleName", "android-phone-wallet-socialpayee");
        Object service = Tools.getRpcService(Tools.getAlipayApplication(mClassLoader));
        XposedBridge.log("service " + service);
        Object SingleCollectRpc = XposedHelpers.callMethod(service, "getRpcProxy", XposedHelpers.findClass("com.alipay.android.phone.personalapp.socialpayee.rpc.SingleCollectRpc", classload));
        Object singleCreateReq = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.android.phone.personalapp.socialpayee.rpc.req.SingleCreateReq", classload));
        XposedBridge.log(" singleCreateReq " + JSON.toJSONString(singleCreateReq));
        Field[] fields = singleCreateReq.getClass().getDeclaredFields();
//        for (Field field : fields) {
//            XposedBridge.log(" " + field.getName() + " " + field.getType());
//        }
//        XposedHelpers.setObjectField(singleCreateReq, "userName", "");
        XposedHelpers.setObjectField(singleCreateReq, "userId", userid);
//        XposedHelpers.setObjectField(singleCreateReq, "logonId", logonId);
        XposedHelpers.setObjectField(singleCreateReq, "desc", remark);
        XposedHelpers.setObjectField(singleCreateReq, "payAmount", money);
        XposedHelpers.setObjectField(singleCreateReq, "billName", "个人收款");
        XposedHelpers.setObjectField(singleCreateReq, "source", "chat");
        Object o = XposedHelpers.callMethod(SingleCollectRpc, "createBill", singleCreateReq);
        XposedBridge.log(" 结果 " + JSON.toJSONString(o));//  结果 {"success":true,"transferNo":"20190225200040011100700099484159"}
//        Tools.delectContact(mClassLoader,userid);
        return o;
    }

    public static void sendBillMsg(final String userid, final String money, final String remark, final String orderid, final Context context) {
        try {
            Object o = sendBillMsg(userid, money, remark);
            JSONObject json = new JSONObject(JSON.toJSONString(o));
//            HttpManager.getInstance().sendTrade(json.getString("transferNo"),odrderid,context);
            if (json.has("transferNo")) {
                Intent intent = new Intent();
                intent.setAction(AppConst.HOOK_FRIEND_ORDER_ACTION);
                intent.putExtra("no", json.getString("transferNo"));
                intent.putExtra("orderid", orderid);
                context.sendBroadcast(intent);
            } else {
                PayHelperUtils.sendmsg(context, "支付宝提示你：" + json.getString("message"));
            }
        } catch (Exception e) {
            XposedBridge.log("发送订单异常");
            XposedBridge.log(e);
        }
    }

    private void securityCheckHook(ClassLoader classLoader) {
        try {
            Class<?> securityCheckClazz = XposedHelpers.findClass("com.alipay.mobile.base.security.CI", classLoader);
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", String.class, String.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Object object = param.getResult();
                    XposedHelpers.setBooleanField(object, "a", false);
                    param.setResult(object);
                    super.afterHookedMethod(param);
                }
            });
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", Class.class, String.class, String.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return (byte) 1;
                }
            });
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", ClassLoader.class, String.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return (byte) 1;
                }
            });
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return false;
                }
            });

        } catch (Error | Exception e) {
            e.printStackTrace();
        }
    }
    //
    public static void getTGCode(final Context context, final String url) {
        final ClassLoader classLoader = context.getClassLoader();
        new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    XposedBridge.log("开始生成推广二维码");
                    String campStr = "p1j%2BdzkZl018zOczaHT4Z5CLdPVCgrEXq89JsWOx1gdt05SIDMPg3PTxZbdPw9dL";
                    Object json = XposedHelpers.newInstance(XposedHelpers.findClass("com.alibaba.fastjson.JSONObject", classLoader));
                    Class H5RpcUtil = XposedHelpers.findClass("com.alipay.mobile.nebulabiz.rpc.H5RpcUtil", classLoader);
                    String userId = PayHelperUtils.getAlipayLoginId(classLoader);
                    Object rpcResult = XposedHelpers.callStaticMethod(H5RpcUtil, "rpcCall",
                            "alipay.mappconfig.appContainerCheck",
                            "[{\"appId\":\"20001003\",\"bizScenario\":\"\",\"httpMethod\":\"GET\",\"insideClient\":false,\"levelNoneFetch\":true,\"pre\":false,\"publicId\":\"\",\"scene\":0,\"sourceId\":\"\",\"url\":\"https://render.alipay.com/p/f/fd-jipf3gil/pages/invitation/../qr/index.html?chInfo=ch_sousuoci\"}]",
                            "",
                            true,
                            json,
                            null,
                            false,
                            null,
                            0,
                            "json",
                            false,
                            -1
                    );
                    String result = JsonHelper.toJson(rpcResult);
                    XposedBridge.log("推广二维码result》》》"+result);
                    JSONObject resultJson = new JSONObject(result);
                    JSONObject response = new JSONObject(resultJson.getString("response"));
                    XposedBridge.log("推广二维码response》》》"+response);
                    if (response.getBoolean("success")) {

                        String sign = response.getString("sign");
                        JSONArray array = new JSONArray();

                        JSONObject object = new JSONObject();
                        JSONObject contextData = new JSONObject();
                        contextData.put("needFullText", "true");
                        String bizLinkedId = String.format(url+"%s", URLEncoder.encode("&c_stype=search_pwd&c_sign=%s&schemeInnerSource=20001003&bizType=C2C_COUPON", "utf-8"));
//                        String bizLinkedId = String.format("alipays://platformapi/startapp?appId=20000067&url="+"%s",URLEncoder.encode("alipayqr://platformapi/startapp?appId=20000123&actionType=scan&biz_data={\"u\": \"2088822908577619\",\"a\": \"1\",\"m\":\"\"}","utf-8"));
//                        String ss = "[{\"bizLinkedId\":\"alipays://platformapi/startapp?appId=20000067&url=https://www.alipay.com\",\"bizType\":\"C2C_COUPON_S\",\"codeType\":\"search_code\",\"operator\":\"2088822908577619\",\"contextData\":{\"needFullText\":\"true\"},\"savingMode\":false,\"shareChannel\":\"NORMAL\",\"timeout\":300000,\"userId\":\"2088822908577619\"}]";
                        XposedBridge.log("bizLinkedId==>" + bizLinkedId);
                        object.put("bizLinkedId", bizLinkedId);
                        object.put("bizType", "C2C_COUPON_S");
                        object.put("codeType", "search_code");
                        object.put("operator", userId);
                        object.put("contextData", contextData);
                        object.put("savingMode", false);
                        object.put("shareChannel", "NORMAL");
                        object.put("timeout", 5 * 60 * 1000);
                        object.put("userId", userId);
                        array.put(object);
                        Object shakeCodeRz = XposedHelpers.callStaticMethod(H5RpcUtil, "rpcCall",
                                "alipay.mobilecodec.shakeCodeRz.encode",
                                array.toString(),
                                "",
                                true,
                                json,
                                null,
                                false,
                                null,
                                0,
                                "",
                                false,
                                -1
                        );
                        XposedBridge.log("生成码结果==>" + JSON.toJSONString(shakeCodeRz));
                        Intent intent = new Intent();
                        intent.setAction("com.result.alipayhook");
                        intent.putExtra("msg",JSON.toJSONString(shakeCodeRz));
                        context.sendBroadcast(intent);
                        PayHelperUtils.sendmsg(context,JSON.toJSONString(shakeCodeRz));
                        XposedBridge.log("生成码结果==>" + JSON.toJSONString(shakeCodeRz));
                    }
                    XposedBridge.log(JSON.toJSONString(rpcResult));
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        }.start();

    }
    //
    public static void getCode(final Context context, final String url) {
        final ClassLoader classLoader = context.getClassLoader();
        new Thread() {
            @Override
            public void run() {
                super.run();
                try {
                    XposedBridge.log("开始 产搜索码111111111111111111111111");
                    String campStr = "p1j%2BdzkZl018zOczaHT4Z5CLdPVCgrEXq89JsWOx1gdt05SIDMPg3PTxZbdPw9dL";
                    Object json = XposedHelpers.newInstance(XposedHelpers.findClass("com.alibaba.fastjson.JSONObject", classLoader));
                    Class H5RpcUtil = XposedHelpers.findClass("com.alipay.mobile.nebulabiz.rpc.H5RpcUtil", classLoader);
                    String userId = PayHelperUtils.getAlipayLoginId(classLoader);
                    Object rpcResult = XposedHelpers.callStaticMethod(H5RpcUtil, "rpcCall",
                            "alipay.promoprod.common.c2cshare.sign",
                            "[{\"campStr\":\"p1j%2BdzkZl018zOczaHT4Z5CLdPVCgrEXq89JsWOx1gdt05SIDMPg3PTxZbdPw9dL\",\"scene\":\"offlinePaymentNewSns\",\"shareId\":\"" + userId + "\"}]",
                            "",
                            true,
                            json,
                            null,
                            false,
                            null,
                            0,
                            "",
                            false,
                            -1
                    );
                    String result = JsonHelper.toJson(rpcResult);
                    XposedBridge.log("搜索码result》》》"+result);
                    JSONObject resultJson = new JSONObject(result);
                    JSONObject response = new JSONObject(resultJson.getString("response"));
                    if ("SUCCESS".equals(response.getString("errorMsg"))) {

                        String sign = response.getString("sign");
                        com.alibaba.fastjson.JSONArray array = new com.alibaba.fastjson.JSONArray();

                        com.alibaba.fastjson.JSONObject object = new com.alibaba.fastjson.JSONObject();
                        com.alibaba.fastjson.JSONObject contextData = new com.alibaba.fastjson.JSONObject();
                        contextData.put("needFullText", "true");
                        String _url = "alipays://platformapi/startapp?appId=09999988&actionType=toCard&ap_framework_sceneId=20000067&bankAccount=张玛瑙&cardNo=621700***0027&bankName=中国建设银行&bankMark=CCB&money=1.99&amount=1.99&REALLY_STARTAPP=true&startFromExternal=false&cardIndex=1605211523392833350&cardChannel=HISTORY_CARD&cardNoHidden=true";
                        _url = "https://render.alipay.com/p/f/fd-j6lzqrgm/guiderofmklvtvw.html?scheme="+"https://www.baidu.com";
                        String bizLinkedId = String.format("alipays://platformapi/startapp?appId=20000067&url="+"%s", URLEncoder.encode(_url+"&c_stype=search_pwd&c_sign=%s&schemeInnerSource=20001003&bizType=C2C_COUPON", "utf-8"));
//                        String bizLinkedId = String.format("alipays://platformapi/startapp?appId=20000067&url="+"%s",URLEncoder.encode("alipayqr://platformapi/startapp?appId=20000123&actionType=scan&biz_data={\"u\": \"2088822908577619\",\"a\": \"1\",\"m\":\"\"}","utf-8"));
                        String ss = "[{\"bizLinkedId\":\""+bizLinkedId+"\",\"bizType\":\"C2C_COUPON_S\",\"codeType\":\"search_code\",\"operator\":\"2088822908577619\",\"contextData\":{\"needFullText\":\"true\"},\"savingMode\":false,\"shareChannel\":\"NORMAL\",\"timeout\":63072000,\"userId\":\"2088822908577619\"}]";
                        XposedBridge.log("bizLinkedId==>" + bizLinkedId);
                        object.put("bizLinkedId", ss);
                        object.put("bizType", "C2C_COUPON_S");
                        object.put("codeType", "search_code");
                        object.put("operator", userId);
                        object.put("contextData", contextData);
                        object.put("savingMode", false);
                        object.put("shareChannel", "NORMAL");
                        object.put("timeout", 5 * 60 * 1000);
                        object.put("userId", userId);
                        array.add(object);
                        Object shakeCodeRz = XposedHelpers.callStaticMethod(H5RpcUtil, "rpcCall",
                                "alipay.mobilecodec.shakeCodeRz.encode",
                                array.toJSONString(),
                                "",
                                true,
                                json,
                                null,
                                false,
                                null,
                                0,
                                "",
                                false,
                                -1
                        );
                        XposedBridge.log("生成码结果==>" + JSON.toJSONString(shakeCodeRz));
                        Intent intent = new Intent();
                        intent.setAction("com.result.alipayhook");
                        intent.putExtra("msg",JSON.toJSONString(shakeCodeRz));
                        context.sendBroadcast(intent);
                        PayHelperUtils.sendmsg(context,JSON.toJSONString(shakeCodeRz));
                        XposedBridge.log("生成码结果==>" + JSON.toJSONString(shakeCodeRz));
                    }
                    XposedBridge.log(JSON.toJSONString(rpcResult));
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        }.start();

    }
}