package com.zhiyi.xppay.hook;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.zhiyi.xppay.consts.AppConst;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/1/18.
 */

public class MBankService extends Service implements Runnable {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        new Thread(this).start();
    }

    @Override
    public void run() {
        try {
            while(true){
                Thread.sleep(60000);
                Intent intent = new Intent();
                intent.setAction(AppConst.ALIPAYMBANK_ACTION);
                CustomApplcation.getContext().sendBroadcast(intent);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
