package com.zhiyi.xppay.hook;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.google.myjson.reflect.TypeToken;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.lakala.TradeDataLKL;
import com.zhiyi.xppay.hook.lakala.TradeServiceLKL;
import com.zhiyi.xppay.main.Main;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/1/11.
 */
public class LakalaHook {
    Handler mHandler;
    private static ClassLoader mclassLoader;
    private static Context mcontext;
    private static JSONObject jsonInfo;

    public void hook(final ClassLoader classLoader, final Context context) {
        try {
            hook_real(classLoader, context);
        } catch (Throwable th) {
            XposedBridge.log("LKL 出现异常1 》》》》》》》");
            XposedBridge.log(th);
        }
    }

    private void hook_real(final ClassLoader classLoader, final Context context) {
        mclassLoader = classLoader;
        mcontext = context;
        if (mHandler == null) {
            mHandler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    super.handleMessage(msg);
                    boolean isAppRunning = PayHelperUtils.isAppRunning(mcontext, "com.lakala.cloudpos.qcodeapp");
                    XposedBridge.log("拉卡拉" + (isAppRunning ? "" : "未") + "启动》》》》》》");
                    if (!isAppRunning) {
                        XposedBridge.log("重新启动拉卡拉");
                        PayHelperUtils.startAppLKL(mcontext);
                    }
                    mHandler.sendEmptyMessageDelayed(1001, 1000);
                }
            };
            mHandler.sendEmptyMessageDelayed(1001, 1000);
        } else {
            mHandler.removeMessages(1001);
        }
        XposedHelpers.findAndHookMethod("com.lakala.qcodeapp.module.home.fragment.HomePageFragment$13", classLoader, "onSuccess", Object.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                super.beforeHookedMethod(param);
                Object obj = param.args[0];
                Object retCode = XposedHelpers.callMethod(obj, "getRetCode");
                if (retCode.equals("000000")) {
                    Object retdata = XposedHelpers.callMethod(obj, "getRetData");
                    jsonInfo = new JSONObject(JsonHelper.toJson(retdata));
                    PayHelperUtils.sendLoginId(jsonInfo.getString("phone"), AppConst.TYPE_LKLPAY, context);
                }
            }
        });
        XposedHelpers.findAndHookMethod("com.avos.avoscloud.AVPushConnectionManager", classLoader, "processPushMessage", String.class, String.class, String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("=================通知2：" + param.args[1]);
                try {
                    JSONObject jsonObject = new JSONObject((String) param.args[1]);
                    String action = jsonObject.getString("action");
//                    if (null != jsonObject && action.equals("com.lakala.qcode.action")) {
//                        String strtrade = jsonObject.getString("title");
//                        JSONObject tradeinfo = new JSONObject(strtrade);
//                        XposedBridge.log("tradeinfo ==:" + tradeinfo);
//                        String tradeNo = tradeinfo.getString("tradeNo");
//                        String orderId = tradeinfo.getString("orderId");
//                        String money = tradeinfo.getString("tradeAmount");
//                        String mark = tradeinfo.getString("logNo");
//                        String tradeType = tradeinfo.getString("tradeTypeName");
//
//                        XposedBridge.log("收到lakala支付订单：" + tradeNo + "==" + money + "==" + mark + "bill_account=");
//                        Intent broadCastIntent = new Intent();
//                        broadCastIntent.putExtra("bill_no", tradeNo);
//                        broadCastIntent.putExtra("bill_money", money);
//                        broadCastIntent.putExtra("bill_mark", orderId);
//                        broadCastIntent.putExtra("bill_type", AppConst.TYPE_LKLPAY);
//                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
//                        context.sendBroadcast(broadCastIntent);
//                    }
                } catch (Exception e) {
                    XposedBridge.log("==========解析lakala异常:" + e.getMessage());
                    e.printStackTrace();
                }
            }
        });
        XposedHelpers.findAndHookMethod("com.lakala.qcodeapp.net.l", classLoader, "fa", String.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("l fa >> " + param.args[0] + ">>" + param.getResult());
            }
        });
        XposedHelpers.findAndHookMethod("com.lakala.qcodeapp.net.MTSRequest", classLoader, "b",
                XposedHelpers.findClass("com.lakala.qcodeapp.net.m", classLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Object obje = param.args[0];
                        Object urlparam = XposedHelpers.getObjectField(obje, "urlParams");
                        XposedBridge.log("请求的数据》》》》》》》" + JsonHelper.toJson(urlparam));
                    }
                });
    }

    public static void CreateQRCode(String money, String mark) {
        try {
            String shopNo = jsonInfo.getString("shopNo");
            String termNo = jsonInfo.getString("termNo");
            String shopName = jsonInfo.getString("name");
            String _money = translAmountStr212Str(money);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("shopNo", shopNo);
            jsonObject.put("termId", termNo);
            jsonObject.put("shopName", shopName);
            jsonObject.put("shopType", "");
            jsonObject.put("amount", _money);
            jsonObject.put("orderId", UUID.randomUUID().toString().replaceAll("-", "").substring(0, 32));
            jsonObject.put("subject", "");
            jsonObject.put("description", mark);
            jsonObject.put("location", "");
            jsonObject.put("sign", createSign(shopNo, termNo, _money));
            RequestNet(createqr, getM(jsonObject.toString()), new QRCode(money, mark));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void GetTrade() {
        try {
            String loginName = getLoginName();
            String shopNo = jsonInfo.getString("shopNo");
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("loginName", loginName);
            jsonObject.put("pageSize", "20");
            jsonObject.put("startTime", "");
            jsonObject.put("endTime", "");
            jsonObject.put("page", "1");
            jsonObject.put("shopNo", shopNo);
            jsonObject.put("tradeType", "");
            jsonObject.put("status", "");
            RequestNet(tradeQuery, getM(jsonObject.toString()), new TradeQuery());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public synchronized static void GetOneTrade(TradeDataLKL dataLKL){
        try {
            XposedBridge.log("GetOneTrade 开始");
            String shopNo = jsonInfo.getString("shopNo");
            String termNo = jsonInfo.getString("termNo");
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("termId", termNo);
            jsonObject.put("tradeNo", dataLKL.tradeNo);
            jsonObject.put("shopNo", shopNo);
            jsonObject.put("sign", createSign(shopNo,termNo,dataLKL.tradeNo));
            RequestNet(transquery, getM(jsonObject.toString()), new TradeOneQuery(dataLKL));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static String getLoginName() {
        Class clazz = XposedHelpers.findClass("com.lakala.qcodeapp.AppApplication", mclassLoader);
        String loginName = "" + XposedHelpers.getStaticObjectField(clazz, "loginName");
        return loginName;
    }

    private static String createSign(String str, String str2, String str3) {
        Class clazz = XposedHelpers.findClass("com.lakala.qcodeapp.module.trade.c", mclassLoader);
        Object sign = XposedHelpers.callStaticMethod(clazz, "j", str, str2, str3);
        return "" + sign;
    }

    private static String translAmountStr212Str(String str) {
        try {
            return new DecimalFormat("000000000000").format((long) ((int) (Double.parseDouble(str) * 100.0d)));
        } catch (Exception e) {
            return str;
        }
    }


    private static void RequestNet(String urlapi, Object om, InvocationHandler oproxy) {
        Class clazz = XposedHelpers.findClass("com.lakala.qcodeapp.net.l", mclassLoader);
        Object ofa = XposedHelpers.callStaticMethod(clazz, "fa", urlapi);
        Object ob = XposedHelpers.callMethod(ofa, "b", om);
        Object oew = XposedHelpers.callMethod(ob, "eW", "POST");
        // 代理 com.lakala.qcodeapp.net.d 接口
        Object oagy = XposedHelpers.getObjectField(oew, "agy");
        Class<?> classfunc1 = XposedHelpers.findClass("com.lakala.qcodeapp.net.d", mclassLoader);
        Object objfunc4 = Proxy.newProxyInstance(mclassLoader, new Class[]{classfunc1}, oproxy);
        XposedHelpers.callMethod(oagy, "a", objfunc4);
        //
        XposedHelpers.callMethod(oew, "sf");
    }

    private static Object getM(String obj) {
        Class clazzm = XposedHelpers.findClass("com.lakala.qcodeapp.net.m", mclassLoader);
        Object newm = XposedHelpers.newInstance(clazzm);
        Type type = new TypeToken<ConcurrentHashMap<String, String>>() {
        }.getType();
        ConcurrentHashMap map = JsonHelper.fromJson(obj, type);
        XposedHelpers.setObjectField(newm, "urlParams", map);
        XposedBridge.log("getM >>>>>>>>>>>" + XposedHelpers.getObjectField(newm, "urlParams"));
        return newm;
    }

    static class TradeOneQuery implements InvocationHandler{
        private TradeDataLKL No;
        public TradeOneQuery(TradeDataLKL data){
            No = data;
        }
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            String methodName = method.getName();
            XposedBridge.log("TradeOneQuery 调用的方法名称为:" + methodName);
            try {
                if (methodName.equals("onResponse")) {
                    Object obj = objects[1];
                    Object objbody = XposedHelpers.callMethod(obj, "vw");
                    String databody = "" + XposedHelpers.callMethod(objbody, "string");
                    JSONObject json = new JSONObject(databody);
                    String retcode = json.optString("retCode");
                    XposedBridge.log("TradeOneQuery databody >>>> "+databody);
                    if(retcode.equals("000000")){
                        JSONObject retdata = json.optJSONObject("retData");
                        String tradeNo = retdata.optString("tradeNo");
                        String payNo = retdata.optString("payNo");
                        String money = retdata.optString("amount");
                        money = ""+((float)(Integer.parseInt(money)))/100.f;
                        String tradetime = retdata.optString("payTime");
                        tradetime = PayHelperUtils.dateToStamp(tradetime,"yyyyMMddhhmmss");//
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("bill_no", payNo);
                        broadCastIntent.putExtra("bill_money", money);
                        broadCastIntent.putExtra("bill_mark", tradeNo);
                        broadCastIntent.putExtra("bill_dt", tradetime);
                        broadCastIntent.putExtra("bill_type", AppConst.TYPE_LKLPAY);
                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                        mcontext.sendBroadcast(broadCastIntent);
                        No.states = 1;
                    }else{
                        String retMsg = json.optString("retMsg");
                        if(retMsg.equals("商户订单超时")){
                            No.states = 1;
                        }
                    }
                }
                XposedBridge.log("TradeOneQuery---------------------");
                if (methodName.equals("accept")) {
                    return "";
                }
                if(methodName.equals("onFailure")){
                    Object obj = objects[1];
                    IOException e = (IOException) obj;
                    XposedBridge.log(e);
                }
            } catch (Exception e) {
            }
            return null;
        }
    }

    static class TradeQuery implements InvocationHandler {
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            String methodName = method.getName();
            XposedBridge.log("TradeQuery 调用的方法名称为:" + methodName);
            try {
                if (methodName.equals("onResponse")) {
                    Object obj = objects[1];
                    Object objbody = XposedHelpers.callMethod(obj, "vw");
                    String databody = "" + XposedHelpers.callMethod(objbody, "string");
                    JSONObject json = new JSONObject(databody);
                    String retcode = json.optString("retCode");
                    XposedBridge.log("TradeQuery databody >>>> "+databody);
                    if (!TextUtils.isEmpty(retcode) && retcode.equals("000000")) {
                        JSONObject retdata = json.optJSONObject("retData");
                        JSONArray array = retdata.optJSONArray("dealDetails");
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject jsondetail = array.getJSONObject(i);
                            String tradeNo = jsondetail.optString("tradeNo");
                            String money = jsondetail.optString("tradeAmount");
                            String status = jsondetail.optString("tradeStatus");
                            String tradetime = jsondetail.optString("tradeTime");
                            tradetime = PayHelperUtils.dateToStamp(tradetime,"yyyyMMddhhmmss");
                            if(!status.equals("1")||TextUtils.isEmpty(tradeNo)){
                                continue;
                            }
                            //
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("bill_no", tradeNo);
                            broadCastIntent.putExtra("bill_money", money);
                            broadCastIntent.putExtra("bill_mark", tradeNo);
                            broadCastIntent.putExtra("bill_dt", tradetime);
                            broadCastIntent.putExtra("bill_type", AppConst.TYPE_LKLPAY);
                            broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                            mcontext.sendBroadcast(broadCastIntent);
                        }
                    }
                }
                XposedBridge.log("---------------------");
                if (methodName.equals("accept")) {
                    return "";
                }
            } catch (Exception e) {
            }
            return null;
        }
    }

    static class QRCode implements InvocationHandler {
        private String money;
        private String mark;

        public QRCode(String _money, String _mark) {
            money = _money;
            mark = _mark;
        }

        //
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            String methodName = method.getName();
            XposedBridge.log("QRCode 调用的方法名称为:" + methodName);
            try {
                if (methodName.equals("onResponse")) {
                    Object obj = objects[1];
                    Object objbody = XposedHelpers.callMethod(obj, "vw");
                    String databody = "" + XposedHelpers.callMethod(objbody, "string");
                    XposedBridge.log("objbody >>>>>>>>>>>> " + databody);
                    JSONObject json = new JSONObject(databody);
                    String retcode = json.optString("retCode");
                    if (!TextUtils.isEmpty(retcode) && retcode.equals("000000")) {
                        JSONObject retdata = json.optJSONObject("retData");
                        String code = retdata.optString("code");
                        String tradeNo = retdata.optString("tradeNo");
                        String orderId = retdata.optString("orderId");
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("money", money);
                        broadCastIntent.putExtra("mark", mark);
                        broadCastIntent.putExtra("type", AppConst.TYPE_LKLPAY);
                        broadCastIntent.putExtra("payurl", code);
                        broadCastIntent.putExtra("img_url", tradeNo);
                        broadCastIntent.putExtra("orderid", mark);
                        broadCastIntent.setAction(AppConst.QRCODERECEIVED_ACTION);
                        mcontext.sendBroadcast(broadCastIntent);
                        TradeDataLKL data = new TradeDataLKL();
                        data.reqTime = System.currentTimeMillis();
                        data.tradeNo = tradeNo;
                        TradeServiceLKL.getInstance().add(data);
                    }
                }
                XposedBridge.log("---------------------");
                if (methodName.equals("accept")) {
                    return "";
                }
            } catch (Exception e) {
            }
            return null;
        }
    }

    public static String tradeQuery = "qcode/api/qr/trade/tradeQuery";
    public static String agh = "qcode/api/qr/transfer/transferQuery";
    public String agj = "qcode/api/qr/trade/tradeSummaryQuery";
    public static String createqr = "qcode/api/qr/transaction/create";
    public static String transquery = "qcode/api/qr/transaction/query";
}
