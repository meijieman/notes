package com.zhiyi.xppay.net.Socket.SendMsg;

/**
 * Created by pc_unity on 2018/10/29.
 */

public class LoginInfo {

    public enum LoginStatus{
        noinfo,
        no,
        loading,
        finish

    }

    public String name;
    public String type;
    public LoginStatus loginStatus;

    public LoginInfo(){
        loginStatus = LoginStatus.noinfo;
    }

    public LoginInfo(String name,String type){
        this.name = name;
        this.type = type;
        loginStatus = LoginStatus.no;
    }
//    public LoginInfo(String name,String type,LoginStatus status){
//        this.name = name;
//        this.type = type;
//        loginStatus = status;
//    }

    public boolean hasInfo(){
        return loginStatus.ordinal() > LoginStatus.no.ordinal();
    }

    public boolean hasLogin(){
        return hasInfo()&&loginStatus!=LoginStatus.no;
    }

    public boolean hasNoLogin(){
        return loginStatus==LoginStatus.no;
    }
}
