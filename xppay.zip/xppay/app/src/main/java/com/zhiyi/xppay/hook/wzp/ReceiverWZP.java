package com.zhiyi.xppay.hook.wzp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.main.Main;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/6/17.
 */

public class ReceiverWZP extends BroadcastReceiver {
    public static String ACTION_CREATEQR = "com.zhiyi.wzp.createqrcode";
    public IntentFilter filter;
    public ReceiverWZP(){
        if(filter == null){
            filter = new IntentFilter();
            filter.addAction(ACTION_CREATEQR);
        }
    }
    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals(ACTION_CREATEQR)){
            XposedBridge.log("微掌铺收到生成QRCODE指令");
            HookWZP.CreateQR(intent);
        }
    }
}
