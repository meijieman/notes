package com.zhiyi.xppay.net.Socket.RecevieMsg;

/**
 * Created by pc_unity on 2018/11/5.
 */

public class BathBuildQrcode  {
    public int type;
    public String format;
    public String paytype;
    public int producetype;

    @Override
    public String toString() {
        return "BathBuildQrcode:{" +
                "type=" + type +
                ",format='" + format + '\'' +
                ",paytype='" + paytype + '\'' +
                ",producetype=" + producetype +
                "}";
    }
}
