package com.zhiyi.xppay.hook.xgj;

import android.content.Context;
import android.os.Build;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.zhiyi.xppay.consts.*;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.DBManager;
import com.zhiyi.xppay.utils.DBManagerXgj;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.yst.consts.Appconsts;

import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/3/21.
 */

public class HookXgj {
    private static ClassLoader mClassLoader;
    private static Context mContext;
    private static DBManagerXgj dbManagerXgj;
    public void hook(ClassLoader classLoader, Context context) {
        mClassLoader = classLoader;
        mContext = context;
        XposedHelpers.findAndHookMethod("com.newland.satrpos.starposmanager.module.main.MainActivity", mClassLoader, "initViews", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                mContext = (Context) param.thisObject;
                dbManagerXgj = new DBManagerXgj(mContext);
                PayHelperUtils.sendLoginId(getUserNo(), com.zhiyi.xppay.hook.xgj.AppConst.TYPE_XGJ,mContext);
            }
        });
    }

    public static void getTradeQuery() {
        try {
            HttpUtils httpUtils = new HttpUtils(30000);
            TradeReqBodyXGJ reqbody = new TradeReqBodyXGJ(getUserNo(), getTokenID(), Build.MANUFACTURER, PayHelperUtils.getVerName(mContext), "GBK", "0", "starPOS", "APP");
            RequestParams params = new RequestParams();
            StringEntity entity = new StringEntity(reqbody.toJson(), "UTF-8");
            params.setBodyEntity(entity);
            params.setContentType("application/json");
            String url = "https://gateway.starpos.com.cn/estmadp2/qry_notice_list.json";
            httpUtils.send(HttpRequest.HttpMethod.POST, url, params, new RequestCallBack<String>() {
                @Override
                public void onSuccess(ResponseInfo<String> responseInfo) {
                    String result = responseInfo.result;
                    resolveTradeData(result);
                }

                @Override
                public void onFailure(HttpException e, String s) {

                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    private static void resolveTradeData(String str){
        try {
            JSONObject jsonObject = new JSONObject(str);
            JSONArray tradelist = jsonObject.getJSONArray("noticeList");
            for(int i = 0;i<tradelist.length();i++){
                JSONObject trade = tradelist.getJSONObject(i);
                String merc_id = trade.getString("merc_id");
                String ordertime = trade.getString("txn_tm");
                String amount = trade.getString("txn_amt");
                String remark =ordertime+"&"+amount;
                if(dbManagerXgj.isExistTradeNo(remark)){
                    return;
                }
                dbManagerXgj.addTradeNo(remark);
                ToolsXGJ.sendTrade(mContext,ordertime,amount,remark);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static String getUserNo() {
        return getUserInfo("getNumber");
    }

    public static String getTokenID() {
        return getUserInfo("getToken_id");
    }

    private static String getUserInfo(String funname) {
        Class<?> clazzApp = XposedHelpers.findClass("com.newland.satrpos.starposmanager.MyApplication", mClassLoader);
        Object o_user = XposedHelpers.getStaticObjectField(clazzApp, "a");
        String data = "";
        if (o_user != null) {
            Object o_data = XposedHelpers.callMethod(o_user, funname);
            data = "" + o_data;
        }
        return data;
    }


}
