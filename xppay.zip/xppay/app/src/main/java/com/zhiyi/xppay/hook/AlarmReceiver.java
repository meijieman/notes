package com.zhiyi.xppay.hook;

import java.util.List;

import com.zhiyi.xppay.net.Socket.ClientManager;
import com.zhiyi.xppay.utils.AbSharedUtil;
import com.zhiyi.xppay.utils.DBManager;
import com.zhiyi.xppay.utils.OrderBean;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.StringUtils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import de.robv.android.xposed.XposedBridge;

/**
 * 

* @ClassName: AlarmReceiver

* @Description: TODO(这里用一句话描述这个类的作用)

* @author SuXiaoliang

* @date 2018年6月23日 下午1:25:47

*
 */

public class AlarmReceiver extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		DBManager dbManager=new DBManager(context);
		List<OrderBean> orderBeans=dbManager.FindAllOrders();
		for (OrderBean orderBean : orderBeans) {
			if(ClientManager.getInstance().isStart()){
				//
				if(orderBean.getTime()>=2){
					dbManager.updateTradeStep3(orderBean.getNo());
				}
				String[] temp = orderBean.getMark().split("/");
				String remark,wh = "";
				if(temp == null||temp.length<=0){
					remark = orderBean.getMark();
				}else if(temp.length<=1){
					remark = temp[0];
				}else{
					remark = temp[0];
					wh = temp[1];
				}
				ClientManager.getInstance().sendPayOverNotify(orderBean.getType(), orderBean.getNo(), orderBean.getMoney(), remark,orderBean.getDt(),wh);
				dbManager.updateOrder(orderBean.getNo(),orderBean.getResult());
			}
		}
		List<OrderBean> orderBeans0 = dbManager.FindReuslt0Orders();
		for(OrderBean orderBean : orderBeans0) {
			if(ClientManager.getInstance().isStart()){
				ClientManager.getInstance().getExTradeResult(orderBean);
			}
		}
	}

}
