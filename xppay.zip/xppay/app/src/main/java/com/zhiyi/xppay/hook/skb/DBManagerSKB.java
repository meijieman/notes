package com.zhiyi.xppay.hook.skb;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * 

* @ClassName: DBManager

* @Description: TODO(这里用一句话描述这个类的作用)

* @author SuXiaoliang

* @date 2018年6月23日 下午1:27:22

*
 */
public class DBManagerSKB {
	private SQLiteDatabase db;
	private DBHelperSKB helper;
	public DBManagerSKB(Context context){
        helper = new DBHelperSKB(context);
        db = helper.getWritableDatabase();

    }

	public void addTradeNo(String tradeNo) {
		db.beginTransaction();// 开始事务
		try {
			db.execSQL("INSERT INTO trade VALUES(null,?)", new Object[] { tradeNo });
			db.setTransactionSuccessful();// 事务成功
		} finally {
			db.endTransaction();// 结束事务
		}
	}
	
	public boolean isExistTradeNo(String tradeNo) {
		boolean isExist=false;
		String sql = "SELECT * FROM trade WHERE tradeno='"+tradeNo+"'";
		Cursor c = ExecSQLForCursor(sql);
		if(c.getCount()>0){
			isExist=true;
		}
		c.close();
		return isExist;
	}

	    
    /**
     * 执行SQL，返回一个游标
     * 
     * @param sql
     * @return
     */
    private Cursor ExecSQLForCursor(String sql) {
        Cursor c = db.rawQuery(sql, null);
        return c;
    }
}
