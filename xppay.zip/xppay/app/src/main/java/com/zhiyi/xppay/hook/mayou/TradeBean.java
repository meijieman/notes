package com.zhiyi.xppay.hook.mayou;

import java.io.Serializable;

/**
 * Created by pc_mg on 2019/4/12.
 */

public class TradeBean implements Serializable {
    public String money;
    public String mark;
    public long createtime;
    public int state;
}
