package com.zhiyi.xppay.hook.yzf;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.nio.charset.Charset;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by pc_mg on 2019/5/25.
 */

public class HookYZF {
    private static ClassLoader mclassLoader;
    private static Context mcontext;

    public void hook(final ClassLoader classLoader, final Context context) {
        final Class<?> clazz = XposedHelpers.findClass("com.stub.StubApp", classLoader); // onCreate
        XposedHelpers.findAndHookMethod(clazz, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log(" onCreate " + param.thisObject);
                Field field = XposedHelpers.findField(clazz, "ᵢˎ");
                XposedBridge.log(" onCreate field " + field.getClass().getName());
                field.setAccessible(true);
                Object obj = field.get(param.thisObject);
                Field fieldc = XposedHelpers.findField(clazz, "ᵢˑ");
                fieldc.setAccessible(true);
                Object objc = fieldc.get(param.thisObject);
                hook_real(obj.getClass().getClassLoader(), (Context) objc);
            }
        });
    }

    private void hook_real(final ClassLoader classLoader, final Context context) {
        mclassLoader = classLoader;
        mcontext = context;
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @SuppressLint("ResourceType")
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("当前益支付 activity 》》》》》》》》》》" + param.thisObject.getClass().getName());
            }
        });
        XposedHelpers.findAndHookMethod("com.softbank.flybank.g.a$8", classLoader, "b", XposedHelpers.findClass("com.google.gson.JsonObject", classLoader), new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                trade(param.args[0]);
            }
        });
        XposedHelpers.findAndHookMethod("com.softbank.flybank.a.h", classLoader, "getLong", String.class, long.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                if ("cust_id".equals("" + param.args[0])) {
                    String loginid = "" + param.getResult();
                    XposedBridge.log(" loginid >>>" + loginid);
                    PayHelperUtils.sendLoginId(loginid, AppConst.TYPE_YZF, mcontext);
                }
            }
        });
    }

    private void trade(Object obj) {
        String strjson = ""+obj;
        try {
            JSONObject jsonObject = new JSONObject(strjson);
            XposedBridge.log("trade jsonObject >>>>>>>>> " + jsonObject);
            JSONArray array = jsonObject.optJSONArray("groupList");
            if (array != null && array.length() > 0) {
                for (int i = 0; i < array.length(); i++) {
                    JSONObject jsonobj = array.optJSONObject(i);
                    if (jsonobj != null) {
                        JSONArray array1 = jsonobj.optJSONArray("msgList");
                        if (array1 != null && array1.length() > 0) {
                            for (int j = 0; j < array1.length(); j++) {
                                JSONObject objmsg = array1.getJSONObject(j);
                                JSONObject objcontent = objmsg.getJSONObject("content");
                                String orederNo = objcontent.optString("orderNo");
                                String money = "" + (Float.parseFloat(objcontent.optString("totalAmt")) / 100);
                                String time = objmsg.optString("createdTime");
                                time = PayHelperUtils.dateToStamp(time, "yyyy-MM-dd HH:mm:ss");
                                Intent broadCastIntent = new Intent();
                                broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                                broadCastIntent.putExtra("bill_type", AppConst.TYPE_YZF);
                                broadCastIntent.putExtra("bill_money", money);
                                broadCastIntent.putExtra("bill_mark", orederNo);
                                broadCastIntent.putExtra("bill_no", orederNo);
                                broadCastIntent.putExtra("bill_dt", time);
                                mcontext.sendBroadcast(broadCastIntent);
                            }
                        }
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void CreateQR(Intent intent) {
        String money = intent.getStringExtra("money");
        String mark = intent.getStringExtra("mark");
        request("flybankRest", "rest/provider/FaceCashier", money, mark);
    }

    private static void request(String str, String str2, String money, String mark) {// flybank  rest/provider/FaceCashier
        XposedBridge.log("开始请求》》》》》》》》》》》》》》》金額》》 "+money);
        String _money = (long)(Float.parseFloat(money) * 100) + "";
        XposedBridge.log("金額》》 "+_money);
        Class classa = XposedHelpers.findClass("com.softbank.flybank.a.a", mclassLoader);
        Object objyG = XposedHelpers.callStaticMethod(classa, "yG");
        Object objyI = XposedHelpers.callMethod(objyG, "yI");
        Class classjson = XposedHelpers.findClass("com.google.gson.JsonObject", mclassLoader);
        Object objjson = XposedHelpers.newInstance(classjson);
        XposedHelpers.callMethod(objjson, "addProperty", "amount", Long.valueOf(_money));
        Class<?> clazzcallback = XposedHelpers.findClass("com.softbank.flybank.g.a$b", mclassLoader);
        Object call = Proxy.newProxyInstance(mclassLoader, new Class[]{clazzcallback}, new ClsInterface(money, mark));
        XposedHelpers.callMethod(objyI, "a", str, str2, objjson, call);
    }

    static class ClsInterface implements InvocationHandler {

        private String money, mark;

        private ClsInterface(String _money, String _mark) {
            money = _money;
            mark = _mark;
        }

        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            String methodname = method.getName();
            if (methodname.equals("b")) {
                Object object = objects[0];
                XposedBridge.log("object >>>>>>>>> " + object.toString());
                JSONObject qrdata = new JSONObject(object.toString());
                XposedBridge.log("qrdata 》》"+qrdata);
                String result = qrdata.optString("resultCode");
                XposedBridge.log("result 》》"+result);
                if (!TextUtils.isEmpty(result) && result.equals("0")) {
                    String qrcode = qrdata.optString("qrCode");
                    Intent v2 = new Intent();
                    v2.putExtra("type", AppConst.TYPE_YZF);
                    v2.putExtra("mark", mark);
                    v2.putExtra("money", money);
                    v2.putExtra("payurl", qrcode);
                    v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                    XposedBridge.log("生成的二维码金额 》》"+money+"备注》》"+mark+"支付连接》》"+qrcode);
                    mcontext.sendBroadcast(v2);
                }
            }
            return null;
        }
    }
}
