package com.zhiyi.xppay.net.Socket.SendMsg;

import static com.zhiyi.xppay.net.Socket.ClientManager.LOGIN;

/**
 * Created by zhiyi on 2018/10/19.
 */

public class LoginSend {
    public int type = LOGIN;
    public String name;
    public String paytype;
    public String deviceid;
    public String app_id;

    public LoginSend(String name,String paytype,String device,String app_id){
        this.name = name;
        this.paytype = paytype;
        this.deviceid = device;
        this.app_id = app_id;
    }

    @Override
    public String toString() {
        return "LoginSend{" +
                "type='" + type +
                ", name='" + name + '\'' +
                ", deviceid='" + deviceid + '\'' +
                ",app_id='" + app_id + '\'' +
                '}';
    }
}
