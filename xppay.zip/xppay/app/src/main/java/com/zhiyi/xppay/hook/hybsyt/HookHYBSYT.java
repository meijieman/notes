package com.zhiyi.xppay.hook.hybsyt;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.MD5;
import com.zhiyi.xppay.utils.PayHelperUtils;

import org.apache.http.entity.StringEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import okhttp3.MediaType;

/**
 * Created by pc_mg on 2019/5/8.
 */

public class HookHYBSYT {
    private static ClassLoader mclassLoader;
    private static Context mcontext;
    Handler mHandler;
    public void hook(final ClassLoader classLoader, final Context context) {
        final Class<?> clazz = XposedHelpers.findClass("com.stub.StubApp", classLoader); // onCreate
        XposedHelpers.findAndHookMethod(clazz, "onCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log(" onCreate " + param.thisObject);
                Field field = XposedHelpers.findField(clazz, "ᵢˎ");
                XposedBridge.log(" onCreate field " + field.getClass().getName());
                field.setAccessible(true);
                Object obj = field.get(param.thisObject);
                Field fieldc = XposedHelpers.findField(clazz, "ᵢˑ");
                fieldc.setAccessible(true);
                Object objc = fieldc.get(param.thisObject);
                hook_real(obj.getClass().getClassLoader(), (Context) objc);
            }
        });
    }

    private void hook_real(final ClassLoader classLoader, final Context context) {
        mclassLoader = classLoader;
        mcontext = context;
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("当前activity 》》》》》》" + param.thisObject.getClass().getName());
                if (param.thisObject.getClass().getName().equals("com.hybunion.MainActivity")) {
                    PayHelperUtils.sendLoginId(getMid(),AppConst.TYPE_HYBSYT,mcontext);
                    if (mHandler == null) {
                        mHandler = new Handler() {
                            @Override
                            public void handleMessage(Message msg) {
                                super.handleMessage(msg);
                                if(msg.what == 1001){
                                    transHistoryLogin();
                                    mHandler.sendEmptyMessageDelayed(1001,20000);
                                }
                            }
                        };
                        mHandler.sendEmptyMessageDelayed(1001, 20000);
                    } else {
                        mHandler.removeMessages(1001);
                    }
                }
            }
        });
        XposedHelpers.findAndHookMethod("com.hybunion.presenter.QrCodeTransPresenter", classLoader, "packageParams", String.class, String.class, String.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        XposedBridge.log("param.args[0]>>" + param.args[0] + ">> param.args[1] >>" + param.args[1] + ">> param.args[2] >>" + param.args[2]
                                + "result >>> " + param.getResult());
                    }
                }
        );
        XposedHelpers.findAndHookMethod("com.hybunion.presenter.QrCodeTransPresenter", classLoader, "success",
                XposedHelpers.findClass("com.hybunion.data.bean.QrCodeTransactionInfoBean", classLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        XposedBridge.log(">>>" + JsonHelper.toJson(param.args[0]));
                    }
                }
        );
        XposedHelpers.findAndHookMethod("com.hybunion.utils.NetworkUtils", classLoader, "isWifiProxy", new XC_MethodReplacement() {
            @Override
            protected Object replaceHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                return false;
            }
        });
        XposedHelpers.findAndHookMethod("com.hybunion.net.http.HYBHttpEngine", classLoader, "post", Context.class, String.class,
                XposedHelpers.findClass("com.loopj.android.http.RequestParams",classLoader),
                XposedHelpers.findClass("com.hybunion.net.handler.HttpResponseHandler",classLoader),
                new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                super.afterHookedMethod(param);
                XposedBridge.log("post param >>"+param.args[1]+">>"+param.args[2]);
            }
        });
        XposedHelpers.findAndHookMethod(XposedHelpers.findClass("com.hybunion.net.http.Request", mclassLoader), "queryQrCodeTransInfo",
                XposedHelpers.findClass("com.loopj.android.http.RequestParams", mclassLoader), new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Object object = XposedHelpers.callMethod(param.thisObject,"getHttpEngine");
                        XposedBridge.log("Request RequestParams XXXX object>>> "+object.getClass()+">>param >>"+param.args[0]);
                    }
                }
        );
    }

    private static void getUserInfo(){
        final HttpUtils httpUtils = new HttpUtils(30000);
        RequestParams params = new RequestParams();
        params.addBodyParameter("mid", getMid());
        String url = "https://merchmobile.hybunion.cn/HrtApp/phone/phoneMicroMerchantInfo_queryMicroMerchantInfo.action";
        httpUtils.send(HttpRequest.HttpMethod.POST, url, params, new RequestCallBack<String>() {
            @Override
            public void onSuccess(ResponseInfo<String> responseInfo) {
                String result = responseInfo.result;
                XposedBridge.log("交易记录登录transHistoryLogin result >>>>>> " + result);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        XposedBridge.log("交易记录登录--------------- >>>>>> ");
                        RequestHistory(httpUtils,createHistoryParam());
                    }
                }).start();
            }

            @Override
            public void onFailure(HttpException e, String s) {

            }
        });
    }

    public static void createQr(Intent intent) {
        final String money = intent.getStringExtra("money");
        final String mark = intent.getStringExtra("mark");
//        https://merchmobile.hybunion.cn/HrtApp/phone/phoneMicroMerchantInfo_serachMerchantInfoMid.action
        XposedBridge.log("开始创建会员宝收银台QRCode 》》》》");
        HttpUtils httpUtils = new HttpUtils(30000);
        RequestParams params = new RequestParams();
        params.addBodyParameter("mid", getMid());
        String url = "https://merchmobile.hybunion.cn/HrtApp/phone/phoneMicroMerchantInfo_serachMerchantInfoMid.action";
        httpUtils.send(HttpRequest.HttpMethod.POST, url, params, new RequestCallBack<String>() {
            @Override
            public void onSuccess(ResponseInfo<String> responseInfo) {
                String result = responseInfo.result;
                XposedBridge.log("创建QRCode result >>>>>> " + result);
//                {"msg":"查询成功","numberUnits":"","obj":"http://xpay.hrtpayment.com/xpay/qrpayment?mid=HRTSYT000041670&sign=KTODNOXQUR&timeStamp=1558080488805","sessionExpire":false,"success":true}
                try {
                    JSONObject json = new JSONObject(result);
                    boolean result_q = json.optBoolean("success");
                    if(result_q){
                        String qrurl = json.optString("obj");
                        Intent v2 = new Intent();
                        v2.putExtra("type", AppConst.TYPE_HYBSYT);
                        v2.putExtra("mark", mark);
                        v2.putExtra("money", money);
                        v2.putExtra("payurl", qrurl);
                        v2.setAction(AppConst.QRCODERECEIVED_ACTION);
                        mcontext.sendBroadcast(v2);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpException e, String s) {

            }
        });
    }

    private static void transHistoryLogin(){
        XposedBridge.log("会员宝收银台轮询订单>>>>>>");
        final HttpUtils httpUtils = new HttpUtils(30000);
        RequestParams params = new RequestParams();
        params.addBodyParameter("loginName", getMid());
        String url = "https://merchmobile.hybunion.cn/HrtApp/phone/phoneUser_login.action";
        httpUtils.send(HttpRequest.HttpMethod.POST, url, params, new RequestCallBack<String>() {
            @Override
            public void onSuccess(ResponseInfo<String> responseInfo) {
                String result = responseInfo.result;
                XposedBridge.log("交易记录登录transHistoryLogin result >>>>>> " + result);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        XposedBridge.log("交易记录登录--------------- >>>>>> ");
                        RequestHistory(httpUtils,createHistoryParam());
                    }
                }).start();
            }

            @Override
            public void onFailure(HttpException e, String s) {

            }
        });
    }

    public static String getMid() {
        Class clazz = XposedHelpers.findClass("com.hybunion.utils.SPUtils", mclassLoader);
        Object obj = XposedHelpers.callStaticMethod(clazz, "getMid");
        XposedBridge.log("获得到的mid 》》》》》》》 " + obj);
        return "" + obj;
    }

    private static String S4() {
        long d = ((long) (((1 + Math.random()) * (0x10000))) | 0);
        return Long.toHexString(d).substring(1);
    }

    private static String getUid() {
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
    }

    public static String createSign(String amount) {
        return MD5.md5(getMid() + "&" + amount + "&" + getUid());
    }

    private static Object createHistoryParam(){
        Class clazz = XposedHelpers.findClass("com.loopj.android.http.RequestParams",mclassLoader);
        Object objnew = XposedHelpers.newInstance(clazz);
        XposedHelpers.callMethod(objnew,"put","code","3");
        XposedHelpers.callMethod(objnew,"put","page","1");
        XposedHelpers.callMethod(objnew,"put","rows","10");
        XposedHelpers.callMethod(objnew,"put","startDay","2019-05-06");
        XposedHelpers.callMethod(objnew,"put","endDay","2019-05-12");
        return objnew;
    }

    private static void RequestHistory(HttpUtils httpUtils, Object _params) {
//        String url = "https://merchmobile.hybunion.cn/HrtApp/phone/phoneCheckUnitDealData_findHistertoyScanData.action";
//        Class clazz = XposedHelpers.findClass("com.hybunion.net.http.Request",mclassLoader);
//        Object objhttp = XposedHelpers.callStaticMethod(clazz,"getHttpEngine");
//        //
//        Class _clazz = XposedHelpers.findClass("com.hybunion.net.handler.HttpResponseHandler",mclassLoader);
//        Class __clazz = XposedHelpers.findClass("com.hybunion.net.handler.Subscriber",mclassLoader);
//        TransHistory th = new TransHistory();
//        Object objProxy = Proxy.newProxyInstance(mclassLoader,new Class[]{__clazz},th);
//        Object handler = XposedHelpers.newInstance(_clazz,objProxy);
//        //
//        XposedHelpers.callMethod(objhttp,"post",url,params,handler);
//        HttpUtils httpUtils = new HttpUtils(30000);
        String endtime = ""+System.currentTimeMillis();
        endtime = PayHelperUtils.dateToStamp(endtime,"yyyy-MM-dd");
        String starttime = ""+(System.currentTimeMillis()-(7*24*3600));
        starttime = PayHelperUtils.dateToStamp(starttime,"yyyy-MM-dd");
        RequestParams params = new RequestParams();
//        params.addBodyParameter("code", "3");
//        params.addBodyParameter("startDay", starttime);
//        params.addBodyParameter("endDay", endtime);
        params.addBodyParameter("page", "1");
        params.addBodyParameter("rows", "10");
        String url = "https://merchmobile.hybunion.cn/HrtApp/phone/phoneCheckUnitDealData_findHistertoyScanData.action";
        url = "https://merchmobile.hybunion.cn/HrtApp/phone/phoneCheckUnitDealData_findWechatRealTimeRrading.action";
        httpUtils.send(HttpRequest.HttpMethod.POST, url, params, new RequestCallBack<String>() {
            @Override
            public void onSuccess(ResponseInfo<String> responseInfo) {
                String result = responseInfo.result;
                XposedBridge.log("HYBSYT RequestHistory result >>>>>> " + result);
//                {"countTxnAmount":"600","msg":"查询成功！","numberUnits":"",
//              "obj":{"rows":[{"ACCNO":"null","CDATE":"20190507","FIID":"微信","MDA":1.14,"MER_ORDERID":"qrpay2019 0507 172435 77051849","MID":"HRTSYT000041670","RESPCODE":"SUCCESS","SMAMOUNT":"298.86","STATUS":"1","TXNAMT":"300.00","sum":600,"sumAmount":309.72},
//                             {"ACCNO":"null","CDATE":"20190507","FIID":"支付宝","MDA":1.14,"MER_ORDERID":"130000QRB00611110507115154439D5E","MID":"HRTSYT000041670","RESPCODE":"10000","SMAMOUNT":"10.86","STATUS":"1","TXNAMT":"300.00"}],"total":2},"sessionExpire":false,"success":true}
//               {"msg":"查询成功！","numberUnits":"",
//              "obj":{"rows":[{"BUSID":1,"CARDPAN":"null","INSTALLEDNAME":"null","ISMPOS":2,"MID":"HRTSYT000045777","MTI":0,"ORDERID":"qrpay2019052116043934979820","PKID":222233496,"RNAME":"郑敏","SALENAME":"xxx","TID":"null","TXNAMOUNT":300,"TXNDAY":"20190521","TXNSTATE":0,"TXNTIME":"160447","TXNTYPE":1,"UNNAME":"付予-高翔","UNNO":"i13646"},{"BUSID":1,"CARDPAN":"null","INSTALLEDNAME":"null","ISMPOS":2,"MID":"HRTSYT000045777","MTI":0,"ORDERID":"qrpay2019052116010882815682","PKID":222225945,"RNAME":"郑敏","SALENAME":"xxx","TID":"null","TXNAMOUNT":300,"TXNDAY":"20190521","TXNSTATE":0,"TXNTIME":"160115","TXNTYPE":1,"UNNAME":"付予-高翔","UNNO":"i13646"}],"total":2},"sessionExpire":false,"success":true}


                try {
                    JSONObject json = new JSONObject(result);
                    JSONObject obj = json.optJSONObject("obj");
                    JSONArray array = obj.optJSONArray("rows");
                    if(array != null&&array.length()>0){
                        for(int i = 0;i<array.length();i++){
                            JSONObject object = array.getJSONObject(i);
                            String tradeNo = object.optString("MER_ORDERID");
                            tradeNo = object.optString("ORDERID");
                            String money = object.optString("TXNAMT");
                            money = object.optString("TXNAMOUNT");
                            String type = object.optString("FIID");
                            type = object.optString("TXNTYPE");
                            type = type.equals("1")?"微信":"";
                            String time = ""+System.currentTimeMillis();
                            if(!TextUtils.isEmpty(type)&&type.equals("微信")){
                                time = tradeNo.substring(5,19);
                                XposedBridge.log("微信订单时间 》》》 "+time);
                                time = PayHelperUtils.dateToStamp(time,"yyyyMMddhhmmss");
                                XposedBridge.log("11微信订单时间 》》》 "+time);
                            }
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                            broadCastIntent.putExtra("bill_type", AppConst.TYPE_HYBSYT);
                            broadCastIntent.putExtra("bill_money", money);
                            broadCastIntent.putExtra("bill_mark", tradeNo);
                            broadCastIntent.putExtra("bill_no", tradeNo);
                            broadCastIntent.putExtra("bill_dt", time);
                            mcontext.sendBroadcast(broadCastIntent);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpException e, String s) {

            }
        });
    }
    static class TransHistory implements InvocationHandler{
        @Override
        public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
            String methodname = method.getName();
            XposedBridge.log("TransHistory methodname"+methodname);
            if(methodname.equals("onCompleted")){
                Object objresult = objects[0];
                XposedBridge.log("TransHistory 》》》 result 》》》》》"+objresult.getClass().getName()+">>"+objresult);
            }
            return null;
        }
    }
}
