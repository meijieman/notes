package com.zhiyi.xppay.hook;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.zhiyi.xppay.consts.AppConstsNxys;
import com.zhiyi.xppay.utils.PayHelperUtils;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/3/10.
 */

public class TradeQueryService extends Service implements Runnable {
    private boolean isrunning;
    private String appname;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        XposedBridge.log("appname >>>>>>>>> "+appname);
        appname = intent.getStringExtra("appname");
        XposedBridge.log("appname >>>>>>>>> "+appname);
        if(!isrunning){
            XposedBridge.log("订单查询服务线程启动");
            isrunning = true;
            new Thread(this).start();
        }
        return START_STICKY;
    }

    @Override
    public void run() {
        XposedBridge.log("订单查询服务启动");
        while(true){
            try {
                Thread.sleep(20000);
                XposedBridge.log("20秒 轮询一次");
                if(!TextUtils.isEmpty(appname)&&appname.equals(AppConstsNxys.PACKAGENAME)){
                    boolean isrunning = PayHelperUtils.isAppRunning(getApplicationContext(),appname);
                    if(!isrunning){
                        PayHelperUtils.sendmsg(getApplicationContext(),"重新启动农信易扫");
                        PayHelperUtils.startAPP(getApplicationContext(),appname);
                        this.isrunning = false;
                        return;
                    }
                }
                Intent intent = new Intent();
                intent.setAction(AppConstsNxys.ACTION_TRADEQUERY);
                sendBroadcast(intent);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public void onDestroy() {
        super.onDestroy();
        // 如果Service被杀死 重启自己
        Intent intent = new Intent(getApplicationContext(),TradeQueryService.class);
        startService(intent);
        isrunning = false;
    }
}
