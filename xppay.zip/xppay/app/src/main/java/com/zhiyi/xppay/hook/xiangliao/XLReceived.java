package com.zhiyi.xppay.hook.xiangliao;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.google.myjson.JsonObject;
import com.google.myjson.JsonParser;
import com.zhiyi.xppay.consts.AppConst;

import java.lang.reflect.Proxy;
import java.util.ArrayList;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Administrator on 2019/3/26.
 */

public class XLReceived extends BroadcastReceiver {


    Context mContext;

    public XLReceived(Context arg2) {
        super();

        this.mContext = arg2;
    }

//    private static ArrayList<JsonObject> orders;


    private void CreatRedPacket(Context context, ClassLoader classLoader, Intent intent) {
        String jsonStr = intent.getStringExtra("json");
        JsonObject json = (JsonObject)new JsonParser().parse(jsonStr);

        String remark = json.get("remark").getAsString();
        String receiveId = json.get("pay_uid").getAsString();
        String amount = json.get("pay_money").getAsString();
        String orderId = json.get("orderid").getAsString();
//        orders.add(json);
        Object v1 = XposedHelpers.newInstance(XposedHelpers.findClass("com.ixl.talk.xlmm.base.api.b.d.l", classLoader), new Object[]{Proxy.newProxyInstance(classLoader, new Class[]{XposedHelpers.findClass("com.ixl.talk.xlmm.base.api.resp.IRequestCallBack", classLoader)}, new CreatPacketProxy(context, remark, amount, receiveId,orderId))});
        XposedHelpers.setObjectField(v1, "b", remark);
        XposedHelpers.setObjectField(v1, "c", amount);
        XposedHelpers.setObjectField(v1, "d", "1");
        XposedHelpers.setObjectField(v1, "e", receiveId);
        XposedHelpers.setObjectField(v1, "f", "1");
        XposedHelpers.setObjectField(v1, "g", null);
        XposedHelpers.callMethod(v1, "e", new Object[0]);
    }

//    public static String getOrderId(String money){
//        for(int i=orders.size()-1;i>=0;i--){
//            JsonObject jsonObject = orders.get(i);
//            if(money.equals(jsonObject.get("pay_money").getAsString())){
//                orders.remove(i);
//                return jsonObject.get("orderid").getAsString();
//            }
//        }
//    }

    public void onReceive(Context arg6, Intent intent) {

        XposedBridge.log("发起乡聊");
        try {
            if (intent.getAction().equals(AppConst.TYPE_XiangLiao+AppConst.ACTION_BUILD_QRCODE)) {
                this.CreatRedPacket(arg6, mContext.getClassLoader(), intent);
            }

        } catch (Exception v1) {
            XposedBridge.log("发起钉乡聊失败");
        }
    }
}

