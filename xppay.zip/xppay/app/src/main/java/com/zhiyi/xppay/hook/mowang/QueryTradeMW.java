package com.zhiyi.xppay.hook.mowang;

import android.content.Context;
import android.content.Intent;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.hook.mayou.TradeBean;
import com.zhiyi.xppay.net.Socket.ClientManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/4/12.
 */

public class QueryTradeMW {
    protected LinkedList<OrderObjectMW> getTradeList;
    protected ArrayList<Object> reciveTradeList;

    protected boolean isStart;

    protected Context mng;

    public QueryTradeMW(Context mng) {
        isStart = false;
        getTradeList = new LinkedList<>();
        reciveTradeList = new ArrayList<>();
        this.mng = mng;
    }
    public void CreateTrade(OrderObjectMW object){
        //
        XposedBridge.log("===========准备轮询==============");
        addOrderBean(object);
        XposedBridge.log("isStart >>>>>>>>> "+isStart);
        if (!isStart){
            isStart = true;
            XposedBridge.log("===========start==============");
            startQueryTrade();
        }
    }

    public void addOrderBean(OrderObjectMW object){
        boolean ishas = false;
        for (Iterator<OrderObjectMW> o = getTradeList.iterator(); o.hasNext(); ) {
            OrderObjectMW code = o.next();
            if(object.mark.equals(code.mark)){
                XposedBridge.log(">>>>>>> 重复订单 >>>>>>> "+object.mark);
                ishas = true;
            }
        }
        if(!ishas){
            getTradeList.addLast(object);
            XposedBridge.log(">>>>>>> 增加了一个新的轮询订单 >>>>>>> "+object);
        }
    }

    public void receiveOrderBean(Object data) {
        OrderObjectMW receive = getOrderBeanByState(data);
        if(receive != null){
            boolean ishas = getTradeList.contains(receive);
            if(ishas){
                getTradeList.remove(receive);
                XposedBridge.log("删除 成功的订单");
                XposedBridge.log("===========end==============");
            }
        }
    }

    private void SendOrderBean(OrderObjectMW orderbean){
        HookMoTong.checkCallBack(orderbean);
    }

    private OrderObjectMW bean;
    private void startQueryTrade(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(!getTradeList.isEmpty()){
                    try {
                        bean = getTradeList.getLast();
                        if(!bean.ischecked){
                            bean.ischecked = true;
                            SendOrderBean(bean);
                        }
                        Thread.sleep(500);
                        if(System.currentTimeMillis() - bean.createtime>600000){
                            getTradeList.remove(bean);
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                isStart = false;
                XposedBridge.log("startQueryTrade轮询完成》》》》");
            }
        }).start();
    }
    public synchronized OrderObjectMW getOrderBeanByState(Object data) {
        OrderObjectMW rcode = null;
        for (Iterator<OrderObjectMW> o = getTradeList.iterator(); o.hasNext(); ) {
            OrderObjectMW code = o.next();
            if(code.o_observable.equals(data)){
                XposedBridge.log("getOrderBeanByState code >> "+code);
                return code;
            }else{
                XposedBridge.log("两个物体不相同");
            }
        }
        return rcode;
    }
}
