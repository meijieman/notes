package com.zhiyi.xppay.hook.dingding.groupgather;

/**
 * Created by pc_mg on 2019/4/16.
 */

public class CreatBilProxy {
}
