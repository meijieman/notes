package com.zhiyi.xppay.yst.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.zhiyi.xppay.yst.consts.Appconsts;
import com.zhiyi.xppay.yst.hook.Hookyst;

import org.json.JSONException;
import org.json.JSONObject;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_mg on 2019/3/6.
 */

public class ToolsYST {
    public static boolean ishookeed;// hook到
    public static boolean isactivitystart;// activity开启
    public static String remark;
    public static String money;
    public static boolean iscreating;
    private  static String gpsInfo = "121.50,31.27";
    @SuppressLint("WrongConstant")
    public static void CreateQRCode(final Context context, final String _money,final String mark) {
//        HookNxys.createqr(money, type);
        //
        gpsInfo = Hookyst.getLocation();
        sendqrcode(context,_money,mark,gpsInfo);

        if(true) return;
        if (!iscreating) {// https://m.ysepay.com/yst-qr/scanPay?transId=2018001&merId=826392452110009&transAmt=10.00&userCode=826392452110009&clientGps=13537748.560542481,4680171.282777258
            iscreating = true;
            remark = mark;
            money = _money;
            ComponentName componentName = new ComponentName("com.ysepay.mobileportal.activity", "com.ysepay.mobileportal.activity.html.JsBridgeHtml");
            Intent intent = new Intent();
            intent.setComponent(componentName);
            intent.putExtra("html5Url", "https://m.ysepay.com/yst-qr/newQrCode?userCode=" + Hookyst.getUserCode(context) + "&userType=02&curPayMoney=" + money + "&system=Android&version=4.1.4180802");
            intent.putExtra("hideRefleshItem", false);
            intent.putExtra("qrCodeEntryString", "02");
            intent.putExtra("htmlTitle", "收款");
            intent.setFlags(67108864);
            context.startActivity(intent);
        }
    }

    public static void setGpsInfo(){
        HttpUtils httpUtils = new HttpUtils(300000);
        httpUtils.send(HttpRequest.HttpMethod.GET, "https://ip.nf/me.json", null, new RequestCallBack<String>() {// 获取IP地址
            @Override
            public void onSuccess(ResponseInfo<String> responseInfo) {
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(responseInfo.result);
                    jsonObject = jsonObject.getJSONObject("ip");
                    if(jsonObject.has("latitude")&&jsonObject.has("longitude")){
                        String strlat = jsonObject.getString("latitude");
                        String strlon = jsonObject.getString("longitude");
                        String gps = strlon+","+strlat;
                        //
                        gpsInfo = gps;
                        //
                    }else {
                        XposedBridge.log("获取地址失败");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(HttpException e, String s) {
                XposedBridge.log("获取地址失败e "+e);
            }
        });
    }

    private static void sendqrcode(final Context context, final String _money,final String mark,String location){
        HttpUtils httpUtils = new HttpUtils(30000);
        RequestParams params = new RequestParams();
        String usercode = Hookyst.getUserCode(context);
        params.addBodyParameter("transId","2018001");
        params.addBodyParameter("merId",usercode.contains("m")?Hookyst.getMerCId(context):usercode);
        params.addBodyParameter("transAmt",_money);
        params.addBodyParameter("userCode",usercode);
        params.addBodyParameter("clientGps",location);
        XposedBridge.log("Hookyst.getUserCode(context) >>>>>> "+usercode);
        httpUtils.send(HttpRequest.HttpMethod.POST, "https://m.ysepay.com/yst-qr/scanPay", params, new RequestCallBack<String>() {
                    @Override
                    public void onSuccess(ResponseInfo<String> responseInfo) {
                        String str = responseInfo.result;
                        try { //https://m.ysepay.com/yst-qr/newQrCode?userCode=m15659021513&userType=01&curPayMoney=6&system=Android&version=4.1.4180802
                            JSONObject jsonObject = new JSONObject(responseInfo.result);
                            XposedBridge.log("jsonObject >>>>>>>>>>>>> "+jsonObject);
                            if(jsonObject.has("codeUrl")){
                                String codeurl = jsonObject.getString("codeUrl");
                                ToolsYST.sendqrcod(context,_money,codeurl,mark);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            XposedBridge.log(e.getMessage());
                        }
                    }

                    @Override
                    public void onFailure(HttpException e, String s) {
                        XposedBridge.log("银盛通获取二维码异常 "+e);
                    }
                }
        );
    }

    public static void sendmsg(Context context, String msg) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("msg", msg);
        broadCastIntent.setAction(Appconsts.ACTION_MSGRECEIVED);
        context.sendBroadcast(broadCastIntent);
    }

    public static void sendqrcod(Context context,String money, String qrlink, String remark) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(Appconsts.ACTION_SENDQRCODE);
        broadCastIntent.putExtra("qrlink", qrlink);
        broadCastIntent.putExtra("mark", remark);
        broadCastIntent.putExtra("money", money);
        context.sendBroadcast(broadCastIntent);
    }

    public static void sendtrade(Context context, String payTime, String orderId, String realAmount, String merName, String type) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(Appconsts.ACTION_SENDTRADE);
        broadCastIntent.putExtra("payTime", payTime);
        broadCastIntent.putExtra("orderId", orderId);
        broadCastIntent.putExtra("realAmount", realAmount);
        broadCastIntent.putExtra("merName", merName);
        broadCastIntent.putExtra("type", type);
        context.sendBroadcast(broadCastIntent);
    }

    public static void sendActivitystart(Context context) {
        Intent intent = new Intent();
        intent.setAction(Appconsts.ACTION_ACTIVITYSTART);
        context.sendBroadcast(intent);
    }

    public static void tradequery(Context context) {
        if (isactivitystart && ishookeed) {
            ToolsYST.sendmsg(context, "开启账单轮询");
            Intent broadCastIntent = new Intent();
            broadCastIntent.setAction(Appconsts.ACTION_STARTTRADEQUERY);
            context.sendBroadcast(broadCastIntent);
        }
    }

    public static void forceOpenSelf(Context context) {
        Intent intent = new Intent();
        intent.setClassName("com.zhiyi.xppay", "com.zhiyi.xppay.ui.MainActivity");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
