package com.zhiyi.xppay.net.Socket;

import android.content.Context;
import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.consts.AppConstsNxys;
import com.zhiyi.xppay.net.Socket.RecevieMsg.BathBuildQrcode;
import com.zhiyi.xppay.net.Socket.RecevieMsg.BathQrcodeFormat;
import com.zhiyi.xppay.net.Socket.RecevieMsg.BuildQrcode;
import com.zhiyi.xppay.ui.MainActivity;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.yst.consts.Appconsts;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

import de.robv.android.xposed.XposedBridge;

/**
 * Created by pc_unity on 2018/11/12.
 */

public class BuildQrCode {

    protected LinkedList<BuildQrcode> getQrcodeList;
    protected ArrayList<BuildQrcode> reciveQrcodeList;

    protected Random random;

    protected boolean isStart;

    protected String runningAppType = "";

    protected ClientManager mng;

    public BuildQrCode(ClientManager mng) {
        isStart = false;
        getQrcodeList = new LinkedList<>();
        reciveQrcodeList = new ArrayList<>();
        random = new Random(System.currentTimeMillis());
        this.mng = mng;
    }


    protected String getMark() {
        String chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        String ret = "";
        for (int i = 0; i < 4; i++) {
            int ra = random.nextInt(chars.length() - 1);
            ret += chars.substring(ra, ra + 1);
        }

        int year3 = 3 * 365 * 86400;
        ret += (System.currentTimeMillis() / 1000) % year3;
        return ret;
    }

    public void batchBuildQrcode(BathBuildQrcode build, BathQrcodeFormat formate) {
        for (String money : formate.money) {
            BuildQrcode data = new BuildQrcode();
            data.remark = getMark();
            data.money = money;
            data.paytype = build.paytype;
            getQrcodeList.addFirst(data);
        }

        if (!isStart) {
            isStart = true;
            StartBullitQrcode();
        }
    }

    public void buildQrcode(BuildQrcode data) {
        String mny = data.money;
        double dmny = Double.parseDouble(mny);
        data.money = String.format("%.2f", dmny);
        getQrcodeList.addFirst(data);
        if (!isStart) {
            isStart = true;
            StartBullitQrcode();
        }
    }

    public void receiveQrCode(BuildQrcode data) {
        if (building != null) {
            data.orderId = building.orderId;
        }
        reciveQrcodeList.add(data);
    }

    protected void BullidQrcode(String type, String money, String mark) {
        if (type == null || type.equals("")) {
            type = AppConst.TYPE_ALIPAY;
        }
        type = type.toUpperCase();
        Context context = mng.getContext();

        if (type.equals(AppConst.TYPE_ALIPAY) && !PayHelperUtils.isAppRunning(context, "com.eg.android.AlipayGphone")) {
            PayHelperUtils.startAPP(context, "com.eg.android.AlipayGphone");
        } else if (type.equals(AppConst.TYPE_WXPAY) && !PayHelperUtils.isAppRunning(context, "com.tencent.mm")) {
            PayHelperUtils.startAPP(context, "com.tencent.mm");
        } else if (type.equals(AppConst.TYPE_QQPAY) && !PayHelperUtils.isAppRunning(context, "com.tencent.mobileqq")) {
            PayHelperUtils.startAPP(context, "com.tencent.mobileqq");
        } else if (type.equals(AppConst.TYPE_LKLPAY) && !PayHelperUtils.isAppRunning(context, "com.lakala.cloudpos.qcodeapp")) {
//            PayHelperUtils.startAppLKL(context);
            PayHelperUtils.startAPP(context, "com.lakala.cloudpos.qcodeapp");
        } else if (type.equals(AppConst.TYPE_DingDing) && !PayHelperUtils.isAppRunning(context, AppConst.APP_DINGDING)) {
            PayHelperUtils.startAPP(context, AppConst.APP_DINGDING);
        }else if(type.equals(AppConst.TYPE_DIANDIANCHONG)){

        }else if(type.equals(AppConst.TYPE_TBH)&&!PayHelperUtils.isAppRunning(context,AppConst.APP_TBH)){
            XposedBridge.log("重启旺信");
            PayHelperUtils.sendmsg(context,"重启旺信");
            PayHelperUtils.startAPP(context, AppConst.APP_TBH);
        }else if(type.equals(AppConstsNxys.TYPE_NXYS)&&!PayHelperUtils.isAppRunning(context,AppConstsNxys.PACKAGENAME)){
            PayHelperUtils.sendmsg(context,"重启农信易扫");
            PayHelperUtils.startAPP(context, AppConstsNxys.PACKAGENAME);
        }
        else if(type.contains(AppConst.TYPE_NXFJSH)&&!PayHelperUtils.isAppRunning(context,AppConst.APP_NXFJSH)){
            PayHelperUtils.startAPP(context, AppConst.APP_NXFJSH);
        }else if(type.equals(AppConst.TYPE_XX)&&!PayHelperUtils.isAppRunning(context,"com.jishuo.xiaoxin")){
            PayHelperUtils.startAPP(context, "com.jishuo.xiaoxin");
        }else if(type.equals(AppConst.TYPE_YZF)&&!PayHelperUtils.isAppRunning(context,AppConst.APP_YZF)){
            PayHelperUtils.startAPP(context, AppConst.APP_YZF);
        }else if(type.equals(AppConst.TYPE_CPPAY)&&!PayHelperUtils.isAppRunning(context,"com.unionpay")){
            PayHelperUtils.startAPP(context,"com.unionpay");
        }else if(type.equals(AppConst.TYPE_SB)&&!PayHelperUtils.isAppRunning(context,AppConst.APP_SB)){
            PayHelperUtils.startAPP(context,AppConst.APP_SB);
        }
//        else if() 云闪付不用启动
        PayHelperUtils.sendAppMsg(money, mark, type, context);
    }

    private BuildQrcode building;

    protected void StartBullitQrcode() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (!getQrcodeList.isEmpty()) {
                    try {
                        building = getQrcodeList.getLast();
                        //
                        if (AppConst.LOCKSCREEN) {
                            if (GetQRFailLScreen(building)) {
                                continue;
                            }
                        }
                        //
                        if (!runningAppType.isEmpty() && !runningAppType.equals(building.paytype)) {
                            PayHelperUtils.startAPP();
                            Thread.sleep(500);
                        }
                        runningAppType = building.paytype;
                        XposedBridge.log("生成qrcode");
                        BullidQrcode(building.paytype, building.money, building.remark);
                        long time = System.currentTimeMillis();
                        while (true) {
                            BuildQrcode receive = getQrCodeByRemark(building);
                            float t_wait= 5;
                            if(building.paytype.equals(Appconsts.TYPE_YST)||building.paytype.equals((AppConst.TYPE_MY))){// 银盛通时间较长
                                t_wait= 30;
                            }
                            if (receive == null && System.currentTimeMillis() - time < t_wait * 1000) {
                                Thread.sleep(200);
                            } else {
                                if (receive != null) {
                                    getQrcodeList.removeLast();
                                    reciveQrcodeList.remove(receive);
                                }
                                break;
                            }
                        }
                        if (!getQrcodeList.isEmpty()) {
                            Thread.sleep(1500);
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                PayHelperUtils.startAPP();
                isStart = false;
                runningAppType = "";
            }
        }).start();
    }

    public synchronized BuildQrcode getQrCodeByRemark(BuildQrcode bcode) {
        BuildQrcode rcode = null;
        for (Iterator<BuildQrcode> o = reciveQrcodeList.iterator(); o.hasNext(); ) {
            BuildQrcode code = o.next();
            if (code.paytype.equals(bcode.paytype)) {
                if (code.money.equals(bcode.money)) {
                    rcode = code;
                    if (code.remark.equals(bcode.remark)) {
                        return code;
                    } else {
                        MainActivity.sendmsg("备注相同，金额不对：" + code.remark + " " + code.money);
                    }
                }
            }
        }
        return rcode;
    }

    /**
     * 锁屏状态 获取QR失败
     * @param info 二维码信息
     * @return 是否跳过,返回true,表示锁屏状态不能产生二维码,失败
     */
    private boolean GetQRFailLScreen(BuildQrcode info) {
        if ("-".equals(info.paytype)) {
            getQrcodeList.removeLast();
//            isStart = false;
//            runningAppType = "";
//            getQrcodeList.clear();
//            reciveQrcodeList.clear();
            ClientManager.getInstance().OnLScreenError(info.type, info.paytype, info.remark, "锁屏状态获取二维码失败");
            MainActivity.sendmsg("锁屏无法生产二维码:"+info.type+"/" +info.paytype+",备注"+info.remark);
            return true;
        }
        return false;
    }
}
