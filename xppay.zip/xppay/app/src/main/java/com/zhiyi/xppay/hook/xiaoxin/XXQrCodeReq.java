package com.zhiyi.xppay.hook.xiaoxin;

import com.zhiyi.xppay.utils.JsonHelper;

/**
 * Created by pc_mg on 2019/4/23.
 */

public class XXQrCodeReq {
    private String orderTitle;
    private String amount;
    private String type;
    private String redPacketNumber;
    private String businessId;
    public XXQrCodeReq(String _orderTitle, String _amount, String _businessId){
        orderTitle = _orderTitle;
        amount = _amount;
        type = "2";
        redPacketNumber = "1";
        businessId = _businessId;
    }
    public String toJson() {
        String sendStr = JsonHelper.toJson(this);
        return sendStr;
    }
}
