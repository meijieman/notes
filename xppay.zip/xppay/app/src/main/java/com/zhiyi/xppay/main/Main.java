package com.zhiyi.xppay.main;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import com.zhiyi.xppay.consts.AppConst;
import com.zhiyi.xppay.consts.AppConstsNxys;
import com.zhiyi.xppay.ddc.DianDianChong;
import com.zhiyi.xppay.hook.AlipayHook;
import com.zhiyi.xppay.hook.AlipayHook38;
import com.zhiyi.xppay.hook.CloudPayHook;
import com.zhiyi.xppay.hook.HookNxys;
import com.zhiyi.xppay.hook.alihook.AlipayHook65;
import com.zhiyi.xppay.hook.fl.HookFL;
import com.zhiyi.xppay.hook.fshl.HookFSHL;
import com.zhiyi.xppay.hook.hybsyt.HookHYBSYT;
import com.zhiyi.xppay.hook.jyen.HookJYES;
import com.zhiyi.xppay.hook.mayou.CreatBilProxy;
import com.zhiyi.xppay.hook.mayou.HookMayou;
import com.zhiyi.xppay.hook.nxfjsh.HookNXFJSH;
import com.zhiyi.xppay.hook.mayou.QueryProxy;
import com.zhiyi.xppay.hook.mowang.HookMoTong;
import com.zhiyi.xppay.hook.nxys_hb.HookNXYS_HB;
import com.zhiyi.xppay.hook.pashgj.HookPASHGJ;
import com.zhiyi.xppay.hook.qnshb.HookQNSHB;
import com.zhiyi.xppay.hook.sb.HookSB;
import com.zhiyi.xppay.hook.sb.ReceiverSB;
import com.zhiyi.xppay.hook.skb.Hook51SKB;
import com.zhiyi.xppay.hook.skb.ToolsSKB;
import com.zhiyi.xppay.hook.skm.HookSKM;
import com.zhiyi.xppay.hook.sqeyh.HookSQEYH;
import com.zhiyi.xppay.hook.taobao.HookTB;
import com.zhiyi.xppay.hook.taobao.ToolsTaobao;
import com.zhiyi.xppay.hook.v138.Tools;
import com.zhiyi.xppay.hook.wl.HookWL;
import com.zhiyi.xppay.hook.wzp.HookWZP;
import com.zhiyi.xppay.hook.wzp.ReceiverWZP;
import com.zhiyi.xppay.hook.xgj.HookXgj;
import com.zhiyi.xppay.hook.LakalaHook;
import com.zhiyi.xppay.hook.QQHook;
import com.zhiyi.xppay.hook.QQPlugHook;
import com.zhiyi.xppay.hook.RimetHook;
import com.zhiyi.xppay.hook.WechatHook;
import com.zhiyi.xppay.hook.xgj.ToolsXGJ;
import com.zhiyi.xppay.hook.xiangliao.XLHook;
import com.zhiyi.xppay.hook.xiaoxin.HookXiaoxin;
import com.zhiyi.xppay.hook.xxqg.HookXxqg;
import com.zhiyi.xppay.hook.yzf.HookYZF;
import com.zhiyi.xppay.utils.AlipayInfo;
import com.zhiyi.xppay.utils.JsonHelper;
import com.zhiyi.xppay.utils.PayHelperUtils;
import com.zhiyi.xppay.utils.QQDBManager;
import com.zhiyi.xppay.utils.QrCodeBean;
import com.zhiyi.xppay.utils.ToolsNxys;
import com.zhiyi.xppay.yst.consts.Appconsts;
import com.zhiyi.xppay.yst.hook.Hookyst;
import com.zhiyi.xppay.yst.utils.ToolsYST;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Iterator;

import dalvik.system.BaseDexClassLoader;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * @author 大连致一科技
 * @ClassName: Main
 * @Description: 开始监控所有
 * @date 2018年11月7日 下午1:26:26
 */
public class Main implements IXposedHookLoadPackage {
    public static String WECHAT_PACKAGE = "com.tencent.mm";
    public static String ALIPAY_PACKAGE = "com.eg.android.AlipayGphone";
    public static String QQ_PACKAGE = "com.tencent.mobileqq";
    public static String CP_PACKAGE = "com.unionpay";
    public static String LKL_PACKAGE = "com.lakala.cloudpos.qcodeapp";
    public static String DDC_PACKAGE = "com.alibaba.android.babylon";

    public static String QQ_WALLET_PACKAGE = "com.qwallet";
    public static boolean WECHAT_PACKAGE_ISHOOK = false;
    public static boolean ALIPAY_PACKAGE_ISHOOK = false;
    public static boolean QQ_PACKAGE_ISHOOK = false;
    public static boolean QQ_WALLET_ISHOOK = false;
    public static boolean CP_PACKAGE_ISHOOK = false;
    public static boolean LKL_PACKAGE_ISHOOK = false;
    private static boolean ishookednxys = false;
    private static boolean ishookedyst = false;
    public static boolean DINGDING_ISHOOK = false;
    public static boolean XYJ_ISHOOK = false;
    private static boolean DDC_PACKAGE_ISHOOK = false;
    private static boolean TB_HOOK = false;
    private static boolean SKB_HOOK = false;
    private static boolean XXQG_HOOK = false;
    private static boolean MY_HOOK = false;
    private static boolean XX_HOOK = false;
    private static boolean NXYSHB_HOOK = false;
    private static boolean NXFJSH_HOOK = false;
    private static boolean HYBSYT_HOOK = false;
    private static boolean JYEN_HOOK = false;
    private static boolean YZF_HOOK = false;
    private static boolean FL_HOOK = false;
    private static boolean SKM_HOOK = false;
    private static boolean WL_HOOK = false;
    private static boolean PA_HOOK = false;
    private static boolean QNSHB_HOOK = false;
    private static boolean WZP_HOOK = false;
    private static boolean SB_HOOK = false;
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam)
            throws Throwable {
        if (lpparam.appInfo == null || (lpparam.appInfo.flags & (ApplicationInfo.FLAG_SYSTEM |
                ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) {
            if (lpparam.appInfo != null) {
                XposedBridge.log("不能监控的包" + lpparam.appInfo.name + "," + lpparam.packageName);
            }
            return;
        }
        final String packageName = lpparam.packageName;
        final String processName = lpparam.processName;

        if (DDC_PACKAGE.equals(lpparam.packageName)) {
            try {
                XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Context context = (Context) param.args[0];
                        if (Main.DDC_PACKAGE.equals(processName) && !Main.DDC_PACKAGE_ISHOOK) {
                            Main.DDC_PACKAGE_ISHOOK = true;
                            XposedBridge.log("handleLoadPackage: " + packageName);
                            PayHelperUtils.sendmsg(context, "点点虫Hook成功，当前点点虫版本:" + PayHelperUtils.getVerName(context) + ";");
                            XposedHelpers.findAndHookMethod("com.alibaba.android.babylon.biz.MainActionBarActivity", lpparam.classLoader, "onCreate", new Object[]{Bundle.class, new XC_MethodHook() {
                                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                    Context context = (Context) param.thisObject;
                                    new DianDianChong(context);
                                }
                            }});

                        }
                    }
                }});
            } catch (Throwable e22) {
                XposedBridge.log(e22);
            }
        } else if (WECHAT_PACKAGE.equals(packageName)) {
            XposedBridge.log("开始监控微信");
            try {
                XposedHelpers.findAndHookMethod(ContextWrapper.class, "attachBaseContext", Context.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        if (WECHAT_PACKAGE.equals(processName) && !WECHAT_PACKAGE_ISHOOK) {
                            WECHAT_PACKAGE_ISHOOK = true;
                            //注册广播
                            StartWechatReceived stratWechat = new StartWechatReceived();
                            IntentFilter intentFilter = new IntentFilter();
                            intentFilter.addAction(AppConst.WECHATSTART_ACTION);
                            context.registerReceiver(stratWechat, intentFilter);
                            XposedBridge.log("handleLoadPackage: " + packageName);
                            PayHelperUtils.sendmsg(context, "微信Hook成功，当前微信版本:" + PayHelperUtils.getVerName(context));
                            new WechatHook().hook(appClassLoader, context);
                        }
                    }
                });
            } catch (Throwable e) {
                XposedBridge.log(e);
            }
        } else if (ALIPAY_PACKAGE.equals(packageName)) {
            XposedBridge.log("开始监控支付宝");
            try {
                XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        String vs = PayHelperUtils.getVerName(context);
                        XposedBridge.log("当前版本vs"+vs);
                        if (ALIPAY_PACKAGE.equals(processName) && !ALIPAY_PACKAGE_ISHOOK) {
                            if (vs.startsWith("10.1.22")) {
                                // 进入余额
                                StartAlipayToBanlance banlance = new StartAlipayToBanlance();
                                IntentFilter _intentFilter0 = new IntentFilter();
                                _intentFilter0.addAction("com.payhelper.alipay.tobanlance");
                                context.registerReceiver(banlance, _intentFilter0);
                                // 自动提现
                                StartAlipayAutowithdraw autowithdraw = new StartAlipayAutowithdraw();
                                IntentFilter _intentFilter = new IntentFilter();
                                _intentFilter.addAction("com.payhelper.alipay.withdraw");
                                context.registerReceiver(autowithdraw, _intentFilter);
                                // 自动转账到银行
                                StarAlipayAutoTransfertoBank autotrantobank = new StarAlipayAutoTransfertoBank();
                                IntentFilter _intentFilter1 = new IntentFilter();
                                _intentFilter1.addAction("com.payhelper.alipay.transfertobank");
                                context.registerReceiver(autotrantobank, _intentFilter1);
                                //自动转账到支付宝
                                StarAlipayAutoTransfertoAliAccount autoTransfertoAliAccount = new StarAlipayAutoTransfertoAliAccount();
                                IntentFilter _intentFilter2 = new IntentFilter();
                                _intentFilter2.addAction("com.payhelper.alipay.transfertoaliaccount");
                                context.registerReceiver(autoTransfertoAliAccount, _intentFilter2);

                                //注册广播
                                StartAlipayReceived startAlipay = new StartAlipayReceived();
                                IntentFilter intentFilter = new IntentFilter();
                                intentFilter.addAction(AppConst.ALIPAYSTART_ACTION);
                                intentFilter.addAction(AppConst.ALIPAYMBANK_ACTION);
                                context.registerReceiver(startAlipay, intentFilter);
                                XposedBridge.log("handleLoadPackage: " + packageName);

                                new AlipayHook().hook(appClassLoader, context);
                            } else if (vs.startsWith("10.1.38")) {
                                StartAlipayReceived startAlipay = new StartAlipayReceived();
                                IntentFilter intentFilter = new IntentFilter();
                                intentFilter.addAction(AppConst.ALIPAYSTART_ACTION);
                                intentFilter.addAction(AppConst.ALIPAY_FRIEND_ORDER_ACTION);
                                intentFilter.addAction(AppConst.ALIPAY_FRIEND_CHECK_ACTION);
                                intentFilter.addAction(AppConst.ALIPAYPERSONALQRCODE_ACTION);
                                intentFilter.addAction(AppConst.ALIPAY_FIXED_POSITION);
                                intentFilter.addAction(AppConst.TRADEDETAIL_ACTION);
                                context.registerReceiver(startAlipay, intentFilter);
                                XposedBridge.log("handleLoadPackage: " + packageName);
                                new AlipayHook38().hook(appClassLoader, context);
                            }else if(vs.startsWith("10.1.65")){
                                StartAlipayReceived startAlipay1 = new StartAlipayReceived();
                                IntentFilter intentFilter = new IntentFilter();
                                intentFilter.addAction(AppConst.ALIPAYSTART_ACTION);
                                intentFilter.addAction(AppConst.ALIPAY_FRIEND_ORDER_ACTION);
                                intentFilter.addAction(AppConst.ALIPAY_FRIEND_CHECK_ACTION);
                                intentFilter.addAction(AppConst.ALIPAYPERSONALQRCODE_ACTION);
                                intentFilter.addAction(AppConst.ALIPAY_FIXED_POSITION);
                                intentFilter.addAction(AppConst.TRADEDETAIL_ACTION);
                                context.registerReceiver(startAlipay1, intentFilter);
                                new AlipayHook65().hook(appClassLoader, context);
                            }
                            else {
                                PayHelperUtils.sendmsg(context, "不支持的支付宝版本:" + vs);
                                return;
                            }
                            ALIPAY_PACKAGE_ISHOOK = true;
                            PayHelperUtils.sendmsg(context, "支付宝Hook成功，当前支付宝版本:" + vs);
                        } else {
                            XposedBridge.log("processName:" + ALIPAY_PACKAGE.equals(processName) + ":" + processName);
                            XposedBridge.log("hooked:" + ALIPAY_PACKAGE_ISHOOK);
                        }
                    }
                });
            } catch (Throwable e) {
                XposedBridge.log(e);
            }
        } else if (QQ_PACKAGE.equals(packageName)) {
            XposedBridge.log("开始监控QQ");
            try {
                XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        if (QQ_PACKAGE.equals(processName) && !QQ_PACKAGE_ISHOOK) {
                            QQ_PACKAGE_ISHOOK = true;
                            //注册广播
                            StartQQReceived startQQ = new StartQQReceived();
                            IntentFilter intentFilter = new IntentFilter();
                            intentFilter.addAction(AppConst.QQSTART_ACTION);
                            context.registerReceiver(startQQ, intentFilter);
                            XposedBridge.log("handleLoadPackage: " + packageName);
                            PayHelperUtils.sendmsg(context, "QQHook成功，当前QQ版本:" + PayHelperUtils.getVerName(context));
                            new QQHook().hook(appClassLoader, context);
                        }
                    }
                });

                XposedHelpers.findAndHookConstructor("dalvik.system.BaseDexClassLoader",
                        lpparam.classLoader, String.class, File.class, String.class, ClassLoader.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {

                                if (param.args[0].toString().contains("qwallet_plugin.apk")) {
                                    ClassLoader classLoader = (BaseDexClassLoader) param.thisObject;
                                    new QQPlugHook().hook(classLoader);
                                }
                            }
                        });
            } catch (Exception e) {
                XposedBridge.log(e);
            }
        } else if (CP_PACKAGE.equals(packageName)) {
            XposedBridge.log("开始监控云闪付");
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                    Context context = (Context) param.args[0];
                    ClassLoader appClassLoader = context.getClassLoader();
                    if (CP_PACKAGE.equals(processName) && !CP_PACKAGE_ISHOOK) {
                        CP_PACKAGE_ISHOOK = true;
                        XposedBridge.log(" 云闪付hook成功,当前版本 " + PayHelperUtils.getVerName(context));
                        new CloudPayHook().hook(lpparam.classLoader, context);
                    }
                }
            });
        } else if (LKL_PACKAGE.equals(packageName)) {
            try {
                final Class<?> clazz = XposedHelpers.findClass("com.stub.StubApp", lpparam.classLoader);
                XposedHelpers.findAndHookMethod(clazz, "onCreate", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        if (LKL_PACKAGE.equals(processName) && !LKL_PACKAGE_ISHOOK) {
                            XposedBridge.log("开始监控拉卡拉");
                            LKL_PACKAGE_ISHOOK = true;
                            XposedBridge.log(" onCreate " + param.thisObject);
                            Field field = XposedHelpers.findField(clazz, "ᵢˎ");
                            XposedBridge.log(" onCreate field " + field.getClass().getName());
                            field.setAccessible(true);
                            Object obj = field.get(param.thisObject);
                            Field fieldc = XposedHelpers.findField(clazz, "ᵢˑ");
                            fieldc.setAccessible(true);
                            Object objc = fieldc.get(param.thisObject);
                            XposedBridge.log(" onCreate Application " + obj + "context" + objc);
                            Context context = (Context) objc;
                            //注册广播LKLPayReceiver
                            IntentFilter intentFilter = new IntentFilter();
                            intentFilter.addAction(AppConst.LKL_QRCODE);
                            intentFilter.addAction(AppConst.LKL_TRADELIST);
                            context.registerReceiver(new Main().new LKLPayReceiver(), intentFilter);
                            new LakalaHook().hook(obj.getClass().getClassLoader(), (Context) objc);
                        }

                    }
                });
            } catch (Throwable th) {
                XposedBridge.log("LKL 出现异常0 》》》》》》》");
                XposedBridge.log(th);
            }
        } else if (AppConstsNxys.PACKAGENAME.equals(packageName)) {
            XposedBridge.log("开始监控农信易扫>>>");
            XposedHelpers.findAndHookMethod("s.h.e.l.l.S", lpparam.classLoader, "attachBaseContext", Context.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    super.beforeHookedMethod(param);
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    if (AppConstsNxys.PACKAGENAME.equals(processName) && !ishookednxys) {
                        ishookednxys = true;
                        //
                        Application application = (Application) param.thisObject;
                        Context context = application.getBaseContext();
                        XposedBridge.log("开始监控农信易扫 context >>>>>>> " + context);
                        ClassLoader classLoader = param.thisObject.getClass().getClassLoader();
                        ReceiverNxys receiverNxys = new ReceiverNxys();
                        IntentFilter filter = new IntentFilter();
                        filter.addAction(AppConstsNxys.ACTION_CREATEQRCODE);
                        filter.addAction(AppConstsNxys.ACTION_TRADEQUERY);
                        filter.addAction(AppConstsNxys.ACTION_ACTIVITYSTART);
                        context.registerReceiver(receiverNxys, filter);
                        new HookNxys().hook(classLoader, context);
                        ToolsNxys.ishookeed = true;
                    }
                }
            });
        } else if (AppConst.APP_DINGDING.equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {

                @Override
                protected void beforeHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                    super.beforeHookedMethod(methodHookParam);
                    Context context = (Context) methodHookParam.args[0];
                    String vs = PayHelperUtils.getVerName(context);
                    if (vs.equals("4.6.14")) {
                        PayHelperUtils.sendmsg(context, "DingDing 准备 Hook，当前版本:" + vs);
                    } else {
                        PayHelperUtils.sendmsg(context, "钉钉版本不对,请安装 4.6.14");
                    }
                }

                protected void afterHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                    super.afterHookedMethod(methodHookParam);
                    if (!DINGDING_ISHOOK) {
                        DINGDING_ISHOOK = true;
                        Context context = (Context) methodHookParam.args[0];
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addAction(AppConst.DINGDING_ACTION);
                        context.registerReceiver(new RimetHook.MyReceiver(), intentFilter);
                        RimetHook.hook(context, context.getClassLoader());
                        PayHelperUtils.sendmsg(context, "DingDing Hook成功，当前版本:" + PayHelperUtils.getVerName(context));
                    }
                }
            }});
            XposedBridge.log("==========调试=========:" + DINGDING_ISHOOK);
        } else if (Appconsts.PACKAGENAME.equals(packageName)) {
            XposedBridge.log("开始监控银盛通");
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    if (Appconsts.PACKAGENAME.equals(processName) && !ishookedyst) {
                        ishookedyst = true;
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        //
                        ReceiverYST receiverYST = new ReceiverYST();
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addAction(Appconsts.ACTION_CREATEQRCODE);
                        intentFilter.addAction(Appconsts.ACTION_ACTIVITYSTART);
                        intentFilter.addAction(Appconsts.ACTION_TRADEQUERY);
                        context.registerReceiver(receiverYST, intentFilter);
                        new Hookyst().hook(appClassLoader, context);
                        //
                        ToolsYST.ishookeed = true;
                    }
                }
            });
        } else if (AppConst.APP_XGJ.equals(packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    if (AppConst.APP_XGJ.equals(processName) && !XYJ_ISHOOK) {
                        XYJ_ISHOOK = true;
                        Context context = (Context) param.args[0];
                        ClassLoader classLoader = context.getClassLoader();
                        ReceiverXGJ receiverXGJ = new ReceiverXGJ();
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addAction(com.zhiyi.xppay.hook.xgj.AppConst.ACTION_ACTIVITYSTART);
                        intentFilter.addAction(com.zhiyi.xppay.hook.xgj.AppConst.ACTION_TRADEQUERY);
                        context.registerReceiver(receiverXGJ, intentFilter);
                        new HookXgj().hook(classLoader, context);
                        PayHelperUtils.sendmsg(context, "星管家Hook成功，当前版本:" + PayHelperUtils.getVerName(context));
                        ToolsXGJ.ishookeed = true;
                    }
                }
            });
        } else if ("com.ixl.talk.xlmm".equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Context v1 = (Context) param.args[0];
                    ClassLoader v0 = (v1).getClassLoader();
                    if (("com.ixl.talk.xlmm".equals(processName))) {
                        XLHook.hook(v0, v1);
                    }
                }
            }});
        } else if (AppConst.APP_TBH.equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Context v1 = (Context) param.args[0];
                    ClassLoader v0 = (v1).getClassLoader();
                    if ((AppConst.APP_TBH.equals(processName)) && !TB_HOOK) {
                        TB_HOOK = true;
                        PayHelperUtils.sendmsg(v1, "旺信Hook成功，当前旺信版本:" + PayHelperUtils.getVerName(v1));
                        ReceiverWX receiverTBWX = new ReceiverWX();
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addAction(AppConst.TBH_ACTION);
                        v1.registerReceiver(receiverTBWX, intentFilter);
                        new HookTB().hook(v0, v1);
                    }
                }
            }});
        } else if (AppConst.APP_SKB.equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Context context = (Context) param.args[0];
                    ClassLoader appClassLoader = context.getClassLoader();

                    final Class<?> clazz = XposedHelpers.findClass("com.stub.StubApp", appClassLoader); // onCreate

                    XposedHelpers.findAndHookMethod(clazz, "onCreate", new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            super.afterHookedMethod(param);
                            if (!SKB_HOOK && AppConst.APP_SKB.equals(processName)) {
                                SKB_HOOK = true;
                                XposedBridge.log(" onCreate " + param.thisObject);
                                Field fieldc = XposedHelpers.findField(clazz, "ᵢˑ");
                                fieldc.setAccessible(true);
                                Object objc = fieldc.get(param.thisObject);
                                Context context1 = (Context) objc;
                                //
                                ReceiverSKB receiverYST = new ReceiverSKB();
                                IntentFilter intentFilter = new IntentFilter();
                                intentFilter.addAction(AppConst.ACTION_CREATEQRCODE_SKB);
                                intentFilter.addAction(AppConst.ACTION_ACTIVITYSTART_SKB);
                                intentFilter.addAction(AppConst.ACTION_TRADEQUERY_SKB);
                                context1.registerReceiver(receiverYST, intentFilter);
                                //
                                ToolsSKB.ishookeed = true;
                                new Hook51SKB().hook(context1.getClassLoader(), context1);
                            }
                        }
                    });
                }
            });
        } else if (AppConst.APP_XXQG.equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Context v1 = (Context) param.args[0];
                    ClassLoader v0 = (v1).getClassLoader();
                    if ((AppConst.APP_XXQG.equals(processName)) && !XXQG_HOOK) {
                        XXQG_HOOK = true;
                        PayHelperUtils.sendmsg(v1, "学习强国Hook成功，当前学习强国版本:" + PayHelperUtils.getVerName(v1));
                        ReceiverXXQG receiver = new ReceiverXXQG();
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addAction(AppConst.ACTION_CREATEQRCODE_XXQG);
                        v1.registerReceiver(receiver, intentFilter);
                        new HookXxqg().hook(v0, v1);
                    }
                }
            }});
        } else if ("com.aoetech.aoelailiao".equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Context context = (Context) param.args[0];
                    ClassLoader appClassLoader = context.getClassLoader();
                    if ("com.aoetech.aoelailiao".equals(processName) && !MY_HOOK) {
                        MY_HOOK = true;
                        ReceiverMaYou stratWechat = new ReceiverMaYou(context);
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addAction(AppConst.ACTION_CREATEQRCODE_MAYOU);
                        context.registerReceiver(stratWechat, intentFilter);
                        XposedBridge.log("handleLoadPackage: " + packageName);
                        PayHelperUtils.sendmsg(context, "麻油Hook成功，当前麻油版本:" + PayHelperUtils.getVerName(context));
                        new HookMayou().hook(appClassLoader, context);
                    }
                }
            });
        } else if ("com.jishuo.xiaoxin".equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Context context = (Context) param.args[0];
                    ClassLoader appClassLoader = context.getClassLoader();
                    if ("com.jishuo.xiaoxin".equals(processName) && !XX_HOOK) {
                        XX_HOOK = true;
                        ReceiverXiaoXin stratXiaoxin = new ReceiverXiaoXin();
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addAction(AppConst.ACTION_CREATEQRCODE_XIAOXIN);
                        context.registerReceiver(stratXiaoxin, intentFilter);
                        XposedBridge.log("handleLoadPackage: " + packageName);
                        PayHelperUtils.sendmsg(context, "小信Hook成功，当前小信版本:" + PayHelperUtils.getVerName(context));
                        new HookXiaoxin().hook(appClassLoader, context);
                    }
                }
            });
        } else if (lpparam.packageName.equals(AppConst.APP_NXYS_HB) || lpparam.packageName.equals(AppConst.APP_NXYS_GT)) {
            try {
                XposedHelpers.findAndHookMethod("s.h.e.l.l.S", lpparam.classLoader, "attachBaseContext", Context.class, new XC_MethodHook() {
                    Context context = null;

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        super.beforeHookedMethod(param);
                    }

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        if ((lpparam.processName.equals(AppConst.APP_NXYS_HB) ||
                                lpparam.processName.equals(AppConst.APP_NXYS_GT)
                        ) && !NXYSHB_HOOK) {
                            NXYSHB_HOOK = true;
                            context = (Context) param.args[0];
                            ReceiverNxysHB receiverNxys = new ReceiverNxysHB();
                            receiverNxys.packagename = lpparam.processName;
                            IntentFilter filter = new IntentFilter();
                            filter.addAction(AppConstsNxys.ACTION_CREATEQRCODE);
                            filter.addAction(AppConstsNxys.ACTION_TRADEQUERY);
                            filter.addAction(AppConstsNxys.ACTION_ACTIVITYSTART);
                            context.registerReceiver(receiverNxys, filter);
                            new HookNXYS_HB().hook(lpparam.classLoader, context);
                            HookNXYS_HB.ishookeed = true;
                        }
                    }
                });
            } catch (Exception e) {
                Log.e("Xposed", "农信易扫 异常 e2>>>>>>>>>>>>" + e);
            }

        } else if (AppConst.APP_NXFJSH.equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod("s.h.e.l.l.S", lpparam.classLoader, "attachBaseContext", Context.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    super.beforeHookedMethod(param);
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    if (lpparam.processName.equals(AppConst.APP_NXFJSH) && !NXFJSH_HOOK) {
                        PayHelperUtils.LogMsg("开始HOOK福建农信商户版 Activity >>>>>>");
                        NXFJSH_HOOK = true;
                        Context context = (Context) param.args[0];
                        ReceiverNxysHJSH receiverNxys = new ReceiverNxysHJSH();
                        IntentFilter filter = new IntentFilter();
                        filter.addAction(AppConstsNxys.ACTION_CREATEQRCODE);
                        filter.addAction(AppConstsNxys.ACTION_TRADEQUERY);
                        filter.addAction(AppConstsNxys.ACTION_ACTIVITYSTART);
                        context.registerReceiver(receiverNxys, filter);
                        new HookNXFJSH().hook(lpparam.classLoader, context);
                        HookNXFJSH.ishookeed = true;
                    }
                }
            });
        } else if (AppConst.APP_HYBSYT.equals(packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    if (AppConst.APP_HYBSYT.equals(processName) && !HYBSYT_HOOK) {
                        HYBSYT_HOOK = true;
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        ReceiverHYBSYT receiverHYBSYT = new ReceiverHYBSYT();
                        IntentFilter filter = new IntentFilter();
                        filter.addAction(AppConst.ACTION_CREATEQRCODE_HYBSYT);
                        context.registerReceiver(receiverHYBSYT, filter);
                        //
                        new HookHYBSYT().hook(appClassLoader, context);
                        //
                    }
                }
            });
        } else if (AppConst.APP_JYES.equals(packageName)) {
            XposedHelpers.findAndHookMethod("s.h.e.l.l.S", lpparam.classLoader, "attachBaseContext", Context.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    super.beforeHookedMethod(param);
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    if (lpparam.processName.equals(AppConst.APP_JYES) && !JYEN_HOOK) {
                        JYEN_HOOK = true;
                        Context context = (Context) param.args[0];
                        ReceiverJYES receiverNxys = new ReceiverJYES();
                        IntentFilter filter = new IntentFilter();
                        filter.addAction(AppConstsNxys.ACTION_CREATEQRCODE);
                        filter.addAction(AppConstsNxys.ACTION_TRADEQUERY);
                        filter.addAction(AppConstsNxys.ACTION_ACTIVITYSTART);
                        context.registerReceiver(receiverNxys, filter);
                        new HookJYES().hook(lpparam.classLoader, context);
                        HookJYES.ishookeed = true;
                        PayHelperUtils.sendmsg(context, "开始HOOK河南农信金燕E商，当前版本" + PayHelperUtils.getVerName(context));
                    }
                }
            });
        } else if (AppConst.APP_FL.equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(ContextWrapper.class, "attachBaseContext", Context.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    if (AppConst.APP_FL.equals(processName) && !FL_HOOK) {
                        Context context = (Context) param.args[0];
                        FL_HOOK = true;
                        XposedBridge.log("handleLoadPackage: " + packageName);
                        PayHelperUtils.sendmsg(context, "飞聊Hook成功，当前flhook版本:" + PayHelperUtils.getVerName(context) + ";");
                        ReceiverFL receiverFL = new ReceiverFL();
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addAction(AppConst.ACTION_CREATEQRCODE_FL);
                        context.registerReceiver(receiverFL, intentFilter);
                        ClassLoader classLoader = context.getClassLoader();
                        new HookFL().hook(classLoader, context);
                    }
                }
            });
        }
        else if ("com.jmxchat.im".equals(packageName)) {
            try {
                XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        if ("com.jmxchat.im".equals(processName) && !Main.WL_HOOK) {
                            WL_HOOK = true;
                            XposedBridge.log("handleLoadPackage: " + packageName);
                            ReceiverWL receiverWL = new ReceiverWL();
                            IntentFilter intentFilter = new IntentFilter();
                            intentFilter.addAction(AppConst.ACTION_CREATEQRCODE_WL);
                            context.registerReceiver(receiverWL, intentFilter);
                            PayHelperUtils.sendmsg(context, "微聊Hook成功，当前微聊版本:" + PayHelperUtils.getVerName(context) + ";");
                            new HookWL().hook(appClassLoader, context);
                        }
                    }
                }});
            } catch (Throwable e222222) {
                XposedBridge.log(e222222);
            }
        }
        else if (AppConst.APP_YZF.equals(packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    if (AppConst.APP_YZF.equals(processName) && !YZF_HOOK) {
                        YZF_HOOK = true;
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        XposedBridge.log("handleLoadPackage: " + packageName);
                        PayHelperUtils.sendmsg(context, "益支付Hook成功，当前益支付版本:" + PayHelperUtils.getVerName(context) + ";");
                        //
                        ReceiverYZF receiverYZF = new ReceiverYZF();
                        IntentFilter filter = new IntentFilter();
                        filter.addAction(AppConst.ACTION_CREATEQRCODE_YZF);
                        context.registerReceiver(receiverYZF, filter);
                        new HookYZF().hook(appClassLoader, context);
                        //
                    }
                }
            });
        } else if ("com.example.gtcapp".equals(packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    if ("com.example.gtcapp".equals(processName) && !SKM_HOOK) {
                        SKM_HOOK = true;
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        XposedBridge.log("handleLoadPackage: " + packageName);
                        PayHelperUtils.sendmsg(context, "收款猫Hook成功，当前收款猫版本:" + PayHelperUtils.getVerName(context) + ";");
                        //
                        new HookSKM().hook(appClassLoader, context);
                        //
                    }
                }
            });
        }else if ("com.yqb.mm".equals(packageName)) {
            XposedHelpers.findAndHookMethod("s.h.e.l.l.S", lpparam.classLoader, "attachBaseContext", Context.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    super.beforeHookedMethod(param);
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    if (lpparam.processName.equals("com.yqb.mm") && !PA_HOOK) {
                        PA_HOOK = true;
                        Context context = (Context) param.args[0];
                        new HookPASHGJ().hook(lpparam.classLoader, context);
                    }
                }
            });
        } else if("com.yitong.zjrc.mfs.android".equals(packageName)){
            XposedHelpers.findAndHookMethod("com.secneo.apkwrapper.ApplicationWrapper", lpparam.classLoader, "attachBaseContext", Context.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    super.beforeHookedMethod(param);
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    if (lpparam.processName.equals("com.yitong.zjrc.mfs.android") && !PA_HOOK) {
                        PA_HOOK = true;
                        Context context = (Context) param.args[0];
                        new HookFSHL().hook(lpparam.classLoader, context);
                    }
                }
            });
        }else if (AppConst.APP_QNSHB.equals(packageName)) {
            XposedHelpers.findAndHookMethod("com.SecShell.SecShell.ApplicationWrapper",lpparam.classLoader, "attachBaseContext", Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    if (AppConst.APP_QNSHB.equals(processName) && !QNSHB_HOOK) {
                        QNSHB_HOOK = true;
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        XposedBridge.log("handleLoadPackage: " + packageName);
                        PayHelperUtils.sendmsg(context, "黔农商户宝Hook成功，当前黔农商户宝版本:" + PayHelperUtils.getVerName(context) + ";");
                        //
                        new HookQNSHB().hook(appClassLoader, context);
                        //
                    }
                }
            });
        }else if(AppConst.APP_WZP.equals(packageName)){
            XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Context context = (Context) param.args[0];
                    ClassLoader appClassLoader = context.getClassLoader();
                    if (AppConst.APP_WZP.equals(processName) && !Main.WZP_HOOK) {
                        WZP_HOOK = true;
                        XposedBridge.log("handleLoadPackage: " + packageName);
                        PayHelperUtils.sendmsg(context, "微掌铺Hook成功，当前微掌铺版本:" + PayHelperUtils.getVerName(context) + ";");
                        ReceiverWZP receiver = new ReceiverWZP();
                        context.registerReceiver(receiver,receiver.filter);
                        new HookWZP().hook(appClassLoader, context);
                    }
                }
            }});
        }else if(AppConst.APP_SB.equals(packageName)){
            XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Context context = (Context) param.args[0];
                    ClassLoader appClassLoader = context.getClassLoader();
                    if (AppConst.APP_SB.equals(processName) && !SB_HOOK) {
                        SB_HOOK = true;
                        XposedBridge.log("handleLoadPackage: " + packageName);
                        PayHelperUtils.sendmsg(context, "扫呗Hook成功，当前扫呗版本:" + PayHelperUtils.getVerName(context) + ";");
                        ReceiverSB receiver = new ReceiverSB();
                        context.registerReceiver(receiver,receiver.filter);
                        new HookSB().hook(appClassLoader, context);
                    }
                }
            }});
        }
        else {
            XposedBridge.log("-----调试--------:" + lpparam.packageName);
        }
    }

    class ReceiverWL extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConst.ACTION_CREATEQRCODE_WL)) {
                XposedBridge.log("微聊生成二维码》》》》》》》》》》》》");
                HookWL.CreateQR(intent);
            }
        }
    }

    class ReceiverFL extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConst.ACTION_CREATEQRCODE_FL)) {
                XposedBridge.log("飞聊生成二维码》》》》》》》》》》》》");
                HookFL.CreateQR(intent);
            }
        }
    }

    // 麻油
    private void queryPayResult(ArrayList<QrCodeBean> mlist, ClassLoader classLoader) {
        Iterator<QrCodeBean> iter = mlist.iterator();
        while (iter.hasNext()) {
//            queryPayResultById(classLoader, ((QrCodeBean) iter.next()).getPayurl());
        }// SG20190411111355529285017044
    }

//    private void queryPayResultById(final ClassLoader classLoader, final String pay_order_no) {
//        new Thread(new Runnable() {
//            public void run() {
//                Object Message = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.UserQueryPayResultReq.Builder", classLoader), new Object[0]), "pay_order_no", new Object[]{pay_order_no}), "build", new Object[0]);
//                Object ProtoBufPacket = XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.core.proto.ProtoBufPacket", classLoader), new Object[]{Integer.valueOf(1033), Message});
//                Class PacketSendCallback = XposedHelpers.findClass("com.aoetech.aoelailiao.entity.PacketSendCallback", classLoader);
//                Class MessageInfoManagerCls = XposedHelpers.findClass("com.aoetech.aoelailiao.core.local.manager.MessageInfoManager", classLoader);
//                QueryProxy myHandler = new QueryProxy();
//                Object obj = Proxy.newProxyInstance(classLoader, new Class[]{PacketSendCallback}, myHandler);
//                XposedHelpers.callMethod(XposedHelpers.callStaticMethod(MessageInfoManagerCls, "getInstant", new Object[0]), "a", new Object[]{ProtoBufPacket, obj});
//            }
//        }).start();
//    }

    private void createGroupBill(Context context, ClassLoader classLoader, Intent intent) {
        String orderInfo = intent.getStringExtra("mark");
        String money = intent.getStringExtra("money");
        int amount =  (int) (Float.parseFloat(money) * 100.0f);
        String receiveId = HookMayou.getGroupid();
        int userid = ((Integer) XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.aoetech.aoelailiao.cache.UserCache", classLoader), "getInstance", new Object[0]), "getLoginUserId", new Object[0])).intValue();
        Object AliEnvelopeInfo = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.AliEnvelopeInfo.Builder", classLoader), new Object[0]), "envelope_desc", new Object[]{orderInfo}), "envelope_owner_uid", new Object[]{Integer.valueOf(userid)}), "build", new Object[0]);
        Object aliEnvelopeDetailInfoBuilder = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.AliEnvelopeDetailInfo.Builder", classLoader), new Object[0]), "envelope_info", new Object[]{AliEnvelopeInfo}), "envelope_count", new Object[]{Integer.valueOf(1)}), "envelope_type", new Object[]{Integer.valueOf(1)}), "envelope_mode", new Object[]{Integer.valueOf(2)}), "envelope_total_amount", new Object[]{Integer.valueOf(amount)});
        Object GroupEnvelopeReceiverList = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.GroupEnvelopeReceiverList.Builder", classLoader), new Object[0]), "group_envelope_receivers", new Object[]{new ArrayList()}), "build", new Object[0]);
        Object aliEnvelopeDetailInfo = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callMethod(aliEnvelopeDetailInfoBuilder, "group_envelope_receiver_list", new Object[]{GroupEnvelopeReceiverList}), "envelope_receiver", new Object[]{Integer.valueOf(receiveId)}), "build", new Object[0]);
        Object Message = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.protobuf.UserGrantAliEnvelopeInfoReq.Builder", classLoader), new Object[0]), "ali_envelope_detail_info", new Object[]{aliEnvelopeDetailInfo}), "build", new Object[0]);
        Object ProtoBufPacket = XposedHelpers.newInstance(XposedHelpers.findClass("com.aoetech.aoelailiao.core.proto.ProtoBufPacket", classLoader), new Object[]{Integer.valueOf(3001), Message});
        Class PacketSendCallback = XposedHelpers.findClass("com.aoetech.aoelailiao.entity.PacketSendCallback", classLoader);
        Class MessageInfoManagerCls = XposedHelpers.findClass("com.aoetech.aoelailiao.core.local.manager.MessageInfoManager", classLoader);
        Class[] clsArr = new Class[]{PacketSendCallback};
        Object obj = Proxy.newProxyInstance(classLoader, clsArr, new CreatBilProxy(context, orderInfo, money, receiveId));
        XposedHelpers.callMethod(XposedHelpers.callStaticMethod(MessageInfoManagerCls, "getInstant", new Object[0]), "a", new Object[]{ProtoBufPacket, obj});
        XposedBridge.log("发起麻油订单成功");
    }
    class ReceiverXiaoXin extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConst.ACTION_CREATEQRCODE_XIAOXIN)) {
                HookXiaoxin.createQRCode(intent);
            }
        }
    }

    class ReceiverMaYou extends BroadcastReceiver {
        Context mContext;

        public ReceiverMaYou(Context context) {
            this.mContext = context;
        }

        public void onReceive(Context context, Intent intent) {
            try {
                ClassLoader classLoader = this.mContext.getClassLoader();
                if (intent.getAction().equals(AppConst.ACTION_CREATEQRCODE_MAYOU)) {
                    Main.this.createGroupBill(context, classLoader, intent);
                } else if (intent.getAction().equals(AppConst.ACTION_ORDERCOMPLETE_MAYOU)) {
                    String id = intent.getStringExtra("orderno");
//                    Main.this.queryPayResultById(classLoader,id);
//                    Main.this.queryPayResult((ArrayList) intent.getSerializableExtra("allQrCodes"), classLoader);
                } else if (intent.getAction().equals(AppConst.ACTION_ORDERCOMPLETE_GROUP_MAYOU)) {
//                    Main.this.queryPayResult((ArrayList) intent.getSerializableExtra("allQrCodes"), classLoader,context);
                }
            } catch (Exception e) {
                XposedBridge.log(e);
            }
        }
    }

    //
    private class ReceiverXXQG extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConst.ACTION_CREATEQRCODE_XXQG)) {
                XposedBridge.log("学习强国开始产码");
                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                HookXxqg.CreateTrade(money, mark);
            }
        }
    }

    private class ReceiverHYBSYT extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConst.ACTION_CREATEQRCODE_HYBSYT)) {
                HookHYBSYT.createQr(intent);
            }
        }
    }

    private class ReceiverYZF extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConst.ACTION_CREATEQRCODE_YZF)) {
                HookYZF.CreateQR(intent);
            }
        }
    }

    // 收款宝
    private class ReceiverSKB extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            XposedBridge.log("context >>>>>>>>>>>>>>> " + context + "intent.getAction() >>> " + intent.getAction());
            if (intent.getAction().equals(AppConst.ACTION_CREATEQRCODE_SKB)) {
                String paytype = intent.getStringExtra("type");
                int type = paytype.equals("SKB_ALIPAY") ? 0 : 1;
                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                String address = intent.getStringExtra("address");
                ToolsSKB.CreateQRCode(address, money, type, mark);
            } else if (intent.getAction().equals(AppConst.ACTION_TRADEQUERY_SKB)) {
                XposedBridge.log("收款宝查询订单");
                Hook51SKB.GetBillRecord();
            } else if (intent.getAction().equals(AppConst.ACTION_ACTIVITYSTART_SKB)) {
                if (!ToolsSKB.isactivitystart) {
                    ToolsSKB.isactivitystart = true;
                    ToolsSKB.QueryTrade(context);
                }
            }
        }
    }


    private class ReceiverWX extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConst.TBH_ACTION)) {
                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                ToolsTaobao.SendHongbao(money, mark);
            }
        }
    }

    private class ReceiverXGJ extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(com.zhiyi.xppay.hook.xgj.AppConst.ACTION_ACTIVITYSTART)) {
                if (!ToolsXGJ.isactivitystart) {
                    ToolsXGJ.isactivitystart = true;
                    ToolsXGJ.tradequery(context);
                }
            } else if (intent.getAction().equals(com.zhiyi.xppay.hook.xgj.AppConst.ACTION_TRADEQUERY)) {
                XposedBridge.log("星管家开始轮询账单");
                HookXgj.getTradeQuery();
            }
        }
    }

    // 银盛通
    private class ReceiverYST extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            XposedBridge.log("context >>>>>>>>>>>>>>> " + context + "intent.getAction() >>> " + intent.getAction());
            if (intent.getAction().equals(Appconsts.ACTION_CREATEQRCODE)) {
                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                ToolsYST.CreateQRCode(context, money, mark);
            } else if (intent.getAction().equals(Appconsts.ACTION_TRADEQUERY)) {
                XposedBridge.log("银盛通查询订单");
                Hookyst.TradeQuery();
            } else if (intent.getAction().equals(Appconsts.ACTION_ACTIVITYSTART)) {
                XposedBridge.log("ToolsYST.isactivitystart >>>>>>> " + ToolsYST.isactivitystart);
                if (!ToolsYST.isactivitystart) {
                    ToolsYST.isactivitystart = true;
                    ToolsYST.tradequery(context);
                }
            }
        }
    }

    //
    private class ReceiverNxys extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConstsNxys.ACTION_CREATEQRCODE)) {
                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                String type = intent.getStringExtra("type");
                ToolsNxys.CreateQRCode(money, mark, type);
            } else if (intent.getAction().equals(AppConstsNxys.ACTION_TRADEQUERY)) {
                HookNxys.getalltrade();
            } else if (intent.getAction().equals(AppConstsNxys.ACTION_ACTIVITYSTART)) {
                if (!ToolsNxys.isactivitystart) {
                    ToolsNxys.isactivitystart = true;
                    ToolsNxys.tradequery(context);
                }
            }
        }
    }

    private class ReceiverNxysHB extends BroadcastReceiver {
        String packagename = "";

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConstsNxys.ACTION_CREATEQRCODE)) {
                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                String type = intent.getStringExtra("type");
                HookNXYS_HB.CreateQR(money, mark, type);
            } else if (intent.getAction().equals(AppConstsNxys.ACTION_TRADEQUERY)) {
                HookNXYS_HB.getalltrade();
            } else if (intent.getAction().equals(AppConstsNxys.ACTION_ACTIVITYSTART)) {
                if (!HookNXYS_HB.isactivitystart) {
                    HookNXYS_HB.isactivitystart = true;
                    if (HookNXYS_HB.isactivitystart && HookNXYS_HB.ishookeed) {
                        if (!TextUtils.isEmpty(HookNXYS_HB.loginid)) {
                            PayHelperUtils.sendmsg(context, "农信易扫开启账单轮询");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("appname", packagename);
                            broadCastIntent.setAction(AppConstsNxys.ACTION_STARTTRADEQUERY);
                            context.sendBroadcast(broadCastIntent);
                        } else {
                            PayHelperUtils.sendmsg(context, "未获取到农信易扫账号");
                        }
                    }
                }
            }
        }
    }

    private class ReceiverJYES extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConstsNxys.ACTION_CREATEQRCODE)) {
                PayHelperUtils.LogMsg("金燕E商生成二维码");
                HookJYES.createQRCode(intent);
            } else if (intent.getAction().equals(AppConstsNxys.ACTION_TRADEQUERY)) {
                HookJYES.queryTrade();
            } else if (intent.getAction().equals(AppConstsNxys.ACTION_ACTIVITYSTART)) {
                if (!HookJYES.isactivitystart) {
                    HookJYES.isactivitystart = true;
                    if (HookJYES.isactivitystart && HookJYES.ishookeed) {
                        if (TextUtils.isEmpty(HookJYES.loginid)) {
                            HookJYES.sendLoginID();
                        }
                        PayHelperUtils.sendmsg(context, "河南农信金燕E商开启账单轮询");
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("appname", AppConst.APP_JYES);
                        broadCastIntent.setAction(AppConstsNxys.ACTION_STARTTRADEQUERY);
                        context.sendBroadcast(broadCastIntent);
                    }
                }
            }
        }
    }

    private class ReceiverNxysHJSH extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConstsNxys.ACTION_CREATEQRCODE)) {
                HookNXFJSH.CreateQR(intent);
            } else if (intent.getAction().equals(AppConstsNxys.ACTION_TRADEQUERY)) {
                HookNXFJSH.getalltrade();
            } else if (intent.getAction().equals(AppConstsNxys.ACTION_ACTIVITYSTART)) {
                if (!HookNXFJSH.isactivitystart) {
                    HookNXFJSH.isactivitystart = true;
                    if (HookNXFJSH.isactivitystart && HookNXFJSH.ishookeed) {
                        if (TextUtils.isEmpty(HookNXFJSH.loginid)) {
                            HookNXFJSH.sendLoginID();
                        }
                        PayHelperUtils.sendmsg(context, "福建农信商户开启账单轮询");
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("appname", AppConst.APP_NXFJSH);
                        broadCastIntent.setAction(AppConstsNxys.ACTION_STARTTRADEQUERY);
                        context.sendBroadcast(broadCastIntent);
                    }
                }
            }
        }
    }

    //自定义启动微信广播
    class StartWechatReceived extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            XposedBridge.log("启动微信Activity");
            try {
                Intent intent2 = new Intent(context, XposedHelpers.findClass("com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI", context.getClassLoader()));
                intent2.putExtra("mark", intent.getStringExtra("mark"));
                intent2.putExtra("money", intent.getStringExtra("money"));
                intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent2);
                XposedBridge.log("启动微信成功");
            } catch (Exception e) {
                XposedBridge.log("启动微信失败：" + e.getMessage());
            }
        }
    }

    public class LKLPayReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConst.LKL_QRCODE)) {
                XposedBridge.log("启动LakalaActivity");
                try {
                    String money = intent.getStringExtra("money");
                    String mark = intent.getStringExtra("mark");
                    LakalaHook.CreateQRCode(money, mark);
                } catch (Exception e) {
                    PayHelperUtils.sendmsg(context, "StartLAkalaReceived 异常" + e.getMessage());
                }
            } else if (intent.getAction().equals(AppConst.LKL_TRADELIST)) {
                try {
                    String data = intent.getStringExtra("data");
                    JSONArray list = new JSONArray(data);
                    int length = list.length() >= 5 ? 5 : list.length();
                    for (int i = length - 1; i > 0; --i) {
                        JSONObject json = list.getJSONObject(i);
                        String tradeNo = json.getString("tradeNo");
                        String money = json.getString("tradeAmount");
                        String mark = json.getString("logNo");
                        String tradeType = json.getString("tradeTypeName");
                        String tradeTime = json.getString("tradeTime");
                        tradeTime = PayHelperUtils.dateToStamp(tradeTime, "yyyyMMddhhmmss");
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("bill_no", tradeNo);
                        broadCastIntent.putExtra("bill_money", money);
                        broadCastIntent.putExtra("bill_mark", mark);
                        broadCastIntent.putExtra("bill_dt", tradeTime);
                        broadCastIntent.putExtra("bill_type", AppConst.TYPE_LKLPAY);
                        broadCastIntent.setAction(AppConst.BILLRECEIVED_ACTION);
                        context.sendBroadcast(broadCastIntent);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public class CloundPayReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(AppConst.CP_QRCODE)) {
                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                String type = intent.getStringExtra("type");
                if (money == null) {
                    money = "0.01";
                }
                if (mark == null) {
                    mark = "测试";
                }
                final Activity activity = (Activity) context;
                CloudPayHook.BuildQRcode(activity, money, mark, type);
            } else if (intent.getAction().equals(AppConst.CP_GETPAYER)) {
                String orderid = intent.getStringExtra("orderid");
//                CloudPayHook.startGetPayer(orderid);
            } else if (intent.getAction().equals(AppConst.CP_LOGIN)) {
                CloudPayHook.Login();
            }
        }
    }

    class StartAlipayAutowithdraw extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            //
            Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.withdraw.ui.WithdrawActivity_", context.getClassLoader()));
            intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent2.putExtra("passward", intent.getStringExtra("passward"));
            context.startActivity(intent2);
        }
    }

    class StartAlipayToBanlance extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            String data = bundle.getString("alipayinfo");
            AlipayInfo info = JsonHelper.fromJson(data, AlipayInfo.class);
            XposedBridge.log("StartAlipayToBanlance onReceive == " + data);
            String value = info.alipaypwd;
            String value1 = info.withdrawcount;
            //
            Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("alipays://platformapi/startapp?appId=20000067&showTitleBar=YES&showToolBar=NO&url=alipays://platformapi/startapp?appId=20000019"));
            context.startActivity(intent2);
            //
            Intent intent1 = new Intent(context, XposedHelpers.findClass("com.alipay.android.app.birdnest.ui.BNTplActivity", context.getClassLoader()));
            intent1.putExtras(bundle);
            context.startActivity(intent1);
            XposedBridge.log("intent1 密码 == " + value + "intent1 金额 == " + value1);
            //
        }
    }

    class StarAlipayAutoTransfertoBank extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.transferapp.ui.TransferToCardFormActivity_", context.getClassLoader()));
            intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent2.putExtra("account", intent.getStringExtra("account"));
            intent2.putExtra("cardno", intent.getStringExtra("cardno"));
            intent2.putExtra("money", intent.getStringExtra("money"));
            intent2.putExtra("passward", intent.getStringExtra("passward"));
            context.startActivity(intent2);
        }
    }

    class StarAlipayAutoTransfertoAliAccount extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.transferapp.ui.TFToAccountInputActivity_", context.getClassLoader()));
            intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent2.putExtra("aliaccount", intent.getStringExtra("aliaccount"));
            intent2.putExtra("money", intent.getStringExtra("money"));
            intent2.putExtra("passward", intent.getStringExtra("passward"));
            context.startActivity(intent2);
        }
    }

    //自定义启动支付宝广播
    class StartAlipayReceived extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            XposedBridge.log("收到通知:::" + intent.getAction());
            if (intent.getAction().equals(AppConst.ALIPAYMBANK_ACTION)) {
//                PayHelperUtils.getBankDetailInfo(AlipayMBhook.mMainClassLoader, AlipayMBhook.context);
            } else if (intent.getAction().equals(AppConst.ALIPAYSTART_ACTION)) {
                XposedBridge.log("启动支付宝Activity");
                Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", context.getClassLoader()));
                intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent2.putExtra("mark", intent.getStringExtra("mark"));
                intent2.putExtra("money", intent.getStringExtra("money"));
                context.startActivity(intent2);
            } else if (intent.getAction().equals(AppConst.ALIPAY_FRIEND_ORDER_ACTION)) {
                String payuid = intent.getStringExtra("pay_uid");
                String money = intent.getStringExtra("money");
                String remark = intent.getStringExtra("remark");
                String localorderid = intent.getStringExtra("orderid");
                PayHelperUtils.SendBillMsg(payuid, money, remark, localorderid, context);
            } else if (intent.getAction().equals(AppConst.ALIPAY_FRIEND_CHECK_ACTION)) {
                String payuid = intent.getStringExtra("payuid");
                String localorderid = intent.getStringExtra("localorderid");
                Object o = Tools.compareFriend(payuid,context.getClassLoader());
                boolean isfriend = o != null && true == (boolean) XposedHelpers.callMethod(o, "isMyFriend");
                intent = new Intent();
                intent.setAction(AppConst.HOOK_FRIEND_CHECK_ACTION);
                intent.putExtra("orderid", localorderid);
                intent.putExtra("isfriend", isfriend);
                context.sendBroadcast(intent);
            } else if (intent.getAction().equals(AppConst.ALIPAYPERSONALQRCODE_ACTION)) {
                Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.payee.ui.PayeeQRActivity", context.getClassLoader()));
                intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent2);
            } else if (intent.getAction().equals(AppConst.TRADEDETAIL_ACTION)) {
                String tradeno = intent.getStringExtra("tradeno");
                AlipayHook38.getDetailTrade(tradeno, context, "TRADE");
            } else if (intent.getAction().equals(AppConst.ALIPAY_FIXED_POSITION)) {
                String latitude = intent.getStringExtra("latitude");
                String longitude = intent.getStringExtra("longitude");
                AlipayHook38.setFixedPosition(latitude, longitude);
            }
        }
    }

    //自定义启动QQ广播
    class StartQQReceived extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            XposedBridge.log("启动QQActivity");
            try {
//    			PayHelperUtils.sendmsg(context, "启动QQActivity"+l);

                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                if (!TextUtils.isEmpty(money) && !TextUtils.isEmpty(mark)) {
                    QQDBManager qqdbManager = new QQDBManager(context);
                    qqdbManager.addQQMark(intent.getStringExtra("money"), intent.getStringExtra("mark"));
                    long l = System.currentTimeMillis();
                    String url = "mqqapi://wallet/open?src_type=web&viewtype=0&version=1&view=7&entry=1&seq=" + l;
                    Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent2);
                }

//    			PayHelperUtils.sendmsg(context, "启动成功"+l);
            } catch (Exception e) {
                PayHelperUtils.sendmsg(context, "StartQQReceived异常" + e.getMessage());
            }
        }
    }
}
