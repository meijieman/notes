package com.zhiyi.xppay.net.Socket.SendMsg;

import android.content.Intent;

import com.zhiyi.xppay.net.Socket.TransConst;


public class FriendOrder extends TransMessage{
    public FriendOrder(Intent intent) {
        super(TransConst.NewFriendBill);
        orderid = intent.getStringExtra("orderid");
        no = intent.getStringExtra("no");
    }

    public String orderid;
    public String no;
}
